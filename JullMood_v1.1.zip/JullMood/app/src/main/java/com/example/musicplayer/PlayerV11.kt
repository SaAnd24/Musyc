package com.example.musicplayer

import android.content.res.Configuration
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Curva "emphasized decelerate": entra rápido y se asienta suave. Se usa en casi todo el movimiento de v1.1. */
internal val JmEase = CubicBezierEasing(0.2f, 0f, 0f, 1f)

// ---------- Utilidades de movimiento (baratas: solo escalas/alphas en la capa gráfica) ----------

/** Pulsación con rebote ligero. No usa ripple ni recomposición: la escala se aplica en la capa gráfica. */
internal fun Modifier.jmPress(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val reduced = LocalUi.current.reducedMotion
    val s by animateFloatAsState(
        if (pressed && !reduced) 0.9f else 1f,
        spring(dampingRatio = 0.55f, stiffness = 520f), label = "jmPress"
    )
    this
        .graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, enabled = enabled, role = Role.Button, onClick = onClick)
}

/** Entrada escalonada: desde transparente y ligeramente abajo hasta su sitio. */
private fun Modifier.staged(p: Animatable<Float, AnimationVector1D>, dy: Float = 28f): Modifier = graphicsLayer {
    val v = p.value
    alpha = v
    translationY = (1f - v) * dy.dp.toPx()
}

/** Icono Play/Pausa: los dos símbolos se cruzan con escala + fundido. */
@Composable
internal fun PlayPauseGlyph(playing: Boolean, size: Dp, tint: Color) {
    val reduced = LocalUi.current.reducedMotion
    AnimatedContent(
        targetState = playing, label = "playPause",
        transitionSpec = {
            if (reduced) EnterTransition.None togetherWith ExitTransition.None
            else (fadeIn(tween(150, 50)) + scaleIn(tween(200, easing = JmEase), initialScale = 0.5f)) togetherWith
                (fadeOut(tween(90)) + scaleOut(tween(120), targetScale = 0.5f))
        }
    ) { p ->
        Icon(
            painterResource(if (p) R.drawable.ic_pause else R.drawable.ic_play),
            if (p) "Pausa" else "Reproducir", Modifier.size(size), tint = tint
        )
    }
}

/** Botón de favoritos con microanimación: rebote al añadir, pequeño "pulso" al quitar. */
@Composable
internal fun HeartButton(fav: Boolean, accent: Color, size: Dp = 28.dp, onClick: () -> Unit) {
    val reduced = LocalUi.current.reducedMotion
    val haptic = LocalHapticFeedback.current
    val scale = remember { Animatable(1f) }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(fav) {
        if (first) { first = false; return@LaunchedEffect }
        if (reduced) return@LaunchedEffect
        if (fav) {
            scale.snapTo(0.6f)
            scale.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = 380f))
        } else {
            scale.animateTo(0.8f, tween(80))
            scale.animateTo(1f, tween(140))
        }
    }
    val off = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
    val tint by animateColorAsState(if (fav) accent else off, tween(200), label = "heartTint")
    IconButton(onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onClick() }) {
        Icon(
            painterResource(if (fav) R.drawable.ic_heart else R.drawable.ic_heart_outline),
            if (fav) "Quitar de favoritos" else "Añadir a favoritos",
            Modifier.size(size).graphicsLayer { scaleX = scale.value; scaleY = scale.value },
            tint = tint
        )
    }
}

// ---------- Barra de progreso ----------

/**
 * Barra de progreso propia: avanza fotograma a fotograma leyendo la posición real del reproductor y SOLO se
 * redibuja (no recompone). Al arrastrar, la pista y el pulgar crecen y los tiempos siguen al dedo.
 */
@Composable
internal fun SeekBarV11(vm: PlayerViewModel, accent: Color) {
    val reduced = LocalUi.current.reducedMotion
    val haptic = LocalHapticFeedback.current
    var drag by remember { mutableStateOf<Float?>(null) }
    val frac = remember { mutableFloatStateOf(0f) }
    var widthPx by remember { mutableIntStateOf(1) }

    LaunchedEffect(vm.isPlaying, reduced) {
        while (true) {
            if (drag == null) {
                val d = vm.duration
                frac.floatValue = if (d > 0) (vm.livePosition().toFloat() / d).coerceIn(0f, 1f) else 0f
            }
            if (vm.isPlaying && !reduced) withFrameNanos { } else delay(250)
        }
    }

    val active = drag != null
    val trackH by animateDpAsState(if (active) 10.dp else 5.dp, tween(150), label = "trackH")
    val thumbR by animateFloatAsState(if (active) 11f else 6.5f, spring(dampingRatio = 0.6f, stiffness = 500f), label = "thumbR")

    Box(
        Modifier.fillMaxWidth().height(36.dp)
            .onSizeChanged { widthPx = it.width.coerceAtLeast(1) }
            .pointerInput(vm.duration) {
                detectTapGestures { o ->
                    val d = vm.duration
                    if (d > 0) {
                        val f = (o.x / widthPx).coerceIn(0f, 1f)
                        frac.floatValue = f
                        vm.seekTo((f * d).toLong())
                    }
                }
            }
            .pointerInput(vm.duration) {
                detectHorizontalDragGestures(
                    onDragStart = { o ->
                        drag = (o.x / widthPx).coerceIn(0f, 1f)
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    },
                    onDragEnd = {
                        drag?.let { f -> frac.floatValue = f; vm.seekTo((f * vm.duration).toLong()) }
                        drag = null
                    },
                    onDragCancel = { drag = null },
                    onHorizontalDrag = { change, amount ->
                        change.consume()
                        drag = ((drag ?: frac.floatValue) + amount / widthPx).coerceIn(0f, 1f)
                    }
                )
            }
            .drawBehind {
                val f = drag ?: frac.floatValue
                val th = trackH.toPx()
                val cy = size.height / 2f
                val r = CornerRadius(th / 2f)
                drawRoundRect(accent.copy(alpha = 0.22f), Offset(0f, cy - th / 2f), Size(size.width, th), r)
                val w = (size.width * f).coerceAtLeast(th)
                drawRoundRect(accent, Offset(0f, cy - th / 2f), Size(w, th), r)
                val tr = thumbR.dp.toPx()
                drawCircle(accent, tr, Offset((size.width * f).coerceIn(tr, size.width - tr), cy))
            }
    )

    val secs by remember { derivedStateOf { (((drag ?: frac.floatValue) * vm.duration) / 1000f).toLong() } }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(formatTime(secs * 1000), color = if (active) accent else Gray, fontSize = 12.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal)
        Text(formatTime(vm.duration), color = Gray, fontSize = 12.sp)
    }
}

// ---------- Controles ----------

/** Shuffle / repetir: activo = fondo de acento + punto indicador; apagado = gris. El estado se ve sin leer el icono. */
@Composable
private fun ToggleChip(res: Int, desc: String, active: Boolean, accent: Color, onClick: () -> Unit) {
    val off = Gray
    val bg by animateColorAsState(if (active) accent.copy(alpha = 0.2f) else Color.Transparent, tween(200), label = "chipBg")
    val tint by animateColorAsState(if (active) accent else off, tween(200), label = "chipTint")
    val dot by animateFloatAsState(if (active) 1f else 0f, tween(200), label = "chipDot")
    Box(Modifier.size(48.dp).clip(CircleShape).background(bg).jmPress(onClick = onClick), Alignment.Center) {
        Icon(painterResource(res), desc, Modifier.size(24.dp), tint = tint)
        Box(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp).size(4.dp)
                .graphicsLayer { alpha = dot; scaleX = dot; scaleY = dot }.clip(CircleShape).background(accent)
        )
    }
}

@Composable
private fun ControlsV11(vm: PlayerViewModel, accent: Color) {
    val haptic = LocalHapticFeedback.current
    val onAccent = MaterialTheme.colorScheme.onPrimary
    val onBg = MaterialTheme.colorScheme.onBackground
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        ToggleChip(R.drawable.ic_shuffle, if (vm.shuffle) "Aleatorio activado" else "Aleatorio desactivado", vm.shuffle, accent) { vm.toggleShuffle() }
        Box(Modifier.size(56.dp).jmPress { vm.previous() }, Alignment.Center) {
            Icon(painterResource(R.drawable.ic_prev), "Anterior", Modifier.size(38.dp), tint = onBg)
        }
        Box(
            Modifier.size(78.dp).clip(CircleShape).background(accent)
                .jmPress { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); vm.togglePlay() },
            Alignment.Center
        ) {
            PlayPauseGlyph(vm.isPlaying, 42.dp, onAccent)
            if (vm.buffering) CircularProgressIndicator(Modifier.fillMaxSize().padding(4.dp), color = onAccent.copy(alpha = 0.6f), strokeWidth = 2.dp)
        }
        Box(Modifier.size(56.dp).jmPress { vm.next() }, Alignment.Center) {
            Icon(painterResource(R.drawable.ic_next), "Siguiente", Modifier.size(38.dp), tint = onBg)
        }
        val rep = vm.repeatMode
        ToggleChip(
            if (rep == Player.REPEAT_MODE_ONE) R.drawable.ic_repeat_one else R.drawable.ic_repeat,
            when (rep) { Player.REPEAT_MODE_ONE -> "Repetir canción"; Player.REPEAT_MODE_ALL -> "Repetir cola"; else -> "Repetir desactivado" },
            rep != Player.REPEAT_MODE_OFF, accent
        ) { vm.cycleRepeat() }
    }
}

// ---------- Estados del reproductor ----------

/** Carga, error, archivo eliminado y fin de cola: una tarjeta integrada, no un mensaje suelto. */
@Composable
private fun StateBanner(vm: PlayerViewModel, accent: Color) {
    val kind = when {
        vm.playbackIssue == 1 -> 1
        vm.playbackIssue == 2 -> 2
        vm.ended -> 3
        else -> 0
    }
    val shown = remember { intArrayOf(0) }
    if (kind != 0) shown[0] = kind
    val cs = MaterialTheme.colorScheme
    AnimatedVisibility(
        visible = kind != 0,
        enter = fadeIn(tween(200)) + expandVertically(tween(260, easing = JmEase)),
        exit = fadeOut(tween(120)) + shrinkVertically(tween(200))
    ) {
        val k = shown[0]
        val tone = if (k == 3) accent else cs.error
        Row(
            Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(uiShape(16.dp)).background(tone.copy(alpha = 0.14f)).padding(start = 14.dp, end = 4.dp, top = 2.dp, bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(painterResource(if (k == 3) R.drawable.ic_check else R.drawable.ic_info), null, Modifier.size(20.dp), tint = tone)
            Column(Modifier.weight(1f).padding(start = 10.dp, top = 8.dp, bottom = 8.dp)) {
                Text(
                    when (k) { 1 -> "Este archivo ya no está en tu dispositivo"; 2 -> "No se pudo reproducir esta canción"; else -> "Has llegado al final de la cola" },
                    fontSize = 14.sp, fontWeight = FontWeight.SemiBold
                )
                Text(
                    when (k) { 1 -> "Puede que se haya movido o eliminado."; 2 -> "El archivo puede estar dañado."; else -> "Pulsa repetir para volver a empezar." },
                    fontSize = 12.sp, color = Gray
                )
            }
            if (k == 2) TextButton(onClick = { vm.togglePlay() }) { Text("Reintentar", color = tone) }
            if (k != 3) TextButton(onClick = { vm.next() }) { Text("Siguiente", color = tone) }
            else TextButton(onClick = { vm.togglePlay() }) { Text("Repetir", color = tone) }
        }
    }
}

/** Texto pequeño de la cabecera: refleja el estado real (reproduciendo, pausa, cargando, error, fin). */
@Composable
private fun statusText(vm: PlayerViewModel): String = when {
    vm.playbackIssue != 0 -> "No se pudo reproducir"
    vm.ended -> "Fin de la cola"
    vm.buffering -> "Cargando…"
    vm.isPlaying -> "Reproduciendo"
    else -> "En pausa"
}

// ---------- Reproductor completo ----------

@Composable
internal fun NowPlayingV11(
    vm: PlayerViewModel, song: Song, onClose: () -> Unit, onQueue: () -> Unit, onSleep: () -> Unit, onAdd: (Song) -> Unit
) {
    val accent = MaterialTheme.colorScheme.primary
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val reduced = LocalUi.current.reducedMotion
    val pager = rememberPagerState(pageCount = { 2 })
    val scope = rememberCoroutineScope()
    val goTo: (Int) -> Unit = { p -> scope.launch { if (reduced) pager.scrollToPage(p) else pager.animateScrollToPage(p) } }
    BackHandler { if (pager.currentPage == 1) goTo(0) else onClose() }

    // Entrada coordinada (portada → información → controles): sustituye al "salto" de pantalla.
    val coverIn = remember { Animatable(if (reduced) 1f else 0f) }
    val infoIn = remember { Animatable(if (reduced) 1f else 0f) }
    val ctrlIn = remember { Animatable(if (reduced) 1f else 0f) }
    LaunchedEffect(Unit) {
        if (!reduced) {
            launch { coverIn.animateTo(1f, tween(380, easing = JmEase)) }
            launch { infoIn.animateTo(1f, tween(360, delayMillis = 70, easing = JmEase)) }
            launch { ctrlIn.animateTo(1f, tween(360, delayMillis = 130, easing = JmEase)) }
        }
    }

    Box(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.32f), Color.Transparent)))
    ) {
        VerticalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            if (page == 1) LyricsPage(vm, song, accent) { goTo(0) }
            else Column(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 8.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconBtn(R.drawable.ic_down, "Cerrar", onClick = onClose)
                    Crossfade(targetState = statusText(vm), label = "status", animationSpec = tween(180), modifier = Modifier.weight(1f)) { t ->
                        Text(t, color = Gray, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }
                    IconBtn(R.drawable.ic_queue, "Añadir a lista", Gray) { onAdd(song) }
                }
                if (landscape) {
                    Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(24.dp), verticalAlignment = Alignment.CenterVertically) {
                        BoxWithConstraints(Modifier.weight(1f).fillMaxHeight().padding(vertical = 8.dp), Alignment.Center) {
                            BigCover(vm, song, Modifier.size(minOf(maxWidth, maxHeight)), coverIn)
                        }
                        Column(Modifier.weight(1.2f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.Center) {
                            Column(Modifier.staged(infoIn)) { InfoV11(vm, song, accent); StateBanner(vm, accent) }
                            Column(Modifier.staged(ctrlIn)) {
                                SeekBarV11(vm, accent)
                                ControlsV11(vm, accent)
                                NpExtras(accent, onSleep, onQueue, { goTo(1) }, vm.lyrics)
                            }
                        }
                    }
                } else {
                    BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().padding(vertical = 10.dp), Alignment.Center) {
                        BigCover(vm, song, Modifier.size(minOf(maxWidth, maxHeight)), coverIn)
                    }
                    Column(Modifier.staged(infoIn)) {
                        StateBanner(vm, accent)
                        InfoV11(vm, song, accent)
                    }
                    Column(Modifier.staged(ctrlIn)) {
                        SeekBarV11(vm, accent)
                        ControlsV11(vm, accent)
                        NpExtras(accent, onSleep, onQueue, { goTo(1) }, vm.lyrics)
                    }
                }
            }
        }
    }
}

/** Dirección del cambio de canción (1 = siguiente, -1 = anterior) para que la portada entre por el lado correcto. */
@Composable
private fun rememberDirection(vm: PlayerViewModel): Int {
    val idx = vm.currentIndex
    val prev = remember { intArrayOf(idx) }
    val dir = if (idx >= prev[0]) 1 else -1
    SideEffect { prev[0] = idx }
    return dir
}

/** Portada protagonista: grande, esquinas amplias, "respira" (escala) con play/pausa y se desliza al cambiar de canción. */
@Composable
private fun BigCover(vm: PlayerViewModel, song: Song, modifier: Modifier, appear: Animatable<Float, AnimationVector1D>) {
    val reduced = LocalUi.current.reducedMotion
    val playScale by animateFloatAsState(
        if (vm.isPlaying || reduced) 1f else 0.92f, spring(dampingRatio = 0.75f, stiffness = 260f), label = "coverBreath"
    )
    val dir = rememberDirection(vm)
    Box(
        modifier.graphicsLayer {
            val a = appear.value
            val s = playScale * (0.78f + 0.22f * a)
            scaleX = s; scaleY = s; alpha = a
        }
    ) {
        AnimatedContent(
            targetState = song, contentKey = { it.id }, label = "cover", modifier = Modifier.fillMaxSize(),
            transitionSpec = {
                if (reduced) EnterTransition.None togetherWith ExitTransition.None
                else (fadeIn(tween(260, 40)) + slideInHorizontally(tween(320, easing = JmEase)) { dir * it / 8 } + scaleIn(tween(320, easing = JmEase), initialScale = 0.94f)) togetherWith
                    (fadeOut(tween(160)) + scaleOut(tween(220), targetScale = 0.94f))
            }
        ) { s -> Cover(s, Modifier.fillMaxSize(), px = 700, radius = 28.dp) }
    }
}

/** Jerarquía: título (grande) → artista (medio) → álbum (discreto). Cambian con fundido + desplazamiento corto. */
@Composable
private fun InfoV11(vm: PlayerViewModel, song: Song, accent: Color) {
    val reduced = LocalUi.current.reducedMotion
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        AnimatedContent(
            targetState = song, contentKey = { it.id }, label = "info", modifier = Modifier.weight(1f),
            transitionSpec = {
                if (reduced) EnterTransition.None togetherWith ExitTransition.None
                else (fadeIn(tween(240, 60)) + slideInVertically(tween(280, easing = JmEase)) { it / 5 }) togetherWith fadeOut(tween(120))
            }
        ) { s ->
            Column(Modifier.fillMaxWidth()) {
                Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.85f))
                Text(s.album, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Gray, fontSize = 13.sp)
            }
        }
        HeartButton(song.id in vm.favorites, accent) { vm.toggleFavorite(song.id) }
    }
}

// ---------- Mini-reproductor ----------

@Composable
internal fun MiniBarV11(vm: PlayerViewModel, song: Song, onOpen: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val primary = cs.primary
    val reduced = LocalUi.current.reducedMotion
    val frac = if (vm.duration > 0) (vm.position.toFloat() / vm.duration).coerceIn(0f, 1f) else 0f
    // El progreso llega cada 500 ms; esta interpolación lineal lo convierte en movimiento continuo sin coste extra.
    val smooth by animateFloatAsState(frac, if (reduced) tween(0) else tween(520, easing = LinearEasing), label = "miniProgress")
    var acc by remember { mutableFloatStateOf(0f) }
    val issue = vm.playbackIssue != 0

    Box(Modifier.fillMaxWidth().background(cs.surface).padding(horizontal = 8.dp, vertical = 6.dp)) {
        Column(
            Modifier.fillMaxWidth().clip(uiShape(22.dp)).background(cs.surfaceVariant)
                .pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onDragStart = { acc = 0f },
                        onDragEnd = { if (acc < -40f) onOpen() },
                        onVerticalDrag = { _, dy -> acc += dy }
                    )
                }
                .clickable(onClickLabel = "Abrir reproductor", onClick = onOpen)
        ) {
            Row(Modifier.padding(start = 8.dp, top = 8.dp, bottom = 6.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                AnimatedContent(
                    targetState = song, contentKey = { it.id }, label = "miniCover",
                    transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(160)) }
                ) { s -> Cover(s, Modifier.size(48.dp), radius = 12.dp) }
                AnimatedContent(
                    targetState = song, contentKey = { it.id }, label = "miniInfo", modifier = Modifier.weight(1f).padding(start = 12.dp),
                    transitionSpec = {
                        if (reduced) EnterTransition.None togetherWith ExitTransition.None
                        else (fadeIn(tween(200, 40)) + slideInVertically(tween(240, easing = JmEase)) { it / 3 }) togetherWith fadeOut(tween(100))
                    }
                ) { s ->
                    Column(Modifier.fillMaxWidth()) {
                        Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        Text(
                            if (issue) "No se pudo reproducir" else if (vm.buffering) "Cargando…" else s.artist,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp,
                            color = if (issue) cs.error else Gray
                        )
                    }
                }
                Box(Modifier.size(42.dp).clip(CircleShape).background(primary).jmPress { vm.togglePlay() }, Alignment.Center) {
                    PlayPauseGlyph(vm.isPlaying, 24.dp, cs.onPrimary)
                }
                Box(Modifier.size(44.dp).jmPress { vm.next() }, Alignment.Center) {
                    Icon(painterResource(R.drawable.ic_next), "Siguiente", Modifier.size(26.dp), tint = cs.onSurfaceVariant)
                }
            }
            Box(
                Modifier.fillMaxWidth().height(3.dp).drawBehind {
                    drawRect(primary.copy(alpha = 0.22f))
                    drawRect(primary, size = Size(size.width * smooth, size.height))
                }
            )
        }
    }
}
