@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.example.musicplayer

import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Collections
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Texto secundario: sigue al tema activo. */
internal val Gray: Color
    @Composable get() = MaterialTheme.colorScheme.onSurfaceVariant

internal data class Detail(val kind: Int, val name: String) // 0 álbum, 1 artista, 2 lista, 3 mood, 4 estadísticas, 5 identidad musical semanal, 6 Easter Eggs de Juli, 7 identidad musical, 8 logros, 9 descubrir, 10 colecciones, 12 lista de colección, 13 progreso de álbumes, 14 exploración de artistas

/** Para que la pantalla abierta (álbum, lista, estadísticas…) sobreviva a rotaciones y cambios de configuración. */
private val DetailSaver: Saver<Detail?, Any> = listSaver<Detail?, Any>(
    save = { d -> listOf(d?.kind ?: -1, d?.name.orEmpty()) },
    restore = { l -> (l[0] as Int).let { k -> if (k < 0) null else Detail(k, l[1] as String) } }
)

// ---------- Raíz ----------

@Composable
fun PlayerApp(vm: PlayerViewModel, onRequestPermission: () -> Unit) {
    // Primera vez: nombre, carpeta de música y análisis. Se guarda y no se vuelve a preguntar.
    if (!vm.onboarded) OnboardingScreen(vm)
    else MainShell(vm, onRequestPermission)
}

@Composable
private fun MainShell(vm: PlayerViewModel, onRequestPermission: () -> Unit) {
    // rememberSaveable: rotar el teléfono no cierra el reproductor, la cola ni el resto de pantallas abiertas.
    var showPlayer by rememberSaveable { mutableStateOf(false) }
    var showQueue by rememberSaveable { mutableStateOf(false) }
    var showSleep by rememberSaveable { mutableStateOf(false) }
    var addTarget by remember { mutableStateOf<Song?>(null) }
    var newList by rememberSaveable { mutableStateOf(false) }
    var tab by rememberSaveable { mutableIntStateOf(0) }       // 0 Home, 1 Biblioteca, 2 Playlists, 3 Ajustes, 4 Mood
    var libTab by rememberSaveable { mutableIntStateOf(0) }
    var detail by rememberSaveable(stateSaver = DetailSaver) { mutableStateOf<Detail?>(null) }
    val homeState = rememberLazyListState()
    val reducedNav = LocalUi.current.reducedMotion

    BackHandler(enabled = detail != null) { detail = null }
    BackHandler(enabled = detail == null && tab != 0) { tab = 0 }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                Column {
                    vm.current?.let { MiniBar(vm, it) { showPlayer = true } }
                    BottomNav(tab) { tab = it; detail = null }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                AnimatedContent(
                    targetState = tab, label = "tabs", modifier = Modifier.fillMaxSize(),
                    transitionSpec = {
                        if (reducedNav) EnterTransition.None togetherWith ExitTransition.None
                        else (fadeIn(tween(220, 80)) + scaleIn(tween(260, easing = JmEase), initialScale = 0.98f)) togetherWith fadeOut(tween(90))
                    }
                ) { t ->
                    when (t) {
                        0 -> HomeScreen(
                            vm, homeState, onOpenPlayer = { showPlayer = true }, onDetail = { detail = it },
                            onSeeFavorites = { libTab = 3; tab = 1 }, onSearch = { libTab = 0; tab = 1 },
                            onRequestPermission = onRequestPermission
                        )
                        1 -> Library(vm, libTab, { libTab = it }, onRequestPermission,
                            onDetail = { detail = it }, onAdd = { addTarget = it }, onNewList = { newList = true })
                        2 -> PlaylistsScreen(vm, onNewList = { newList = true }, onOpen = { detail = Detail(2, it) })
                        4 -> MoodScreen(vm, onOpen = { detail = Detail(3, it.name) })
                        else -> SettingsScreen(vm, onOpenStats = { detail = Detail(4, "") }, onOpenEggs = { detail = Detail(6, "") }, onOpenEco = { detail = Detail(it, "") })
                    }
                }
                // Álbum / artista / lista: se dibuja encima, así las pestañas conservan su scroll.
                AnimatedContent(
                    targetState = detail, label = "detail", modifier = Modifier.fillMaxSize(),
                    transitionSpec = {
                        if (reducedNav) EnterTransition.None togetherWith ExitTransition.None
                        else if (targetState != null)
                            (slideInHorizontally(tween(280, easing = FastOutSlowInEasing)) { it / 5 } + fadeIn(tween(220))) togetherWith fadeOut(tween(140))
                        else
                            fadeIn(tween(160)) togetherWith (slideOutHorizontally(tween(240, easing = FastOutSlowInEasing)) { it / 5 } + fadeOut(tween(200)))
                    }
                ) { d ->
                    if (d != null) Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
                        DetailScreen(vm, d, onBack = { detail = null }, onAdd = { addTarget = it }, onOpen = { detail = it })
                    } else Box(Modifier.fillMaxSize())
                }
            }
        }
        val cur = vm.current
        val lastSong = remember { arrayOfNulls<Song>(1) }       // evita un hueco mientras el reproductor se está cerrando
        if (cur != null) lastSong[0] = cur
        AnimatedVisibility(
            visible = showPlayer && cur != null,
            enter = if (reducedNav) EnterTransition.None else slideInVertically(tween(340, easing = JmEase)) { it / 4 } + fadeIn(tween(220)),
            exit = if (reducedNav) ExitTransition.None else slideOutVertically(tween(260, easing = FastOutSlowInEasing)) { it / 4 } + fadeOut(tween(200))
        ) {
            lastSong[0]?.let { sc ->
                NowPlaying(vm, sc, onClose = { showPlayer = false }, onQueue = { showQueue = true },
                    onSleep = { showSleep = true }, onAdd = { addTarget = it })
            }
        }
        if (showQueue) QueueScreen(vm) { showQueue = false }
        // Frase de Juli al elegir una canción (solo con "Activar personalidad Juli"): breve, sobre todo y sin bloquear toques.
        vm.ecoToast?.let { t -> EcoToastView(t, Modifier.align(Alignment.TopCenter).padding(top = 76.dp)) { vm.dismissEcoToast(t) } }
        vm.juliLine?.let { line -> JuliToast(line, Modifier.align(Alignment.TopCenter), onDismiss = { vm.dismissJuliLine(line) }) }
        // Always-On Lyrics (Módulo 11A): capa negra encima de todo; un toque o "atrás" la cierra.
        if (vm.alwaysOnActive) AlwaysOnLyrics(vm)
    }

    if (showSleep) SleepDialog { showSleep = false }
    addTarget?.let { s -> AddToPlaylistDialog(vm, s) { addTarget = null } }
    if (newList) NameDialog(onCreate = { vm.createPlaylist(it) }) { newList = false }
}

@Composable
private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    // (índice de pestaña, etiqueta, icono): el índice de Mood es 4 para no alterar los demás.
    val items = listOf(
        Triple(0, "Home", R.drawable.ic_home), Triple(1, "Biblioteca", R.drawable.ic_library),
        Triple(4, "Mood", R.drawable.ic_note),
        Triple(2, "Playlists", R.drawable.ic_queue), Triple(3, "Ajustes", R.drawable.ic_settings)
    )
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 0.dp) {
        items.forEach { (i, label, icon) ->
            NavigationBarItem(
                selected = selected == i, onClick = { onSelect(i) },
                icon = { Icon(painterResource(icon), label, Modifier.size(24.dp)) },
                label = { Text(label, fontSize = 12.sp) }
            )
        }
    }
}

// ---------- Biblioteca ----------

@Composable
private fun Library(
    vm: PlayerViewModel, tab: Int, onTab: (Int) -> Unit, onRequestPermission: () -> Unit,
    onDetail: (Detail) -> Unit, onAdd: (Song) -> Unit, onNewList: () -> Unit
) {
    val tabs = listOf("Canciones", "Álbumes", "Artistas", "Favoritos", "Listas")
    val albums = remember(vm.songs, vm.query) { vm.filtered.groupBy { it.album } }
    val artists = remember(vm.songs, vm.query) { vm.filtered.groupBy { it.artist } }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Biblioteca", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            TextButton(onClick = { vm.loadSongs() }) { Text("Reescanear") }
        }
        OutlinedTextField(
            value = vm.query, onValueChange = { vm.query = it },
            placeholder = { Text("Buscar canciones, artistas o álbumes") },
            singleLine = true, shape = uiShape(18.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
        )
        when {
            !vm.hasPermission -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Se necesita permiso para leer tu música", color = Gray)
                    Button(onClick = onRequestPermission, modifier = Modifier.padding(top = 12.dp)) {
                        Text("Conceder permiso")
                    }
                }
            }
            vm.loading -> Empty("Escaneando…")
            else -> Column {
                ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp, containerColor = Color.Transparent) {
                    tabs.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { onTab(i) }, text = { Text(t) }) }
                }
                when (tab) {
                    0 -> SongList(vm, vm.filtered, onAdd)
                    1 -> GroupList(albums) { onDetail(Detail(0, it)) }
                    2 -> GroupList(artists) { onDetail(Detail(1, it)) }
                    3 -> SongList(vm, vm.songs.filter { it.id in vm.favorites }, onAdd, emptyText = "Toca el ♥ en una canción para añadirla")
                    else -> PlaylistsContent(vm, onNewList) { onDetail(Detail(2, it)) }
                }
            }
        }
    }
}

@Composable
private fun PlaylistsScreen(vm: PlayerViewModel, onNewList: () -> Unit, onOpen: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text("Playlists", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 4.dp))
        PlaylistsContent(vm, onNewList, onOpen)
    }
}

@Composable
private fun PlaylistsContent(vm: PlayerViewModel, onNewList: () -> Unit, onOpen: (String) -> Unit) {
    Column {
        TextButton(onClick = onNewList, modifier = Modifier.padding(horizontal = 8.dp)) { Text("+ Nueva lista") }
        if (vm.playlists.isEmpty()) Empty("Aún no tienes listas")
        LazyColumn {
            items(vm.playlists.keys.toList(), key = { it }) { name ->
                val songs = vm.playlistSongs(name)
                Row(
                    Modifier.fillMaxWidth().clickable { onOpen(name) }.padding(start = 16.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (songs.isEmpty()) Box(Modifier.size(52.dp).clip(uiShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant), Alignment.Center) {
                        Icon(painterResource(R.drawable.ic_queue), null, tint = Gray, modifier = Modifier.size(26.dp))
                    } else GroupCover(songs, Modifier.size(52.dp), radius = 10.dp)
                    Column(Modifier.weight(1f).padding(start = 16.dp)) {
                        Text(name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${vm.playlists[name].orEmpty().size} canciones", color = Gray, fontSize = 13.sp)
                    }
                    IconBtn(R.drawable.ic_delete, "Eliminar lista", Gray) { vm.deletePlaylist(name) }
                }
            }
        }
    }
}

@Composable
private fun DetailScreen(vm: PlayerViewModel, d: Detail, onBack: () -> Unit, onAdd: (Song) -> Unit, onOpen: (Detail) -> Unit) {
    // Sin `return` temprano: cada tipo de pantalla es una rama; el resto (álbum/artista/lista/mood) va a ListDetail.
    when (d.kind) {
        0 -> AlbumScreen(vm, d.name, onBack, onAdd)
        4 -> StatsScreen(vm, onBack)
        5 -> WeeklyIdentityScreen(vm, onBack)
        6 -> EasterEggScreen(vm, onBack)
        7 -> IdentityScreen(vm, onBack, onOpen)
        8 -> AchievementsScreen(vm, onBack)
        9 -> DiscoverScreen(vm, onBack, onOpen)
        10 -> CollectionsScreen(vm, onBack, onOpen)
        12 -> EcoListScreen(vm, d.name, onBack)
        13 -> ProgressListScreen(vm, true, d.name, onBack, onOpen)
        14 -> ProgressListScreen(vm, false, d.name, onBack, onOpen)
        else -> ListDetail(vm, d, onBack, onAdd)
    }
}

@Composable
private fun ListDetail(vm: PlayerViewModel, d: Detail, onBack: () -> Unit, onAdd: (Song) -> Unit) {
    val list = when (d.kind) {
        0 -> vm.songs.filter { it.album == d.name }
        1 -> vm.songs.filter { it.artist == d.name }
        3 -> vm.songsFor(Mood.fromName(d.name))
        else -> vm.playlistSongs(d.name)
    }
    val title = if (d.kind == 3) Mood.fromName(d.name)?.let { "${it.emoji} ${it.label}" } ?: d.name else d.name
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(R.drawable.ic_down, "Volver", rotate = true, onClick = onBack)
            Text(title, fontWeight = FontWeight.Bold, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (list.isNotEmpty()) Row(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { vm.playSong(list.first(), list) }, shape = uiShape(16.dp)) {
                Icon(painterResource(R.drawable.ic_play), null, Modifier.size(20.dp)); Text("  Reproducir")
            }
            FilledTonalButton(onClick = { vm.playShuffled(list) }, shape = uiShape(16.dp)) {
                Icon(painterResource(R.drawable.ic_shuffle), null, Modifier.size(20.dp)); Text("  Aleatorio")
            }
        }
        if (d.kind == 1) ArtistProgressRow(vm, list)
        SongList(vm, list, onAdd, onRemove = if (d.kind == 2) ({ s: Song -> vm.removeFromPlaylist(d.name, s.id) }) else null)
    }
}

@Composable
internal fun Empty(text: String) =
    Box(Modifier.fillMaxWidth().padding(32.dp), Alignment.Center) { Text(text, color = Gray) }

@Composable
private fun SongList(
    vm: PlayerViewModel, list: List<Song>, onAdd: (Song) -> Unit,
    onRemove: ((Song) -> Unit)? = null, emptyText: String = "No hay canciones"
) {
    if (list.isEmpty()) Empty(emptyText) else LazyColumn(Modifier.fillMaxSize()) {
        items(list, key = { it.id }) { SongRow(vm, it, list, onAdd, onRemove) }
    }
}

@Composable
private fun GroupList(groups: Map<String, List<Song>>, onClick: (String) -> Unit) {
    val ui = LocalUi.current
    if (groups.isEmpty()) Empty("No hay resultados") else LazyColumn(Modifier.fillMaxSize()) {
        items(groups.keys.sortedBy { it.lowercase() }, key = { it }) { name ->
            val songs = groups.getValue(name)
            Row(
                Modifier.fillMaxWidth().clickable { onClick(name) }.padding(horizontal = 16.dp, vertical = ui.d(8.dp)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                GroupCover(songs, Modifier.size(ui.d(52.dp)), radius = 6.dp)
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    Text("${songs.size} canciones", color = Gray, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
internal fun SongRow(
    vm: PlayerViewModel, song: Song, context: List<Song>, onAdd: (Song) -> Unit, onRemove: ((Song) -> Unit)?,
    number: Int? = null
) {
    val ui = LocalUi.current
    val selected = song.id.toString() == vm.currentId
    val fav = song.id in vm.favorites
    var actions by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    Row(
        Modifier.fillMaxWidth().combinedClickable(
            onClick = { vm.selectSong(song, context) },
            onLongClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); actions = true }
        ).padding(start = 16.dp, top = ui.d(4.dp), bottom = ui.d(4.dp)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (number != null) Text("$number", Modifier.width(28.dp), color = Gray, fontSize = 13.sp, textAlign = TextAlign.Start)
        Cover(song, Modifier.size(ui.d(52.dp)))
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(
                song.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Medium
            )
            Text("${song.artist} · ${song.album}", maxLines = 1, overflow = TextOverflow.Ellipsis, color = Gray, fontSize = 13.sp)
        }
        IconBtn(if (fav) R.drawable.ic_heart else R.drawable.ic_heart_outline, "Favorito",
            if (fav) MaterialTheme.colorScheme.primary else Gray) { vm.toggleFavorite(song.id) }
        IconBtn(R.drawable.ic_more, "Más", Gray) { actions = true }
    }
    if (actions) SongActions(vm, song, onAdd, onRemove) { actions = false }
}

// ---------- Barra mini ----------

@Composable
private fun MiniBar(vm: PlayerViewModel, song: Song, onOpen: () -> Unit) =
    PlayerAccent(vm) { MiniBarV11(vm, song, onOpen) }

// ---------- Pantalla completa ----------

@Composable
private fun NowPlaying(vm: PlayerViewModel, song: Song, onClose: () -> Unit, onQueue: () -> Unit, onSleep: () -> Unit, onAdd: (Song) -> Unit) =
    PlayerAccent(vm) { NowPlayingV11(vm, song, onClose, onQueue, onSleep, onAdd) }

@Composable
internal fun NpExtras(accent: Color, onSleep: () -> Unit, onQueue: () -> Unit, onLyrics: () -> Unit, lyrics: LyricsData) {
    val left = SleepTimer.leftMs
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onSleep) {
            Icon(painterResource(R.drawable.ic_timer), null, tint = if (left > 0) accent else Gray, modifier = Modifier.size(22.dp))
            Text(if (left > 0) "  " + formatTime(left) else "  Dormir", color = if (left > 0) accent else Gray)
        }
        TextButton(onClick = onLyrics) {
            // Resalta el botón cuando ya hay letras disponibles.
            val has = lyrics.hasLyrics
            Icon(painterResource(R.drawable.ic_lyrics), null, tint = if (has) accent else Gray, modifier = Modifier.size(22.dp))
            Text("  Letras", color = if (has) accent else Gray)
        }
        TextButton(onClick = onQueue) {
            Icon(painterResource(R.drawable.ic_queue), null, tint = Gray, modifier = Modifier.size(22.dp))
            Text("  Cola", color = Gray)
        }
    }
}

// ---------- Cola ----------

@Composable
private fun QueueScreen(vm: PlayerViewModel, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    val ui = LocalUi.current
    var adding by rememberSaveable { mutableStateOf(false) }
    // Se abre posicionada en la canción actual, así "lo que viene" se ve sin desplazarse.
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = vm.currentIndex.coerceAtLeast(0))
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Row(Modifier.fillMaxWidth().padding(end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(R.drawable.ic_down, "Cerrar", onClick = onClose)
            Column(Modifier.weight(1f)) {
                Text("Cola de reproducción", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                val left = (vm.queue.size - vm.currentIndex - 1).coerceAtLeast(0)
                if (vm.queue.isNotEmpty()) Text(
                    "${vm.queue.size} en la cola · $left por sonar" +
                        (if (vm.shuffle) " · aleatorio" else "") +
                        (when (vm.repeatMode) { Player.REPEAT_MODE_ALL -> " · repetir cola"; Player.REPEAT_MODE_ONE -> " · repetir canción"; else -> "" }),
                    color = Gray, fontSize = 12.sp
                )
            }
            IconBtn(R.drawable.ic_add, "Añadir canciones", MaterialTheme.colorScheme.primary) { adding = true }
        }
        if (vm.queue.isEmpty()) Empty("La cola está vacía")
        LazyColumn(Modifier.fillMaxSize(), state = listState) {
            itemsIndexed(vm.queue) { i, s ->
                val now = i == vm.currentIndex
                Row(
                    Modifier.fillMaxWidth().clickable { vm.playQueueIndex(i) }.padding(start = 16.dp, top = ui.d(2.dp), bottom = ui.d(2.dp)),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Cover(s, Modifier.size(44.dp))
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = if (now) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground)
                        Text(if (now) "Reproduciendo · ${s.artist}" else s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Gray, fontSize = 13.sp)
                    }
                    if (i > 0) IconBtn(R.drawable.ic_up, "Subir", Gray, 20.dp) { vm.moveQueue(i, i - 1) } else Spacer(Modifier.size(48.dp))
                    if (i < vm.queue.lastIndex) IconBtn(R.drawable.ic_arrow_down, "Bajar", Gray, 20.dp) { vm.moveQueue(i, i + 1) } else Spacer(Modifier.size(48.dp))
                    IconBtn(R.drawable.ic_close, "Quitar", Gray, 20.dp) { vm.removeFromQueue(i) }
                }
            }
        }
    }
    if (adding) AddToQueueDialog(vm) { adding = false }
}

// ---------- Diálogos ----------

@Composable
private fun SleepDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("Temporizador para dormir") },
        text = {
            Column {
                if (SleepTimer.leftMs > 0) Text("Se detendrá en ${formatTime(SleepTimer.leftMs)}", color = MaterialTheme.colorScheme.primary)
                listOf(5, 15, 30, 45, 60, 90).forEach { m ->
                    TextButton(onClick = { SleepTimer.start(m); onDismiss() }) { Text("$m minutos") }
                }
                if (SleepTimer.leftMs > 0) TextButton(onClick = { SleepTimer.cancel(); onDismiss() }) { Text("Cancelar temporizador") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }
    )
}

@Composable
private fun AddToPlaylistDialog(vm: PlayerViewModel, song: Song, onDismiss: () -> Unit) {
    var creating by remember { mutableStateOf(false) }
    if (creating) NameDialog(onCreate = { vm.createPlaylist(it, song.id) }) { creating = false; onDismiss() } else AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("Añadir a una lista") },
        text = {
            LazyColumn {
                item { TextButton(onClick = { creating = true }) { Text("+ Nueva lista") } }
                items(vm.playlists.keys.toList(), key = { it }) { n ->
                    TextButton(onClick = { vm.addToPlaylist(n, song.id); onDismiss() }) { Text(n) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }
    )
}

/** Busca en la biblioteca y añade canciones al final de la cola sin salir de ella; admite varias seguidas. */
@Composable
private fun AddToQueueDialog(vm: PlayerViewModel, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf("") }
    var added by remember { mutableStateOf(setOf<Long>()) }
    val results = remember(q, vm.songs) {
        val t = q.trim()
        (if (t.isEmpty()) vm.songs else vm.songs.filter {
            it.title.contains(t, true) || it.artist.contains(t, true) || it.album.contains(t, true)
        }).take(80)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("Añadir a la cola") },
        text = {
            Column {
                OutlinedTextField(
                    q, { q = it }, singleLine = true, placeholder = { Text("Buscar canciones") },
                    shape = uiShape(16.dp), modifier = Modifier.fillMaxWidth()
                )
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 340.dp)) {
                    items(results, key = { it.id }) { s ->
                        val done = s.id in added
                        Row(
                            Modifier.fillMaxWidth().clickable(enabled = !done) { vm.addToQueue(s); added = added + s.id }.padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Cover(s, Modifier.size(40.dp))
                            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                                Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                                Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Gray, fontSize = 12.sp)
                            }
                            Icon(
                                painterResource(if (done) R.drawable.ic_check else R.drawable.ic_add),
                                if (done) "Añadida" else "Añadir", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 8.dp).size(22.dp)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Listo") } }
    )
}

@Composable
private fun NameDialog(onCreate: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("Nueva lista") },
        text = { OutlinedTextField(name, { name = it }, singleLine = true, placeholder = { Text("Nombre") }) },
        confirmButton = { TextButton(onClick = { onCreate(name); onDismiss() }, enabled = name.isNotBlank()) { Text("Crear") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

// ---------- Componentes ----------

@Composable
internal fun IconBtn(res: Int, desc: String, tint: Color = MaterialTheme.colorScheme.onBackground, size: Dp = 24.dp, rotate: Boolean = false, onClick: () -> Unit) {
    IconButton(onClick = onClick) {
        Icon(
            painterResource(res), desc, tint = tint,
            modifier = Modifier.size(size).then(if (rotate) Modifier.rotate(90f) else Modifier)
        )
    }
}

@Composable
fun Cover(song: Song, modifier: Modifier = Modifier, px: Int = 256, radius: Dp = 6.dp) {
    val ctx = LocalContext.current
    // Si la carátula ya está en caché se pinta al instante (sin parpadeo al desplazar ni al cambiar de canción).
    val bmp by produceState<Bitmap?>(ArtCache.peek(song, px), song.id, song.customArt, px) {
        value = ArtCache.peek(song, px)
        if (value == null) value = withContext(Dispatchers.IO) { ArtCache.load(ctx, song, px) }
    }
    Box(modifier.clip(uiShape(radius)), Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else DefaultCover(song.album)
    }
}

/** Carátula por defecto: degradado único por álbum + nota musical. */
@Composable
internal fun DefaultCover(seed: String) {
    val hue = (abs(seed.hashCode()) % 360).toFloat()
    Box(
        Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(Color.hsv(hue, 0.45f, 0.45f), Color.hsv((hue + 40) % 360, 0.55f, 0.22f)))
        ),
        Alignment.Center
    ) {
        Icon(painterResource(R.drawable.ic_note), null, tint = Color.White.copy(alpha = 0.75f), modifier = Modifier.fillMaxSize(0.45f))
    }
}

/** Busca carátula: miniatura del sistema → imagen incrustada en el archivo → null (se usa la de por defecto). */
object ArtCache {
    // Caché limitada por memoria (no por cantidad): ~1/8 de la RAM de la app, máx. 48 MB.
    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 8).coerceAtMost(48L * 1024 * 1024).toInt()
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val missing: MutableSet<String> = Collections.synchronizedSet(HashSet())

    /** Solo consulta la caché (no decodifica nada). */
    fun peek(song: Song, px: Int): Bitmap? = cache.get(keyOf(song, px))

    // La ruta de la carátula descargada forma parte de la clave: al corregir una canción se vuelve a cargar.
    private fun keyOf(song: Song, px: Int) = "${song.id}:${song.customArt.hashCode()}:$px"

    private fun custom(path: String, px: Int): Bitmap? = runCatching {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, o)
        o.inSampleSize = max(1, min(o.outWidth, o.outHeight) / px)
        o.inJustDecodeBounds = false
        BitmapFactory.decodeFile(path, o)
    }.getOrNull()

    fun load(ctx: Context, song: Song, px: Int): Bitmap? {
        val key = keyOf(song, px)
        cache.get(key)?.let { return it }
        if (key in missing) return null
        val bmp = (if (song.customArt.isNotEmpty()) custom(song.customArt, px) else null) ?: runCatching {
            if (Build.VERSION.SDK_INT >= 29) ctx.contentResolver.loadThumbnail(song.uri, Size(px, px), null)
            else ctx.contentResolver.openInputStream(song.artUri)?.use { BitmapFactory.decodeStream(it) }
        }.getOrNull() ?: embedded(ctx, song, px)
        if (bmp != null) cache.put(key, bmp) else missing.add(key)
        return bmp
    }

    private fun embedded(ctx: Context, song: Song, px: Int): Bitmap? = runCatching {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, song.uri)
            val b = r.embeddedPicture ?: return@runCatching null
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(b, 0, b.size, o)
            o.inSampleSize = max(1, min(o.outWidth, o.outHeight) / px)
            o.inJustDecodeBounds = false
            BitmapFactory.decodeByteArray(b, 0, b.size, o)
        } finally { r.release() }
    }.getOrNull()
}

fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(total / 60, total % 60)
}
