package com.example.musicplayer

import java.security.MessageDigest

/** Estados que la UI (Módulo 10B) puede consultar para decidir qué mostrar. */
enum class LyricsStatus { NOT_QUERIED, LOADING, SYNCED, UNSYNCED, NOT_FOUND, ERROR }

/** Una línea de letra sincronizada: [timestampMs] desde el inicio de la canción. */
data class LyricLine(val timestampMs: Long, val text: String)

/** Resultado crudo de un proveedor (sin decisiones de caché). */
sealed class ProviderResult {
    data class Found(val synced: String?, val plain: String?, val source: String) : ProviderResult()
    object NotFound : ProviderResult()
    data class Failure(val reason: String) : ProviderResult()
}

/** Metadatos mínimos que se envían al proveedor. Nunca incluye la ruta/URI del archivo. */
data class LyricsQuery(val title: String, val artist: String, val album: String, val durationSec: Int) {
    val usable: Boolean
        get() = title.isNotBlank() && artist.isNotBlank() && !artist.startsWith("Artista desconocido")
}

/** Lo que se guarda en disco y lo que la UI recibe. */
data class LyricsData(
    val status: LyricsStatus,
    val plain: String = "",
    val syncedLrc: String = "",        // LRC original, tal como lo devolvió el proveedor
    val lines: List<LyricLine> = emptyList(),
    val updatedAt: Long = 0L,
    val source: String = "",
    val fromCache: Boolean = false,
    val retryAfter: Long = 0L,         // para NOT_FOUND / ERROR: no volver a consultar antes de esta fecha
    val attempts: Int = 0              // fallos consecutivos (para el cooldown creciente)
) {
    val hasLyrics: Boolean get() = status == LyricsStatus.SYNCED || status == LyricsStatus.UNSYNCED
    val isSynced: Boolean get() = status == LyricsStatus.SYNCED
    val isLoading: Boolean get() = status == LyricsStatus.LOADING
    val isError: Boolean get() = status == LyricsStatus.ERROR

    /** Línea activa para una posición de reproducción (búsqueda binaria); -1 si aún no empieza. */
    fun lineIndexAt(positionMs: Long): Int {
        if (lines.isEmpty()) return -1
        var lo = 0; var hi = lines.lastIndex; var ans = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (lines[mid].timestampMs <= positionMs) { ans = mid; lo = mid + 1 } else hi = mid - 1
        }
        return ans
    }

    companion object {
        val NOT_QUERIED = LyricsData(LyricsStatus.NOT_QUERIED)
        val LOADING = LyricsData(LyricsStatus.LOADING)
    }
}

/** Parser de LRC: [mm:ss], [mm:ss.xx], [mm:ss.xxx], [mm:ss:xx], varios tiempos por línea, offset y etiquetas. */
object LrcParser {
    private val TIME = Regex("""\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?]""")
    private val OFFSET = Regex("""^\[offset:\s*([+-]?\d+)\s*]""", RegexOption.IGNORE_CASE)
    private val WORD_TAG = Regex("""<\d{1,3}:\d{1,2}(?:[.:]\d{1,3})?>""")   // LRC "enhanced": <mm:ss.xx>

    fun parse(lrc: String): List<LyricLine> {
        if (lrc.isBlank()) return emptyList()
        var offset = 0L
        val out = ArrayList<LyricLine>()
        for (raw in lrc.lineSequence()) {
            val line = raw.trim().trimStart('\uFEFF')
            if (line.isEmpty()) continue
            val off = OFFSET.find(line)
            if (off != null) { offset = off.groupValues[1].toLongOrNull() ?: 0L; continue }
            val times = TIME.findAll(line).toList()
            if (times.isEmpty()) continue            // etiquetas [ar:], [ti:], etc. o texto suelto
            // El texto es lo que queda tras el último timestamp inicial.
            val textStart = times.last().range.last + 1
            val text = WORD_TAG.replace(line.substring(textStart), "").trim()
            for (m in times) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val ms = when (frac.length) { 0 -> 0L; 1 -> frac.toLong() * 100; 2 -> frac.toLong() * 10; else -> frac.take(3).toLong() }
                val t = (min * 60_000L + sec * 1000L + ms - offset).coerceAtLeast(0L)
                out += LyricLine(t, text)
            }
        }
        return out.sortedBy { it.timestampMs }
    }

    /** Un LRC es válido si trae al menos un par de líneas con texto real. */
    fun isValid(lines: List<LyricLine>) = lines.count { it.text.isNotBlank() } >= 2
}

/** Clave estable de caché: hash de título+artista+álbum+duración normalizados + id de la canción. */
object LyricsKey {
    private fun norm(s: String) = s.lowercase().trim().replace(Regex("\\s+"), " ")

    fun of(song: Song): String {
        val raw = listOf(song.id.toString(), norm(song.title), norm(song.artist), norm(song.album), (song.durationMs / 1000).toString())
            .joinToString("\u0001")
        return MessageDigest.getInstance("SHA-256").digest(raw.toByteArray())
            .joinToString("") { "%02x".format(it) }.take(40)
    }
}

/**
 * Extensión futura (Módulo de Mood): datos externos por canción (género, BPM, energía…).
 * Independiente de las letras; por ahora solo se define la estructura.
 */
data class SongEnrichment(
    val genre: String = "", val subgenre: String = "", val bpm: Int = 0, val energy: Float = -1f,
    val features: Map<String, String> = emptyMap(), val source: String = "", val updatedAt: Long = 0L
)
