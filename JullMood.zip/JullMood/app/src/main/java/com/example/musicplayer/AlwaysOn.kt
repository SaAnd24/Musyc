package com.example.musicplayer

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableIntState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlin.math.abs
import kotlin.math.min

/*
 * Módulo 11 · Parte A — Always-On Lyrics.
 *
 *   Reproductor → posición real (vm.livePosition) → LyricsData (10A/10B) → línea actual → esta pantalla
 *
 * No descarga nada, no crea servicios ni hilos propios, no toca el motor de reproducción y no mantiene la
 * pantalla encendida: es solo una capa negra con las letras que ya existen.
 */

/**
 * Cuenta tiempo de REPRODUCCIÓN REAL (no de reloj): solo suma mientras suena algo.
 *  · Una pausa congela el contador; al reanudar continúa donde iba.
 *  · Si la pausa/parada dura más de [RESET_AFTER_PAUSE_MS], se considera una sesión nueva y vuelve a 0.
 *  · Cambiar de canción NO lo reinicia: el criterio es "escucha continua", no "canción actual".
 * Es lógica pura (recibe el reloj por parámetro): la llama el tick de 500 ms que el ViewModel ya tenía.
 */
class AlwaysOnTimer {
    companion object {
        const val THRESHOLD_MS = 120_000L            // 2 minutos de reproducción
        const val RESET_AFTER_PAUSE_MS = 300_000L    // 5 minutos sin sonar = sesión nueva
        private const val MAX_STEP_MS = 2_000L       // un salto grande de reloj (suspensión) no cuenta como escucha
    }

    var playedMs = 0L; private set
    private var last = -1L
    private var pausedSince = -1L

    val reached: Boolean get() = playedMs >= THRESHOLD_MS

    /** [nowMs] = SystemClock.elapsedRealtime(); [playing] = suena una canción. Devuelve si ya se alcanzaron los 2 min. */
    fun update(nowMs: Long, playing: Boolean): Boolean {
        val dt = if (last < 0) 0L else (nowMs - last).coerceIn(0L, MAX_STEP_MS)
        last = nowMs
        if (playing) {
            pausedSince = -1L
            playedMs = min(THRESHOLD_MS, playedMs + dt)
        } else {
            if (pausedSince < 0) pausedSince = nowMs
            else if (nowMs - pausedSince >= RESET_AFTER_PAUSE_MS) playedMs = 0L
        }
        return reached
    }

    fun reset() { playedMs = 0L; pausedSince = -1L }
}

/** Se marca la línea unos milisegundos antes para compensar la animación (mismo criterio que 10B). */
private const val LEAD_MS = 100L
/** Lectura de la posición: 10 veces por segundo basta para una línea de texto y gasta menos que un bucle por fotograma. */
private const val POLL_MS = 100L
/** Posición vertical de la línea actual (0 = arriba, 0.5 = centro). */
private const val FOCUS = 0.42f

/**
 * Pantalla completa: negro absoluto + letras blancas. Un toque (o "atrás") sale del modo.
 * Sin portada, botones, barra de progreso, degradados ni colores dinámicos.
 */
@Composable
internal fun AlwaysOnLyrics(vm: PlayerViewModel) {
    val songId = vm.currentId?.toLongOrNull()
    // Si el estado de letras aún es el de la canción anterior, nunca se muestra: pantalla negra hasta tener las nuevas.
    val l = if (songId != null && vm.lyricsSongId == songId) vm.lyrics else LyricsData.LOADING

    BackHandler { vm.exitAlwaysOn() }

    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .pointerInput(Unit) { detectTapGestures { vm.exitAlwaysOn() } }
    ) {
        when {
            l.isSynced && l.lines.isNotEmpty() -> key(songId, l.updatedAt) { AoSynced(vm, l) }
            l.hasLyrics -> AoPlain(l.plain.ifBlank { l.lines.joinToString("\n") { it.text } })
            else -> Unit   // cargando: negro (si no hay letras, el ViewModel cierra el modo solo)
        }
    }
}

@Composable
private fun AoSynced(vm: PlayerViewModel, data: LyricsData) {
    val lines = data.lines
    val reduced = LocalUi.current.reducedMotion
    val listState = rememberLazyListState()
    val index = remember { mutableIntStateOf(-1) }
    var last by remember { mutableIntStateOf(-99) }

    // Sincronización: lee la posición REAL del reproductor; no hay ningún temporizador que simule la canción.
    // Solo se escribe estado cuando cambia la línea. Un seek, pausa o cambio de cola se reflejan en la siguiente lectura.
    LaunchedEffect(data) {
        while (true) {
            val i = data.lineIndexAt(vm.livePosition() + LEAD_MS)
            if (i != index.intValue) index.intValue = i
            delay(POLL_MS)
        }
    }

    // Auto-scroll suave: solo cuando cambia la línea. Las filas se dibujan una vez; el desplazamiento es programático.
    LaunchedEffect(Unit) {
        snapshotFlow { listState.layoutInfo.viewportSize.height }.first { it > 0 }
        snapshotFlow { index.intValue }.collectLatest { idx ->
            if (idx < 0) return@collectLatest
            val vh = listState.layoutInfo.viewportSize.height
            val item = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == idx + 1 }   // +1: espacio superior
            val jump = reduced || last < 0 || abs(idx - last) > 6 || item == null                    // primera vez o seek lejano
            last = idx
            if (jump) {
                listState.scrollToItem(idx + 1, -(vh * FOCUS).toInt())
                listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == idx + 1 }?.let {
                    listState.scrollBy(it.offset + it.size / 2f - vh * FOCUS)
                }
            } else {
                listState.animateScrollBy(item!!.offset + item.size / 2f - vh * FOCUS, tween(450, easing = FastOutSlowInEasing))
            }
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val vh = maxHeight
        LazyColumn(
            state = listState, userScrollEnabled = false, modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 28.dp)
        ) {
            item(key = "top") { Spacer(Modifier.height(vh * FOCUS)) }
            itemsIndexed(lines, key = { i, _ -> i }) { i, line -> AoLine(i, line.text, index, reduced) }
            item(key = "bottom") { Spacer(Modifier.height(vh * (1f - FOCUS))) }
        }
    }
}

@Composable
private fun AoLine(i: Int, text: String, index: MutableIntState, reduced: Boolean) {
    // Solo se recomponen las filas cuyo estado cambia al avanzar de línea.
    val current by remember(i) { derivedStateOf { index.intValue == i } }
    val target by remember(i) {
        derivedStateOf {
            val c = index.intValue
            if (c < 0) 0.35f else when (abs(i - c)) { 0 -> 1f; 1 -> 0.5f; 2 -> 0.3f; else -> 0.18f }
        }
    }
    val alpha by animateFloatAsState(target, if (reduced) snap() else tween(300), label = "aoAlpha")
    Text(
        text.ifBlank { "♪" },
        color = Color.White.copy(alpha = alpha),
        fontSize = 26.sp, lineHeight = 34.sp,
        fontWeight = if (current) FontWeight.SemiBold else FontWeight.Medium,
        modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)
    )
}

/** Letras sin sincronizar: estáticas (con desplazamiento por si no caben). Un toque, igualmente, sale del modo. */
@Composable
private fun AoPlain(text: String) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 40.dp)) {
        Text(text, color = Color.White.copy(alpha = 0.92f), fontSize = 22.sp, lineHeight = 32.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(48.dp))
    }
}
