package com.example.musicplayer

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * Caché local persistente: un archivo JSON por canción en filesDir/lyrics/<hash>.json.
 * Sobrevive a cierres de la app y reinicios. Se eligió en vez de SharedPreferences porque las letras son textos
 * grandes, y en vez de Room para no añadir dependencias (el proyecto no usa base de datos).
 */
class LyricsStore(ctx: Context) {
    private val dir = File(ctx.filesDir, "lyrics").apply { mkdirs() }

    private fun file(key: String) = File(dir, "$key.json")

    fun read(key: String): LyricsData? = runCatching {
        val f = file(key)
        if (!f.exists()) return null
        val o = JSONObject(f.readText())
        val status = LyricsStatus.values().firstOrNull { it.name == o.optString("status") } ?: return null
        val lrc = o.optString("lrc", "")
        val lines = if (lrc.isNotBlank()) LrcParser.parse(lrc) else emptyList()
        LyricsData(
            status = status, plain = o.optString("plain", ""), syncedLrc = lrc, lines = lines,
            updatedAt = o.optLong("updatedAt"), source = o.optString("source", ""), fromCache = true,
            retryAfter = o.optLong("retryAfter"), attempts = o.optInt("attempts")
        )
    }.getOrNull()

    fun write(key: String, d: LyricsData) {
        runCatching {
            val o = JSONObject()
                .put("status", d.status.name).put("plain", d.plain).put("lrc", d.syncedLrc)
                .put("updatedAt", d.updatedAt).put("source", d.source)
                .put("retryAfter", d.retryAfter).put("attempts", d.attempts)
            val tmp = File(dir, "$key.tmp")
            tmp.writeText(o.toString())
            if (!tmp.renameTo(file(key))) { file(key).delete(); tmp.renameTo(file(key)) }   // escritura atómica
        }
    }

    fun delete(key: String) { runCatching { file(key).delete() } }
    fun clear() { runCatching { dir.listFiles()?.forEach { it.delete() } } }
    fun count(): Int = dir.listFiles { f -> f.extension == "json" }?.size ?: 0
}

/**
 * LyricsProvider → LyricsRepository → LyricsStore.
 * Regla: caché local primero; Internet solo si no hay datos locales válidos y no hay cooldown activo.
 */
class LyricsRepository(
    private val ctx: Context,
    private val provider: LyricsProvider = LrclibProvider(),
    private val store: LyricsStore = LyricsStore(ctx)
) {
    companion object {
        private const val NOT_FOUND_TTL = 7L * 24 * 3600 * 1000      // tras un NOT_FOUND no se reintenta durante 7 días
        private const val ERROR_BASE = 15L * 60 * 1000               // tras un error: 15 min, luego 30, 60… (máx. 6 h)
        private const val ERROR_MAX = 6L * 3600 * 1000
        private const val OFFLINE_RETRY = 2L * 60 * 1000             // sin red: no se insiste en 2 min (solo en memoria)
    }

    private val memory = ConcurrentHashMap<String, LyricsData>()
    private val netLock = Mutex()        // una petición de red a la vez: nunca se satura el servicio

    /** Consulta instantánea, sin red: memoria → disco. Null si nunca se ha buscado. */
    suspend fun cached(song: Song): LyricsData? {
        val key = LyricsKey.of(song)
        memory[key]?.let { return it }
        val d = withContext(Dispatchers.IO) { store.read(key) } ?: return null
        memory[key] = d
        return d
    }

    /**
     * Devuelve las letras de la canción. Nunca lanza excepciones ni toca el hilo principal.
     * [force] ignora cooldowns (reintento manual del usuario).
     */
    suspend fun load(song: Song, force: Boolean = false): LyricsData = withContext(Dispatchers.IO) {
        val key = LyricsKey.of(song)
        val now = System.currentTimeMillis()
        val local = memory[key] ?: store.read(key)?.also { memory[key] = it }

        if (local != null && local.hasLyrics) return@withContext local                        // caché válida: sin Internet
        if (!force && local != null && now < local.retryAfter) return@withContext local       // NOT_FOUND / ERROR en cooldown

        netLock.withLock {
            // Otra corrutina pudo haber resuelto la misma canción mientras esperábamos el turno.
            memory[key]?.let { if (it.hasLyrics) return@withContext it }

            val q = LyricsQuery(song.title, song.artist, song.album, (song.durationMs / 1000).toInt())
            if (!q.usable) {
                // Metadatos insuficientes: no se consulta para evitar coincidencias falsas.
                return@withContext LyricsData(LyricsStatus.NOT_FOUND, updatedAt = now).also { memory[key] = it }
            }
            if (!isOnline()) {
                // Sin conexión: se informa pero no se guarda nada en disco ni se insiste.
                return@withContext LyricsData(LyricsStatus.ERROR, retryAfter = now + OFFLINE_RETRY, attempts = local?.attempts ?: 0)
                    .also { memory[key] = it }
            }

            val result = runCatching { provider.fetch(q) }.getOrElse { ProviderResult.Failure(it.javaClass.simpleName) }
            val t = System.currentTimeMillis()
            val data = when (result) {
                is ProviderResult.Found -> build(result, t)
                is ProviderResult.NotFound -> LyricsData(LyricsStatus.NOT_FOUND, updatedAt = t, source = provider.name, retryAfter = t + NOT_FOUND_TTL)
                is ProviderResult.Failure -> {
                    val n = (local?.attempts ?: 0) + 1
                    val wait = (ERROR_BASE shl (n - 1).coerceAtMost(5)).coerceAtMost(ERROR_MAX)
                    LyricsData(LyricsStatus.ERROR, updatedAt = t, source = provider.name, retryAfter = t + wait, attempts = n)
                }
            }
            memory[key] = data
            store.write(key, data)      // también NOT_FOUND y ERROR, para respetar el cooldown tras reiniciar
            data
        }
    }

    /** Valida lo descargado: prefiere LRC válido; si no, texto plano; si nada sirve, cuenta como NOT_FOUND. */
    private fun build(r: ProviderResult.Found, now: Long): LyricsData {
        val lines = r.synced?.let { LrcParser.parse(it) }.orEmpty()
        if (r.synced != null && LrcParser.isValid(lines)) {
            val plain = r.plain ?: lines.joinToString("\n") { it.text }
            return LyricsData(LyricsStatus.SYNCED, plain = plain, syncedLrc = r.synced, lines = lines, updatedAt = now, source = r.source)
        }
        val plain = r.plain?.trim().orEmpty()
        if (plain.length >= 10) return LyricsData(LyricsStatus.UNSYNCED, plain = plain, updatedAt = now, source = r.source)
        return LyricsData(LyricsStatus.NOT_FOUND, updatedAt = now, source = r.source, retryAfter = now + NOT_FOUND_TTL)
    }

    @Suppress("DEPRECATION")
    private fun isOnline(): Boolean = runCatching {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }.getOrDefault(true)

    /** Borra las letras de una canción (p. ej. para forzar una nueva búsqueda). */
    suspend fun forget(song: Song) = withContext(Dispatchers.IO) {
        val key = LyricsKey.of(song); memory.remove(key); store.delete(key)
    }

    suspend fun clearAll() = withContext(Dispatchers.IO) { memory.clear(); store.clear() }
    suspend fun cachedCount(): Int = withContext(Dispatchers.IO) { store.count() }
}
