package com.example.musicplayer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.Normalizer
import kotlin.math.min

/**
 * Ambientes de la biblioteca. `assignable` = el usuario puede elegirlo a mano;
 * MIXTO y SIN_CLASIFICAR solo los asigna el clasificador automático.
 */
enum class Mood(val emoji: String, val label: String, val color: Color, val assignable: Boolean = true) {
    TRISTE("😢", "Triste / Melancólica", Color(0xFF42A5F5)),
    ALEGRE("😊", "Alegre", Color(0xFFFFB300)),
    ENERGIA("🔥", "Energía", Color(0xFFFF5722)),
    ROMANTICA("❤️", "Romántica", Color(0xFFE91E63)),
    NOCTURNA("🌙", "Nocturna", Color(0xFF5E35B1)),
    RELAJANTE("😌", "Relajante", Color(0xFF26A69A)),
    ROCK("🎸", "Rock", Color(0xFFC62828)),
    FIESTA("💃", "Fiesta", Color(0xFFD500F9)),
    CONCENTRACION("🧠", "Concentración", Color(0xFF00838F)),
    MIXTO("🎲", "Mixto", Color(0xFF78909C), false),
    SIN_CLASIFICAR("❓", "Sin clasificar", Color(0xFF616161), false);

    companion object {
        fun fromName(n: String?): Mood? = values().firstOrNull { it.name == n }
    }
}

/**
 * Clasificación 100 % local y sin Internet. Usa género, carpeta, álbum y título (palabras clave con peso).
 * No inventa: si no hay señal suficiente la canción queda "Sin clasificar"; si hay señales que compiten, "Mixto".
 * Las canciones sin género pueden heredar el Mood de su artista/álbum solo si la mayoría de sus otras canciones coincide.
 * (MediaStore no expone BPM, por eso no se usa.)
 */
object MoodClassifier {
    private const val MIN_SCORE = 1.5
    private const val FIELD_CAP = 4.0
    private const val UNKNOWN_ARTIST = "Artista desconocido"
    private const val UNKNOWN_ALBUM = "Álbum desconocido"

    /** `text` ya normalizado; `prefix` = coincide con el inicio de cualquier palabra (en la tabla se escribe con "*"). */
    private class Kw(val text: String, val prefix: Boolean, val weight: Double)

    private fun kws(vararg p: Pair<String, Double>): List<Kw> = p.map { (w, v) ->
        Kw(norm(w.removeSuffix("*")), w.endsWith("*"), v)
    }

    private val table: List<Pair<Mood, List<Kw>>> = listOf(
        Mood.TRISTE to kws(
            "sad" to 3.0, "triste*" to 3.0, "melanc*" to 3.0, "sadcore" to 3.0, "slowcore" to 3.0, "blues" to 2.5,
            "emo" to 2.0, "fado" to 2.5, "heartbreak*" to 2.5, "desamor" to 2.5, "lagrima*" to 2.0, "tears" to 2.0,
            "lonely" to 2.0, "soledad" to 2.0, "lament*" to 2.0, "balada*" to 1.5, "ballad*" to 1.5, "bolero*" to 1.5,
            "tango" to 1.5, "trova" to 1.5, "llorar" to 1.5, "cry" to 1.5, "dolor" to 1.5, "singer songwriter" to 1.0
        ),
        Mood.ALEGRE to kws(
            "happy" to 3.0, "feliz" to 3.0, "alegr*" to 3.0, "calypso" to 2.5, "reggae" to 2.0, "ska" to 2.0,
            "vallenato" to 2.0, "tropical" to 2.0, "sunshine" to 2.0, "summer" to 2.0, "verano" to 2.0, "samba" to 2.0,
            "k pop" to 2.0, "j pop" to 2.0, "indie pop" to 2.0, "salsa" to 1.5, "merengue" to 1.5, "cumbia" to 1.5,
            "funk" to 1.5, "disco" to 1.5, "swing" to 1.5, "gospel" to 1.5, "fun" to 1.5, "pop" to 1.2, "latin*" to 1.2,
            "country" to 1.0
        ),
        Mood.ENERGIA to kws(
            "hardcore" to 3.0, "drum and bass" to 3.0, "dnb" to 3.0, "dubstep" to 3.0, "hardstyle" to 3.0,
            "thrash" to 3.0, "workout" to 3.0, "gym" to 3.0, "energ*" to 3.0, "adrenalin*" to 3.0, "metal" to 2.5,
            "punk" to 2.5, "techno" to 2.5, "edm" to 2.5, "trance" to 2.5, "trap" to 2.0, "pump*" to 2.0, "beast" to 2.0,
            "electro*" to 1.8, "hip hop" to 1.5, "rap" to 1.5, "house" to 1.5, "grunge" to 1.5, "power" to 1.5,
            "fuerza" to 1.5, "speed" to 1.5, "rock" to 0.8
        ),
        Mood.ROMANTICA to kws(
            "romant*" to 3.0, "te amo" to 3.0, "slow jam*" to 3.0, "serenata*" to 3.0, "valentine*" to 3.0,
            "crooner*" to 2.5, "te quiero" to 2.5, "wedding" to 2.5, "boda" to 2.5, "amor*" to 2.0, "beso*" to 2.0,
            "bachata" to 2.0, "bolero*" to 2.0, "r b" to 2.0, "rnb" to 2.0, "love" to 1.5, "corazon" to 1.5,
            "soul" to 1.5, "balada*" to 1.5, "ballad*" to 1.5, "kiss*" to 1.5, "heart" to 1.0, "bossa*" to 1.0
        ),
        Mood.NOCTURNA to kws(
            "noct*" to 3.0, "midnight" to 3.0, "medianoche" to 3.0, "synthwave" to 3.0, "darkwave" to 3.0,
            "trip hop" to 3.0, "after hours" to 3.0, "late night" to 3.0, "nocturne*" to 3.0, "chillwave" to 2.5,
            "downtempo" to 2.5, "deep house" to 2.5, "night*" to 2.0, "noche*" to 2.0, "moon*" to 2.0, "luna" to 2.0,
            "dark*" to 1.5, "lounge" to 1.5, "dream*" to 1.5, "sueno*" to 1.5, "lo fi" to 1.2, "lofi" to 1.2,
            "estrella*" to 1.2, "jazz" to 1.0
        ),
        Mood.RELAJANTE to kws(
            "ambient" to 3.0, "chill*" to 3.0, "relax*" to 3.0, "calm*" to 3.0, "calma" to 3.0, "meditat*" to 3.0,
            "new age" to 3.0, "sleep*" to 3.0, "spa" to 3.0, "zen" to 3.0, "yoga" to 3.0, "soothing" to 3.0,
            "easy listening" to 3.0, "healing" to 2.5, "acoustic" to 2.0, "acustic*" to 2.0, "lounge" to 2.0,
            "bossa*" to 2.0, "nature" to 2.0, "naturaleza" to 2.0, "peace*" to 2.0, "soft" to 1.5, "folk" to 1.5,
            "piano" to 1.5, "classical" to 1.5, "clasic*" to 1.5, "lo fi" to 1.5, "lofi" to 1.5, "unplugged" to 1.5,
            "paz" to 1.5, "rain" to 1.5, "lluvia" to 1.5, "jazz" to 1.0
        ),
        Mood.ROCK to kws(
            "rock" to 3.0, "grunge" to 3.0, "britpop" to 3.0, "rockabilly" to 2.5, "stoner" to 2.5, "alternativ*" to 2.5,
            "metal" to 2.0, "punk" to 2.0, "shoegaze" to 2.0, "indie" to 1.5, "garage" to 1.5, "hardcore" to 1.5,
            "progressive" to 1.5, "psychedelic*" to 1.5, "guitar*" to 1.0
        ),
        Mood.FIESTA to kws(
            "party" to 3.0, "fiesta*" to 3.0, "reggaeton" to 3.0, "club*" to 3.0, "dancehall" to 3.0, "perreo" to 3.0,
            "twerk" to 3.0, "trap latino" to 3.0, "dance*" to 2.5, "salsa" to 2.5, "merengue" to 2.5, "urbano*" to 2.5,
            "baile*" to 2.5, "bailar" to 2.5, "rumba*" to 2.5, "cumbia" to 2.0, "edm" to 2.0, "house" to 2.0,
            "disco" to 2.0, "boogie" to 2.0, "bounce" to 2.0, "mambo" to 2.0, "tequila" to 2.0, "electro*" to 1.5,
            "techno" to 1.5, "remix*" to 1.5, "bachata" to 1.5, "funk" to 1.5, "samba" to 1.5, "latin*" to 1.5,
            "hip hop" to 1.0, "pop" to 0.5
        ),
        Mood.CONCENTRACION to kws(
            "instrumental*" to 3.0, "focus*" to 3.0, "study" to 3.0, "estudi*" to 3.0, "concentr*" to 3.0,
            "classical" to 3.0, "clasic*" to 3.0, "baroque" to 3.0, "barroc*" to 3.0, "concerto" to 3.0, "sonata" to 3.0,
            "etude" to 3.0, "chamber" to 3.0, "binaural" to 3.0, "white noise" to 3.0, "deep focus" to 3.0,
            "neo classical" to 3.0, "neoclasic*" to 3.0, "lo fi" to 2.5, "lofi" to 2.5, "post rock" to 2.5,
            "piano" to 2.0, "ambient" to 2.0, "minimal*" to 2.0, "soundtrack*" to 2.0, "orchestr*" to 2.0,
            "orquest*" to 2.0, "symphon*" to 2.0, "sinfon*" to 2.0, "cinematic" to 2.0, "score" to 1.5, "ost" to 1.5
        )
    )

    /** Minúsculas, sin acentos ni signos: "Hip-Hop/Rap" -> "hip hop rap". */
    private fun norm(s: String): String {
        if (s.isBlank()) return ""
        val d = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
        val sb = StringBuilder(d.length)
        var lastSpace = true
        for (ch in d) {
            if (Character.getType(ch) == Character.NON_SPACING_MARK.toInt()) continue
            if (ch.isLetterOrDigit()) { sb.append(ch); lastSpace = false }
            else if (!lastSpace) { sb.append(' '); lastSpace = true }
        }
        return sb.toString().trim()
    }

    private fun pad(s: String): String = norm(s).let { if (it.isEmpty()) "" else " $it " }

    private fun fieldScore(padded: String, list: List<Kw>): Double {
        if (padded.isEmpty()) return 0.0
        var sum = 0.0
        for (k in list) {
            val hit = if (k.prefix) padded.contains(" ${k.text}") else padded.contains(" ${k.text} ")
            if (hit) sum += k.weight
        }
        return min(sum, FIELD_CAP)
    }

    private fun score(s: Song): DoubleArray {
        val genre = pad(s.genre)
        val dir = pad(s.pathKey.substringBeforeLast('/', ""))
        val album = if (s.album == UNKNOWN_ALBUM) "" else pad(s.album)
        val title = pad(s.title)
        val out = DoubleArray(table.size)
        for (i in table.indices) {
            val list = table[i].second
            out[i] = fieldScore(genre, list) + 0.8 * fieldScore(dir, list) +
                0.5 * fieldScore(album, list) + 0.5 * fieldScore(title, list)
        }
        return out
    }

    /** null = sin señal suficiente; [MIXTO] = 3 o más ambientes igual de probables. */
    private fun decide(sc: DoubleArray): List<Mood>? {
        var best = 0
        for (i in sc.indices) if (sc[i] > sc[best]) best = i
        val top = sc[best]
        if (top < MIN_SCORE) return null
        val close = sc.indices.filter { sc[it] >= MIN_SCORE && sc[it] >= top * 0.7 }.sortedByDescending { sc[it] }
        if (close.size >= 3) return listOf(Mood.MIXTO)
        return close.map { table[it].first }
    }

    private class Votes { var n = 0; val w = HashMap<Mood, Double>() }

    private fun vote(map: HashMap<String, Votes>, key: String, moods: List<Mood>) {
        val v = map.getOrPut(key) { Votes() }
        v.n++
        for (m in moods) v.w[m] = (v.w[m] ?: 0.0) + 1.0
    }

    /** Hereda un Mood solo si hay >= 2 canciones ya clasificadas y al menos el 60 % comparten ese Mood. */
    private fun infer(v: Votes?): Mood? {
        if (v == null || v.n < 2) return null
        val top = v.w.entries.maxByOrNull { it.value } ?: return null
        return if (top.value / v.n >= 0.6) top.key else null
    }

    fun classify(songs: List<Song>): Map<Long, List<Mood>> {
        val direct = HashMap<Long, List<Mood>>(songs.size)
        for (s in songs) decide(score(s))?.let { direct[s.id] = it }

        val byArtist = HashMap<String, Votes>()
        val byAlbum = HashMap<String, Votes>()
        for (s in songs) {
            val d = direct[s.id] ?: continue
            if (d.first() == Mood.MIXTO) continue
            if (s.artist != UNKNOWN_ARTIST) vote(byArtist, s.artist, d)
            if (s.album != UNKNOWN_ALBUM) vote(byAlbum, s.album, d)
        }

        val out = HashMap<Long, List<Mood>>(songs.size)
        for (s in songs) {
            val d = direct[s.id]
            out[s.id] = if (d != null) d else {
                val m = (if (s.artist != UNKNOWN_ARTIST) infer(byArtist[s.artist]) else null)
                    ?: (if (s.album != UNKNOWN_ALBUM) infer(byAlbum[s.album]) else null)
                if (m != null) listOf(m) else listOf(Mood.SIN_CLASIFICAR)
            }
        }
        return out
    }
}

private fun countLabel(n: Int) = if (n == 1) "1 canción" else "$n canciones"

// ---------- Pantalla Mood ----------

@Composable
internal fun MoodScreen(vm: PlayerViewModel, onOpen: (Mood) -> Unit) {
    val groups = vm.moodGroups
    val shown = Mood.values().filter { !groups[it].isNullOrEmpty() }   // no se muestran categorías vacías

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item {
            Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 12.dp)) {
                Text("Mood", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    "Tu biblioteca por ambiente. Se clasifica en tu dispositivo, sin Internet.",
                    color = Gray, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
        when {
            vm.songs.isEmpty() -> item { Empty(if (vm.loading) "Escaneando tu biblioteca…" else "Aún no hay canciones para clasificar") }
            shown.isEmpty() -> item { Empty("Clasificando tu biblioteca…") }
            else -> {
                items(shown.chunked(2)) { row ->
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 14.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        row.forEach { m ->
                            MoodTile(vm, m, groups.getValue(m), Modifier.weight(1f), onClick = { onOpen(m) }, onPlay = { vm.playMood(m) })
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
                item {
                    Text(
                        "¿Una canción no encaja? Cambia su Mood desde el menú ⋮.",
                        color = Gray, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

/** Tarjeta de un Mood: carátulas más escuchadas de ese Mood, cantidad y botón de reproducción rápida. */
@Composable
internal fun MoodTile(
    vm: PlayerViewModel, mood: Mood, songs: List<Song>, modifier: Modifier = Modifier,
    subtitle: String? = null, onClick: () -> Unit, onPlay: () -> Unit
) {
    val reps = remember(songs) {
        songs.sortedByDescending { (vm.stats[it.id]?.plays ?: 0) * 2 + if (it.id in vm.favorites) 3 else 0 }.take(6)
    }
    Box(modifier.aspectRatio(1f).pressable(onClick).clip(uiShape(24.dp))) {
        GroupCover(reps, Modifier.fillMaxSize(), px = 400, radius = 0.dp)
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(mood.color.copy(alpha = 0.55f), Color.Black.copy(alpha = 0.85f)))
            )
        )
        Text(mood.emoji, fontSize = 30.sp, modifier = Modifier.align(Alignment.TopStart).padding(14.dp))
        Box(
            Modifier.align(Alignment.TopEnd).padding(10.dp).size(40.dp).clip(CircleShape)
                .background(Color.White.copy(alpha = 0.92f)).clickable(onClick = onPlay),
            Alignment.Center
        ) {
            Icon(painterResource(R.drawable.ic_play), "Reproducir ${mood.label}", tint = Color.Black, modifier = Modifier.size(22.dp))
        }
        Column(Modifier.align(Alignment.BottomStart).padding(14.dp)) {
            Text(mood.label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(
                subtitle ?: countLabel(songs.size), color = Color.White.copy(alpha = 0.78f),
                fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// ---------- Cambiar Mood (menú ⋮ de una canción) ----------

@Composable
internal fun ChangeMoodDialog(vm: PlayerViewModel, song: Song, onDismiss: () -> Unit) {
    val hasManual = song.id in vm.manualMoods
    val initial = remember { vm.moodsOf(song).filter { it.assignable }.toSet() }
    var selected by remember { mutableStateOf(initial) }
    val options = remember { Mood.values().filter { it.assignable } }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("Cambiar Mood") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Gray, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp))
                options.forEach { m ->
                    val on = m in selected
                    Row(
                        Modifier.fillMaxWidth().clickable { selected = if (on) selected - m else selected + m },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = on, onCheckedChange = { selected = if (it) selected + m else selected - m })
                        Text("${m.emoji}  ${m.label}")
                    }
                }
                Text(
                    if (hasManual) "Elegido por ti: tiene prioridad sobre la clasificación automática."
                    else "Ahora es automático. Si eliges otro, tu elección tendrá prioridad.",
                    color = Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
                )
                if (hasManual) TextButton(onClick = { vm.setManualMoods(song.id, emptyList()); onDismiss() }) {
                    Text("Volver a automático")
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (selected != initial) vm.setManualMoods(song.id, options.filter { it in selected })
                    onDismiss()
                },
                enabled = selected.isNotEmpty()
            ) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
