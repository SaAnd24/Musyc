package com.example.musicplayer

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Visor básico de letras del Módulo 10A: muestra el estado y el texto, sin resaltado, auto-scroll ni seek.
 * La experiencia completa tipo Spotify se construirá en el Módulo 10B sobre vm.lyrics.
 */
@Composable
internal fun LyricsScreen(vm: PlayerViewModel, song: Song, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    val l = if (vm.lyricsSongId == song.id) vm.lyrics else LyricsData.LOADING
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Row(Modifier.fillMaxWidth().padding(end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(R.drawable.ic_down, "Cerrar", onClick = onClose)
            Column(Modifier.weight(1f)) {
                Text(song.title, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1)
                Text(song.artist, color = Gray, fontSize = 13.sp, maxLines = 1)
            }
        }
        when {
            l.isLoading || l.status == LyricsStatus.NOT_QUERIED -> Centered {
                CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
                Text("Buscando letras…", color = Gray, modifier = Modifier.padding(top = 12.dp))
            }
            l.hasLyrics -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 12.dp)) {
                val info = (if (l.isSynced) "Sincronizada" else "Sin sincronizar") + if (l.fromCache) " · guardada en tu teléfono" else ""
                Text(info, color = Gray, fontSize = 12.sp, modifier = Modifier.padding(bottom = 12.dp))
                val body = if (l.isSynced) l.lines.joinToString("\n") { it.text } else l.plain
                Text(body, fontSize = 20.sp, lineHeight = 30.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(48.dp))
            }
            else -> Centered {
                Text(
                    if (l.isError) "No se pudieron obtener las letras ahora mismo" else "No hay letras para esta canción",
                    color = Gray
                )
                TextButton(onClick = { vm.retryLyrics() }, modifier = Modifier.padding(top = 8.dp)) { Text("Buscar de nuevo") }
            }
        }
    }
}

@Composable
private fun Centered(content: @Composable ColumnScope.() -> Unit) =
    Box(Modifier.fillMaxSize().padding(32.dp), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, content = content)
    }
