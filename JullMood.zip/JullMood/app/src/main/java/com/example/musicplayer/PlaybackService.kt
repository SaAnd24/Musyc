package com.example.musicplayer

import android.app.PendingIntent
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.Player
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/** Temporizador para dormir: vive en el proceso del servicio, así sigue aunque cierres la pantalla. */
object SleepTimer {
    var leftMs by mutableLongStateOf(0L); private set
    var player: Player? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            leftMs -= 1000
            if (leftMs <= 0) { leftMs = 0; player?.pause() } else handler.postDelayed(this, 1000)
        }
    }
    fun start(minutes: Int) { cancel(); leftMs = minutes * 60_000L; handler.postDelayed(tick, 1000) }
    fun cancel() { handler.removeCallbacks(tick); leftMs = 0 }
}

class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()

        SleepTimer.player = player

        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        session = MediaSession.Builder(this, player).setSessionActivity(openApp).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = session?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        SleepTimer.cancel()
        SleepTimer.player = null
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }
}
