package com.example.musicplayer

import org.json.JSONArray
import org.json.JSONObject
import java.util.Random

/*
 * Motor de frases de Juli (100 % local, sin red, sin servicios, sin hilos propios).
 *
 *   PhraseEngine ── fachada: surprise(ctx) / playback(ctx)
 *    ├─ ContextAnalyzer ........ convierte lo que JullMood YA sabe (historial, favoritos, Mood, hora) en un PhraseContext
 *    ├─ SurprisePhraseProvider . qué categorías de frases encajan con una recomendación de Sorpréndeme
 *    ├─ PlaybackPhraseProvider . qué categorías encajan al elegir una canción normalmente
 *    ├─ PhraseSelector ......... elige categoría (ponderada + cooldown) y frase (sin repetir las recientes)
 *    ├─ PhraseHistory .......... memoria pequeña: últimas frases/categorías por modo + racha de repetición
 *    └─ PhraseBank (PhraseBank.kt) las 600 frases, solo datos
 *
 * Una selección cuesta unas decenas de operaciones sobre listas de < 60 elementos: no hay I/O salvo guardar un JSON
 * de ~2 KB en las SharedPreferences ya existentes (apply() es asíncrono).
 */

internal enum class PhraseMode { SURPRISE, NORMAL }

internal enum class Daypart {
    NIGHT, MORNING, AFTERNOON, EVENING, UNKNOWN;

    companion object {
        /** Mismo reparto de horas que Recommender.timeMoods: noche = 22-5. */
        fun of(hour: Int): Daypart = when (hour) {
            in 22..23, in 0..5 -> NIGHT
            in 6..11 -> MORNING
            in 12..17 -> AFTERNOON
            in 18..21 -> EVENING
            else -> UNKNOWN
        }
    }
}

/** Lo que el selector sabe de una canción en el instante de elegirla. Todo sale de datos que ya existen. */
internal class PhraseContext(
    val mode: PhraseMode,
    val songId: Long,
    val plays: Int,                 // 0 si no hay historial
    val lastPlayedAt: Long,         // 0 = nunca / desconocido
    val isFavorite: Boolean,
    val moods: List<Mood>,          // ya sin SIN_CLASIFICAR / MIXTO
    val hour: Int,                  // -1 si se desconoce
    val now: Long,
    val sameAsCurrent: Boolean = false,
    val heavyPlays: Int = ContextAnalyzer.HEAVY_FALLBACK,
    val surpriseType: SurpriseType? = null
) {
    val isHeavy: Boolean get() = plays >= heavyPlays
    val isForgotten: Boolean get() = plays >= 2 && lastPlayedAt > 0L && now - lastPlayedAt >= ContextAnalyzer.FORGOTTEN_MS
    val isFresh: Boolean get() = plays <= 1
    val daypart: Daypart get() = Daypart.of(hour)
}

internal object ContextAnalyzer {
    const val HEAVY_MIN = 8
    const val HEAVY_MAX = 25
    const val HEAVY_FALLBACK = 10                       // con poco historial se usa un umbral fijo
    const val FORGOTTEN_MS = 30L * 86_400_000L          // "hace semanas/meses": 30 días o más

    /** "Muy escuchada": top ~5 % de la biblioteca, entre [HEAVY_MIN] y [HEAVY_MAX] reproducciones. */
    fun heavyThreshold(stats: Map<Long, SongStat>): Int {
        val plays = stats.values.map { it.plays }.filter { it > 0 }
        if (plays.size < 20) return HEAVY_FALLBACK
        val sorted = plays.sorted()
        val i = (sorted.size * 0.95).toInt().coerceAtMost(sorted.size - 1)
        return sorted[i].coerceIn(HEAVY_MIN, HEAVY_MAX)
    }

    fun build(
        mode: PhraseMode, songId: Long, stats: Map<Long, SongStat>, favs: Set<Long>, moods: List<Mood>,
        hour: Int, now: Long, sameAsCurrent: Boolean = false, type: SurpriseType? = null
    ): PhraseContext {
        val st = stats[songId]
        return PhraseContext(
            mode, songId, st?.plays ?: 0, st?.last ?: 0L, songId in favs,
            moods.filter { it != Mood.SIN_CLASIFICAR && it != Mood.MIXTO }.distinct(),
            hour, now, sameAsCurrent,
            if (mode == PhraseMode.NORMAL) heavyThreshold(stats) else HEAVY_FALLBACK, type
        )
    }
}

/** Una categoría candidata: su clave (para el cooldown), sus frases y su peso relativo. */
internal class PhraseSlot(
    val key: String, val pool: List<String>, val weight: Double,
    val cooldown: Int = 3,              // si esta categoría salió en las últimas [cooldown] frases, pesa 10 veces menos
    val generic: Boolean = false        // genérica = no depende de ningún dato del usuario
)

// ---------- Memoria pequeña (no son cientos de datos: ~40 frases por modo) ----------

internal class PhraseHistory {
    class Track {
        val phrases = ArrayDeque<String>()
        val cats = ArrayDeque<String>()

        fun remember(phrase: String, cat: String) {
            phrases.addLast(phrase); while (phrases.size > MAX_PHRASES) phrases.removeFirst()
            cats.addLast(cat); while (cats.size > MAX_CATS) cats.removeFirst()
        }

        fun toJson(): JSONObject = JSONObject().put("p", JSONArray(phrases.toList())).put("c", JSONArray(cats.toList()))

        fun load(o: JSONObject?) {
            phrases.clear(); cats.clear()
            if (o == null) return
            o.optJSONArray("p")?.let { a -> for (i in 0 until a.length()) phrases.addLast(a.getString(i)) }
            o.optJSONArray("c")?.let { a -> for (i in 0 until a.length()) cats.addLast(a.getString(i)) }
            while (phrases.size > MAX_PHRASES) phrases.removeFirst()
            while (cats.size > MAX_CATS) cats.removeFirst()
        }
    }

    // Cada modo tiene SU memoria: las frases de Sorpréndeme y las de selección normal nunca se mezclan.
    val surprise = Track()
    val normal = Track()
    var lastSongId = 0L        // última canción comentada en selección normal
    var lastAt = 0L
    var streak = 0             // veces seguidas que se repitió esa canción
    var shownAt = 0L           // última vez que se mostró una frase en selección normal

    fun track(m: PhraseMode): Track = if (m == PhraseMode.SURPRISE) surprise else normal

    fun reset() {
        surprise.load(null); normal.load(null)
        lastSongId = 0L; lastAt = 0L; streak = 0; shownAt = 0L
    }

    fun toJson(): String = JSONObject()
        .put("s", surprise.toJson()).put("n", normal.toJson())
        .put("id", lastSongId).put("at", lastAt).put("st", streak).put("sh", shownAt).toString()

    fun load(json: String?) {
        if (json.isNullOrBlank()) return
        val o = JSONObject(json)
        surprise.load(o.optJSONObject("s")); normal.load(o.optJSONObject("n"))
        lastSongId = o.optLong("id", 0L); lastAt = o.optLong("at", 0L)
        streak = o.optInt("st", 0); shownAt = o.optLong("sh", 0L)
    }

    companion object {
        const val MAX_PHRASES = 40     // no repetir la misma frase durante las últimas 40 de ese modo
        const val MAX_CATS = 8
    }
}

// ---------- Selector ----------

internal object PhraseSelector {
    class Result(val key: String, val phrase: String, val generic: Boolean)

    private const val CATEGORY_PENALTY = 0.1
    private const val RELAXED_MEMORY = 5      // si una categoría pequeña se agota, solo se evitan las últimas 5

    /** Categoría ponderada (con cooldown) y luego frase al azar entre las que no se usaron hace poco. Null si no hay nada. */
    fun choose(slots: List<PhraseSlot>, track: PhraseHistory.Track, rnd: Random): Result? {
        val live = slots.filter { it.pool.isNotEmpty() && it.weight > 0.0 }
        if (live.isEmpty()) return null

        val avail = live.map { s ->
            var l = s.pool.filter { it !in track.phrases }
            if (l.isEmpty()) {
                val lastFew = track.phrases.takeLast(RELAXED_MEMORY)
                l = s.pool.filter { it !in lastFew }
            }
            if (l.isEmpty()) s.pool else l
        }
        val w = live.map { s ->
            s.weight * (if (track.cats.takeLast(s.cooldown).contains(s.key)) CATEGORY_PENALTY else 1.0)
        }
        var r = rnd.nextDouble() * w.sum()
        var i = w.size - 1
        for (k in w.indices) { r -= w[k]; if (r <= 0.0) { i = k; break } }
        val slot = live[i]
        val list = avail[i]
        return Result(slot.key, list[rnd.nextInt(list.size)], slot.generic)
    }
}

// ---------- Proveedores: qué categorías encajan en cada modo ----------

internal object SurprisePhraseProvider {
    fun slots(c: PhraseContext): List<PhraseSlot> {
        val out = ArrayList<PhraseSlot>()
        fun add(cat: SurpriseCat, w: Double, cd: Int, generic: Boolean = false) {
            out += PhraseSlot(cat.name, PhraseBank.surprise(cat), w, cd, generic)
        }

        // 1) Frase acorde al tipo de recomendación (sin revelar necesariamente por qué se eligió).
        when (c.surpriseType) {
            SurpriseType.REDISCOVER -> add(SurpriseCat.NOSTALGIA, 6.0, 2)
            SurpriseType.FAVORITE -> add(SurpriseCat.FAVORITA, 6.0, 2)
            SurpriseType.DISCOVERY -> { add(SurpriseCat.DESCUBRIMIENTO, 5.0, 2); add(SurpriseCat.RUTINA, 1.0, 2) }
            SurpriseType.DEEP_CUT -> { add(SurpriseCat.DESCUBRIMIENTO, 5.0, 2); add(SurpriseCat.RUTINA, 1.0, 2) }
            SurpriseType.WILDCARD -> add(SurpriseCat.RUTINA, 5.0, 2)
            SurpriseType.MOOD -> {}
            null -> {}
        }
        // 2) Momento del día, solo si la canción de verdad encaja (Mood nocturno/relajante de noche; alegre/energía por la mañana).
        val moodType = c.surpriseType == SurpriseType.MOOD
        if (c.daypart == Daypart.NIGHT && c.moods.any { it == Mood.NOCTURNA || it == Mood.RELAJANTE })
            add(SurpriseCat.NOCHE, if (moodType) 5.0 else 2.0, 3)
        if (c.daypart == Daypart.MORNING && c.moods.any { it == Mood.ALEGRE || it == Mood.ENERGIA })
            add(SurpriseCat.MANANA, if (moodType) 4.0 else 1.5, 3)
        // 3) Genéricas (recomendación general): siempre disponibles.
        add(SurpriseCat.CURIOSIDAD, 0.5, 2, true)
        add(SurpriseCat.MISTERIO, 0.4, 2, true)
        add(SurpriseCat.RECOMENDACION, 0.6, 2, true)
        add(SurpriseCat.CONFIANZA, 0.4, 2, true)
        add(SurpriseCat.HUMOR, 0.35, 2, true)
        return out
    }
}

internal object PlaybackPhraseProvider {
    /** [streak] = veces seguidas que se repite esta misma canción (0 = primera vez). */
    fun slots(c: PhraseContext, streak: Int): List<PhraseSlot> {
        // Misma canción otra vez: el tipo de comentario cambia con cada repetición (2.ª, 3.ª, 4.ª o más).
        if (streak >= 1) {
            val cat = when (streak) {
                1 -> NormalCat.REPETIDA_1
                2 -> NormalCat.REPETIDA_2
                else -> NormalCat.REPETIDA_3
            }
            return listOf(PhraseSlot(cat.name, PhraseBank.normal(cat), 1.0, 1))
        }
        val out = ArrayList<PhraseSlot>()
        fun add(cat: NormalCat, w: Double, cd: Int, generic: Boolean = false) {
            out += PhraseSlot(cat.name, PhraseBank.normal(cat), w, cd, generic)
        }

        // Contextuales por historial: solo si el dato existe y es cierto.
        if (c.isHeavy) add(NormalCat.CLASICO, 0.9, 4)
        if (c.isForgotten) add(NormalCat.OLVIDADA, 1.4, 3)
        if (c.isFavorite) add(NormalCat.FAVORITA, 0.8, 4)
        if (c.isFresh) add(NormalCat.NUEVA, 0.8, 4)

        // Mood: un slot por Mood de la canción (el peso total del Mood se reparte entre ellos).
        for (m in c.moods) out += PhraseSlot("MOOD_${m.name}", PhraseBank.normalMood(m), 0.5 / c.moods.size, 4)

        // Momento del día (hora local del dispositivo).
        when (c.daypart) {
            Daypart.NIGHT -> add(NormalCat.TIEMPO_NOCHE, 0.35, 5)
            Daypart.MORNING -> add(NormalCat.TIEMPO_MANANA, 0.35, 5)
            Daypart.AFTERNOON -> add(NormalCat.TIEMPO_TARDE, 0.3, 5)
            Daypart.EVENING -> {}
            Daypart.UNKNOWN -> {}
        }

        // Genéricas: sirven para cualquier canción aunque no haya ningún dato.
        add(NormalCat.APROBACION, 0.45, 2, true)
        add(NormalCat.HUMOR, 0.3, 2, true)
        add(NormalCat.ENTUSIASMO, 0.4, 2, true)
        return out
    }
}

// ---------- Fachada ----------

internal class PhraseEngine(
    private val rnd: Random = Random(),
    private val store: (String?) -> Unit = {}      // guarda (o borra con null) la memoria; en la app son las SharedPreferences
) {
    private val h = PhraseHistory()

    companion object {
        const val FALLBACK_SURPRISE = "Esto podría gustarte…"
        const val MIN_GAP_MS = 2_500L                    // dos toques casi seguidos no generan dos frases
        const val REPEAT_WINDOW_MS = 15 * 60_000L        // "acaba de repetirse": misma canción en menos de 15 min
        const val GENERIC_SHOW_P = 0.7                   // una frase genérica no sale siempre (no molestar); las contextuales sí
        const val NAG_SHOW_P = 0.5                       // a partir de la 5.ª repetición seguida solo comenta la mitad de las veces
    }

    fun load(json: String?) { runCatching { h.load(json) }.onFailure { h.reset() } }

    /** "Borrar historial de escucha" también reinicia rachas y memoria de frases. */
    fun clear() { h.reset(); store(null) }

    /** Frase de Sorpréndeme. Siempre devuelve una. */
    fun surprise(ctx: PhraseContext): String {
        val res = PhraseSelector.choose(SurprisePhraseProvider.slots(ctx), h.surprise, rnd) ?: return FALLBACK_SURPRISE
        h.surprise.remember(res.phrase, res.key)
        save()
        return res.phrase
    }

    /** Frase al elegir una canción normalmente. Null = esta vez Juli no comenta (genérica sin suerte, toques muy seguidos...). */
    fun playback(ctx: PhraseContext): String? {
        // Racha: misma canción otra vez en poco tiempo. Se actualiza SIEMPRE, se muestre o no la frase.
        val again = h.lastSongId == ctx.songId && ctx.now - h.lastAt in 0L..REPEAT_WINDOW_MS
        val streak = when {
            again -> h.streak + 1
            ctx.sameAsCurrent -> 1
            else -> 0
        }
        h.lastSongId = ctx.songId; h.lastAt = ctx.now; h.streak = streak

        var out: String? = null
        val gap = ctx.now - h.shownAt
        if (gap < 0L || gap >= MIN_GAP_MS) {
            val res = PhraseSelector.choose(PlaybackPhraseProvider.slots(ctx, streak), h.normal, rnd)
            if (res != null) {
                val p = when {
                    streak >= 4 -> NAG_SHOW_P
                    res.generic -> GENERIC_SHOW_P
                    else -> 1.0
                }
                if (rnd.nextDouble() < p) {
                    h.normal.remember(res.phrase, res.key)
                    h.shownAt = ctx.now
                    out = res.phrase
                }
            }
        }
        save()
        return out
    }

    private fun save() { runCatching { store(h.toJson()) } }
}
