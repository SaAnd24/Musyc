package com.example.musicplayer

import kotlin.math.min

/** Accesos rápidos de escucha. Aleatorio reutiliza "Sorpréndeme" (selección ponderada, no un shuffle plano). */
enum class ListeningMode(val emoji: String, val label: String) {
    NIGHT("🌙", "Noche"),
    ENERGY("🔥", "Energía"),
    RELAX("😌", "Relax"),
    HEADPHONES("🎧", "Auriculares"),
    RANDOM("🎲", "Aleatorio")
}

/**
 * Cada modo puntúa las canciones con los datos que JullMood ya tiene: Mood (clasificación automática o manual),
 * género, favoritos, frecuencia de reproducción, afinidad de artista, omisiones y lo que sonó hace poco.
 * MediaStore no expone el BPM, así que la "energía" se infiere del Mood y del género, no de un tempo medido.
 *
 * Si casi ninguna canción encaja con el modo (biblioteca sin géneros ni Moods, por ejemplo) se completa con la
 * selección general de "Sorpréndeme" y se avisa en la nota, en vez de devolver una lista vacía o mala.
 */
object ListeningModes {
    private const val UNKNOWN_ALBUM = "Álbum desconocido"
    private const val MATCH = 0.8                 // puntuación mínima de "encaje" para considerar que una canción pertenece al modo
    private const val ENOUGH = 10                 // por debajo de esto se completa con la selección general
    private val LOSSLESS = setOf("flac", "wav", "alac", "ape", "aiff", "aif", "wv")

    private val moodWeights: Map<ListeningMode, Map<Mood, Double>> = mapOf(
        ListeningMode.NIGHT to mapOf(
            Mood.NOCTURNA to 2.0, Mood.RELAJANTE to 1.3, Mood.ROMANTICA to 1.0, Mood.TRISTE to 0.8, Mood.CONCENTRACION to 0.6,
            Mood.ENERGIA to -1.5, Mood.FIESTA to -1.5, Mood.ROCK to -0.6
        ),
        ListeningMode.ENERGY to mapOf(
            Mood.ENERGIA to 2.0, Mood.FIESTA to 1.5, Mood.ROCK to 1.2, Mood.ALEGRE to 0.8,
            Mood.RELAJANTE to -1.5, Mood.NOCTURNA to -1.0, Mood.TRISTE to -1.2, Mood.CONCENTRACION to -0.8
        ),
        ListeningMode.RELAX to mapOf(
            Mood.RELAJANTE to 2.0, Mood.CONCENTRACION to 1.2, Mood.ROMANTICA to 0.8, Mood.NOCTURNA to 0.6,
            Mood.ENERGIA to -1.5, Mood.FIESTA to -1.5, Mood.ROCK to -1.0
        )
    )

    /** Palabras de género (minúsculas) que refuerzan el modo además del Mood. */
    private val genreWords: Map<ListeningMode, List<String>> = mapOf(
        ListeningMode.NIGHT to listOf("jazz", "lounge", "ambient", "chill", "lofi", "lo-fi", "downtempo", "trip", "synthwave", "soul", "r&b", "blues"),
        ListeningMode.ENERGY to listOf("rock", "metal", "punk", "dance", "electro", "house", "techno", "hip", "rap", "trap", "edm", "drum", "hardcore", "reggaeton"),
        ListeningMode.RELAX to listOf("ambient", "chill", "acoustic", "folk", "new age", "classical", "piano", "lounge", "bossa", "jazz", "instrumental"),
        ListeningMode.HEADPHONES to listOf("classical", "jazz", "ambient", "electronic", "progressive", "post-rock", "soundtrack", "psychedelic", "orchestral", "instrumental", "experimental")
    )

    private class Cand(val song: Song, val fit: Double, val score: Double)

    fun build(
        mode: ListeningMode, songs: List<Song>, stats: Map<Long, SongStat>, favs: Set<Long>, skips: Map<Long, Int>,
        moodsOf: (Song) -> List<Mood>, now: Long, avoid: Set<Long>, hour: Int, seed: Long, count: Int = 30
    ): Surprise {
        if (songs.isEmpty()) return Surprise(emptyList(), "")
        if (mode == ListeningMode.RANDOM) return Recommender.surprise(songs, stats, favs, skips, moodsOf, now, avoid, hour, seed, count)

        val rnd = java.util.Random(seed)
        val weights = moodWeights[mode].orEmpty()
        val words = genreWords[mode].orEmpty()

        // Afinidad por artista (reproducciones + favoritos), normalizada 0..1.
        val artistTotal = HashMap<String, Double>()
        for (s in songs) {
            val v = (stats[s.id]?.plays ?: 0) + (if (s.id in favs) 3 else 0)
            if (v > 0) artistTotal[s.artist] = (artistTotal[s.artist] ?: 0.0) + v
        }
        val mx = artistTotal.values.maxOrNull() ?: 0.0
        fun affinity(a: String) = if (mx <= 0.0) 0.0 else (artistTotal[a] ?: 0.0) / mx

        val all = songs.map { s ->
            // Encaje con el modo: lo mejor de sus Moods (y lo peor, si es incompatible) + género + rasgos del archivo.
            val w = moodsOf(s).map { weights[it] ?: 0.0 }
            var fit = (w.maxOrNull() ?: 0.0).coerceAtLeast(0.0) + (w.minOrNull() ?: 0.0).coerceAtMost(0.0)
            val g = s.genre.lowercase()
            if (g.isNotEmpty() && words.any { g.contains(it) }) fit += 0.9
            if (mode == ListeningMode.HEADPHONES) {
                if (s.pathKey.substringAfterLast('.', "") in LOSSLESS) fit += 0.8
                if (s.durationMs >= 210_000L) fit += 0.5
                if (s.durationMs >= 300_000L) fit += 0.3
            }

            val st = stats[s.id]
            var v = fit + rnd.nextDouble() * 0.6
            if (s.id in favs) v += 1.0
            v += 0.12 * min(st?.plays ?: 0, 8)
            v += 0.7 * affinity(s.artist)
            val last = st?.last ?: 0L
            if (last > 0L && now - last < 6 * 3_600_000L) v -= 1.2     // no repetir lo que acaba de sonar
            v -= 0.7 * min(skips[s.id] ?: 0, 4)
            if (s.id in avoid) v -= 1.0
            Cand(s, fit, v)
        }

        val pool = all.filter { it.fit >= MATCH }.sortedByDescending { it.score }.take(300).toMutableList()
        val picked = ArrayList<Song>()

        // Auriculares: escucha de álbum completo, en su orden, de los álbumes que mejor puntúan.
        if (mode == ListeningMode.HEADPHONES) {
            val scoreOf = all.associate { it.song.id to it }
            val albums = songs.filter { it.album != UNKNOWN_ALBUM }.groupBy { it.album }
                .filterValues { it.size >= 5 }
                .map { (name, l) -> name to l.sumOf { scoreOf.getValue(it.id).score } / l.size }
                .filter { (_, avg) -> avg >= MATCH }
                .sortedByDescending { it.second }
                .take(2)
            for ((name, _) in albums) {
                for (s in songs.filter { it.album == name }.sortedWith(AlbumOrder)) if (picked.size < count) picked += s
            }
            pool.removeAll { c -> picked.any { it.id == c.song.id } }
        }

        // El resto: elige de una en una penalizando repetir artista o álbum (variedad).
        val artistN = HashMap<String, Int>()
        val albumN = HashMap<String, Int>()
        for (s in picked) { artistN[s.artist] = (artistN[s.artist] ?: 0) + 1; albumN[s.album] = (albumN[s.album] ?: 0) + 1 }
        while (picked.size < count && pool.isNotEmpty()) {
            var bi = 0
            var bv = Double.NEGATIVE_INFINITY
            for (i in pool.indices) {
                val s = pool[i].song
                val ap = if (s.artist == "Artista desconocido") 0 else (artistN[s.artist] ?: 0)
                val lp = if (s.album == UNKNOWN_ALBUM) 0 else (albumN[s.album] ?: 0)
                val v = pool[i].score - 1.4 * ap - 0.9 * lp
                if (v > bv) { bv = v; bi = i }
            }
            val s = pool.removeAt(bi).song
            picked += s
            artistN[s.artist] = (artistN[s.artist] ?: 0) + 1
            albumN[s.album] = (albumN[s.album] ?: 0) + 1
        }

        val label = "${mode.emoji} ${mode.label}"
        if (picked.size >= ENOUGH) return Surprise(picked, "Modo $label · según tu música")

        // Degradación: pocas canciones encajan; se completa con la selección general.
        val have = picked.map { it.id }.toSet()
        val general = Recommender.surprise(songs, stats, favs, skips, moodsOf, now, avoid + have, hour, seed, count).songs
            .filter { it.id !in have }
        val out = picked + general.take(count - picked.size)
        val note = if (picked.isEmpty()) "Aún no hay datos para $label: mezcla general según tus gustos"
        else "Pocas canciones encajan con $label: la completamos con tu mezcla general"
        return Surprise(out, note)
    }
}
