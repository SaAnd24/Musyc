package com.example.musicplayer

import android.os.SystemClock
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Se marca la línea unos milisegundos antes para compensar el fotograma de pantalla y la animación. */
private const val LEAD_MS = 120L
/** Posición vertical de la línea actual dentro del panel (0 = arriba, 0.5 = centro). */
private const val FOCUS = 0.36f
/** Tiempo sin tocar las letras antes de volver a seguir la línea actual. */
private const val RESUME_MS = 3_500L

/**
 * Segunda página del reproductor a pantalla completa (módulo 10B). Solo LEE el estado de 10A (`vm.lyrics`) y la
 * posición del reproductor; no descarga ni guarda nada. Seek = `vm.seekTo`, el mismo del slider.
 */
@Composable
internal fun LyricsPage(vm: PlayerViewModel, song: Song, accent: Color, onBack: () -> Unit) {
    // Si el estado de letras aún pertenece a la canción anterior, nunca se muestra: se considera "cargando".
    val l = if (vm.lyricsSongId == song.id) vm.lyrics else LyricsData.LOADING
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 4.dp, top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Cover(song, Modifier.size(44.dp), radius = 8.dp)
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(song.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("♪ Letras · ${song.artist}", color = Gray, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconBtn(R.drawable.ic_up, "Volver al reproductor", accent, onClick = onBack)
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                l.isSynced && l.lines.isNotEmpty() ->
                    key(song.id, l.updatedAt) { SyncedLyrics(vm, l, accent) }
                l.hasLyrics -> PlainLyrics(l.plain.ifBlank { l.lines.joinToString("\n") { it.text } })
                l.isLoading || l.status == LyricsStatus.NOT_QUERIED -> Centered {
                    CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp, color = accent)
                    Text("Buscando letras…", color = Gray, modifier = Modifier.padding(top = 12.dp))
                }
                l.isError -> Centered {
                    Text("♪", fontSize = 40.sp, color = Gray)
                    Text("No se pudieron cargar las letras", color = Gray, modifier = Modifier.padding(top = 8.dp))
                    FilledTonalButton(onClick = { vm.retryLyrics() }, modifier = Modifier.padding(top = 12.dp)) { Text("Reintentar") }
                }
                else -> Centered {
                    Text("♪", fontSize = 40.sp, color = Gray)
                    Text("No hay letras disponibles", color = Gray, modifier = Modifier.padding(top = 8.dp))
                    TextButton(onClick = { vm.retryLyrics() }, modifier = Modifier.padding(top = 4.dp)) { Text("Buscar de nuevo") }
                }
            }
        }
        LyricsControls(vm, accent)
    }
}

// ---------- Letras sincronizadas ----------

@Composable
private fun SyncedLyrics(vm: PlayerViewModel, data: LyricsData, accent: Color) {
    val lines = data.lines
    val reduced = LocalUi.current.reducedMotion
    val listState = rememberLazyListState()
    val index = remember { mutableIntStateOf(-1) }       // línea actual: solo cambia cuando hace falta
    val frac = remember { mutableFloatStateOf(0f) }      // avance dentro de la línea (solo lo lee el dibujo)
    var following by remember { mutableStateOf(true) }
    var holdUntil by remember { mutableLongStateOf(0L) } // breve "congelado" tras un seek por toque
    var last by remember { mutableIntStateOf(-99) }      // última línea centrada

    // Seguimiento: lee la posición REAL del reproductor en cada fotograma (o cada 120 ms si está en pausa,
    // para reaccionar igualmente a un seek). Solo se escribe estado cuando la línea o el avance cambian.
    LaunchedEffect(data) {
        while (true) {
            if (SystemClock.elapsedRealtime() >= holdUntil) {
                val pos = vm.livePosition() + LEAD_MS
                val i = data.lineIndexAt(pos)
                var f = 0f
                if (i >= 0) {
                    val ln = lines[i]
                    val gap = ((lines.getOrNull(i + 1)?.timestampMs ?: (ln.timestampMs + 5_000L)) - ln.timestampMs).coerceAtLeast(1L)
                    // Duración estimada de cantar la línea (LRCLIB solo da el inicio de cada línea).
                    val sing = min(gap, max(1_000L, ln.text.length * 115L))
                    f = if (reduced) 1f else ((pos - ln.timestampMs).toFloat() / sing).coerceIn(0f, 1f)
                }
                if (abs(f - frac.floatValue) > 0.003f || f == 0f) frac.floatValue = f
                if (i != index.intValue) index.intValue = i
            }
            if (vm.isPlaying) withFrameNanos { } else delay(120)
        }
    }

    // Scroll manual: mientras el usuario arrastra no se le devuelve a la línea actual; vuelve solo tras unos segundos.
    val dragged by listState.interactionSource.collectIsDraggedAsState()
    LaunchedEffect(dragged) {
        if (dragged) following = false
        else if (!following) { delay(RESUME_MS); following = true }
    }

    // Auto-scroll: solo cuando cambia la línea (o al recuperar el seguimiento).
    LaunchedEffect(following) {
        if (!following) return@LaunchedEffect
        snapshotFlow { listState.layoutInfo.viewportSize.height }.first { it > 0 }
        snapshotFlow { index.intValue }.collectLatest { idx ->
            if (idx < 0) return@collectLatest
            val vh = listState.layoutInfo.viewportSize.height
            val item = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == idx + 1 }   // +1: espacio superior
            val jump = reduced || last < 0 || abs(idx - last) > 6 || item == null                    // primera vez o seek lejano
            last = idx
            if (jump) {
                listState.scrollToItem(idx + 1, -(vh * FOCUS).toInt())
                listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == idx + 1 }?.let {
                    listState.scrollBy(it.offset + it.size / 2f - vh * FOCUS)
                }
            } else {
                listState.animateScrollBy(item!!.offset + item.size / 2f - vh * FOCUS, tween(450, easing = FastOutSlowInEasing))
            }
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val vh = maxHeight
        LazyColumn(state = listState, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 20.dp)) {
            item(key = "top") { Spacer(Modifier.height(vh * FOCUS)) }
            itemsIndexed(lines, key = { i, _ -> i }) { i, line ->
                LyricRow(i, line, index, frac, accent, reduced) {
                    vm.seekTo(line.timestampMs)                    // el mismo seek que el slider
                    index.intValue = i; frac.floatValue = 0f       // respuesta inmediata
                    holdUntil = SystemClock.elapsedRealtime() + 300
                    following = true
                }
            }
            item(key = "bottom") { Spacer(Modifier.height(vh * (1f - FOCUS))) }
        }
        AnimatedVisibility(
            visible = !following && index.intValue >= 0,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp)
        ) {
            FilledTonalButton(onClick = { following = true }) { Text("Ir a la línea actual") }
        }
    }
}

@Composable
private fun LyricRow(
    i: Int, line: LyricLine, index: MutableIntState, frac: MutableFloatState,
    accent: Color, reduced: Boolean, onClick: () -> Unit
) {
    // 0 = pasada, 1 = actual, 2 = futura. derivedStateOf: al cambiar de línea solo se recomponen las filas afectadas.
    val rel by remember(i) { derivedStateOf { val c = index.intValue; if (i < c) 0 else if (i == c) 1 else 2 } }
    val current = rel == 1
    val onBg = MaterialTheme.colorScheme.onBackground
    val a by animateFloatAsState(
        when (rel) { 1 -> 0.62f; 0 -> 0.45f; else -> 0.55f }, if (reduced) snap() else tween(280), label = "lyricAlpha"
    )
    val text = line.text.ifBlank { "♪" }
    val layout = remember { arrayOfNulls<TextLayoutResult>(1) }

    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .clickable(onClickLabel = "Ir a este momento de la canción", role = Role.Button, onClick = onClick)
            .drawBehind {
                // Marcador lateral: la línea actual no depende solo del color.
                if (current) drawRoundRect(accent, Offset(0f, 8.dp.toPx()), Size(3.dp.toPx(), size.height - 16.dp.toPx()), CornerRadius(2.dp.toPx()))
            }
            .padding(start = 14.dp, end = 6.dp, top = 10.dp, bottom = 10.dp)
    ) {
        Text(text, color = onBg.copy(alpha = a), fontSize = 26.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold)
        if (current) {
            // Capa brillante recortada según el avance: rellena la línea de izquierda a derecha al ritmo de la canción.
            Text(
                text, color = onBg, fontSize = 26.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold,
                onTextLayout = { layout[0] = it },
                modifier = Modifier.drawWithContent {
                    val f = if (reduced) 1f else frac.floatValue          // leído en el dibujo: no recompone
                    val lr = layout[0]
                    if (f >= 0.999f || lr == null) { drawContent(); return@drawWithContent }
                    var total = 0f
                    for (k in 0 until lr.lineCount) total += lr.getLineRight(k) - lr.getLineLeft(k)
                    var left = f * total
                    for (k in 0 until lr.lineCount) {
                        val w = lr.getLineRight(k) - lr.getLineLeft(k)
                        val take = left.coerceIn(0f, w)
                        left -= take
                        if (take <= 0f) break
                        val x = lr.getLineLeft(k)
                        clipRect(x, lr.getLineTop(k), x + take, lr.getLineBottom(k)) { this@drawWithContent.drawContent() }
                    }
                }
            )
        }
    }
}

// ---------- Letras sin sincronizar ----------

@Composable
private fun PlainLyrics(text: String) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 12.dp)) {
        Text(text, fontSize = 20.sp, lineHeight = 30.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.92f))
        Spacer(Modifier.height(48.dp))
    }
}

// ---------- Controles compactos (mismas funciones del reproductor) ----------

@Composable
private fun LyricsControls(vm: PlayerViewModel, accent: Color) {
    val frac = if (vm.duration > 0) (vm.position.toFloat() / vm.duration).coerceIn(0f, 1f) else 0f
    Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 4.dp)) {
        Box(Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(2.dp)).background(accent.copy(alpha = 0.25f))) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(accent))
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            IconBtn(R.drawable.ic_prev, "Anterior", size = 30.dp) { vm.previous() }
            FilledIconButton(onClick = { vm.togglePlay() }, modifier = Modifier.padding(horizontal = 20.dp).size(52.dp)) {
                Icon(painterResource(if (vm.isPlaying) R.drawable.ic_pause else R.drawable.ic_play), "Play/Pausa", Modifier.size(30.dp))
            }
            IconBtn(R.drawable.ic_next, "Siguiente", size = 30.dp) { vm.next() }
        }
    }
}

@Composable
private fun Centered(content: @Composable ColumnScope.() -> Unit) =
    Box(Modifier.fillMaxSize().padding(32.dp), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, content = content)
    }
