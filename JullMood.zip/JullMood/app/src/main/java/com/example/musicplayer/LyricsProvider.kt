package com.example.musicplayer

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs

/** Abstracción del proveedor: para cambiar de servicio basta otra implementación. Se llama fuera del hilo principal. */
interface LyricsProvider {
    val name: String
    fun fetch(q: LyricsQuery): ProviderResult
}

/**
 * LRCLIB (https://lrclib.net): API pública y gratuita de letras, sin clave.
 * Solo se envían título, artista, álbum y duración. Nunca rutas ni archivos.
 */
class LrclibProvider : LyricsProvider {
    override val name = "lrclib"

    private val base = "https://lrclib.net/api"
    private val userAgent = "JullMood/1.0 (Android music player)"

    override fun fetch(q: LyricsQuery): ProviderResult {
        if (!q.usable) return ProviderResult.NotFound
        return try {
            // 1) Coincidencia exacta por título + artista + álbum + duración.
            val exact = get("$base/get?" + params(q, withAlbum = true, withDuration = q.durationSec > 0))
            when (exact.code) {
                200 -> toFound(parseObject(exact.body), q)?.let { return it }
                404 -> Unit
                else -> return ProviderResult.Failure("HTTP ${exact.code}")
            }
            // 2) Búsqueda más flexible, eligiendo solo candidatos que encajen de verdad.
            val search = get("$base/search?" + params(q, withAlbum = false, withDuration = false))
            when (search.code) {
                200 -> pickBest(JSONArray(search.body), q)?.let { return it } ?: ProviderResult.NotFound
                404 -> ProviderResult.NotFound
                else -> ProviderResult.Failure("HTTP ${search.code}")
            }
        } catch (e: IOException) {
            ProviderResult.Failure("red: ${e.javaClass.simpleName}")
        } catch (e: org.json.JSONException) {
            ProviderResult.Failure("JSON inválido")
        } catch (e: Exception) {
            ProviderResult.Failure(e.javaClass.simpleName)
        }
    }

    private fun params(q: LyricsQuery, withAlbum: Boolean, withDuration: Boolean): String {
        fun enc(s: String) = URLEncoder.encode(s.trim(), "UTF-8")
        val sb = StringBuilder("track_name=${enc(q.title)}&artist_name=${enc(q.artist)}")
        if (withAlbum && q.album.isNotBlank() && !q.album.startsWith("Álbum desconocido")) sb.append("&album_name=${enc(q.album)}")
        if (withDuration) sb.append("&duration=${q.durationSec}")
        return sb.toString()
    }

    private class Http(val code: Int, val body: String)

    private fun get(url: String): Http {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8_000
            c.readTimeout = 10_000
            c.requestMethod = "GET"
            c.setRequestProperty("User-Agent", userAgent)
            c.setRequestProperty("Accept", "application/json")
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText().take(2_000_000) }.orEmpty()
            return Http(code, body)
        } finally { c.disconnect() }
    }

    private fun parseObject(body: String): JSONObject = JSONObject(body)

    private fun toFound(o: JSONObject, q: LyricsQuery): ProviderResult.Found? {
        if (o.optBoolean("instrumental", false)) return null
        val synced = o.optString("syncedLyrics", "").takeIf { it.isNotBlank() && it != "null" }
        val plain = o.optString("plainLyrics", "").takeIf { it.isNotBlank() && it != "null" }
        if (synced == null && plain == null) return null
        return ProviderResult.Found(synced, plain, name)
    }

    /** Descarta candidatos cuya duración difiera más de 3 s o cuyo título/artista no coincida. */
    private fun pickBest(arr: JSONArray, q: LyricsQuery): ProviderResult.Found? {
        fun n(s: String) = s.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()
        val title = n(q.title); val artist = n(q.artist)
        var best: JSONObject? = null
        var bestScore = Int.MIN_VALUE
        for (i in 0 until minOf(arr.length(), 20)) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optBoolean("instrumental", false)) continue
            val t = n(o.optString("trackName")); val a = n(o.optString("artistName"))
            if (t != title) continue
            if (!(a == artist || a.contains(artist) || artist.contains(a))) continue
            val dur = o.optDouble("duration", -1.0)
            if (q.durationSec > 0 && dur > 0 && abs(dur - q.durationSec) > 3.0) continue
            var score = 0
            if (a == artist) score += 4
            if (n(o.optString("albumName")) == n(q.album)) score += 2
            if (o.optString("syncedLyrics", "").isNotBlank()) score += 3
            if (q.durationSec > 0 && dur > 0) score += (3 - abs(dur - q.durationSec)).toInt()
            if (score > bestScore) { bestScore = score; best = o }
        }
        return best?.let { toFound(it, q) }
    }
}
