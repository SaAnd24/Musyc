package com.example.musicplayer

import kotlin.math.exp

/** Historial por canción: nº de reproducciones "reales" y última vez que sonó (ms epoch). */
data class SongStat(val plays: Int = 0, val last: Long = 0L)

class AlbumGroup(val name: String, val artist: String, val songs: List<Song>)
class ArtistGroup(val name: String, val songs: List<Song>)
class Mix(val title: String, val subtitle: String, val songs: List<Song>)
class Suggestion(val song: Song, val reason: String)

class HomeData(
    val hasHistory: Boolean,
    val continueTitle: String, val continueSongs: List<Song>,
    val mixes: List<Mix>,
    val favorites: List<Song>,
    val albumsTitle: String, val albums: List<AlbumGroup>,
    val artistsTitle: String, val artists: List<ArtistGroup>,
    val mostPlayed: List<Song>,
    val suggestions: List<Suggestion>,
    val added: List<Song>,
    val discover: List<Song>
)

/**
 * Recomendaciones 100 % locales y deterministas: misma biblioteca + mismo historial + misma semilla
 * => mismo resultado. La semilla cambia cada día (o al pulsar "Mezclar"), así el Home se siente vivo.
 *
 * Puntuación de una canción = reproducciones*2 + bonus por reciente (decae en ~14 días) + bonus si es favorita.
 * La afinidad de artista/álbum/género es la suma de puntuaciones normalizada (0..1).
 * Si no hay historial ni favoritos, todo cae a contenido útil: recientes, artistas y álbumes por tamaño.
 */
object Recommender {
    private const val DAY_MS = 86_400_000.0
    private const val UNKNOWN_ARTIST = "Artista desconocido"
    private const val UNKNOWN_ALBUM = "Álbum desconocido"

    fun build(songs: List<Song>, stats: Map<Long, SongStat>, favs: Set<Long>, now: Long, seed: Long): HomeData {
        val hasHistory = stats.values.any { it.last > 0L }
        val favSongs = songs.filter { it.id in favs }
        val hasSignal = hasHistory || favSongs.isNotEmpty()

        fun last(s: Song) = stats[s.id]?.last ?: 0L
        fun plays(s: Song) = stats[s.id]?.plays ?: 0
        fun jitter(s: Song, salt: Long = 0L): Double {
            val x = (s.id + seed * 7919L + salt) * 2654435761L
            return ((x ushr 12) and 0xFFFFL) / 65535.0
        }
        fun score(s: Song): Double {
            var v = plays(s) * 2.0
            val l = last(s)
            if (l > 0L) v += 2.0 * exp(-((now - l) / DAY_MS).coerceAtLeast(0.0) / 14.0)
            if (s.id in favs) v += 3.0
            return v
        }
        fun ranked(l: List<Song>) = l.sortedByDescending { score(it) + 0.8 * jitter(it, 11L) }
        fun seeded(l: List<Song>, salt: Long = 0L) = l.shuffled(java.util.Random(seed + salt))

        val byArtist = songs.groupBy { it.artist }
        val byAlbum = songs.groupBy { it.album }
        val byGenre = songs.filter { it.genre.isNotBlank() }.groupBy { it.genre.trim() }

        val artistScore = byArtist.mapValues { e -> e.value.sumOf { score(it) } }
        val albumScore = byAlbum.mapValues { e -> e.value.sumOf { score(it) } }
        val genreScore = byGenre.mapValues { e -> e.value.sumOf { score(it) } }
        fun norm(m: Map<String, Double>): Map<String, Double> {
            val mx = m.values.maxOrNull() ?: 0.0
            return if (mx <= 0.0) m.mapValues { 0.0 } else m.mapValues { it.value / mx }
        }
        val artistAff = norm(artistScore)
        val albumAff = norm(albumScore)
        val genreAff = norm(genreScore)

        // ---- Añadidas recientemente ----
        val added = songs.sortedByDescending { it.dateAdded }.take(12)

        // ---- Continúa escuchando ----
        val played = songs.filter { last(it) > 0L }.sortedByDescending { last(it) }
        val continueTitle: String
        val continueSongs: List<Song>
        if (hasHistory) {
            val base = played.take(10)
            continueSongs = if (base.size >= 4) base
            else (base + added.filter { a -> base.none { it.id == a.id } }).take(6)
            continueTitle = "Continúa escuchando"
        } else {
            continueSongs = added.take(8)
            continueTitle = "Empieza por aquí"
        }

        // ---- Favoritos ----
        val favorites = favSongs
            .sortedWith(compareByDescending<Song> { plays(it) }.thenBy { it.title.lowercase() })
            .take(12)

        // ---- Álbumes ----
        fun albumGroup(name: String, l: List<Song>) = AlbumGroup(
            name,
            l.groupingBy { it.artist }.eachCount().maxByOrNull { it.value }?.key ?: UNKNOWN_ARTIST,
            l
        )
        val realAlbums = byAlbum.filterKeys { it != UNKNOWN_ALBUM }
        val albumsTitle: String
        val albums: List<AlbumGroup>
        if (hasHistory) {
            albumsTitle = "Escuchado recientemente"
            albums = realAlbums.entries
                .filter { e -> e.value.any { last(it) > 0L } }
                .sortedByDescending { e -> e.value.maxOf { last(it) } }
                .take(10).map { albumGroup(it.key, it.value) }
        } else {
            albumsTitle = "Álbumes de tu biblioteca"
            albums = realAlbums.entries
                .sortedWith(compareByDescending<Map.Entry<String, List<Song>>> { e -> e.value.maxOf { it.dateAdded } }
                    .thenBy { it.key.lowercase() })
                .take(10).map { albumGroup(it.key, it.value) }
        }

        // ---- Artistas ----
        val rankedArtistNames = byArtist.keys.filter { it != UNKNOWN_ARTIST }.sortedWith(
            compareByDescending<String> { artistScore[it] ?: 0.0 }
                .thenByDescending { byArtist[it]?.size ?: 0 }
                .thenBy { it.lowercase() }
        )
        val artists = rankedArtistNames.take(12).map { ArtistGroup(it, byArtist.getValue(it)) }
        val artistsTitle = if (hasSignal) "Tus artistas" else "Artistas de tu biblioteca"

        // ---- Más escuchadas ----
        val mostPlayed = songs.filter { plays(it) > 0 }
            .sortedWith(compareByDescending<Song> { plays(it) }.thenByDescending { last(it) })
            .take(5)

        // ---- Quizás te guste ----
        class Scored(val song: Song, val total: Double, val reason: String)
        val suggestions: List<Suggestion> = if (hasSignal) {
            val recentCut = now - 3 * 86_400_000L
            val scored = songs.asSequence()
                .filter { plays(it) <= 1 && last(it) < recentCut }
                .map { s ->
                    val a = if (s.artist == UNKNOWN_ARTIST) 0.0 else artistAff[s.artist] ?: 0.0
                    val al = if (s.album == UNKNOWN_ALBUM) 0.0 else albumAff[s.album] ?: 0.0
                    val g = if (s.genre.isBlank()) 0.0 else genreAff[s.genre.trim()] ?: 0.0
                    val reason = when {
                        a >= g && a > 0.05 -> "Porque escuchas a ${s.artist}"
                        g > 0.05 -> "Te suena a ${s.genre.trim()}"
                        al > 0.05 -> "De un álbum que te gusta"
                        else -> "De tu biblioteca"
                    }
                    Scored(s, 3.0 * a + 1.5 * al + 1.5 * g + 0.3 * jitter(s, 5L), reason)
                }
                .sortedByDescending { it.total }
                .toList()
            val perArtist = HashMap<String, Int>()
            val picked = ArrayList<Suggestion>()
            for (sc in scored) {
                val n = perArtist[sc.song.artist] ?: 0
                if (n >= 2) continue
                perArtist[sc.song.artist] = n + 1
                picked += Suggestion(sc.song, sc.reason)
                if (picked.size >= 12) break
            }
            if (picked.size < 8) {
                val ids = picked.map { it.song.id }.toSet()
                picked += seeded(songs.filter { it.id !in ids }, 3L).take(8 - picked.size)
                    .map { Suggestion(it, "Descubre algo nuevo") }
            }
            picked
        } else {
            seeded(songs, 3L).take(10).map { Suggestion(it, "De tu biblioteca") }
        }

        // ---- Descubre tu biblioteca ----
        val sugIds = suggestions.map { it.song.id }.toSet()
        val discover = seeded(songs, 9L).filter { it.id !in sugIds }.take(12)

        // ---- Hecho para ti (mixes) ----
        val mixes = ArrayList<Mix>()
        val daily = if (hasSignal) ranked(songs).take(25) else seeded(songs, 1L).take(25)
        if (daily.size >= 3) mixes += Mix("Mix diario", "Lo mejor de tu biblioteca hoy", daily)

        for (a in rankedArtistNames.filter { (byArtist[it]?.size ?: 0) >= 2 }.take(2)) {
            val own = ranked(byArtist.getValue(a)).take(12)
            val genre = own.map { it.genre.trim() }.filter { it.isNotEmpty() }
                .groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
            val similar = if (genre != null) ranked(byGenre[genre].orEmpty().filter { it.artist != a }).take(10) else emptyList()
            val list = seeded(own + similar, a.hashCode().toLong())
            if (list.size >= 3) mixes += Mix(
                "Mix $a",
                if (similar.isNotEmpty()) "$a y artistas parecidos" else "Lo mejor de $a",
                list
            )
        }

        val topGenre = byGenre.entries.filter { it.value.size >= 4 }.sortedWith(
            compareByDescending<Map.Entry<String, List<Song>>> { genreScore[it.key] ?: 0.0 }
                .thenByDescending { it.value.size }
                .thenBy { it.key }
        ).firstOrNull()
        if (topGenre != null) mixes += Mix("Mix ${topGenre.key}", "Tu música de ${topGenre.key}", seeded(topGenre.value, 17L).take(25))

        return HomeData(
            hasHistory, continueTitle, continueSongs, mixes.take(5), favorites,
            albumsTitle, albums, artistsTitle, artists, mostPlayed, suggestions, added, discover
        )
    }
}
