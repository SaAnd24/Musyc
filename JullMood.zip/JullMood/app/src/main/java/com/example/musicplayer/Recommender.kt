package com.example.musicplayer

import kotlin.math.exp
import kotlin.math.min

/**
 * Historial por canción (único historial de la app): nº de reproducciones "reales", última vez que sonó (ms epoch),
 * tiempo escuchado y las fechas de las últimas reproducciones (para semanas y "volviste a escuchar").
 * Los campos nuevos tienen valor por defecto: el historial guardado por versiones anteriores sigue leyéndose.
 */
data class SongStat(
    val plays: Int = 0, val last: Long = 0L,
    val listenedMs: Long = 0L, val recent: List<Long> = emptyList()
) {
    companion object { const val MAX_RECENT = 10 }
}

class AlbumGroup(val name: String, val artist: String, val songs: List<Song>)
class ArtistGroup(val name: String, val songs: List<Song>)
class Mix(val title: String, val subtitle: String, val songs: List<Song>)
class Suggestion(val song: Song, val reason: String)
class MoodSuggestion(val mood: Mood, val count: Int, val reason: String, val songs: List<Song>)
class Surprise(val songs: List<Song>, val note: String)

class HomeData(
    val hasHistory: Boolean,
    val continueTitle: String, val continueSongs: List<Song>,
    val mixes: List<Mix>,
    val favorites: List<Song>,
    val albumsTitle: String, val albums: List<AlbumGroup>,
    val artistsTitle: String, val artists: List<ArtistGroup>,
    val mostPlayed: List<Song>,
    val suggestions: List<Suggestion>,
    val added: List<Song>,
    val discover: List<Song>,
    val forgotten: List<Song> = emptyList(), val forgottenNote: String? = null,
    val rediscover: List<Song> = emptyList(),
    val moods: List<MoodSuggestion> = emptyList(),
    val message: String? = null
)

/**
 * Recomendaciones 100 % locales y deterministas: misma biblioteca + mismo historial + misma semilla
 * => mismo resultado. La semilla cambia cada día (o al pulsar "Mezclar"), así el Home se siente vivo.
 *
 * Puntuación de una canción = reproducciones*2 + bonus por reciente (decae en ~14 días) + bonus si es favorita.
 * La afinidad de artista/álbum/género es la suma de puntuaciones normalizada (0..1).
 * Si no hay historial ni favoritos, todo cae a contenido útil: recientes, artistas y álbumes por tamaño.
 */
object Recommender {
    private const val DAY_MS = 86_400_000.0
    private const val UNKNOWN_ARTIST = "Artista desconocido"
    private const val UNKNOWN_ALBUM = "Álbum desconocido"

    private fun limitPerArtist(l: List<Song>, per: Int, max: Int): List<Song> {
        val n = HashMap<String, Int>()
        val out = ArrayList<Song>()
        for (s in l) {
            val c = n[s.artist] ?: 0
            if (s.artist != UNKNOWN_ARTIST && c >= per) continue
            n[s.artist] = c + 1
            out += s
            if (out.size >= max) break
        }
        return out
    }

    /** Moods que encajan con la hora del día (0-23). */
    private fun timeMoods(hour: Int): List<Pair<Mood, String>> = when (hour) {
        in 0..5, in 22..23 -> listOf(Mood.NOCTURNA to "Para esta noche", Mood.RELAJANTE to "Para desconectar")
        in 6..11 -> listOf(Mood.ALEGRE to "Para empezar el día", Mood.ENERGIA to "Para ponerte en marcha")
        in 12..17 -> listOf(Mood.CONCENTRACION to "Para esta tarde", Mood.ENERGIA to "Para no bajar el ritmo")
        in 18..21 -> listOf(Mood.ROCK to "Para cerrar el día", Mood.ROMANTICA to "Para el atardecer", Mood.RELAJANTE to "Para bajar revoluciones")
        else -> emptyList()
    }

    fun build(
        songs: List<Song>, stats: Map<Long, SongStat>, favs: Set<Long>, now: Long, seed: Long,
        skips: Map<Long, Int> = emptyMap(), moodsOf: (Song) -> List<Mood> = { emptyList() }, hour: Int = -1
    ): HomeData {
        val hasHistory = stats.values.any { it.last > 0L }
        val favSongs = songs.filter { it.id in favs }
        val hasSignal = hasHistory || favSongs.isNotEmpty()

        fun last(s: Song) = stats[s.id]?.last ?: 0L
        fun plays(s: Song) = stats[s.id]?.plays ?: 0
        fun jitter(s: Song, salt: Long = 0L): Double {
            val x = (s.id + seed * 7919L + salt) * 2654435761L
            return ((x ushr 12) and 0xFFFFL) / 65535.0
        }
        fun skipsOf(s: Song) = skips[s.id] ?: 0
        fun score(s: Song): Double {
            var v = plays(s) * 2.0
            val l = last(s)
            if (l > 0L) v += 2.0 * exp(-((now - l) / DAY_MS).coerceAtLeast(0.0) / 14.0)
            if (s.id in favs) v += 3.0
            v -= 0.6 * min(skipsOf(s), 5)       // las canciones que sueles omitir pesan menos
            return v.coerceAtLeast(0.0)
        }
        fun ranked(l: List<Song>) = l.sortedByDescending { score(it) + 0.8 * jitter(it, 11L) }
        fun seeded(l: List<Song>, salt: Long = 0L) = l.shuffled(java.util.Random(seed + salt))

        val byArtist = songs.groupBy { it.artist }
        val byAlbum = songs.groupBy { it.album }
        val byGenre = songs.filter { it.genre.isNotBlank() }.groupBy { it.genre.trim() }

        val artistScore = byArtist.mapValues { e -> e.value.sumOf { score(it) } }
        val albumScore = byAlbum.mapValues { e -> e.value.sumOf { score(it) } }
        val genreScore = byGenre.mapValues { e -> e.value.sumOf { score(it) } }
        fun norm(m: Map<String, Double>): Map<String, Double> {
            val mx = m.values.maxOrNull() ?: 0.0
            return if (mx <= 0.0) m.mapValues { 0.0 } else m.mapValues { it.value / mx }
        }
        val artistAff = norm(artistScore)
        val albumAff = norm(albumScore)
        val genreAff = norm(genreScore)

        // ---- Añadidas recientemente ----
        val added = songs.sortedByDescending { it.dateAdded }.take(12)

        // ---- Continúa escuchando ----
        val played = songs.filter { last(it) > 0L }.sortedByDescending { last(it) }
        val continueTitle: String
        val continueSongs: List<Song>
        if (hasHistory) {
            val base = played.take(10)
            continueSongs = if (base.size >= 4) base
            else (base + added.filter { a -> base.none { it.id == a.id } }).take(6)
            continueTitle = "Continúa escuchando"
        } else {
            continueSongs = added.take(8)
            continueTitle = "Empieza por aquí"
        }

        // ---- Favoritos ----
        val favorites = favSongs
            .sortedWith(compareByDescending<Song> { plays(it) }.thenBy { it.title.lowercase() })
            .take(12)

        // ---- Álbumes ----
        fun albumGroup(name: String, l: List<Song>) = AlbumGroup(
            name,
            l.groupingBy { it.artist }.eachCount().maxByOrNull { it.value }?.key ?: UNKNOWN_ARTIST,
            l
        )
        val realAlbums = byAlbum.filterKeys { it != UNKNOWN_ALBUM }
        val albumsTitle: String
        val albums: List<AlbumGroup>
        if (hasHistory) {
            albumsTitle = "Escuchado recientemente"
            albums = realAlbums.entries
                .filter { e -> e.value.any { last(it) > 0L } }
                .sortedByDescending { e -> e.value.maxOf { last(it) } }
                .take(10).map { albumGroup(it.key, it.value) }
        } else {
            albumsTitle = "Álbumes de tu biblioteca"
            albums = realAlbums.entries
                .sortedWith(compareByDescending<Map.Entry<String, List<Song>>> { e -> e.value.maxOf { it.dateAdded } }
                    .thenBy { it.key.lowercase() })
                .take(10).map { albumGroup(it.key, it.value) }
        }

        // ---- Artistas ----
        val rankedArtistNames = byArtist.keys.filter { it != UNKNOWN_ARTIST }.sortedWith(
            compareByDescending<String> { artistScore[it] ?: 0.0 }
                .thenByDescending { byArtist[it]?.size ?: 0 }
                .thenBy { it.lowercase() }
        )
        val artists = rankedArtistNames.take(12).map { ArtistGroup(it, byArtist.getValue(it)) }
        val artistsTitle = if (hasSignal) "Tus artistas" else "Artistas de tu biblioteca"

        // ---- Más escuchadas ----
        val mostPlayed = songs.filter { plays(it) > 0 }
            .sortedWith(compareByDescending<Song> { plays(it) }.thenByDescending { last(it) })
            .take(5)

        // ---- Quizás te guste ----
        class Scored(val song: Song, val total: Double, val reason: String)
        val suggestions: List<Suggestion> = if (hasSignal) {
            val recentCut = now - 3 * 86_400_000L
            val scored = songs.asSequence()
                .filter { plays(it) <= 1 && last(it) < recentCut && skipsOf(it) < 3 }
                .map { s ->
                    val a = if (s.artist == UNKNOWN_ARTIST) 0.0 else artistAff[s.artist] ?: 0.0
                    val al = if (s.album == UNKNOWN_ALBUM) 0.0 else albumAff[s.album] ?: 0.0
                    val g = if (s.genre.isBlank()) 0.0 else genreAff[s.genre.trim()] ?: 0.0
                    val reason = when {
                        a >= g && a > 0.05 -> "Porque escuchas a ${s.artist}"
                        g > 0.05 -> "Te suena a ${s.genre.trim()}"
                        al > 0.05 -> "De un álbum que te gusta"
                        else -> "De tu biblioteca"
                    }
                    Scored(s, 3.0 * a + 1.5 * al + 1.5 * g + 0.3 * jitter(s, 5L), reason)
                }
                .sortedByDescending { it.total }
                .toList()
            val perArtist = HashMap<String, Int>()
            val picked = ArrayList<Suggestion>()
            for (sc in scored) {
                val n = perArtist[sc.song.artist] ?: 0
                if (n >= 2) continue
                perArtist[sc.song.artist] = n + 1
                picked += Suggestion(sc.song, sc.reason)
                if (picked.size >= 12) break
            }
            if (picked.size < 8) {
                val ids = picked.map { it.song.id }.toSet()
                picked += seeded(songs.filter { it.id !in ids }, 3L).take(8 - picked.size)
                    .map { Suggestion(it, "Descubre algo nuevo") }
            }
            picked
        } else {
            seeded(songs, 3L).take(10).map { Suggestion(it, "De tu biblioteca") }
        }

        // ---- Descubre tu biblioteca ----
        val sugIds = suggestions.map { it.song.id }.toSet()
        val discover = seeded(songs, 9L).filter { it.id !in sugIds }.take(12)

        // ---- Hecho para ti (mixes) ----
        val mixes = ArrayList<Mix>()
        val daily = if (hasSignal) ranked(songs).take(25) else seeded(songs, 1L).take(25)
        if (daily.size >= 3) mixes += Mix("Mix diario", "Lo mejor de tu biblioteca hoy", daily)

        for (a in rankedArtistNames.filter { (byArtist[it]?.size ?: 0) >= 2 }.take(2)) {
            val own = ranked(byArtist.getValue(a)).take(12)
            val genre = own.map { it.genre.trim() }.filter { it.isNotEmpty() }
                .groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
            val similar = if (genre != null) ranked(byGenre[genre].orEmpty().filter { it.artist != a }).take(10) else emptyList()
            val list = seeded(own + similar, a.hashCode().toLong())
            if (list.size >= 3) mixes += Mix(
                "Mix $a",
                if (similar.isNotEmpty()) "$a y artistas parecidos" else "Lo mejor de $a",
                list
            )
        }

        val topGenre = byGenre.entries.filter { it.value.size >= 4 }.sortedWith(
            compareByDescending<Map.Entry<String, List<Song>>> { genreScore[it.key] ?: 0.0 }
                .thenByDescending { it.value.size }
                .thenBy { it.key }
        ).firstOrNull()
        if (topGenre != null) mixes += Mix("Mix ${topGenre.key}", "Tu música de ${topGenre.key}", seeded(topGenre.value, 17L).take(25))

        // ---- Hace tiempo no escuchas… (canciones que solías poner y llevan >30 días sin sonar) ----
        val longAgo = now - 30L * 86_400_000L
        val forgottenPool = songs.filter { plays(it) >= 2 && last(it) in 1L until longAgo && skipsOf(it) < 3 }
            .sortedByDescending { plays(it) + 1.5 * jitter(it, 21L) }
        val forgotten = limitPerArtist(forgottenPool, 2, 12).let { if (it.size >= 3) it else emptyList() }
        val forgottenNote = forgotten.groupingBy { it.artist }.eachCount()
            .filter { it.key != UNKNOWN_ARTIST && it.value >= 2 }.maxByOrNull { it.value }?.key
            ?.let { "Hace tiempo no escuchas a $it" } ?: "Canciones que solías poner"

        // ---- Redescubre tu música (nunca reproducidas, de artistas que te suenan) ----
        val forgottenIds = forgotten.map { it.id }.toSet()
        val rediscoverPool = if (hasHistory) songs.filter {
            plays(it) == 0 && (it.dateAdded == 0L || it.dateAdded < longAgo) && skipsOf(it) < 3 && it.id !in forgottenIds
        }.sortedByDescending { s ->
            (if (s.artist == UNKNOWN_ARTIST) 0.0 else artistAff[s.artist] ?: 0.0) * 2.0 + jitter(s, 33L)
        } else emptyList()
        val rediscover = limitPerArtist(rediscoverPool, 2, 12).let { if (it.size >= 4) it else emptyList() }

        // ---- Moods recomendados ----
        val moodGroups = HashMap<Mood, MutableList<Song>>()
        val weekly = HashMap<Mood, Int>()
        val weekCut = now - 7L * 86_400_000L
        for (s in songs) for (m in moodsOf(s)) {
            if (m == Mood.SIN_CLASIFICAR || m == Mood.MIXTO) continue
            moodGroups.getOrPut(m) { ArrayList() }.add(s)
            if (last(s) >= weekCut) weekly[m] = (weekly[m] ?: 0) + 1
        }
        val weeklyTop = weekly.entries.filter { it.value >= 3 }.maxByOrNull { it.value }?.key
        val moodSuggestions = ArrayList<MoodSuggestion>()
        fun addMood(m: Mood?, reason: String) {
            if (m == null || moodSuggestions.any { it.mood == m }) return
            val g = moodGroups[m] ?: return
            if (g.size < 5) return
            moodSuggestions += MoodSuggestion(m, g.size, reason, ranked(g).take(30))
        }
        addMood(weeklyTop, "Tu Mood de esta semana")
        for ((m, r) in timeMoods(hour)) addMood(m, r)
        for (e in moodGroups.entries.sortedByDescending { it.value.size }) addMood(e.key, "Muy presente en tu biblioteca")

        // ---- Mensaje contextual (uno solo, rota cada día; a veces ninguno) ----
        val messages = ArrayList<String>()
        val artistPlays = HashMap<String, Int>()
        val artistLast = HashMap<String, Long>()
        for (s in songs) {
            if (s.artist == UNKNOWN_ARTIST) continue
            if (plays(s) > 0) artistPlays[s.artist] = (artistPlays[s.artist] ?: 0) + plays(s)
            if (last(s) > (artistLast[s.artist] ?: 0L)) artistLast[s.artist] = last(s)
        }
        artistPlays.filter { it.value >= 3 && (artistLast[it.key] ?: 0L) in 1L until longAgo }
            .maxByOrNull { it.value }?.let { messages += "Hace tiempo no escuchas a ${it.key}." }
        val recentCut5 = now - 5L * 86_400_000L
        songs.filter { it.artist != UNKNOWN_ARTIST && last(it) >= recentCut5 }.groupBy { it.artist }
            .filter { e -> e.value.size >= 3 && e.value.minOf { last(it) } <= now - 2L * 86_400_000L }
            .maxByOrNull { it.value.size }?.let { messages += "Llevas varios días escuchando a ${it.key}." }
        weeklyTop?.let { messages += "Tu Mood más escuchado esta semana: ${it.emoji} ${it.label}." }
        if (rediscover.isNotEmpty()) messages += "Redescubre tu música: hay canciones que todavía no has puesto."
        val message = messages.getOrNull(Math.floorMod(seed, (messages.size + 1).toLong()).toInt())

        return HomeData(
            hasHistory, continueTitle, continueSongs, mixes.take(5), favorites,
            albumsTitle, albums, artistsTitle, artists, mostPlayed, suggestions, added, discover,
            forgotten = forgotten, forgottenNote = forgottenNote, rediscover = rediscover,
            moods = moodSuggestions.take(4), message = message
        )
    }

    /**
     * "Sorpréndeme": no es un shuffle. Puntúa cada canción (favoritos, frecuencia, poco escuchadas,
     * afinidad de artista, Mood objetivo, omitidas y recientes) y elige de una en una penalizando
     * repetir artista o álbum. `avoid` = canciones a no repetir de inmediato.
     */
    fun surprise(
        songs: List<Song>, stats: Map<Long, SongStat>, favs: Set<Long>, skips: Map<Long, Int>,
        moodsOf: (Song) -> List<Mood>, now: Long, avoid: Set<Long>, hour: Int, seed: Long, count: Int = 25
    ): Surprise {
        if (songs.isEmpty()) return Surprise(emptyList(), "")
        val rnd = java.util.Random(seed)
        val pool = songs.filter { it.id !in avoid }.ifEmpty { songs }
        val hasHistory = stats.values.any { it.last > 0L }

        // Mood objetivo: el de la semana, uno acorde a la hora, o ninguno (variedad total).
        val weekCut = now - 7L * 86_400_000L
        val moodCount = HashMap<Mood, Int>()
        val weekly = HashMap<Mood, Int>()
        for (s in songs) for (m in moodsOf(s)) {
            if (m == Mood.SIN_CLASIFICAR || m == Mood.MIXTO) continue
            moodCount[m] = (moodCount[m] ?: 0) + 1
            if ((stats[s.id]?.last ?: 0L) >= weekCut) weekly[m] = (weekly[m] ?: 0) + 1
        }
        val options = ArrayList<Mood?>()
        weekly.entries.filter { it.value >= 3 }.maxByOrNull { it.value }?.key?.let { options += it }
        timeMoods(hour).forEach { options += it.first }
        options.add(null)
        val usable = options.filter { it == null || (moodCount[it] ?: 0) >= 8 }
        val target: Mood? = usable[rnd.nextInt(usable.size)]

        // Afinidad por artista (reproducciones + favoritos), normalizada 0..1.
        val artistTotal = HashMap<String, Double>()
        for (s in songs) {
            val v = (stats[s.id]?.plays ?: 0) + (if (s.id in favs) 3 else 0)
            if (v > 0) artistTotal[s.artist] = (artistTotal[s.artist] ?: 0.0) + v
        }
        val mx = artistTotal.values.maxOrNull() ?: 0.0
        fun affinity(a: String) = if (mx <= 0.0) 0.0 else (artistTotal[a] ?: 0.0) / mx

        class Cand(val song: Song, val score: Double)
        val scored = pool.map { s ->
            val plays = stats[s.id]?.plays ?: 0
            val last = stats[s.id]?.last ?: 0L
            var v = rnd.nextDouble() * 1.4
            if (s.id in favs) v += 1.2
            v += 0.12 * min(plays, 8)
            if (hasHistory) { if (plays == 0) v += 0.6 else if (plays <= 1) v += 0.3 }
            if (last > 0L) {
                val age = now - last
                if (age < 12 * 3_600_000L) v -= 1.5 else if (age < 3L * 86_400_000L) v -= 0.6
            }
            v -= 0.7 * min(skips[s.id] ?: 0, 4)
            if (target != null && target in moodsOf(s)) v += 1.3
            v += 0.8 * affinity(s.artist)
            Cand(s, v)
        }.sortedByDescending { it.score }.take(300).toMutableList()

        val artistN = HashMap<String, Int>()
        val albumN = HashMap<String, Int>()
        val picked = ArrayList<Song>()
        while (picked.size < count && scored.isNotEmpty()) {
            var bi = 0
            var bv = Double.NEGATIVE_INFINITY
            for (i in scored.indices) {
                val s = scored[i].song
                val artistPen = if (s.artist == UNKNOWN_ARTIST) 0 else (artistN[s.artist] ?: 0)
                val albumPen = if (s.album == UNKNOWN_ALBUM) 0 else (albumN[s.album] ?: 0)
                val v = scored[i].score - 1.6 * artistPen - 1.0 * albumPen
                if (v > bv) { bv = v; bi = i }
            }
            val s = scored.removeAt(bi).song
            picked += s
            artistN[s.artist] = (artistN[s.artist] ?: 0) + 1
            albumN[s.album] = (albumN[s.album] ?: 0) + 1
        }
        val note = if (target != null) "Sorpresa con aire ${target.emoji} ${target.label}" else "Mezcla sorpresa según tus gustos"
        return Surprise(picked, note)
    }
}
