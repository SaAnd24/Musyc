package com.example.musicplayer

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Icon

/**
 * Orden original del álbum: por disco/pista si el archivo la trae; si no, por nombre de archivo
 * (casi siempre empieza por el número de pista) y por último por título.
 */
internal val AlbumOrder: Comparator<Song> =
    compareBy<Song>({ it.track <= 0 }, { it.track }, { it.pathKey }, { it.title.lowercase() })

private fun albumDuration(ms: Long): String {
    val min = ms / 60_000L
    return if (min >= 60) "${min / 60} h ${min % 60} min" else "${maxOf(min, 1L)} min"
}

/** Modo álbum: portada, datos, reproducir/aleatorio y lista en orden. Usa la misma cola y reproductor de siempre. */
@Composable
internal fun AlbumScreen(vm: PlayerViewModel, name: String, onBack: () -> Unit, onAdd: (Song) -> Unit) {
    val list = remember(vm.songs, name) { vm.songs.filter { it.album == name }.sortedWith(AlbumOrder) }
    val artist = remember(list) {
        val counts = list.groupingBy { it.artist }.eachCount()
        if (counts.size > 3) "Varios artistas" else counts.maxByOrNull { it.value }?.key.orEmpty()
    }
    val year = remember(list) {
        list.map { it.year }.filter { it in 1900..2100 }.groupingBy { it }.eachCount()
            .maxByOrNull { it.value }?.key ?: 0
    }
    val totalMs = remember(list) { list.sumOf { it.durationMs } }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(R.drawable.ic_down, "Volver", rotate = true, onClick = onBack)
            Text("Álbum", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
        if (list.isEmpty()) Empty("Este álbum ya no tiene canciones") else LazyColumn(Modifier.fillMaxSize()) {
            item {
                Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    GroupCover(list, Modifier.size(220.dp), px = 600, radius = 24.dp)
                    Text(
                        name, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center,
                        maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 16.dp)
                    )
                    Text(artist, color = Gray, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
                    Text(
                        listOfNotNull(
                            if (year > 0) year.toString() else null,
                            if (list.size == 1) "1 canción" else "${list.size} canciones",
                            if (totalMs > 0) albumDuration(totalMs) else null
                        ).joinToString(" · "),
                        color = Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)
                    )
                    Row(Modifier.padding(top = 14.dp, bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { vm.playSong(list.first(), list) }, shape = uiShape(16.dp)) {
                            Icon(painterResource(R.drawable.ic_play), null, Modifier.size(20.dp)); Text("  Reproducir")
                        }
                        FilledTonalButton(onClick = { vm.playShuffled(list) }, shape = uiShape(16.dp)) {
                            Icon(painterResource(R.drawable.ic_shuffle), null, Modifier.size(20.dp)); Text("  Aleatorio")
                        }
                    }
                }
            }
            // Tocar una canción reproduce el álbum desde ahí, conservando el orden.
            itemsIndexed(list, key = { _, s -> s.id }) { i, s -> SongRow(vm, s, list, onAdd, null, number = i + 1) }
        }
    }
}
