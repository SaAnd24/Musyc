package com.example.musicplayer

import android.app.Application
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/** Guarda el error de un crash para mostrarlo en el siguiente arranque. */
class CrashApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                File(filesDir, "crash.txt").writeText("Hilo: ${t.name}\n\n$sw")
            }
            old?.uncaughtException(t, e)
        }
    }
}
