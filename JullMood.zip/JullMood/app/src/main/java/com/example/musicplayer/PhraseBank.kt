package com.example.musicplayer

/*
 * Banco de frases de Juli. SOLO DATOS: aquí no hay lógica. Para añadir o cambiar una frase basta con editar la lista
 * de su categoría (la lógica de selección está en PhraseEngine.kt).
 *
 * Reglas para escribir frases nuevas:
 *  · Cortas (3-8 palabras; alguna puede ser algo más larga). Sin $ ni comillas dobles dentro del texto.
 *  · Una frase de una categoría contextual (favorita, olvidada, repetida, Mood...) solo se muestra cuando esa condición
 *    es cierta, así que puede afirmarla. Las categorías genéricas NO deben afirmar nada sobre el historial del usuario.
 *  · Emojis y "bro" solo de vez en cuando.
 */

/** Categorías de Sorpréndeme. Las 5 primeras son genéricas (sirven para cualquier recomendación). */
internal enum class SurpriseCat { CURIOSIDAD, MISTERIO, RECOMENDACION, CONFIANZA, HUMOR, DESCUBRIMIENTO, RUTINA, NOSTALGIA, FAVORITA, NOCHE, MANANA }

/** Categorías de selección normal. Los Moods tienen su propio mapa (ver [PhraseBank.normalMood]). */
internal enum class NormalCat {
    APROBACION, HUMOR, ENTUSIASMO,            // genéricas
    CLASICO, OLVIDADA, FAVORITA, NUEVA,       // contextuales por historial
    REPETIDA_1, REPETIDA_2, REPETIDA_3,       // misma canción otra vez (2.ª, 3.ª y 4.ª o más)
    TIEMPO_NOCHE, TIEMPO_MANANA, TIEMPO_TARDE // momento del día
}

internal object PhraseBank {
    fun surprise(c: SurpriseCat): List<String> = SURPRISE[c].orEmpty()
    fun normal(c: NormalCat): List<String> = NORMAL[c].orEmpty()
    fun normalMood(m: Mood): List<String> = NORMAL_MOOD[m].orEmpty()

    fun surpriseTotal(): Int = SURPRISE.values.sumOf { it.size }
    fun normalTotal(): Int = NORMAL.values.sumOf { it.size } + NORMAL_MOOD.values.sumOf { it.size }

    // =====================================================================================================
    //  SORPRÉNDEME  (≈ 300)
    // =====================================================================================================

    private val S_CURIOSIDAD = listOf(
        "Esto podría gustarte…", "A ver qué opinas de esta.", "Tengo curiosidad por tu reacción.", "¿Qué tal esto? 👀",
        "Quiero saber qué te parece.", "A ver si esta te dice algo.", "Me intriga tu veredicto.", "Cuéntame luego qué tal.",
        "¿Y si probamos esta?", "Veamos cómo te cae esta.", "A ver si conectas con esta.", "Hagamos un pequeño experimento.",
        "Pongamos a prueba tu oído.", "A ver cómo reaccionas.", "Me pregunto si te va a enganchar.", "Prueba esta y me dices.",
        "¿Cómo te suena esta?", "Dame unos segundos para convencerte.", "Veamos si hay química.", "Escucha con atención esta.",
        "A ver si acierto con esta.", "Quiero tu veredicto.", "Atento a lo que viene.", "Escúchala hasta el final, ¿sí?",
        "Esta merece tu opinión.", "Veamos qué provoca esta.", "Te la dejo a prueba.", "¿Química o no? Dime tú.",
        "A ver si esta te mueve algo.", "Vamos a ver si esta pega.", "Primer round: esta.", "Una pregunta: ¿te convence?",
        "Curiosidad pura con esta.", "Veremos si me da la razón.", "A ver si estoy en lo cierto.", "Me quedo esperando tu reacción.",
        "Pongo esta y observo.", "Dime si te saca una sonrisa."
    )

    private val S_MISTERIO = listOf(
        "Tengo algo para ti.", "No preguntes, solo escucha.", "Confía y escucha.", "Esta salió de la nada 👀",
        "Sin pistas, solo música.", "No te voy a decir mucho.", "Sorpresa guardada para ahora.", "Algo salió de la manga.",
        "Escondida hasta este momento.", "Mejor no te adelanto nada.", "Aquí hay algo que no esperabas.", "Sin spoilers: solo escucha.",
        "Digamos que esta apareció.", "Salió de un rincón de tu biblioteca.", "Abre bien los oídos.", "Apareció de repente.",
        "No sé explicarlo, escucha.", "Una pista: ninguna.", "Hay cosas que se explican solas.", "Esta llegó con misterio.",
        "Lo que viene es sorpresa.", "Sin explicación, con música.", "Elegida a ciegas, más o menos.", "Salida del sombrero.",
        "Una carta que no esperabas.", "Aquí viene lo inesperado.", "Lo prometido: una sorpresa.", "Esto no estaba en el plan.",
        "Pasa algo con esta.", "Misterio resuelto en unos segundos.", "El destino puso esta.", "Hoy el azar tiene opinión."
    )

    private val S_RECOMENDACION = listOf(
        "Encontré algo interesante.", "Esta tiene algo…", "Quizá esta sea la indicada.", "Creo que esta te va a gustar.",
        "Mi recomendación del momento.", "Te recomiendo esta sin pensarlo.", "Esta va contigo, creo.", "Apuesto por esta.",
        "Mi apuesta de hoy.", "Pensé en ti con esta.", "Creo que esta te queda bien.", "Esta me pareció para ti.",
        "Esta encaja, ya verás.", "Mi sugerencia de ahora.", "Pasa esta por tu radar.", "Quédate con esta.",
        "Esta es una buena opción.", "Una sugerencia sin compromiso.", "Prueba esta, no pierdes nada.", "Creo que le vas a encontrar el gusto.",
        "Esta podría ser de las tuyas.", "Dale una vuelta a esta.", "Anótala por si acaso.", "Una recomendación de la casa.",
        "Opción del día.", "Elegida pensando en ti.", "Creo que acierto con esta.", "Mi intuición dice que esta.",
        "Esta se ve prometedora.", "Buena para escuchar ahora.", "Para este momento, esta.", "Esta tenía que sonar.",
        "Yo apuntaría a esta.", "Corazonada musical.", "Mi olfato musical dice esta.", "Hoy me inclino por esta.",
        "Con esta no se pierde.", "Esto sí que podría gustarte.", "Algo así te puede encantar.", "Esta podría ser tu sorpresa del día."
    )

    private val S_CONFIANZA = listOf(
        "Confía en mí.", "Puede que te sorprenda.", "Dale una oportunidad.", "Tú solo escucha.",
        "Te va a gustar, ya verás.", "Fíate de mí esta vez.", "Dame un voto de confianza.", "Una oportunidad, nada más.",
        "Si no te gusta, la saltamos.", "Sin presión: escucha y decide.", "Déjame esta.", "Dale tiempo, que engancha.",
        "Aguanta los primeros segundos.", "Me la juego con esta.", "Esta no te va a fallar.", "Estoy seguro de esta.",
        "Créeme, esta tiene algo.", "Hazme caso con esta.", "Pruébala sin prejuicios.", "Dale cinco segundos.",
        "Yo me hago responsable.", "Vale la pena.", "Mente abierta, oídos listos.", "Aquí no hay trampa.",
        "Un favor: escúchala.", "Escucha y luego juzgas.", "Va en serio, dale.", "Dale play con fe.",
        "Una más y decides.", "Confianza ciega, un ratito."
    )

    private val S_HUMOR = listOf(
        "No me demandes si no te gusta.", "Si no te gusta, culpa al azar.", "Giro de guion musical.", "Plot twist sonoro.",
        "Tu playlist no lo vio venir.", "Un poco random, pero con cariño.", "Pido disculpas si no pega 😅", "Fue un impulso.",
        "Me dio por esta.", "Resumen: me dio la gana.", "Sorpresa, sorpresa.", "Dale, que no muerde.",
        "Aquí vamos, sin red.", "Lanzo y veremos.", "Moneda al aire y salió esta.", "Esta ganó el sorteo.",
        "Hoy me puse atrevido.", "Me puse creativo.", "Tirando los dados.", "Probemos, qué es lo peor que pasa.",
        "Cambio de planes.", "Si falla, la culpa es mía.", "Esto lo decidí en un segundo.", "Sin garantía, pero con ganas.",
        "Que no se entere tu lista de favoritos.", "Esta entró por la ventana.", "Alguien tenía que hacerlo.", "Me tiré a la piscina con esta.",
        "Spoiler: puede que te guste.", "Hoy jugué a ser DJ."
    )

    private val S_DESCUBRIMIENTO = listOf(
        "Mira lo que apareció.", "Descubrí algo en tu biblioteca.", "Esta estaba por ahí esperando.", "Rescaté esta del fondo.",
        "Creo que esta se te pasó.", "Aquí hay algo por descubrir.", "Esta merece una escucha.", "A esta casi no le hemos dado tiempo.",
        "Una joya medio escondida.", "Estaba escondida entre tus canciones.", "Hay música aquí que apenas conoces.", "Vamos a conocer esta mejor.",
        "Todavía no la conocemos bien.", "Exploremos esta.", "Una canción que merece más vueltas.", "Hay algo bueno por aquí.",
        "Sacándola del anonimato.", "Se nos pasó esta.", "A esta le faltaba su momento.", "Que tenga su momento.",
        "Descubrimiento del día.", "Un hallazgo.", "Encontrada entre tantas.", "Mira qué había aquí.",
        "Una que casi ni sonó.", "Hoy le toca a esta.", "Escarbando encontré esta.", "Algo para explorar.",
        "Dale su turno a esta.", "Algo por conocer aquí."
    )

    private val S_RUTINA = listOf(
        "Vamos a salir de la rutina.", "Hoy toca algo diferente.", "Hoy vamos a probar algo distinto.", "Cambiemos un poco el aire.",
        "Algo fuera de lo habitual.", "Rompamos el patrón.", "Un respiro de lo de siempre.", "Salgamos de la zona de confort.",
        "A veces toca moverse del carril.", "Cambio de aires musicales.", "Hoy vamos por otro lado.", "Hoy no repetimos receta.",
        "Otro rumbo por hoy.", "Variemos un poco.", "Un pequeño desvío.", "Salida de emergencia de la rutina.",
        "Algo distinto no hace daño.", "Mezclemos un poco las cosas.", "Un desvío interesante.", "Ruta alternativa.",
        "Probemos algo que no sueles poner.", "Aire fresco para tus oídos.", "Una ventana nueva.", "Otra perspectiva sonora.",
        "Hoy toca explorar.", "Dale un giro al día.", "Cambiemos de canal.", "Un salto fuera de la rutina.",
        "Rutina fuera, música nueva.", "Hoy toca salirse del guion."
    )

    private val S_NOSTALGIA = listOf(
        "Encontré una vieja conocida.", "Hace tiempo que no sonaba esta.", "Mira quién apareció.", "Esta llevaba un buen rato callada.",
        "Una de esas de antes.", "Qué tal un reencuentro.", "Se te había quedado atrás.", "Volvamos a esta un momento.",
        "Alguien extrañaba sonar.", "Desempolvando esta.", "Del baúl de tus canciones.", "Hora de reencontrarse.",
        "Una vieja amiga.", "Quizá traiga recuerdos.", "Un viaje corto al pasado.", "Esto llevaba tiempo sin sonar.",
        "Ya tocaba revisitar esta.", "Reencuentro con esta.", "Cómo pasa el tiempo con esta.", "Revivamos esta.",
        "Había que sacarla del olvido.", "Se quedó esperando su turno.", "Regresa esta.", "Una visita al pasado.",
        "Esta tenía ganas de volver."
    )

    private val S_FAVORITA = listOf(
        "Sabía dónde buscar.", "Fui sobre seguro.", "Esta nunca decepciona.", "Una de las tuyas.",
        "Algo que ya conoces bien.", "Con esta no hay riesgo.", "Una apuesta segura.", "Jugué sobre seguro.",
        "Un guiño a tus gustos.", "Sé que le tienes aprecio.", "A esta le tienes cariño.", "Pensé: esta nunca falla.",
        "Toca un abrazo musical.", "Una de las de casa.", "Para quedar bien contigo.", "Sin riesgo y con corazón.",
        "La comodidad de lo conocido.", "Un gusto seguro.", "Esta es terreno conocido.", "Hoy me fui por lo seguro."
    )

    private val S_NOCHE = listOf(
        "Tengo algo para estas horas.", "Esta hora pide algo así.", "Perfecta para estas horas.", "Para una noche como esta.",
        "Algo suave para la noche.", "La noche pedía esta.", "Un plan para esta hora.", "Para acompañar la noche.",
        "A estas horas, esta.", "Bajemos las luces con esta.", "La hora justa para esta.", "Música para la noche.",
        "Esta es de las de noche.", "Noche, calma y esta.", "Mejor con poca luz."
    )

    private val S_MANANA = listOf(
        "Buen momento para arrancar con esto.", "Para arrancar la mañana.", "Algo con ánimo para empezar.", "Buenos días, con música.",
        "Mañana y música: buen plan.", "Un empujón para empezar.", "Así se arranca el día.", "Para despertar con ganas.",
        "Una buena forma de empezar.", "Con esta arranca bien el día."
    )

    private val SURPRISE: Map<SurpriseCat, List<String>> = mapOf(
        SurpriseCat.CURIOSIDAD to S_CURIOSIDAD, SurpriseCat.MISTERIO to S_MISTERIO, SurpriseCat.RECOMENDACION to S_RECOMENDACION,
        SurpriseCat.CONFIANZA to S_CONFIANZA, SurpriseCat.HUMOR to S_HUMOR, SurpriseCat.DESCUBRIMIENTO to S_DESCUBRIMIENTO,
        SurpriseCat.RUTINA to S_RUTINA, SurpriseCat.NOSTALGIA to S_NOSTALGIA, SurpriseCat.FAVORITA to S_FAVORITA,
        SurpriseCat.NOCHE to S_NOCHE, SurpriseCat.MANANA to S_MANANA
    )

    // =====================================================================================================
    //  SELECCIÓN NORMAL  (≈ 300)
    // =====================================================================================================

    private val N_APROBACION = listOf(
        "Buen gusto, bro.", "Esa sí.", "Buena elección.", "Elección aprobada. 😎",
        "Respeto.", "Ahora sí.", "Vamos con esa.", "Muy buena.",
        "Aprobada sin dudar.", "Bien ahí.", "Esa me gusta.", "Tienes oído.",
        "Sabes lo que haces.", "Esa cae perfecta.", "Buena jugada.", "Acertaste.",
        "Tú sí sabes.", "Sin dudas, esa.", "De las buenas.", "Gran decisión.",
        "Eso es música.", "Correcto.", "Así se hace.", "Esta elección habla bien de ti.",
        "Mi voto también.", "Visto bueno.", "Esa va.", "Bien escogida.",
        "Gusto refinado.", "Una decisión sensata.", "Buen ojo, buen oído.", "Me alegra que la elijas.",
        "Esa es buena, confirmado.", "Sin discusión.", "Se nota que sabes.", "Exacto, esa.",
        "Directo a lo bueno.", "Eso, esa misma.", "Te respaldo en esta.", "Selección de calidad.",
        "Aquí hay calidad.", "Ni yo la hubiera elegido mejor.", "Muy buena decisión.", "Con criterio, como siempre.",
        "Esa elección tiene estilo.", "Qué buena idea.", "Justo lo que tocaba.", "Bien pensado.",
        "Elegiste bien."
    )

    private val N_HUMOR = listOf(
        "Ok, DJ, te escucho.", "Tú mandas, yo pongo.", "A sus órdenes.", "Que suene, entonces.",
        "Música, maestro.", "Tranquilo, yo me encargo.", "Pidió el jefe, suena el tema.", "Dale que esa va.",
        "Tu dedo tiene criterio.", "Si lo dices tú, suena.", "Sin preguntas, sin dudas.", "Cinco estrellas imaginarias.",
        "Pasó el control de calidad.", "Prueba superada.", "Auriculares en posición.", "Yo solo le doy play.",
        "Primera fila para esta.", "Mi oído aprueba.", "Que corra la música.", "Esto se pone bueno.",
        "Ni lo pensaste, y bien hecho.", "Concierto privado, comienza.", "Ya la estaba esperando. 😏", "Entrada VIP para esta.",
        "Se abre el telón."
    )

    private val N_ENTUSIASMO = listOf(
        "Temazo.", "Ufff, esa pega.", "Buenísima.", "¡Eso!",
        "Vamos, vamos.", "Esta suena increíble.", "Qué buena es.", "Ahí está.",
        "Dale, que empiece.", "Con esta se disfruta.", "Esta sí que suena.", "Subamos esto.",
        "Qué canción.", "Hermosa elección.", "Esta es otra cosa.", "Uf, qué bien suena.",
        "Eso tenía que sonar.", "Ya extrañaba un buen tema.", "Qué tema.", "Esto va a sonar bien.",
        "Que no pare.", "Se viene lo bueno.", "Pega fuerte.", "Esta tiene magia.",
        "Qué placer.", "Aquí vamos.", "Ahora sí se pone interesante.", "Música de la buena.",
        "Pura calidad.", "Otro nivel.", "Esto sí es disfrutar.", "A todo volumen, mentalmente.",
        "Esta no se salta.", "Una joya.", "Qué manera de sonar.", "Se me pone la piel de gallina.",
        "Increíble, esa.", "Brutal.", "Ya empezó la fiesta."
    )

    private val N_CLASICO = listOf(
        "Otra vez aquí 😂", "Tú y esta canción tienen historia.", "Sí, ya sé que te gusta.", "De nuevo con esta, como siempre.",
        "Esta ya es de la familia.", "Clásico.", "Esa nunca falla.", "Ya es costumbre.",
        "Esta es tu terreno.", "La conoces de memoria.", "Otro día, otro play de esta.", "Hay confianza con esta.",
        "Esta ya tiene nombre propio.", "Fiel a esta.", "Imposible cansarse, ¿no?", "Se ganó su lugar.",
        "Ya podrías cantarla entera.", "Esta es un pilar.", "Siempre vuelve esta.", "Una de las que más suenan."
    )

    private val N_OLVIDADA = listOf(
        "Hace rato no escuchábamos esta.", "Mira quién volvió.", "La teníamos olvidada.", "Hora de reencontrarnos con esta.",
        "Qué nostalgia volver a esta.", "Esta llevaba tiempo sin sonar.", "Mira lo que desempolvaste.", "Cuánto tiempo, amiga.",
        "Hacía tiempo que no pasaba por aquí.", "Se había perdido esta.", "Qué bueno que regresó.", "Vuelve una de antes.",
        "Eso sí es un reencuentro.", "Se había ido de vacaciones.", "Esta estaba en pausa.", "Qué recuerdos.",
        "Rescatada del olvido.", "Había que revisitarla."
    )

    private val N_FAVORITA = listOf(
        "Sabía que volverías.", "Una de tus favoritas.", "Aquí hay cariño.", "Esta ya tiene su lugar.",
        "Con corazón y todo.", "De las que guardas cerca.", "Una de las que más quieres.", "Favorita confirmada.",
        "Se nota el cariño.", "Esa tiene tu sello.", "Para ti, de lo mejor.", "Esta se quedó contigo.",
        "Se ganó su corazoncito.", "Con razón es favorita.", "Una de las elegidas.", "Siempre con cariño, esta.",
        "En tu lista de favoritas, y se nota.", "Aquí no se discute."
    )

    private val N_NUEVA = listOf(
        "Vamos a darle una oportunidad.", "Todavía estamos conociéndola.", "A ver si se gana un lugar.", "Esta todavía tiene que demostrar lo suyo.",
        "Una canción por conocer.", "Aún nos falta conocerla.", "A ver qué tal con esta.", "Veamos de qué es capaz.",
        "Explorando esta.", "Primeras impresiones.", "Poco la hemos escuchado.", "Tiene todo por ganarse.",
        "Una oportunidad para esta.", "A ver si engancha.", "Hora de conocerla mejor.", "Todavía es territorio nuevo.",
        "Dándole su momento.", "Una más para descubrir."
    )

    private val N_REPETIDA_1 = listOf(
        "Volvimos a esta.", "¿Otra vez? 😂", "No la soltamos todavía, ¿eh?", "Una más no hace daño.",
        "Repetimos, entonces.", "Otra vuelta a esta.", "Se quedó con ganas.", "Segunda ronda.",
        "A ver, otra vez.", "Bis.", "¿Te quedaste con ganas?", "Como si fuera la primera vez."
    )

    private val N_REPETIDA_2 = listOf(
        "Ok, esta te atrapó 😂", "Ya van tres.", "Esta no te suelta.", "Oficialmente, te enganchó.",
        "Tercera vez, ya es declaración.", "Se nota que esta pega fuerte.", "Aquí hay obsesión sana.", "Esto ya es un loop.",
        "Me estás convenciendo con esta.", "Vamos con la tercera.", "Esto va en serio.", "Tercera ronda, sin juzgar."
    )

    private val N_REPETIDA_3 = listOf(
        "Ya entendí, te gusta.", "Ok, mensaje recibido.", "No hace falta que me lo expliques.", "Esta ya es tu canción del día.",
        "Hay amor, no lo niegues.", "Ya perdí la cuenta.", "Tú y esta, un romance.", "Al menos tienes claro lo que quieres.",
        "Esta no se agota, parece.", "Eres constante, lo respeto.", "Ya la sé hasta yo.", "Directo al himno personal."
    )

    private val N_TIEMPO_NOCHE = listOf(
        "Esta hora pide música así.", "A estas horas todo suena mejor.", "Música y noche, buen plan.", "Buena hora para esto.",
        "La noche y el play, siempre bien.", "A esta hora, mejor con música.", "De noche, el volumen se siente distinto.", "Qué hora para poner música.",
        "Noche de música.", "Con la noche encima, vamos."
    )

    private val N_TIEMPO_MANANA = listOf(
        "Buen comienzo.", "Así se empieza el día.", "Música para arrancar.", "Buenos días, con ritmo.",
        "Con música, la mañana mejora.", "Para estrenar el día.", "De buena mañana, ya.", "Mañana con banda sonora."
    )

    private val N_TIEMPO_TARDE = listOf(
        "Buena tarde para música.", "La tarde pedía esto.", "Tarde con banda sonora.", "Una pausa de tarde, bien.",
        "Para acompañar la tarde.", "Música de media jornada."
    )

    private val NORMAL: Map<NormalCat, List<String>> = mapOf(
        NormalCat.APROBACION to N_APROBACION, NormalCat.HUMOR to N_HUMOR, NormalCat.ENTUSIASMO to N_ENTUSIASMO,
        NormalCat.CLASICO to N_CLASICO, NormalCat.OLVIDADA to N_OLVIDADA, NormalCat.FAVORITA to N_FAVORITA, NormalCat.NUEVA to N_NUEVA,
        NormalCat.REPETIDA_1 to N_REPETIDA_1, NormalCat.REPETIDA_2 to N_REPETIDA_2, NormalCat.REPETIDA_3 to N_REPETIDA_3,
        NormalCat.TIEMPO_NOCHE to N_TIEMPO_NOCHE, NormalCat.TIEMPO_MANANA to N_TIEMPO_MANANA, NormalCat.TIEMPO_TARDE to N_TIEMPO_TARDE
    )

    /** Frases por Mood (las categorías de Mood que JullMood ya tiene). Solo se usan si la canción tiene ese Mood. */
    private val NORMAL_MOOD: Map<Mood, List<String>> = mapOf(
        Mood.TRISTE to listOf(
            "Bueno… vamos a sentirla.", "Esta pega diferente.", "Hoy toca sentir.", "Aquí vienen los recuerdos.",
            "Esta va directo al pecho.", "Para los días de sentir.", "Con esta toca respirar hondo."
        ),
        Mood.ALEGRE to listOf(
            "Eso sí es buen humor.", "Esta contagia.", "Directo a la sonrisa.", "Con esta se anima cualquiera.", "Buena vibra asegurada."
        ),
        Mood.ENERGIA to listOf(
            "Ok, vamos a subirle.", "Ahora sí despertamos.", "Esta viene con gasolina.", "Necesitábamos algo así.",
            "Pisando el acelerador.", "Esta levanta a cualquiera.", "Energía a tope."
        ),
        Mood.ROMANTICA to listOf(
            "Esta tiene vibes peligrosas.", "Modo romántico activado.", "Aquí hay sentimientos.", "Esta habla por sí sola.",
            "Con esta se suspira.", "Cuidado, que esta enamora.", "Cursi, pero bonito."
        ),
        Mood.NOCTURNA to listOf(
            "Esta pide poca luz.", "Perfecta para la noche.", "Modo nocturno activado.", "Esta se siente diferente de noche.",
            "Para los que no duermen.", "Luces bajas, volumen justo.", "Una de las de noche.", "Pura vibra nocturna."
        ),
        Mood.RELAJANTE to listOf(
            "Respira. Ya empezó lo bueno.", "A bajar revoluciones.", "Esta es calma pura.", "Hora de aflojar los hombros.", "Esto sí es desconectar."
        ),
        Mood.ROCK to listOf(
            "Guitarras al frente.", "Esto pide volumen.", "Rock del bueno.", "Eso, a sacudir la cabeza.", "Que suene fuerte."
        ),
        Mood.FIESTA to listOf(
            "Ya es fiesta.", "Esta no se escucha sentado.", "Que empiece el baile.", "Fiesta activada 💃", "Esto es para moverse."
        ),
        Mood.CONCENTRACION to listOf(
            "A concentrarse con esta.", "Foco activado.", "Buena para trabajar con calma.", "Cabeza al frente."
        )
    )
}
