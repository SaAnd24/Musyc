package com.example.musicplayer

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

class MainActivity : ComponentActivity() {

    private val vm: PlayerViewModel by viewModels()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            vm.loadSongs()
        }

    private fun requestPermissions() {
        val perms = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        permissionLauncher.launch(perms)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val crash = File(filesDir, "crash.txt")
        if (crash.exists()) {
            val text = crash.readText()
            setContent {
                Column(Modifier.fillMaxSize().padding(16.dp)) {
                    Text("La app se cerró por este error (mantén pulsado para copiar):")
                    Button(onClick = { crash.delete(); recreate() }) { Text("Borrar error y reintentar") }
                    SelectionContainer(Modifier.verticalScroll(rememberScrollState())) {
                        Text(text, fontSize = 11.sp)
                    }
                }
            }
            return
        }
        // Al rotar o cambiar de configuración el ViewModel conserva la biblioteca: no hace falta reescanearla.
        if (savedInstanceState == null || vm.songs.isEmpty()) vm.loadSongs()
        if (!vm.hasPermission) requestPermissions()

        setContent {
            // Tema elegido en Ajustes (se guarda en SharedPreferences); "Dinámico" sigue la carátula.
            MusicTheme(vm.theme, vm.coverAccent, vm.uiStyle) {
                PlayerApp(vm, onRequestPermission = { requestPermissions() })
            }
        }
    }
}
