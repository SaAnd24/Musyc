package com.example.musicplayer

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar

// ---------- Utilidades compartidas ----------

/** Pulsación con una ligera animación de escala, sin ripple. */
@Composable
internal fun Modifier.pressable(onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.96f else 1f, label = "press")
    return this
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .clickable(interactionSource = src, indication = null, onClick = onClick)
}

/** Carátula de un grupo (álbum, artista, mix): prueba con varias canciones hasta encontrar una imagen. */
@Composable
internal fun GroupCover(songs: List<Song>, modifier: Modifier = Modifier, px: Int = 256, radius: Dp = 12.dp) {
    val ctx = LocalContext.current
    val first = songs.firstOrNull()?.id
    val bmp by produceState<Bitmap?>(null, first, px) {
        value = withContext(Dispatchers.IO) {
            songs.asSequence().take(5).firstNotNullOfOrNull { ArtCache.load(ctx, it, px) }
        }
    }
    Box(modifier.clip(RoundedCornerShape(radius)), Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else DefaultCover(songs.firstOrNull()?.album.orEmpty())
    }
}

// ---------- Primer inicio: nombre → carpeta de música → análisis ----------

@Composable
internal fun OnboardingScreen(vm: PlayerViewModel) {
    var step by rememberSaveable { mutableIntStateOf(0) }          // 0 nombre, 1 carpeta, 2 análisis/listo
    var name by rememberSaveable { mutableStateOf("") }
    val cs = MaterialTheme.colorScheme
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) { vm.chooseMusicFolder(uri); step = 2 }
    }
    val done = step == 2 && vm.scanFinished

    Box(
        Modifier.fillMaxSize().background(cs.background)
            .background(Brush.verticalGradient(listOf(cs.primary.copy(alpha = 0.25f), Color.Transparent)))
    ) {
        Column(
            Modifier.align(Alignment.Center).padding(32.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.size(96.dp).clip(RoundedCornerShape(32.dp)).background(cs.primary), Alignment.Center) {
                Icon(painterResource(R.drawable.ic_jm_logo), null, tint = cs.onPrimary, modifier = Modifier.size(96.dp))
            }
            when {
                step == 0 -> {
                    Text("Bienvenido a JullMood 👋", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 28.dp))
                    Text(
                        "Tu música, tu biblioteca y tus recomendaciones, todo en tu dispositivo y sin conexión.",
                        color = cs.onSurfaceVariant, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp)
                    )
                    Text("¿Cómo quieres que te llamemos?", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 36.dp, bottom = 10.dp))
                    OutlinedTextField(
                        value = name, onValueChange = { if (it.length <= 24) name = it },
                        singleLine = true, placeholder = { Text("Tu nombre") },
                        shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = { name = name.trim(); step = 1 }, enabled = name.isNotBlank(),
                        modifier = Modifier.fillMaxWidth().padding(top = 16.dp).height(52.dp), shape = RoundedCornerShape(18.dp)
                    ) { Text("Continuar", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
                    TextButton(onClick = { name = "amigo"; step = 1 }) { Text("Omitir", color = cs.onSurfaceVariant) }
                }
                step == 1 -> {
                    Text("¿Dónde está tu música?", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 28.dp))
                    Text(
                        "Elige la carpeta donde guardas tus canciones. Analizaremos también todas sus subcarpetas.",
                        color = cs.onSurfaceVariant, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp)
                    )
                    Button(
                        onClick = { picker.launch(null) },
                        modifier = Modifier.fillMaxWidth().padding(top = 36.dp).height(52.dp), shape = RoundedCornerShape(18.dp)
                    ) { Text("Elegir carpeta", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
                    TextButton(onClick = { vm.chooseMusicFolder(null); step = 2 }) {
                        Text("Usar toda la música del dispositivo", color = cs.onSurfaceVariant)
                    }
                }
                !done -> {
                    CircularProgressIndicator(Modifier.padding(top = 36.dp).size(40.dp))
                    Text("Analizando tu biblioteca…", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 24.dp))
                    Text("${vm.scanFound} canciones encontradas", color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
                }
                vm.songs.isEmpty() -> {
                    Text("No encontramos canciones", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 28.dp))
                    Text(
                        "No hay audios compatibles en esa ubicación. Prueba con otra carpeta; puedes cambiarla después en Ajustes.",
                        color = cs.onSurfaceVariant, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp)
                    )
                    Button(
                        onClick = { picker.launch(null) },
                        modifier = Modifier.fillMaxWidth().padding(top = 28.dp).height(52.dp), shape = RoundedCornerShape(18.dp)
                    ) { Text("Elegir otra carpeta", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
                    TextButton(onClick = { vm.finishOnboarding(name) }) { Text("Continuar de todos modos", color = cs.onSurfaceVariant) }
                }
                else -> {
                    Text("¡Todo listo, $name! 🎵", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 28.dp))
                    Text(
                        if (vm.songs.size == 1) "Encontramos 1 canción" else "Encontramos ${vm.songs.size} canciones",
                        color = cs.onSurfaceVariant, fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp)
                    )
                    Button(
                        onClick = { vm.finishOnboarding(name) },
                        modifier = Modifier.fillMaxWidth().padding(top = 36.dp).height(52.dp), shape = RoundedCornerShape(18.dp)
                    ) { Text("Empezar", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
                }
            }
        }
    }
}

// ---------- Home ----------

@Composable
internal fun HomeScreen(
    vm: PlayerViewModel, listState: LazyListState,
    onOpenPlayer: () -> Unit, onDetail: (Detail) -> Unit,
    onSeeFavorites: () -> Unit, onSearch: () -> Unit, onRequestPermission: () -> Unit
) {
    var reroll by rememberSaveable { mutableIntStateOf(0) }
    val day = System.currentTimeMillis() / 86_400_000L
    val data = remember(vm.songs, vm.stats, vm.favorites, reroll) {
        Recommender.build(vm.songs, vm.stats, vm.favorites, System.currentTimeMillis(), day * 31L + reroll)
    }
    val play: (Song, List<Song>) -> Unit = { s, l ->
        if (s.id.toString() == vm.currentId) { if (!vm.isPlaying) vm.togglePlay(); onOpenPlayer() }
        else vm.playSong(s, l)
    }
    val rowPad = PaddingValues(horizontal = 20.dp)
    val gap = Arrangement.spacedBy(14.dp)

    LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(bottom = 28.dp)) {
        item {
            val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            val greet = when { h < 6 -> "Buenas noches"; h < 12 -> "Buenos días"; h < 20 -> "Buenas tardes"; else -> "Buenas noches" }
            Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 20.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Hola, ${vm.userName} 👋", fontSize = 30.sp, lineHeight = 36.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(
                        if (vm.songs.isEmpty()) greet else "$greet · ${vm.songs.size} canciones en tu biblioteca",
                        color = Gray, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp)
                    )
                }
                IconButton(onClick = onSearch) { Icon(painterResource(R.drawable.ic_search), "Buscar", Modifier.size(26.dp)) }
            }
        }

        when {
            !vm.hasPermission -> item {
                Column(Modifier.fillMaxWidth().padding(20.dp).clip(RoundedCornerShape(24.dp)).background(MaterialTheme.colorScheme.surface).padding(24.dp)) {
                    Text("Conecta tu música", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Necesitamos permiso para leer los audios del dispositivo y armar tu Home.", color = Gray, modifier = Modifier.padding(top = 6.dp))
                    Button(onClick = onRequestPermission, modifier = Modifier.padding(top = 14.dp)) { Text("Conceder permiso") }
                }
            }
            vm.loading && vm.songs.isEmpty() -> item { Empty("Escaneando tu biblioteca…") }
            vm.songs.isEmpty() -> item { Empty("No encontramos música en este dispositivo") }
            else -> {
                // Continúa escuchando
                item { SectionTitle(data.continueTitle, if (data.hasHistory) "Retoma donde lo dejaste" else "Lo último que llegó a tu biblioteca") }
                item {
                    LazyRow(contentPadding = rowPad, horizontalArrangement = gap) {
                        items(data.continueSongs, key = { it.id }) { s ->
                            val isCur = s.id.toString() == vm.currentId
                            BigCard(
                                s, if (isCur && vm.duration > 0) (vm.position.toFloat() / vm.duration).coerceIn(0f, 1f) else null,
                                isCur && vm.isPlaying
                            ) { play(s, data.continueSongs) }
                        }
                    }
                }

                // Hecho para ti
                if (data.mixes.isNotEmpty()) {
                    item { SectionTitle("Hecho para ti", "Mezclas armadas con tu biblioteca") }
                    item {
                        LazyRow(contentPadding = rowPad, horizontalArrangement = gap) {
                            items(data.mixes) { m -> MixCard(m) { vm.playSong(m.songs.first(), m.songs) } }
                        }
                    }
                }

                // Favoritos
                if (data.favorites.isNotEmpty()) {
                    item { SectionTitle("Tus favoritos", action = "Ver todo", onAction = onSeeFavorites) }
                    item {
                        LazyRow(contentPadding = rowPad, horizontalArrangement = gap) {
                            items(data.favorites, key = { it.id }) { s ->
                                SquareCard(150.dp, s.title, s.artist, onClick = { play(s, data.favorites) }) { m -> Cover(s, m, px = 400, radius = 20.dp) }
                            }
                        }
                    }
                }

                // Álbumes
                if (data.albums.isNotEmpty()) {
                    item { SectionTitle(data.albumsTitle) }
                    item {
                        LazyRow(contentPadding = rowPad, horizontalArrangement = gap) {
                            items(data.albums, key = { it.name }) { a ->
                                SquareCard(150.dp, a.name, a.artist, onClick = { onDetail(Detail(0, a.name)) }) { m ->
                                    GroupCover(a.songs, m, px = 400, radius = 20.dp)
                                }
                            }
                        }
                    }
                }

                // Artistas
                if (data.artists.isNotEmpty()) {
                    item { SectionTitle(data.artistsTitle) }
                    item {
                        LazyRow(contentPadding = rowPad, horizontalArrangement = gap) {
                            items(data.artists, key = { it.name }) { a ->
                                SquareCard(110.dp, a.name, "${a.songs.size} canciones", circle = true, onClick = { onDetail(Detail(1, a.name)) }) { m ->
                                    GroupCover(a.songs, m, px = 300, radius = 55.dp)
                                }
                            }
                        }
                    }
                }

                // Más escuchadas
                if (data.mostPlayed.isNotEmpty()) {
                    item { SectionTitle("Tus más escuchadas") }
                    item {
                        Column(Modifier.padding(horizontal = 20.dp).fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(MaterialTheme.colorScheme.surface)) {
                            data.mostPlayed.forEachIndexed { i, s ->
                                val n = vm.stats[s.id]?.plays ?: 0
                                Row(Modifier.fillMaxWidth().clickable { play(s, data.mostPlayed) }.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("${i + 1}", Modifier.width(26.dp), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                                    Cover(s, Modifier.size(48.dp), radius = 12.dp)
                                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                        Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                                        Text("${s.artist} · $n ${if (n == 1) "reproducción" else "reproducciones"}", maxLines = 1, overflow = TextOverflow.Ellipsis, color = Gray, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                // Quizás te guste
                if (data.suggestions.isNotEmpty()) {
                    item { SectionTitle("Quizás te guste", "Según lo que más escuchas") }
                    item {
                        LazyRow(contentPadding = rowPad, horizontalArrangement = gap) {
                            items(data.suggestions, key = { it.song.id }) { sg ->
                                SquareCard(150.dp, sg.song.title, sg.reason, onClick = { play(sg.song, data.suggestions.map { it.song }) }) { m ->
                                    Cover(sg.song, m, px = 400, radius = 20.dp)
                                }
                            }
                        }
                    }
                }

                // Añadido recientemente
                if (data.added.isNotEmpty() && data.hasHistory) {
                    item { SectionTitle("Añadido recientemente") }
                    item {
                        LazyRow(contentPadding = rowPad, horizontalArrangement = gap) {
                            items(data.added, key = { it.id }) { s ->
                                SquareCard(130.dp, s.title, s.artist, onClick = { play(s, data.added) }) { m -> Cover(s, m, px = 300, radius = 18.dp) }
                            }
                        }
                    }
                }

                // Descubre tu biblioteca
                item { SectionTitle("Descubre tu biblioteca", "Rincones que quizá tenías olvidados") }
                item {
                    Row(Modifier.padding(horizontal = 20.dp).padding(bottom = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { vm.playShuffled(vm.songs) }, shape = RoundedCornerShape(16.dp)) {
                            Icon(painterResource(R.drawable.ic_shuffle), null, Modifier.size(20.dp))
                            Text("  Todo en aleatorio")
                        }
                        FilledTonalButton(onClick = { reroll++ }, shape = RoundedCornerShape(16.dp)) { Text("Mezclar") }
                    }
                }
                item {
                    LazyRow(contentPadding = rowPad, horizontalArrangement = gap) {
                        items(data.discover, key = { it.id }) { s ->
                            SquareCard(130.dp, s.title, s.artist, onClick = { play(s, data.discover) }) { m -> Cover(s, m, px = 300, radius = 18.dp) }
                        }
                    }
                }
            }
        }
    }
}

// ---------- Componentes del Home ----------

@Composable
private fun SectionTitle(title: String, subtitle: String? = null, action: String? = null, onAction: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 28.dp, bottom = 12.dp), verticalAlignment = Alignment.Bottom) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            if (subtitle != null) Text(subtitle, color = Gray, fontSize = 13.sp)
        }
        if (action != null) TextButton(onClick = onAction) { Text(action) }
    }
}

@Composable
private fun BigCard(song: Song, progress: Float?, playing: Boolean, onClick: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    Box(Modifier.size(264.dp).pressable(onClick).clip(RoundedCornerShape(28.dp))) {
        Cover(song, Modifier.fillMaxSize(), px = 600, radius = 0.dp)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.45f to Color.Transparent, 1f to Color.Black.copy(alpha = 0.85f))))
        Column(Modifier.align(Alignment.BottomStart).padding(start = 18.dp, end = 72.dp, bottom = 18.dp)) {
            Text(song.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(song.artist, color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(Modifier.align(Alignment.BottomEnd).padding(end = 14.dp, bottom = 16.dp).size(44.dp).clip(CircleShape).background(primary), Alignment.Center) {
            Icon(painterResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play), null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(24.dp))
        }
        if (progress != null) {
            Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(4.dp).background(Color.White.copy(alpha = 0.25f))) {
                Box(Modifier.fillMaxWidth(progress).fillMaxHeight().background(primary))
            }
        }
    }
}

@Composable
private fun MixCard(mix: Mix, onClick: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    Box(Modifier.size(180.dp).pressable(onClick).clip(RoundedCornerShape(24.dp))) {
        GroupCover(mix.songs, Modifier.fillMaxSize(), px = 400, radius = 0.dp)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.3f to Color.Transparent, 1f to Color.Black.copy(alpha = 0.85f))))
        Box(Modifier.align(Alignment.TopStart).padding(12.dp).clip(RoundedCornerShape(10.dp)).background(primary).padding(horizontal = 8.dp, vertical = 3.dp)) {
            Text("MIX", color = MaterialTheme.colorScheme.onPrimary, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
        }
        Column(Modifier.align(Alignment.BottomStart).padding(14.dp)) {
            Text(mix.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(mix.subtitle, color = Color.White.copy(alpha = 0.75f), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun SquareCard(
    size: Dp, title: String, subtitle: String, circle: Boolean = false,
    onClick: () -> Unit, cover: @Composable (Modifier) -> Unit
) {
    val align = if (circle) TextAlign.Center else TextAlign.Start
    Column(Modifier.width(size).pressable(onClick), horizontalAlignment = if (circle) Alignment.CenterHorizontally else Alignment.Start) {
        cover(Modifier.size(size))
        Text(title, Modifier.fillMaxWidth().padding(top = 10.dp), fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = align)
        Text(subtitle, Modifier.fillMaxWidth(), color = Gray, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = align)
    }
}
