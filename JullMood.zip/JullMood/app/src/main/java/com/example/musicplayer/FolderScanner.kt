package com.example.musicplayer

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.DocumentsContract
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive

/**
 * Escanea una carpeta elegida con el selector nativo (Storage Access Framework) y todas sus subcarpetas.
 * Las canciones que MediaStore ya conoce se reutilizan (mismo id => favoritos, listas e historial intactos);
 * las que MediaStore no indexa se leen directamente del archivo.
 */
object FolderScanner {

    // Formatos que ExoPlayer reproduce de forma nativa.
    private val AUDIO_EXT = setOf(
        "mp3", "m4a", "aac", "flac", "wav", "ogg", "oga", "opus", "mka", "amr", "3gp", "mp4", "wma", "ape", "mid", "midi"
    )

    private class Entry(val docId: String, val name: String, val uri: Uri)

    /** Nombre legible de la carpeta a partir del URI del árbol (p. ej. "Music/Rock"). */
    fun label(tree: Uri): String = runCatching {
        DocumentsContract.getTreeDocumentId(tree).substringAfter(':', "").trim('/')
    }.getOrDefault("").ifEmpty { "Almacenamiento interno" }

    suspend fun scan(
        ctx: Context, tree: Uri, mediaStoreSongs: List<Song>, onProgress: (Int) -> Unit
    ): List<Song> {
        val entries = listAudio(ctx, tree, onProgress)
        val known = mediaStoreSongs.asSequence().filter { it.pathKey.isNotEmpty() }
            .associateBy { it.pathKey }
        val out = ArrayList<Song>(entries.size)
        for (e in entries) {
            currentCoroutineContext().ensureActive()
            out += known[pathKey(e.docId)] ?: fromFile(ctx, e)
        }
        return out.sortedBy { it.title.lowercase() }
    }

    private suspend fun listAudio(ctx: Context, tree: Uri, onProgress: (Int) -> Unit): List<Entry> {
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val found = ArrayList<Entry>()
        val pending = ArrayDeque<String>().apply { add(rootId) }
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        var first = true
        while (pending.isNotEmpty()) {
            currentCoroutineContext().ensureActive()
            val dir = pending.removeFirst()
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, dir)
            try {
                ctx.contentResolver.query(children, cols, null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getString(0) ?: continue
                        val name = c.getString(1) ?: continue
                        val mime = c.getString(2).orEmpty()
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                            if (!name.startsWith(".")) pending.add(id)   // ignora .thumbnails, .trash…
                        } else if (!name.startsWith(".") &&
                            (mime.startsWith("audio/") || mime == "application/ogg" ||
                                name.substringAfterLast('.', "").lowercase() in AUDIO_EXT)
                        ) {
                            found += Entry(id, name, DocumentsContract.buildDocumentUriUsingTree(tree, id))
                            if (found.size % 20 == 0) onProgress(found.size)
                        }
                    }
                }
            } catch (e: SecurityException) {
                if (first) throw e          // sin acceso a la carpeta raíz: el llamador lo gestiona
            } catch (_: Exception) { /* una subcarpeta ilegible no detiene el análisis */ }
            first = false
        }
        onProgress(found.size)
        return found
    }

    /** Clave para casar un archivo con MediaStore: ruta relativa al volumen, en minúsculas. */
    private fun pathKey(docId: String) = docId.substringAfter(':').lowercase()

    private fun fromFile(ctx: Context, e: Entry): Song {
        val r = MediaMetadataRetriever()
        fun meta(k: Int) = runCatching { r.extractMetadata(k) }.getOrNull()
        return try {
            runCatching { r.setDataSource(ctx, e.uri) }
            val artist = meta(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                ?: meta(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST)
            val album = meta(MediaMetadataRetriever.METADATA_KEY_ALBUM)
            Song(
                id = stableId(e.docId),
                title = meta(MediaMetadataRetriever.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() }
                    ?: e.name.substringBeforeLast('.'),
                artist = if (artist.isNullOrBlank()) "Artista desconocido" else artist,
                album = if (album.isNullOrBlank()) "Álbum desconocido" else album,
                albumId = 0L,
                durationMs = meta(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L,
                uri = e.uri,
                genre = meta(MediaMetadataRetriever.METADATA_KEY_GENRE).orEmpty(),
                year = meta(MediaMetadataRetriever.METADATA_KEY_YEAR)?.toIntOrNull() ?: 0,
                pathKey = pathKey(e.docId)
            )
        } finally { runCatching { r.release() } }
    }

    /** Id estable y negativo (FNV-1a de 64 bits): nunca choca con los ids positivos de MediaStore. */
    private fun stableId(docId: String): Long {
        var h = -3750763034362895579L
        for (ch in docId) { h = h xor ch.code.toLong(); h *= 0x100000001b3L }
        return h or Long.MIN_VALUE
    }
}
