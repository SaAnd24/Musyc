package com.example.musicplayer

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs

/*
 * Módulo 11 · Parte B — Información musical para el Mood.
 *
 *   Song (metadatos locales)
 *     → MusicInfoProvider (opcional, online)
 *       → MusicInfoCache (disco; aquí se guarda todo lo que llega de fuera)
 *         → MoodClassifier (Mood.kt)
 *
 * Es independiente del sistema de letras (10A/10B): no comparte repositorio, caché ni proveedor.
 * Sin Internet o con el enriquecimiento desactivado todo sigue funcionando con los metadatos locales
 * y con lo que ya esté en la caché.
 */

/**
 * Datos externos de una canción. (Sustituye a la estructura vacía que dejó 10A preparada para este módulo;
 * conserva sus campos y añade [tags] y el control de reintentos.)
 * `found = false` es una entrada "negativa": se consultó y no hubo datos fiables; no se vuelve a consultar
 * hasta [retryAfter].
 */
data class SongEnrichment(
    val genre: String = "", val subgenre: String = "", val bpm: Int = 0, val energy: Float = -1f,
    val tags: List<String> = emptyList(),
    val features: Map<String, String> = emptyMap(), val source: String = "", val updatedAt: Long = 0L,
    val found: Boolean = true, val retryAfter: Long = 0L
) {
    /** Hay al menos una señal útil para el clasificador. */
    val usable: Boolean
        get() = found && (genre.isNotBlank() || subgenre.isNotBlank() || tags.isNotEmpty() || bpm > 0 || energy >= 0f)
}

/** Lo único que sale del dispositivo: título, artista y duración. Nunca rutas, URIs ni audio. */
data class MusicInfoQuery(val title: String, val artist: String, val durationSec: Int) {
    val usable: Boolean
        get() = title.isNotBlank() && !title.equals("Sin título", true) &&
            artist.isNotBlank() && !artist.startsWith("Artista desconocido")
}

/** Clave de caché: artista + título normalizados. Describe la grabación, no el archivo (los duplicados la comparten). */
object MusicInfoKey {
    private val NON_ALNUM = Regex("[^\\p{L}\\p{N}]+")
    fun norm(s: String) = s.lowercase().replace(NON_ALNUM, " ").trim()
    fun of(song: Song): String = norm(song.artist) + "|" + norm(song.title)
}

sealed class InfoResult {
    data class Found(val info: SongEnrichment) : InfoResult()
    object NotFound : InfoResult()
    /** [transient] = problema de red/servicio (no se guarda nada por canción); si no, se recuerda como "sin datos". */
    data class Failure(val reason: String, val transient: Boolean) : InfoResult()
}

/** Abstracción del proveedor: para cambiar de servicio basta otra implementación. Se llama fuera del hilo principal. */
interface MusicInfoProvider {
    val name: String
    fun fetch(q: MusicInfoQuery): InfoResult
}

/**
 * MusicBrainz (https://musicbrainz.org/doc/MusicBrainz_API): API pública y abierta, sin clave.
 * Se busca la grabación por título + artista y se aprovechan los géneros/etiquetas votados por la comunidad.
 * Solo se aceptan resultados con puntuación alta, mismo título, mismo artista y duración parecida.
 * Límite del servicio: 1 petición por segundo (lo respeta [MusicInfoRepository]).
 */
class MusicBrainzProvider : MusicInfoProvider {
    override val name = "musicbrainz"

    private val base = "https://musicbrainz.org/ws/2"
    private val userAgent = "JullMood/1.0 (Android music player)"

    override fun fetch(q: MusicInfoQuery): InfoResult {
        if (!q.usable) return InfoResult.NotFound
        return try {
            val title = cleanTitle(q.title)
            val query = "recording:\"${esc(title)}\" AND artist:\"${esc(q.artist)}\""
            val r = get("$base/recording?query=" + URLEncoder.encode(query, "UTF-8") + "&fmt=json&limit=5")
            when {
                r.code == 200 -> pick(JSONObject(r.body), q, title)
                r.code == 429 || r.code == 503 -> InfoResult.Failure("HTTP ${r.code}", transient = true)
                else -> InfoResult.Failure("HTTP ${r.code}", transient = false)
            }
        } catch (e: IOException) {
            InfoResult.Failure("red: ${e.javaClass.simpleName}", transient = true)
        } catch (e: JSONException) {
            InfoResult.Failure("JSON inválido", transient = false)
        } catch (e: Exception) {
            InfoResult.Failure(e.javaClass.simpleName, transient = false)
        }
    }

    /** Quita "(feat. …)", "[Remastered]" y similares solo para la búsqueda. */
    private fun cleanTitle(t: String): String =
        t.replace(Regex("\\s*[\\(\\[].*?[\\)\\]]"), "").trim().ifBlank { t.trim() }

    /** Escapa lo que rompería una frase entre comillas en la sintaxis de búsqueda (Lucene). */
    private fun esc(s: String) = s.trim().replace("\\", "\\\\").replace("\"", "\\\"")

    private class Http(val code: Int, val body: String)

    private fun get(url: String): Http {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8_000
            c.readTimeout = 10_000
            c.requestMethod = "GET"
            c.setRequestProperty("User-Agent", userAgent)
            c.setRequestProperty("Accept", "application/json")
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText().take(500_000) }.orEmpty()
            return Http(code, body)
        } finally { c.disconnect() }
    }

    private fun pick(root: JSONObject, q: MusicInfoQuery, cleaned: String): InfoResult {
        val arr = root.optJSONArray("recordings") ?: return InfoResult.NotFound
        val wantTitles = setOf(MusicInfoKey.norm(q.title), MusicInfoKey.norm(cleaned))
        val wantArtist = MusicInfoKey.norm(q.artist)
        val counts = HashMap<String, Int>()
        val genres = LinkedHashMap<String, Int>()
        var matched = 0
        for (i in 0 until minOf(arr.length(), 5)) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optInt("score", 0) < 90) continue
            if (MusicInfoKey.norm(o.optString("title")) !in wantTitles) continue
            if (!artistMatches(o, wantArtist)) continue
            val lenSec = o.optInt("length", 0) / 1000
            if (q.durationSec > 0 && lenSec > 0 && abs(lenSec - q.durationSec) > 5) continue
            matched++
            addTags(o.optJSONArray("tags"), counts)
            addTags(o.optJSONArray("genres"), counts)
            addTags(o.optJSONArray("genres"), genres)
        }
        if (matched == 0 || counts.isEmpty()) return InfoResult.NotFound
        val tags = counts.entries.sortedByDescending { it.value }.take(8).map { it.key }
        val g = genres.entries.sortedByDescending { it.value }.map { it.key }
        return InfoResult.Found(SongEnrichment(genre = g.getOrElse(0) { "" }, subgenre = g.getOrElse(1) { "" }, tags = tags))
    }

    private fun artistMatches(o: JSONObject, want: String): Boolean {
        val credits = o.optJSONArray("artist-credit") ?: return false
        for (i in 0 until credits.length()) {
            val c = credits.optJSONObject(i) ?: continue
            val names = listOf(c.optString("name"), c.optJSONObject("artist")?.optString("name").orEmpty())
            for (raw in names) {
                val a = MusicInfoKey.norm(raw)
                if (a.isEmpty()) continue
                if (a == want || (a.length >= 3 && want.length >= 3 && (a.contains(want) || want.contains(a)))) return true
            }
        }
        return false
    }

    /** Solo etiquetas con votos positivos; las negativas (descartadas por la comunidad) se ignoran. */
    private fun addTags(a: JSONArray?, into: MutableMap<String, Int>) {
        if (a == null) return
        for (i in 0 until a.length()) {
            val t = a.optJSONObject(i) ?: continue
            val name = t.optString("name").trim().lowercase().take(40)
            val votes = t.optInt("count", 1)
            if (name.isEmpty() || votes < 1) continue
            into[name] = (into[name] ?: 0) + votes
        }
    }
}

/**
 * Caché local persistente: UN archivo JSON (filesDir/musicinfo.json) con una entrada pequeña por canción.
 * No hay segunda base de datos ni dependencias nuevas (mismo criterio que la caché de letras). La escritura
 * es atómica y por lotes: nunca se reescribe el archivo en cada petición.
 */
class MusicInfoCache(ctx: Context) {
    private val file = File(ctx.filesDir, "musicinfo.json")
    private val map = ConcurrentHashMap<String, SongEnrichment>()
    private val loadLock = Mutex()
    @Volatile private var loaded = false
    @Volatile private var dirty = false

    suspend fun ensureLoaded() {
        if (loaded) return
        loadLock.withLock {
            if (loaded) return
            withContext(Dispatchers.IO) { readFile() }
            loaded = true
        }
    }

    private fun readFile() {
        runCatching {
            if (!file.exists()) return
            val items = JSONObject(file.readText()).optJSONObject("items") ?: return
            items.keys().forEach { k ->
                val o = items.optJSONObject(k) ?: return@forEach
                val t = o.optJSONArray("t")
                val tags = if (t == null) emptyList() else List(t.length()) { t.optString(it) }.filter { it.isNotBlank() }
                map[k] = SongEnrichment(
                    genre = o.optString("g"), subgenre = o.optString("sg"), bpm = o.optInt("bpm"),
                    energy = o.optDouble("en", -1.0).toFloat(), tags = tags, source = o.optString("src"),
                    updatedAt = o.optLong("u"), found = o.optInt("f", 1) == 1, retryAfter = o.optLong("r")
                )
            }
        }
    }

    fun get(key: String): SongEnrichment? = map[key]

    fun put(key: String, e: SongEnrichment) { map[key] = e; dirty = true }

    /** Solo las entradas con datos útiles (las "negativas" no le sirven al clasificador). */
    fun usableSnapshot(): Map<String, SongEnrichment> = map.filterValues { it.usable }

    fun size(): Int = map.size

    suspend fun flush() {
        withContext(Dispatchers.IO) { writeFile() }
    }

    private fun writeFile() {
        if (!dirty) return
        dirty = false
        runCatching {
            val items = JSONObject()
            map.forEach { (k, v) ->
                val o = JSONObject().put("f", if (v.found) 1 else 0).put("src", v.source).put("u", v.updatedAt)
                if (v.genre.isNotEmpty()) o.put("g", v.genre)
                if (v.subgenre.isNotEmpty()) o.put("sg", v.subgenre)
                if (v.bpm > 0) o.put("bpm", v.bpm)
                if (v.energy >= 0f) o.put("en", v.energy.toDouble())
                if (v.tags.isNotEmpty()) o.put("t", JSONArray(v.tags))
                if (v.retryAfter > 0L) o.put("r", v.retryAfter)
                items.put(k, o)
            }
            val tmp = File(file.parentFile, "musicinfo.tmp")
            tmp.writeText(JSONObject().put("v", 1).put("items", items).toString())
            if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file) }   // escritura atómica
        }.onFailure { dirty = true }
    }

    suspend fun clear() {
        withContext(Dispatchers.IO) { map.clear(); dirty = false; file.delete() }
    }
}

/**
 * MusicInfoProvider → MusicInfoRepository → MusicInfoCache.
 * Regla: la caché manda. Internet solo para canciones sin entrada válida, a un ritmo de 1 petición/s,
 * con tope por sesión, y solo mientras la app está abierta (no hay servicio ni tarea en segundo plano).
 */
class MusicInfoRepository(
    private val ctx: Context,
    private val provider: MusicInfoProvider = MusicBrainzProvider(),
    private val cache: MusicInfoCache = MusicInfoCache(ctx)
) {
    companion object {
        private const val NOT_FOUND_TTL = 30L * 24 * 3600 * 1000     // sin datos: no se reintenta en 30 días
        private const val HARD_ERROR_TTL = 7L * 24 * 3600 * 1000     // petición rechazada (4xx, JSON roto): 7 días
        private const val MIN_INTERVAL_MS = 1_100L                   // límite de MusicBrainz: 1 petición/s
        private const val MAX_CONSECUTIVE_FAILURES = 3               // red caída o servicio saturado: se para el lote
        private const val FLUSH_EVERY = 25                           // escritura a disco por lotes
        private const val NOTIFY_EVERY = 20                          // cada cuántas canciones nuevas se avisa para reclasificar
    }

    private var lastRequestAt = 0L

    suspend fun ensureLoaded() = cache.ensureLoaded()

    /** Datos útiles ya guardados, por clave de [MusicInfoKey]. Solo lectura de memoria. */
    fun snapshot(): Map<String, SongEnrichment> = cache.usableSnapshot()

    /** ¿Esta canción ya tiene una respuesta guardada que siga vigente? (no hace falta consultar) */
    fun isSettled(song: Song, now: Long = System.currentTimeMillis()): Boolean {
        val e = cache.get(MusicInfoKey.of(song)) ?: return false
        return e.found || now < e.retryAfter
    }

    /**
     * Consulta, en orden, las canciones que aún no tienen respuesta vigente (máx. [maxRequests] peticiones).
     * Devuelve cuántas canciones recibieron datos nuevos. [onNew] se llama cada pocas canciones nuevas y al
     * final para que quien llama reclasifique solo entonces (no una vez por canción).
     */
    suspend fun enrich(songs: List<Song>, maxRequests: Int, onNew: suspend () -> Unit): Int {
        cache.ensureLoaded()
        var requests = 0; var fails = 0; var added = 0; var sinceFlush = 0; var sinceNotify = 0
        val seen = HashSet<String>()
        try {
            for (s in songs) {
                if (requests >= maxRequests || fails >= MAX_CONSECUTIVE_FAILURES) break
                val q = MusicInfoQuery(s.title, s.artist, (s.durationMs / 1000).toInt())
                if (!q.usable) continue                               // metadatos insuficientes: no se consulta
                val key = MusicInfoKey.of(s)
                if (!seen.add(key)) continue                          // duplicados de la misma grabación
                if (isSettled(s)) continue
                if (!isOnline()) break                                // sin red: se sigue con lo local
                val wait = MIN_INTERVAL_MS - (SystemClock.elapsedRealtime() - lastRequestAt)
                if (wait > 0) delay(wait)
                lastRequestAt = SystemClock.elapsedRealtime()
                requests++

                val result = withContext(Dispatchers.IO) {
                    runCatching { provider.fetch(q) }.getOrElse { InfoResult.Failure(it.javaClass.simpleName, true) }
                }
                val t = System.currentTimeMillis()
                when (result) {
                    is InfoResult.Found -> {
                        fails = 0; added++; sinceNotify++
                        cache.put(key, result.info.copy(source = provider.name, updatedAt = t, found = true, retryAfter = 0L))
                    }
                    is InfoResult.NotFound -> {
                        fails = 0
                        cache.put(key, SongEnrichment(found = false, source = provider.name, updatedAt = t, retryAfter = t + NOT_FOUND_TTL))
                    }
                    is InfoResult.Failure ->
                        if (result.transient) fails++
                        else { fails = 0; cache.put(key, SongEnrichment(found = false, source = provider.name, updatedAt = t, retryAfter = t + HARD_ERROR_TTL)) }
                }
                if (++sinceFlush >= FLUSH_EVERY) { sinceFlush = 0; cache.flush() }
                if (sinceNotify >= NOTIFY_EVERY) { sinceNotify = 0; onNew() }
            }
        } finally {
            withContext(NonCancellable) { cache.flush() }             // nada se pierde si se cancela el lote
        }
        if (sinceNotify > 0) onNew()
        return added
    }

    suspend fun clearAll() = cache.clear()
    fun cachedCount(): Int = cache.size()

    @Suppress("DEPRECATION")
    private fun isOnline(): Boolean = runCatching {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }.getOrDefault(true)
}
