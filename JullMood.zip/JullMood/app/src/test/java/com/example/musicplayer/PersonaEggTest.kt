package com.example.musicplayer

import android.content.SharedPreferences
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Random

/** Pruebas de JVM de las personalidades Grosera/Romántica y de los Easter Eggs (sin Android real). */
class PersonaEggTest {
    private val day = 86_400_000L
    private val t0 = 1_800_000_000_000L

    private class FakePrefs : SharedPreferences {
        val m = HashMap<String, Any?>()
        override fun getAll(): MutableMap<String, *> = m
        override fun getString(k: String?, d: String?): String? = (m[k] as? String) ?: d
        override fun getStringSet(k: String?, d: MutableSet<String>?): MutableSet<String>? = d
        override fun getInt(k: String?, d: Int) = (m[k] as? Int) ?: d
        override fun getLong(k: String?, d: Long) = (m[k] as? Long) ?: d
        override fun getFloat(k: String?, d: Float) = (m[k] as? Float) ?: d
        override fun getBoolean(k: String?, d: Boolean) = (m[k] as? Boolean) ?: d
        override fun contains(k: String?) = m.containsKey(k)
        override fun registerOnSharedPreferenceChangeListener(l: SharedPreferences.OnSharedPreferenceChangeListener?) {}
        override fun unregisterOnSharedPreferenceChangeListener(l: SharedPreferences.OnSharedPreferenceChangeListener?) {}
        override fun edit(): SharedPreferences.Editor = object : SharedPreferences.Editor {
            override fun putString(k: String?, v: String?) = apply { m[k!!] = v }
            override fun putStringSet(k: String?, v: MutableSet<String>?) = this
            override fun putInt(k: String?, v: Int) = apply { m[k!!] = v }
            override fun putLong(k: String?, v: Long) = apply { m[k!!] = v }
            override fun putFloat(k: String?, v: Float) = apply { m[k!!] = v }
            override fun putBoolean(k: String?, v: Boolean) = apply { m[k!!] = v }
            override fun remove(k: String?) = apply { m.remove(k) }
            override fun clear() = apply { m.clear() }
            override fun commit() = true
            override fun apply() {}
        }
    }

    /** Song sin pasar por Uri (en JVM no existe): solo se rellenan los campos que usan los Easter Eggs. */
    private fun song(id: Long, artist: String = "A", album: String = "Al", title: String = "t$id"): Song {
        val u = sun.misc.Unsafe::class.java.getDeclaredField("theUnsafe").also { it.isAccessible = true }.get(null) as sun.misc.Unsafe
        val s = u.allocateInstance(Song::class.java) as Song
        fun set(n: String, v: Any) = Song::class.java.getDeclaredField(n).also { it.isAccessible = true }.set(s, v)
        set("id", id); set("title", title); set("artist", artist); set("album", album)
        return s
    }

    /** Frases de una categoría que no están en ninguna otra (hay frases repetidas entre categorías en las listas originales). */
    private fun only(p: JuliPersona, cat: NormalCat): Set<String> =
        PhraseBank.normal(cat, p).toSet() - (NormalCat.values().filter { it != cat }.flatMap { PhraseBank.normal(it, p) } +
            Mood.values().flatMap { PhraseBank.normalMood(it, p) }).toSet()

    private fun engine(p: JuliPersona = JuliPersona.GROSERA, seed: Long = 1) = EggEngine(FakePrefs(), { p }, Random(seed))

    private fun ctx(p: JuliPersona, mode: PhraseMode = PhraseMode.NORMAL, plays: Int = 5, last: Long = t0 - day, fav: Boolean = false,
                    moods: List<Mood> = emptyList(), hour: Int = 20, id: Long = 1, streakArtist: Int = 0, skipped: Int = 0,
                    type: SurpriseType? = null, failed: Int = 0, now: Long = t0) =
        PhraseContext(mode, id, plays, last, fav, moods, hour, now, false, 10, type, p, skipped, streakArtist, failed)

    // ---------- Frases ----------

    @Test fun each_persona_keeps_all_600_lines_and_neutral_is_untouched() {
        assertEquals(600, PersonaBank.raw(JuliPersona.GROSERA).size)
        assertEquals(600, PersonaBank.raw(JuliPersona.ROMANTICA).size)
        assertTrue(PersonaBank.raw(JuliPersona.NEUTRAL).isEmpty())
        assertEquals(300, PhraseBank.surpriseTotal())
        assertEquals(300, PhraseBank.normalTotal())
        // Neutral no tiene las categorías nuevas: no se inventa nada.
        listOf(NormalCat.ARTISTA, NormalCat.ALBUM, NormalCat.UNICA, NormalCat.MADRUGADA, NormalCat.NUNCA_TERMINADA)
            .forEach { assertTrue(PhraseBank.normal(it).isEmpty()) }
    }

    @Test fun grosera_and_romantica_have_their_own_categories_and_no_overlap_with_neutral_lists_inside_a_category() {
        for (p in listOf(JuliPersona.GROSERA, JuliPersona.ROMANTICA)) {
            for (c in NormalCat.values()) PhraseBank.normal(c, p).let { assertEquals(it.size, it.toSet().size) }
            for (c in SurpriseCat.values()) PhraseBank.surprise(c, p).let { assertEquals(it.size, it.toSet().size) }
        }
        assertTrue(PhraseBank.normal(NormalCat.ARTISTA, JuliPersona.GROSERA).isNotEmpty())
        assertTrue(PhraseBank.normal(NormalCat.NUNCA_TERMINADA, JuliPersona.ROMANTICA).isNotEmpty())
        assertTrue(PhraseBank.surprise(SurpriseCat.FALLIDA, JuliPersona.GROSERA).isNotEmpty())
    }

    @Test fun persona_selection_never_mixes_personalities() {
        val neutral = (NormalCat.values().flatMap { PhraseBank.normal(it) } + SurpriseCat.values().flatMap { PhraseBank.surprise(it) } +
            Mood.values().flatMap { PhraseBank.normalMood(it) }).toSet()
        for (p in listOf(JuliPersona.GROSERA, JuliPersona.ROMANTICA)) {
            val own = (NormalCat.values().flatMap { PhraseBank.normal(it, p) } + Mood.values().flatMap { PhraseBank.normalMood(it, p) }).toSet()
            val e = PhraseEngine(Random(3))
            var now = t0
            repeat(300) { i ->
                now += 10_000
                e.playback(ctx(p, id = i.toLong(), now = now, moods = listOf(Mood.ENERGIA), fav = i % 3 == 0, hour = 3))?.let {
                    assertTrue("$p: $it", it in own)
                    assertFalse(it in neutral && it !in own)
                }
            }
        }
    }

    @Test fun contextual_categories_only_when_the_condition_is_true() {
        val artist = only(JuliPersona.GROSERA, NormalCat.ARTISTA)
        val noArtist = (1..200).mapNotNull { PhraseEngine(Random(it.toLong())).playback(ctx(JuliPersona.GROSERA, streakArtist = 1)) }
        assertTrue(noArtist.none { it in artist })
        val yes = (1..200).mapNotNull { PhraseEngine(Random(it.toLong())).playback(ctx(JuliPersona.GROSERA, streakArtist = 4)) }
        assertTrue(yes.count { it in artist } > 40)
        val night = only(JuliPersona.GROSERA, NormalCat.MADRUGADA)
        assertTrue((1..200).mapNotNull { PhraseEngine(Random(it.toLong())).playback(ctx(JuliPersona.GROSERA, hour = 15)) }.none { it in night })
        assertTrue((1..200).mapNotNull { PhraseEngine(Random(it.toLong())).playback(ctx(JuliPersona.GROSERA, hour = 3)) }.count { it in night } > 40)
        val single = only(JuliPersona.GROSERA, NormalCat.UNICA)
        assertTrue((1..200).mapNotNull { PhraseEngine(Random(it.toLong())).playback(ctx(JuliPersona.GROSERA, plays = 1, last = t0 - 60 * day)) }.count { it in single } > 40)
        assertTrue((1..200).mapNotNull { PhraseEngine(Random(it.toLong())).playback(ctx(JuliPersona.GROSERA, plays = 1, last = t0 - 2 * day)) }.none { it in single })
    }

    @Test fun anti_repetition_holds_for_new_personas() {
        for (p in listOf(JuliPersona.GROSERA, JuliPersona.ROMANTICA)) {
            val e = PhraseEngine(Random(9))
            val out = ArrayList<String>()
            var now = t0
            repeat(300) { i -> now += 10_000; e.playback(ctx(p, id = i.toLong(), now = now, fav = true, moods = listOf(Mood.ROMANTICA)))?.let { out += it } }
            assertTrue(out.size > 100)
            for (i in 1 until out.size) assertTrue(out[i] != out[i - 1])
        }
    }

    // ---------- Easter Eggs ----------

    @Test fun eggs_have_all_rarities_and_hints() {
        assertEquals(11, Eggs.all.size)
        assertEquals(Rarity.values().toSet(), Eggs.all.map { it.rarity }.toSet())
        assertTrue(Eggs.all.all { it.hint.isNotBlank() && it.desc.isNotBlank() })
        assertEquals(Eggs.all.size, Eggs.all.map { it.id }.toSet().size)
    }

    @Test fun repetition_egg_unlocks_once_and_is_not_new_again() {
        val e = engine()
        var now = t0
        var hits = 0; var news = 0
        repeat(40) { now += 60_000; e.onCounted(song(1), SongStat(plays = it + 1), false, 12, now, 10)?.let { h -> if (h.def.id == Eggs.REPEAT) { hits++; if (h.isNew) news++ } } }
        assertEquals(1, news)
        assertTrue(Eggs.REPEAT in e.found)
        assertTrue(hits <= 2)
    }

    @Test fun no_false_positive_on_normal_listening() {
        val e = engine()
        var now = t0
        repeat(60) { i -> now += 5 * 60_000; assertNull(e.onCounted(song(i.toLong(), artist = "Ar${i % 7}", album = "Alb$i"), SongStat(plays = 1), false, 15, now, 12)) }
        assertTrue(e.found.isEmpty())
    }

    @Test fun marathon_needs_consecutive_same_artist() {
        val e = engine()
        var now = t0
        repeat(7) { i -> now += 60_000; assertNull(e.onCounted(song(i.toLong(), "X", "Alb$i"), SongStat(plays = 1), false, 15, now, 12)) }
        e.onCounted(song(50, "Y", "Z"), SongStat(plays = 1), false, 15, now + 1, 12)
        assertTrue(Eggs.MARATHON !in e.found)
        repeat(8) { i -> now += 60_000; e.onCounted(song(100L + i, "W", "Alb$i"), SongStat(plays = 1), false, 15, now, 12) }
        assertTrue(Eggs.MARATHON in e.found)
    }

    @Test fun never_finished_needs_repeated_skips_and_completion_resets() {
        val e = engine()
        repeat(3) { assertNull(e.onSkip(7, t0 + it)) }
        e.onCounted(song(7), SongStat(plays = 1), false, 15, t0 + 10, 12)   // la escucha: el contador vuelve a 0
        repeat(3) { assertNull(e.onSkip(7, t0 + 20 + it)) }
        assertNotNull(e.onSkip(7, t0 + 40))
        assertTrue(Eggs.NEVER in e.found)
    }

    @Test fun full_album_requires_all_tracks_without_skips() {
        val e = engine()
        var now = t0
        for (i in 1..4) { now += 60_000; e.onCounted(song(i.toLong(), "A", "Disco"), SongStat(plays = 1), false, 15, now, 5) }
        assertTrue(Eggs.ALBUM !in e.found)                     // faltan canciones
        e.onSkip(99, now)                                      // una omisión rompe la racha
        for (i in 1..5) { now += 60_000; e.onCounted(song(i.toLong(), "A", "Disco"), SongStat(plays = 2), false, 15, now, 5) }
        assertTrue(Eggs.ALBUM in e.found)
    }

    @Test fun small_albums_do_not_count() {
        val e = engine()
        for (i in 1..3) e.onCounted(song(i.toLong(), "A", "EP"), SongStat(plays = 1), false, 15, t0 + i, 3)
        assertTrue(Eggs.ALBUM !in e.found)
    }

    @Test fun night_egg_only_between_3_and_5_am() {
        val e = engine()
        repeat(6) { e.onCounted(song(it.toLong(), "A$it", "B$it"), SongStat(plays = 1), false, 14, t0 + it * 1000L, 12) }
        assertTrue(Eggs.NIGHT !in e.found)
        repeat(3) { e.onCounted(song(10L + it, "A$it", "B$it"), SongStat(plays = 1), false, 3, t0 + 100_000L + it * 1000L, 12) }
        assertTrue(Eggs.NIGHT in e.found)
    }

    @Test fun failed_surprise_egg_needs_three_fails_then_success() {
        val e = engine()
        e.onSurprisePick(1); e.onSkip(1, t0)
        e.onSurprisePick(2); e.onSkip(2, t0)
        e.onSurprisePick(3)
        e.onCounted(song(3), SongStat(plays = 1), false, 15, t0 + 50_000, 12)
        assertTrue(Eggs.SURPRISE !in e.found)                  // solo 2 fallos
        assertEquals(2, e.takeRecovered())
        for (i in 1L..3L) { e.onSurprisePick(10 + i); e.onSkip(10 + i, t0) }
        e.onSurprisePick(20)
        e.onCounted(song(20), SongStat(plays = 1), false, 15, t0 + 90_000, 12)
        assertTrue(Eggs.SURPRISE in e.found)
    }

    @Test fun over_listened_favorite_needs_favorite_and_many_plays() {
        val e = engine()
        e.onCounted(song(1), SongStat(plays = 80), false, 15, t0, 12)
        assertTrue(Eggs.FAV !in e.found)
        e.onCounted(song(2), SongStat(plays = 12), true, 15, t0 + 1, 12)
        assertTrue(Eggs.FAV !in e.found)
        e.onCounted(song(3), SongStat(plays = 41), true, 15, t0 + 2, 12)
        assertTrue(Eggs.FAV in e.found)
    }

    @Test fun single_listen_egg_needs_one_play_and_a_long_absence() {
        val e = engine()
        assertNull(e.onSelect(song(1), SongStat(plays = 1, last = t0 - 10 * day), emptyMap(), t0))
        assertNull(e.onSelect(song(1), SongStat(plays = 3, last = t0 - 200 * day), emptyMap(), t0))
        assertNotNull(e.onSelect(song(1), SongStat(plays = 1, last = t0 - 120 * day), emptyMap(), t0))
        assertTrue(Eggs.SINGLE in e.found)
    }

    @Test fun returned_song_needs_disappearing_then_coming_back() {
        val e = engine()
        val a = song(1, "A", "A1"); val b = song(2, "B", "B1"); val c = song(3, "C", "C1")
        val st = mapOf(1L to SongStat(plays = 5), 2L to SongStat(plays = 5), 3L to SongStat(plays = 5))
        assertNull(e.onLibrary(listOf(a, b, c), st, t0))
        assertNull(e.onLibrary(listOf(a, b), st, t0 + day))               // c desaparece
        assertNull(e.onLibrary(listOf(a, b), st, t0 + 2 * day))
        assertNotNull(e.onLibrary(listOf(a, b, song(30, "C", "C1", title = "t3")), st, t0 + 3 * day))   // vuelve (otro id, mismo título+artista)
        assertTrue(Eggs.RETURNED in e.found)
    }

    @Test fun returned_ignores_mass_disappearance_like_changing_folder() {
        val e = engine()
        val l = (1L..10L).map { song(it, "A$it", "B$it") }
        val st = l.associate { it.id to SongStat(plays = 5) }
        e.onLibrary(l, st, t0)
        e.onLibrary(l.take(2), st, t0 + day)                               // desaparece el 80 %
        assertNull(e.onLibrary(l, st, t0 + 3 * day))
        assertTrue(Eggs.RETURNED !in e.found)
    }

    @Test fun absurd_secret_is_rare_and_uses_the_persona_list() {
        val stats = mapOf(1L to SongStat(plays = 500))
        var hits = 0
        val e = engine(JuliPersona.GROSERA, 5)
        var now = t0
        repeat(5000) { now += 20 * day; e.onSelect(song(1), stats[1], stats, now)?.let { hits++ } }
        assertTrue(hits in 1..80)
        assertTrue(Eggs.ABSURD in e.found)
        val rnd = Random(2)
        repeat(50) { assertTrue(EggLines.pick(Eggs.ABSURD, JuliPersona.GROSERA, rnd) in PersonaBank.absurd(JuliPersona.GROSERA)) }
        repeat(20) { assertTrue(EggLines.pick(Eggs.ABSURD, JuliPersona.ROMANTICA, rnd) in listOf("Hola.", "...", "Ok.", "No tengo nada que decir.")) }
    }

    @Test fun every_egg_has_a_reaction_for_every_persona() {
        val rnd = Random(1)
        for (d in Eggs.all) for (p in JuliPersona.values()) assertTrue(EggLines.pick(d.id, p, rnd).isNotBlank())
        for (p in JuliPersona.values()) assertTrue(EggLines.pick("night2", p, rnd).isNotBlank())
    }

    @Test fun already_found_egg_has_cooldown_and_never_announces_again() {
        val e = engine()
        var now = t0
        var news = 0; var again = 0
        repeat(200) { now += 60_000; e.onCounted(song(1), SongStat(plays = 1), false, 12, now, 10)?.let { if (it.def.id == Eggs.REPEAT) { if (it.isNew) news++ else again++ } } }
        assertEquals(1, news)
        assertTrue(again <= 1)
    }
}
