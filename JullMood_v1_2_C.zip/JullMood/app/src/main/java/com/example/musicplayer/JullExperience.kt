package com.example.musicplayer

import android.graphics.Bitmap
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.material3.ColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * JullExperience (v1.2-A): capa visual OPCIONAL. No toca la reproducción ni sustituye el sistema de temas:
 * toma el esquema del tema elegido y le superpone una paleta sacada de la portada de la canción actual.
 * Con JullExperience (o Dynamic Experience) en OFF nada de este archivo se ejecuta y la app es la v1.1.
 */

/** Paleta dinámica: tonos ya normalizados para tener buen contraste sobre fondos oscuros y claros. */
data class DynamicPalette(
    val primary: Color,     // acento principal (controles, selección, elementos destacados)
    val secondary: Color,   // segundo tono de la portada (o variación del primero)
    val tertiary: Color,    // tercer tono (o variación)
    val tintHue: Float,     // tono (0..360) con el que se tiñen fondos y superficies
    val tintSat: Float      // intensidad del tinte (0..1)
)

object JullPalette {
    /** Paleta segura cuando no hay portada válida: acento por defecto de la app, sin tinte. */
    val SAFE = DynamicPalette(
        primary = AppTheme.DYNAMIC.accent,
        secondary = Color(0xFF8EA8FF),
        tertiary = Color(0xFF5EEAD4),
        tintHue = 260f, tintSat = 0.0f
    )

    /** Si hay portada se usa su tono; si no, el mismo tono que la carátula por defecto (coherente con la UI). */
    fun fallbackFor(seed: String): DynamicPalette = fromHues(
        hues = listOf((abs(seed.hashCode()) % 360).toFloat()), sats = listOf(0.6f), vals = listOf(0.9f), tintSat = 0.35f
    )

    /**
     * Extrae hasta 3 tonos dominantes con un histograma de 12 tonos sobre una miniatura de 32 px
     * (misma técnica que CoverColors, sin librerías). Devuelve null si la imagen es prácticamente gris.
     * Se llama UNA vez por canción (ver JullPaletteCache).
     */
    fun extract(src: Bitmap): DynamicPalette? = runCatching {
        val soft = if (src.config == Bitmap.Config.HARDWARE) src.copy(Bitmap.Config.ARGB_8888, false) else src
        val n = 32
        val b = Bitmap.createScaledBitmap(soft, n, n, true)
        val px = IntArray(n * n)
        b.getPixels(px, 0, n, 0, 0, n, n)

        val bins = 12
        val wSum = DoubleArray(bins); val relSum = DoubleArray(bins)
        val sSum = DoubleArray(bins); val vSum = DoubleArray(bins)
        val hsv = FloatArray(3)
        for (p in px) {
            android.graphics.Color.colorToHSV(p, hsv)
            val s = hsv[1]; val v = hsv[2]
            if (s < 0.16f || v < 0.16f) continue                       // ignora grises, blancos y negros
            val bin = ((hsv[0] + 15f) / 30f).toInt() % bins
            val w = (s * (0.4f + v)).toDouble()
            wSum[bin] += w
            relSum[bin] += w * (((hsv[0] - bin * 30f + 540f) % 360f) - 180f)
            sSum[bin] += w * s
            vSum[bin] += w * v
        }
        val total = wSum.sum()
        if (total < 10.0) return@runCatching null                         // casi escala de grises: sin paleta

        // Tonos ordenados por peso; el 2.º y 3.º deben ser suficientemente relevantes y distintos al resto.
        val order = (0 until bins).sortedByDescending { wSum[it] }
        val picked = ArrayList<Int>()
        for (i in order) {
            if (wSum[i] < total * 0.08) break
            if (picked.none { hueDist(it * 30f, i * 30f) < 45f }) picked += i
            if (picked.size == 3) break
        }
        if (picked.isEmpty()) return@runCatching null
        fun hueOfBin(i: Int) = (i * 30f + (relSum[i] / wSum[i]).toFloat() + 360f) % 360f
        fromHues(
            hues = picked.map { hueOfBin(it) },
            sats = picked.map { (sSum[it] / wSum[it]).toFloat() },
            vals = picked.map { (vSum[it] / wSum[it]).toFloat() },
            tintSat = (sSum[picked[0]] / wSum[picked[0]]).toFloat().coerceIn(0.3f, 0.7f)
        )
    }.getOrNull()

    private fun hueDist(a: Float, b: Float): Float { val d = abs(a - b) % 360f; return min(d, 360f - d) }

    /** Normaliza saturación/brillo (acentos legibles sobre fondo oscuro) y completa los tonos que falten. */
    private fun fromHues(hues: List<Float>, sats: List<Float>, vals: List<Float>, tintSat: Float): DynamicPalette {
        fun accent(i: Int) = Color.hsv(
            hues[i], sats[i].coerceIn(0.5f, 0.9f), vals[i].coerceIn(0.75f, 0.95f)
        )
        val p = accent(0)
        val s = if (hues.size > 1) accent(1) else Color.hsv((hues[0] + 28f) % 360f, 0.55f, 0.88f)
        val t = if (hues.size > 2) accent(2) else Color.hsv((hues[0] + 330f) % 360f, 0.5f, 0.9f)
        return DynamicPalette(p, s, t, hues[0], tintSat)
    }

    /** Interpolación entre paletas (transición suave). */
    fun blend(a: DynamicPalette, b: DynamicPalette, t: Float): DynamicPalette = when {
        t <= 0f -> a
        t >= 1f -> b
        else -> DynamicPalette(
            lerp(a.primary, b.primary, t), lerp(a.secondary, b.secondary, t), lerp(a.tertiary, b.tertiary, t),
            // El tono del tinte se interpola por el camino corto del círculo cromático.
            run {
                val d = ((b.tintHue - a.tintHue + 540f) % 360f) - 180f
                (a.tintHue + d * t + 360f) % 360f
            },
            a.tintSat + (b.tintSat - a.tintSat) * t
        )
    }

    // ---------- Contraste ----------

    private fun contrast(a: Color, b: Color): Float {
        val la = a.luminance() + 0.05f; val lb = b.luminance() + 0.05f
        return max(la, lb) / min(la, lb)
    }

    /** Ajusta `c` (acercándolo a blanco o negro según el fondo) hasta lograr al menos `min` de contraste con `bg`. */
    private fun ensureContrast(c: Color, bg: Color, min: Float): Color {
        if (contrast(c, bg) >= min) return c
        val target = if (bg.luminance() > 0.5f) Color.Black else Color.White
        var out = c
        for (step in 1..10) {
            out = lerp(c, target, step / 10f)
            if (contrast(out, bg) >= min) break
        }
        return out
    }

    /**
     * Aplica la paleta sobre el esquema del tema actual. Mantiene la identidad del tema:
     *  - AMOLED conserva el fondo negro puro; Claro sigue siendo claro; Personalizado conserva su fondo.
     *  - Los textos (onBackground / onSurface) NO se tocan: el contraste del tema se mantiene.
     *  - Los acentos se corrigen para tener contraste >= 3:1 (elementos gráficos) con fondo y superficie.
     */
    fun apply(base: ColorScheme, theme: AppTheme, p: DynamicPalette): ColorScheme {
        val light = base.background.luminance() > 0.5f
        val k = p.tintSat
        fun tint(c: Color, amount: Float): Color {
            val target = Color.hsv(p.tintHue, if (light) 0.30f else 0.55f, if (light) 0.97f else 0.30f)
            return lerp(c, target, (amount * k).coerceIn(0f, 1f))
        }
        val keepBg = theme == AppTheme.AMOLED
        val bg = if (keepBg) base.background else tint(base.background, if (light) 0.22f else 0.30f)
        val surface = tint(base.surface, if (light) 0.18f else 0.32f)
        val variant = tint(base.surfaceVariant, if (light) 0.22f else 0.38f)

        val primary = ensureContrast(p.primary, bg, 3f).let { ensureContrast(it, surface, 3f) }
        val secondary = ensureContrast(p.secondary, bg, 3f)
        val tertiary = ensureContrast(p.tertiary, bg, 3f)
        val container = lerp(surface, primary, if (light) 0.22f else 0.30f)
        val onContainer = if (contrast(base.onSurface, container) >= 4.5f) base.onSurface else onColorFor(container)

        return base.copy(
            primary = primary, onPrimary = onColorFor(primary),
            primaryContainer = container, onPrimaryContainer = onContainer,
            secondary = secondary, onSecondary = onColorFor(secondary),
            secondaryContainer = container, onSecondaryContainer = onContainer,
            tertiary = tertiary, onTertiary = onColorFor(tertiary),
            background = bg, surface = surface, surfaceVariant = variant,
            outlineVariant = variant,
            // Los textos secundarios deben seguir legibles sobre el fondo ya teñido.
            onSurfaceVariant = ensureContrast(base.onSurfaceVariant, surface, 4.5f)
        )
    }
}

/**
 * Caché de paletas por canción (LRU pequeña: unas decenas de bytes por entrada). La clave incluye la carátula
 * personalizada, igual que ArtCache: al corregir una canción se recalcula, y si no, nunca se vuelve a analizar.
 */
object JullPaletteCache {
    private val map = object : LinkedHashMap<String, DynamicPalette>(64, 0.75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<String, DynamicPalette>?) = size > 300
    }

    fun keyOf(song: Song) = "${song.id}:${song.customArt.hashCode()}"
    @Synchronized fun get(song: Song): DynamicPalette? = map[keyOf(song)]
    @Synchronized fun put(song: Song, p: DynamicPalette) { map[keyOf(song)] = p }
}

/** Última paleta realmente mostrada (ya con la anticipación aplicada), para arrancar cada transición sin saltos. */
private class ShownMemo { var last: DynamicPalette? = null }

/**
 * Transición entre la paleta anterior y la nueva: UNA sola animación (progreso 0..1) en vez de una por color.
 * v1.2-C: el tipo de transición (Instantánea/Suave/Lenta/Fundida) y su escala vienen de JullFx; con "Reducir
 * animaciones" el cambio es instantáneo. `anticipation` (Queue Atmosphere) mezcla ligeramente la paleta de la
 * siguiente canción durante los últimos segundos. Devuelve null si la capa está apagada.
 *
 * Cambio rápido de canción: al llegar un destino nuevo la corrutina anterior se cancela (LaunchedEffect) y la
 * nueva parte de lo que se VE en ese momento (incluida la anticipación), así que solo queda la transición de la
 * canción actual y nunca hay saltos.
 */
@Composable
internal fun rememberAnimatedPalette(
    target: DynamicPalette?, reduced: Boolean,
    transition: PaletteTransition = PaletteTransition.SMOOTH, scale: Float = 1f,
    anticipation: Anticipation? = null
): DynamicPalette? {
    if (target == null) return null
    var from by remember { mutableStateOf(target) }
    var to by remember { mutableStateOf(target) }
    val progress = remember { Animatable(1f) }
    val memo = remember { ShownMemo() }
    LaunchedEffect(target) {
        if (target == to) return@LaunchedEffect
        // Punto de partida: lo que se ve ahora mismo (también si la transición anterior no había terminado).
        from = memo.last ?: JullPalette.blend(from, to, progress.value)
        to = target
        val ms = transition.durationMs(scale)
        if (reduced || ms == 0) { progress.snapTo(1f) }
        else { progress.snapTo(0f); progress.animateTo(1f, tween(ms, easing = transition.easing)) }
    }
    val base = JullPalette.blend(from, to, progress.value)
    val shown = if (anticipation != null && anticipation.amount > 0f) JullPalette.blend(base, anticipation.palette, anticipation.amount) else base
    // Solo se recuerda lo mostrado cuando el destino ya está asentado (así el primer fotograma de una canción nueva no lo pisa).
    if (target == to) memo.last = shown
    return shown
}
