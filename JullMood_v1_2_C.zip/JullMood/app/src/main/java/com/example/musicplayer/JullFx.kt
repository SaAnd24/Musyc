package com.example.musicplayer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * v1.2-B: Ambient Background, Music Motion, Player/Mini-player Styles y Motion System.
 * Todo vive dentro de JullExperience: con JullExperience en OFF, [JullFx.OFF] hace que la app se vea como la v1.1.
 * Solo UI nativa (gradientes), sin dependencias, sin vídeo/GIF.
 */

// ---------- Opciones (se guardan por nombre en SharedPreferences) ----------

enum class AmbientMode(val label: String) { OFF("OFF"), STATIC("Static"), LAVA("Lava"), AURORA("Aurora"), GLOW("Glow") }

/** Intensidad compartida por Ambient Background y Music Motion. */
enum class FxLevel(val label: String, val k: Float) { SUBTLE("Sutil", 0.6f), NORMAL("Normal", 1f), INTENSE("Intenso", 1.5f) }

enum class MusicMotionMode(val label: String) { DISABLED("Disabled"), COVER("Cover"), INFO("Info"), PROGRESS("Progress") }

/** Classic = el reproductor de la v1.1 tal cual. */
enum class PlayerStyle(val label: String) { MINIMAL("Minimal"), CLASSIC("Classic"), CINEMATIC("Cinematic"), IMMERSIVE("Immersive") }

/** Classic = el mini-reproductor de la v1.1 tal cual. */
enum class MiniStyle(val label: String) { CLASSIC("Classic"), COMPACT("Compact"), FLOATING("Floating"), GLOW("Glow") }

/** Control global de animaciones. `amp` escala distancias/escalas; `dur` escala duraciones. Normal = v1.1. */
enum class MotionLevel(val label: String, val amp: Float, val dur: Float) {
    OFF("OFF", 0f, 0f), SUBTLE("Sutil", 0.55f, 0.8f), NORMAL("Normal", 1f, 1f), INTENSE("Intenso", 1.5f, 1.25f)
}

/** Duración escalada por el nivel de Motion (mínimo 1 ms para no romper `tween`). */
internal fun MotionLevel.ms(base: Int): Int = max(1, (base * dur).roundToInt())

/**
 * Todas las opciones de JullExperience (v1.2-B y v1.2-C) ya resueltas, con el Experience Mood aplicado:
 * si JullExperience está OFF vale [OFF].
 */
data class JullFx(
    val enabled: Boolean = false,
    val dynamic: Boolean = false,
    val ambient: AmbientMode = AmbientMode.OFF,
    val ambientLevel: FxLevel = FxLevel.NORMAL,
    val musicMotion: MusicMotionMode = MusicMotionMode.DISABLED,
    val musicMotionLevel: FxLevel = FxLevel.NORMAL,
    val playerStyle: PlayerStyle = PlayerStyle.CLASSIC,
    val miniStyle: MiniStyle = MiniStyle.CLASSIC,
    val motion: MotionLevel = MotionLevel.NORMAL,
    // v1.2-C (JullExperience Adaptive). Los valores por defecto equivalen a la v1.2-B.
    val paletteTransition: PaletteTransition = PaletteTransition.SMOOTH,
    val transitionScale: Float = 1f,           // >1 = transiciones y anticipación más largas (Mood Cinemático)
    val queueAtmosphere: Boolean = false,
    val expProgress: ExpProgress = ExpProgress.OFF,
    val mood: ExperienceMood = ExperienceMood.CUSTOM,
    val liveJull: Boolean = false
) {
    val ambientOn: Boolean get() = enabled && ambient != AmbientMode.OFF
    companion object { val OFF = JullFx() }
}

val LocalJull = staticCompositionLocalOf { JullFx.OFF }

// ---------- Reloj de efectos: despierta solo a `fps` y solo si hace falta ----------

/**
 * Tiempo en segundos que avanza únicamente mientras `running` sea true, a `fps` fotogramas por segundo (no 60).
 * Solo se lee en la fase de dibujo/capa gráfica: no provoca recomposiciones. Al parar, la corrutina termina.
 */
@Composable
internal fun rememberFxClock(running: Boolean, fps: Int): State<Float> {
    val t = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(running, fps) {
        if (!running) return@LaunchedEffect
        val step = (1000 / fps).toLong()
        var last = System.nanoTime()
        while (true) {
            delay(step)
            val now = System.nanoTime()
            t.floatValue += (now - last) / 1e9f
            last = now
        }
    }
    return t
}

/** true mientras la app está al menos en STARTED (visible). Las animaciones infinitas se detienen en segundo plano. */
@Composable
internal fun rememberAppVisible(): Boolean {
    val owner = LocalLifecycleOwner.current
    var visible by remember { mutableStateOf(owner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, _ -> visible = owner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED) }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    return visible
}

// ---------- Ambient Background ----------

private fun shiftHue(c: Color, deg: Float): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(android.graphics.Color.argb(255, (c.red * 255).toInt(), (c.green * 255).toInt(), (c.blue * 255).toInt()), hsv)
    return Color.hsv((hsv[0] + deg + 360f) % 360f, hsv[1].coerceIn(0.35f, 1f), hsv[2].coerceIn(0.55f, 1f))
}

/**
 * Fondo ambiental detrás de la interfaz. Los colores salen de MaterialTheme.colorScheme: con Dynamic Experience ON ya
 * son los de la portada actual (con su transición suave); con OFF son los del tema. NUNCA genera ni analiza una paleta.
 * `playing`: Lava/Aurora/Glow solo se animan mientras suena la música, la app está visible y las animaciones no están
 * reducidas; si no, se quedan en un fotograma fijo (sin ningún trabajo por fotograma).
 * `focus`: punto (0..1) alrededor del que se concentra Glow (p. ej. la portada).
 */
@Composable
internal fun AmbientLayer(playing: Boolean, modifier: Modifier = Modifier.fillMaxSize(), focus: Offset = Offset(0.5f, 0.2f)) {
    val fx = LocalJull.current
    val mode = fx.ambient
    if (!fx.enabled || mode == AmbientMode.OFF) return
    val cs = MaterialTheme.colorScheme
    val k = fx.ambientLevel.k
    val animated = mode != AmbientMode.STATIC
    val reducedMotion = rememberReducedMotion()
    val visible = rememberAppVisible()
    val running = animated && playing && !reducedMotion && fx.motion != MotionLevel.OFF && visible
    // Lava es el efecto más caro: el que menos fotogramas por segundo usa.
    val fps = when (mode) { AmbientMode.LAVA -> 15; AmbientMode.AURORA -> 20; else -> 12 }
    // v1.2-C: LiveJull solo pide la energía de audio mientras este efecto se está animando de verdad.
    val live = fx.liveJull && running
    DisposableEffect(live) {
        if (live) LiveEnergy.acquire()
        onDispose { if (live) LiveEnergy.release() }
    }
    val drive = rememberAmbientDrive(running, fps, k, live, fx.expProgress)

    Canvas(modifier) {
        val c1 = cs.primary
        val c2 = if (cs.secondary == cs.primary) shiftHue(c1, 35f) else cs.secondary
        val c3 = if (cs.tertiary == cs.primary || cs.tertiary == cs.secondary) shiftHue(c1, -35f) else cs.tertiary
        val t = drive.t
        val m = drive.mods
        when (mode) {
            AmbientMode.STATIC -> drawStatic(c1, c2, k)
            AmbientMode.LAVA -> drawLava(c1, c2, c3, k, t, m)
            AmbientMode.AURORA -> drawAurora(c1, c2, c3, k, t, m)
            AmbientMode.GLOW -> drawGlow(c1, c2, k, t, focus, m)
            AmbientMode.OFF -> Unit
        }
    }
}

/**
 * Estado de animación del Ambient (v1.2-C): el tiempo del efecto y sus multiplicadores actuales. Se actualiza solo
 * mientras `running` (mismo ritmo de fotogramas que antes). Sin LiveJull ni Progress los multiplicadores son
 * neutros y el tiempo avanza exactamente igual que con rememberFxClock.
 */
@Stable
internal class AmbientDrive {
    var t by mutableFloatStateOf(0f)
    var mods by mutableStateOf(FxMods.NEUTRAL)
    var energy = 0.3f      // energía de audio ya suavizada (no es estado: solo la usa el bucle de animación)
    var mix = 0f           // 0..1: cuánto se fía el efecto de los datos de audio (0 = animación normal)
}

@Composable
internal fun rememberAmbientDrive(running: Boolean, fps: Int, k: Float, live: Boolean, prog: ExpProgress): AmbientDrive {
    val d = remember { AmbientDrive() }
    LaunchedEffect(running, fps, k, live, prog) {
        if (!running) return@LaunchedEffect
        val step = (1000 / fps).toLong()
        var last = System.nanoTime()
        while (true) {
            delay(step)
            val now = System.nanoTime()
            val dt = ((now - last) / 1e9f).coerceAtMost(0.5f)
            last = now
            // Datos de audio solo con LiveJull; -1 = no hay (pausa, formato no soportado…) → vuelve poco a poco a lo normal.
            val raw = if (live) LiveEnergy.read(now) else -1f
            val has = raw >= 0f
            if (has) d.energy += (raw - d.energy) * (1f - exp(-dt / 0.6f))
            d.mix += ((if (has) 1f else 0f) - d.mix) * (1f - exp(-dt / (if (has) 1.0f else 0.6f)))
            val m = fxMods(k, d.mix > 0.01f, d.energy, d.mix, prog, FxProgress.fraction)
            d.mods = m
            d.t += dt * m.speed
        }
    }
    return d
}

/** Alfa máximo: acentos brillantes a poca opacidad sobre el fondo; el texto del tema conserva su contraste. */
private fun a(base: Float, k: Float) = (base * k).coerceIn(0f, 0.5f)

private fun DrawScope.drawStatic(c1: Color, c2: Color, k: Float) {
    drawRect(Brush.verticalGradient(0f to c1.copy(alpha = a(0.30f, k)), 0.6f to Color.Transparent, endY = size.height))
    drawRect(Brush.radialGradient(listOf(c2.copy(alpha = a(0.16f, k)), Color.Transparent),
        center = Offset(size.width * 0.9f, size.height * 0.95f), radius = size.maxDimension * 0.7f))
}

/** Lava: 3 manchas con gradiente radial que derivan despacio (trayectorias suaves, sin blur ni shaders). */
private fun DrawScope.drawLava(c1: Color, c2: Color, c3: Color, k: Float, t: Float, m: FxMods) {
    val w = size.width; val h = size.height; val r = size.maxDimension * 0.55f * m.size
    drawRect(Brush.verticalGradient(0f to c1.copy(alpha = a(0.12f * m.light, k)), 1f to Color.Transparent))
    fun blob(c: Color, ph: Float, sx: Float, sy: Float, fx: Float, fy: Float, rad: Float, al: Float) {
        val cx = w * (0.5f + sx * sin(t * fx + ph)); val cy = h * (0.5f + sy * sin(t * fy + ph * 1.7f))
        val paint = {
            drawCircle(Brush.radialGradient(listOf(c.copy(alpha = a(al * m.light, k)), Color.Transparent), center = Offset(cx, cy), radius = rad), rad, Offset(cx, cy))
        }
        // LiveJull: deformación (la mancha se estira y se encoge); sin LiveJull deform = 0 y se dibuja igual que en la v1.2-B.
        if (m.deform > 0.001f) {
            val d = m.deform * sin(t * 0.7f + ph)
            scale(1f + d, 1f - d, Offset(cx, cy)) { paint() }
        } else paint()
    }
    blob(c1, 0f, 0.35f, 0.30f, 0.17f, 0.13f, r, 0.34f)
    blob(c2, 2.1f, 0.38f, 0.34f, 0.11f, 0.19f, r * 0.9f, 0.28f)
    blob(c3, 4.2f, 0.30f, 0.38f, 0.14f, 0.10f, r * 0.8f, 0.22f)
}

/** Aurora: bandas luminosas inclinadas que ondulan despacio (3 rectángulos con degradado vertical, rotados). */
private fun DrawScope.drawAurora(c1: Color, c2: Color, c3: Color, k: Float, t: Float, m: FxMods) {
    val w = size.width; val h = size.height
    fun band(c: Color, ph: Float, y: Float, tilt: Float, al: Float) {
        val dy = h * 0.06f * m.sway * sin(t * 0.35f + ph)
        val ang = tilt + 6f * m.sway * sin(t * 0.22f + ph * 1.3f)
        val bh = h * 0.34f
        val top = h * y + dy - bh / 2f
        rotate(ang, Offset(w / 2f, h * y + dy)) {
            drawRect(
                Brush.verticalGradient(0f to Color.Transparent, 0.5f to c.copy(alpha = a(al * m.light, k)), 1f to Color.Transparent, startY = top, endY = top + bh),
                topLeft = Offset(-w * 0.3f, top), size = androidx.compose.ui.geometry.Size(w * 1.6f, bh)
            )
        }
    }
    band(c1, 0f, 0.18f, -12f, 0.36f)
    band(c2, 2.0f, 0.42f, 9f, 0.28f)
    band(c3, 4.0f, 0.70f, -7f, 0.22f)
}

/** Glow: luz difusa alrededor de `focus` (la portada) que "respira" muy poco, y un resplandor tenue abajo. */
private fun DrawScope.drawGlow(c1: Color, c2: Color, k: Float, t: Float, focus: Offset, m: FxMods) {
    val breathe = 1f + 0.06f * m.pulse * sin(t * 0.8f)
    val center = Offset(size.width * focus.x, size.height * focus.y)
    val r = size.minDimension * 0.95f * breathe * m.size
    drawRect(Brush.radialGradient(listOf(c1.copy(alpha = a(0.40f * m.light, k)), c1.copy(alpha = a(0.12f * m.light, k)), Color.Transparent), center = center, radius = r))
    drawRect(Brush.radialGradient(listOf(c2.copy(alpha = a(0.14f * m.light, k)), Color.Transparent),
        center = Offset(size.width * 0.5f, size.height * 1.02f), radius = size.maxDimension * 0.6f))
}

// ---------- Música en movimiento (parámetros compartidos) ----------

/** Desplazamiento senoidal lento (±1) para derivas muy sutiles; `period` en segundos. */
internal fun drift(t: Float, period: Float, phase: Float = 0f): Float = sin((t / period) * 2f * PI.toFloat() + phase)
