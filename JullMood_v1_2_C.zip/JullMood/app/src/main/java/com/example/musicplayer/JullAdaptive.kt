package com.example.musicplayer

import android.content.Context
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * v1.2-C: JullExperience Adaptive. Todo se apoya en la arquitectura de v1.2-A/B (paletas, Ambient, Motion):
 * aquí solo viven las opciones nuevas y la lógica pura que las resuelve. Con todo en su valor por defecto
 * (Transición Suave, Queue Atmosphere OFF, Progress OFF, Mood Personalizado, LiveJull OFF) la app se ve como la v1.2-B.
 */

// ---------- 1. Transición de paleta ----------

/** "Fundida": el avance se frena hacia la mitad, de modo que la paleta anterior y la nueva se mezclan un rato. */
private val MixEasing = object : Easing {
    override fun transform(fraction: Float): Float {
        val twoPi = 2f * PI.toFloat()
        return (fraction + 0.8f * sin(twoPi * fraction) / twoPi).coerceIn(0f, 1f)
    }
}

/** Cómo cambia la paleta dinámica al cambiar de canción. Suave = los 650 ms de la v1.2-A/B. */
enum class PaletteTransition(val label: String, val baseMs: Int) {
    INSTANT("Instantánea", 0), SMOOTH("Suave", 650), SLOW("Lenta", 1600), CROSSFADE("Fundida", 1400);

    fun durationMs(scale: Float): Int = if (baseMs == 0) 0 else max(1, (baseMs * scale).roundToInt())
    val easing: Easing get() = if (this == CROSSFADE) MixEasing else FastOutSlowInEasing
}

// ---------- 2. Queue Atmosphere ----------

/** Paleta de la siguiente canción y cuánto se mezcla (0..QUEUE_MAX_MIX) con la actual. */
class Anticipation(val palette: DynamicPalette, val amount: Float)

internal const val QUEUE_WINDOW_MS = 8000L      // últimos segundos en los que empieza a anticiparse
internal const val QUEUE_PREFETCH_MS = 6000L    // la paleta siguiente se prepara un poco antes (sin mezclarla aún)
internal const val QUEUE_MAX_MIX = 0.30f        // tope de la mezcla: es una anticipación, no un cambio

/** Mezcla (0..QUEUE_MAX_MIX) según el tiempo que queda: curva suave, 0 fuera de la ventana. */
internal fun queueMix(remainingMs: Long, windowMs: Long): Float {
    if (windowMs <= 0L) return 0f
    val x = (1f - remainingMs.toFloat() / windowMs).coerceIn(0f, 1f)
    return QUEUE_MAX_MIX * x * x * (3f - 2f * x)
}

// ---------- 4. Experience Progress ----------

/** Evolución del Ambient según el progreso de la canción (solo usa position/duration). */
enum class ExpProgress(val label: String, val amt: Float) { OFF("OFF", 0f), SUBTLE("Sutil", 0.5f), NORMAL("Normal", 1f) }

/** Fracción reproducida de la canción actual (0..1). La escribe el ViewModel solo si Progress está activo. */
internal object FxProgress {
    var fraction by mutableFloatStateOf(0f)
}

// ---------- 5. Experience Mood ----------

enum class ExperienceMood(val label: String) { CALM("Calmado"), LIVELY("Vivo"), CINEMATIC("Cinemático"), CUSTOM("Personalizado") }

/**
 * Aplica el Mood sobre las opciones manuales (que NO se modifican: al volver a Personalizado se recuperan tal cual).
 * Solo ajusta parámetros que ya existen; Motion OFF (accesibilidad) nunca se sobrescribe.
 */
internal fun JullFx.withMood(): JullFx {
    fun motionOr(level: MotionLevel) = if (motion == MotionLevel.OFF) MotionLevel.OFF else level
    return when (mood) {
        ExperienceMood.CUSTOM -> this
        ExperienceMood.CALM -> copy(
            ambientLevel = FxLevel.SUBTLE, musicMotionLevel = FxLevel.SUBTLE, motion = motionOr(MotionLevel.SUBTLE),
            paletteTransition = PaletteTransition.SLOW, transitionScale = 1f
        )
        ExperienceMood.LIVELY -> copy(
            ambientLevel = FxLevel.NORMAL, musicMotionLevel = FxLevel.NORMAL, motion = motionOr(MotionLevel.NORMAL),
            paletteTransition = PaletteTransition.SMOOTH, transitionScale = 1f
        )
        ExperienceMood.CINEMATIC -> copy(
            ambientLevel = FxLevel.INTENSE, musicMotionLevel = FxLevel.NORMAL, motion = motionOr(MotionLevel.INTENSE),
            paletteTransition = PaletteTransition.CROSSFADE, transitionScale = 1.5f
        )
    }
}

// ---------- 6. Modulación de los efectos Ambient (LiveJull + Progress) ----------

/**
 * Multiplicadores sobre los efectos Ambient existentes. NEUTRAL (todo 1, deformación 0) = animación de la v1.2-B.
 * speed: velocidad del reloj del efecto · size: expansión/contracción · deform: deformación (Lava) ·
 * sway: desplazamiento/ondas (Aurora) · light: intensidad luminosa · pulse: pulsación (Glow).
 */
internal class FxMods(
    val speed: Float = 1f, val size: Float = 1f, val deform: Float = 0f,
    val sway: Float = 1f, val light: Float = 1f, val pulse: Float = 1f
) {
    companion object { val NEUTRAL = FxMods() }
}

private fun mix(a: Float, b: Float, t: Float) = a + (b - a) * t
private fun smooth01(x: Float): Float { val c = x.coerceIn(0f, 1f); return c * c * (3f - 2f * c) }

/**
 * k = intensidad Ambient (es el LÍMITE: el máximo de reacción crece con ella). energy = energía suavizada (0..1);
 * liveMix = fiabilidad de los datos de audio (0 = sin datos → animación normal). p = fracción reproducida.
 */
internal fun fxMods(k: Float, liveOn: Boolean, energy: Float, liveMix: Float, prog: ExpProgress, p: Float): FxMods {
    if (!liveOn && prog == ExpProgress.OFF) return FxMods.NEUTRAL
    var speed = 1f; var size = 1f; var deform = 0f; var sway = 1f; var light = 1f; var pulse = 1f
    if (liveOn && liveMix > 0f) {
        val e = smooth01(energy)
        // Canción suave (e≈0): lento y sutil. Canción intensa (e≈1): hasta el límite que marca la intensidad.
        speed = mix(1f, mix(0.55f, 1f + 1.3f * k, e), liveMix)
        size = mix(1f, mix(0.93f, 1f + 0.10f * k, e), liveMix)
        deform = liveMix * (0.03f + 0.15f * k * e)
        sway = mix(1f, mix(0.60f, 1f + 0.9f * k, e), liveMix)
        light = mix(1f, mix(0.85f, 1f + 0.25f * k, e), liveMix)
        pulse = mix(1f, mix(0.50f, 1f + 1.2f * k, e), liveMix)
    }
    if (prog != ExpProgress.OFF) {
        // inicio (-1) → desarrollo (0) → final (+1): evolución gradual y pequeña.
        val evo = 2f * smooth01(p) - 1f
        val a = prog.amt
        speed *= 1f + 0.20f * a * evo
        light *= 1f + 0.16f * a * evo
        size *= 1f + 0.08f * a * evo
        sway *= 1f + 0.15f * a * evo
    }
    return FxMods(
        speed.coerceIn(0.3f, 3.4f), size.coerceIn(0.85f, 1.25f), deform.coerceIn(0f, 0.3f),
        sway.coerceIn(0.4f, 2.4f), light.coerceIn(0.6f, 1.6f), pulse.coerceIn(0.3f, 3.2f)
    )
}

// ---------- 3. Visual Memory ----------

private fun DynamicPalette.quantized() = DynamicPalette(
    Color(primary.toArgb()), Color(secondary.toArgb()), Color(tertiary.toArgb()),
    (tintHue * 10f).roundToInt() / 10f, (tintSat * 100f).roundToInt() / 100f
)

/**
 * Memoria visual persistente: por canción guarda SOLO su paleta (3 colores + tinte) y una firma de la carátula de
 * la que salió. Nunca guarda imágenes ni archivos. Complementa a JullPaletteCache (RAM): si la canción es conocida
 * se evita decodificar la carátula, y si cambia la carátula (firma distinta) o la paleta, la entrada se actualiza.
 * Una entrada por canción (sin duplicados), tope de MAX entradas (se descartan las menos usadas), ~70 bytes cada una.
 */
internal class VisualMemory(context: Context) {
    private class Entry(val sig: String, val p: DynamicPalette, val fallback: Boolean, val album: Int, var ts: Long, var used: Long)

    private val file = File(context.applicationContext.filesDir, "visual_memory.json")
    private val map = HashMap<Long, Entry>()
    private var loaded = false
    private var dirty = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var flushJob: Job? = null

    private companion object {
        const val MAX = 2000
        const val FALLBACK_TTL = 3L * 24 * 3600 * 1000   // una paleta "sin portada" se reintenta pasados 3 días
    }

    /** Firma de la carátula: cambia al corregir/cambiar la portada (misma idea que la clave de ArtCache). */
    private fun sigOf(song: Song) = "${song.albumId}:${song.customArt.hashCode()}"

    @Synchronized fun warmUp() = ensureLoaded()

    @Synchronized fun get(song: Song): DynamicPalette? {
        ensureLoaded()
        val e = map[song.id] ?: return null
        if (e.sig != sigOf(song)) return null                                       // la portada cambió: recalcular
        val now = System.currentTimeMillis()
        if (e.fallback && (e.album != song.album.hashCode() || now - e.ts > FALLBACK_TTL)) return null
        e.used = now
        return e.p
    }

    @Synchronized fun put(song: Song, palette: DynamicPalette, fallback: Boolean) {
        ensureLoaded()
        val p = palette.quantized()
        val sig = sigOf(song)
        val album = if (fallback) song.album.hashCode() else 0
        val now = System.currentTimeMillis()
        val old = map[song.id]
        if (old != null && old.sig == sig && old.p == p && old.fallback == fallback && old.album == album) {
            old.used = now; if (fallback) old.ts = now                              // duplicado: no se escribe nada
            return
        }
        map[song.id] = Entry(sig, p, fallback, album, now, now)
        if (map.size > MAX) {
            val drop = map.entries.sortedBy { it.value.used }.take(map.size - (MAX * 9 / 10)).map { it.key }
            drop.forEach { map.remove(it) }
        }
        dirty = true
        if (flushJob?.isActive != true) flushJob = scope.launch { delay(3000); flushNow() }
    }

    /** Vuelca a disco si hay cambios (escritura atómica). Seguro de llamar desde cualquier hilo. */
    fun flushNow() {
        val text = synchronized(this) {
            if (!dirty) return
            dirty = false
            val arr = JSONArray()
            for ((id, e) in map) {
                arr.put(
                    JSONArray().put(id).put(e.sig)
                        .put(e.p.primary.toArgb()).put(e.p.secondary.toArgb()).put(e.p.tertiary.toArgb())
                        .put(e.p.tintHue.toDouble()).put(e.p.tintSat.toDouble())
                        .put(if (e.fallback) 1 else 0).put(e.album).put(e.ts).put(e.used)
                )
            }
            JSONObject().put("v", 1).put("e", arr).toString()
        }
        runCatching {
            val tmp = File(file.parentFile, file.name + ".tmp")
            tmp.writeText(text)
            if (!tmp.renameTo(file)) { file.writeText(text); tmp.delete() }
        }
    }

    private fun ensureLoaded() {
        if (loaded) return
        loaded = true
        runCatching {
            if (!file.exists()) return@runCatching
            val arr = JSONObject(file.readText()).getJSONArray("e")
            for (i in 0 until arr.length()) {
                val a = arr.getJSONArray(i)
                val p = DynamicPalette(
                    Color(a.getInt(2)), Color(a.getInt(3)), Color(a.getInt(4)),
                    a.getDouble(5).toFloat(), a.getDouble(6).toFloat()
                )
                map[a.getLong(0)] = Entry(a.getString(1), p, a.getInt(7) == 1, a.getInt(8), a.getLong(9), a.getLong(10))
            }
        }.onFailure { map.clear() }                                                  // archivo dañado: se empieza de cero
    }
}
