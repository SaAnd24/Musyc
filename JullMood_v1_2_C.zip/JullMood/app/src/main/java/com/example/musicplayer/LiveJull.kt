package com.example.musicplayer

import android.content.Context
import android.os.Handler
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.Renderer
import androidx.media3.exoplayer.RenderersFactory
import androidx.media3.exoplayer.audio.AudioRendererEventListener
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.MediaCodecAudioRenderer
import androidx.media3.exoplayer.audio.TeeAudioProcessor
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.metadata.MetadataOutput
import androidx.media3.exoplayer.text.TextOutput
import androidx.media3.exoplayer.video.VideoRendererEventListener
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

/**
 * LiveJull (v1.2-C): energía musical aproximada en tiempo real, calculada SOLO con el audio que ya se está
 * reproduciendo en este dispositivo (sin servidor, sin servicio propio, sin permisos, sin reconocer canciones).
 *
 * Cómo: un TeeAudioProcessor de Media3 deja pasar el PCM intacto y [EnergyMeter] mide su volumen RMS con unas
 * ~100 muestras por buffer, en ventanas de ~100 ms, y lo suaviza (sube en ~0,3 s, baja en ~1 s). El resultado es
 * un único Float volátil. Mientras ningún efecto lo necesite ([acquire] sin llamar) el medidor sale en la primera
 * línea: coste cero. Si no llegan datos (otro formato de audio, pipeline distinto, pausa), [read] devuelve -1 y los
 * efectos usan automáticamente la animación normal.
 */
internal object LiveEnergy {
    private val consumers = AtomicInteger(0)
    @Volatile private var level = 0f
    @Volatile private var stamp = 0L

    /** Un efecto Ambient con LiveJull en marcha lo pide al empezar a animarse y lo libera al detenerse. */
    fun acquire() { consumers.incrementAndGet() }
    fun release() { if (consumers.get() > 0) consumers.decrementAndGet() }
    fun wanted() = consumers.get() > 0

    /** Hilo de audio: x = energía instantánea (0..1) de una ventana de dt segundos. */
    fun push(x: Float, dt: Float) {
        val tau = if (x > level) 0.30f else 1.0f
        level += (x - level) * (1f - exp(-dt / tau))
        stamp = System.nanoTime()
    }

    /** Energía suavizada 0..1, o -1 si no hay datos recientes (se debe usar la animación normal). */
    fun read(nowNanos: Long): Float =
        if (!wanted() || nowNanos - stamp > 1_500_000_000L) -1f else level
}

/** Mide el volumen del PCM que pasa por el reproductor. Solo PCM 16 bits o float; cualquier otro formato se ignora. */
internal class EnergyMeter : TeeAudioProcessor.AudioBufferSink {
    private var rate = 44100
    private var channels = 2
    private var encoding = C.ENCODING_PCM_16BIT
    private var sumSq = 0.0
    private var count = 0
    private var frames = 0L

    override fun flush(sampleRateHz: Int, channelCount: Int, encoding: Int) {
        rate = max(8000, sampleRateHz)
        channels = max(1, channelCount)
        this.encoding = encoding
        sumSq = 0.0; count = 0; frames = 0L
    }

    override fun handleBuffer(buffer: ByteBuffer) {
        if (!LiveEnergy.wanted()) return                       // nadie lo necesita: no se procesa nada
        val bytes = when (encoding) {
            C.ENCODING_PCM_16BIT -> 2
            C.ENCODING_PCM_FLOAT -> 4
            else -> return
        }
        val frameBytes = bytes * channels
        val n = buffer.remaining() / frameBytes
        if (n <= 0) return
        buffer.order(ByteOrder.nativeOrder())
        val base = buffer.position()
        val stride = max(1, n / 96)
        var i = 0
        while (i < n) {
            val o = base + i * frameBytes
            val s = if (bytes == 2) {
                var v = buffer.getShort(o) / 32768f
                if (channels > 1) v = (v + buffer.getShort(o + 2) / 32768f) * 0.5f
                v
            } else {
                var v = buffer.getFloat(o)
                if (channels > 1) v = (v + buffer.getFloat(o + 4)) * 0.5f
                v
            }
            sumSq += (s * s).toDouble(); count++
            i += stride
        }
        frames += n
        if (frames >= rate / 10 && count > 0) {
            val rms = sqrt(sumSq / count)
            val db = 20.0 * log10(max(rms, 1e-5))
            // -32 dBFS (muy suave) → 0 ; -12 dBFS (intensa) → 1
            val x = ((db + 32.0) / 20.0).coerceIn(0.0, 1.0).toFloat()
            LiveEnergy.push(x, frames.toFloat() / rate)
            sumSq = 0.0; count = 0; frames = 0L
        }
    }
}

/**
 * Misma cadena de renderers que DefaultRenderersFactory; lo único distinto es que el renderer de audio recibe un
 * AudioSink con el medidor de energía (que no modifica el audio). Si algo fallara al montarlo, se conserva el
 * renderer de audio original: la reproducción nunca depende de LiveJull.
 */
internal class LiveRenderersFactory(private val context: Context) : RenderersFactory {
    private val base = DefaultRenderersFactory(context)

    override fun createRenderers(
        eventHandler: Handler,
        videoRendererEventListener: VideoRendererEventListener,
        audioRendererEventListener: AudioRendererEventListener,
        textRendererOutput: TextOutput,
        metadataRendererOutput: MetadataOutput
    ): Array<Renderer> {
        val defaults = base.createRenderers(
            eventHandler, videoRendererEventListener, audioRendererEventListener, textRendererOutput, metadataRendererOutput
        )
        return Array<Renderer>(defaults.size) { i ->
            val r: Renderer = defaults[i]
            if (r is MediaCodecAudioRenderer) {
                runCatching {
                    val sink = DefaultAudioSink.Builder(context)
                        .setAudioProcessors(arrayOf<AudioProcessor>(TeeAudioProcessor(EnergyMeter())))
                        .build()
                    MediaCodecAudioRenderer(context, MediaCodecSelector.DEFAULT, eventHandler, audioRendererEventListener, sink) as Renderer
                }.getOrDefault(r)
            } else r
        }
    }
}
