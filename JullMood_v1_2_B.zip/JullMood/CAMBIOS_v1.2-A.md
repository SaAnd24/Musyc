# JullMood Music v1.2-A — JullExperience (versionCode 3)

Base: v1.1 intacta. Solo se añade JullExperience + Dynamic Experience.

## Ajustes (Apariencia)
- **JullExperience** ON/OFF (por defecto OFF). Con OFF la app es visualmente la v1.1 y no se ejecuta nada de la capa.
- **Dynamic Experience** ON/OFF (aparece con JullExperience ON; actúa solo si ambos están ON).
- Ambos se guardan en las SharedPreferences "player" (`jullExperience`, `dynamicExperience`).

## Dynamic Experience
- Al cambiar la canción se toma su portada (misma `ArtCache`), se extraen hasta 3 tonos dominantes y se crea una paleta.
- La paleta se superpone al tema elegido (Oscuro, AMOLED, Claro, colores, Dinámico, Personalizado): no lo sustituye.
  AMOLED conserva el negro puro, Claro sigue siendo claro, los textos del tema no se alteran.
- Llega a Home, Biblioteca, Player, Mini-player, Letras, navegación y controles porque todo usa `MaterialTheme.colorScheme`.
- Contraste: acentos corregidos a ≥ 3:1 con fondo/superficie, texto secundario a ≥ 4,5:1.
- Transición suave (650 ms, una sola animación); instantánea con "Reducir animaciones".
- Sin portada o portada casi gris: paleta de respaldo (mismo tono que la carátula por defecto del álbum).
- "Acento del reproductor" no se superpone cuando Dynamic Experience está activa (evita doble acento).

## Rendimiento
- Caché LRU de paletas por canción (300); cada portada se analiza una sola vez, en hilo de fondo, sobre la miniatura ya cacheada (96 px).
- Sin servicios, sin dependencias nuevas, sin procesamiento continuo.

## Archivos
- Nuevo: `JullExperience.kt`.
- Modificados (mínimo): `PlayerViewModel.kt` (estado, persistencia, cálculo de paleta), `Theme.kt` (parámetro `palette` y capa),
  `MainActivity.kt` (pasa la paleta), `Settings.kt` (dos interruptores), `build.gradle.kts` (versión).
- Reproducción, Player, Mini-player, Lyrics y Motion de v1.1: sin cambios.
