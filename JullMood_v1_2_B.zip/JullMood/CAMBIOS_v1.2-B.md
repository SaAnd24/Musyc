# JullMood Music v1.2-B — Ambient + Motion + Styles (versionCode 4)

Base: v1.2-A intacta (JullExperience + Dynamic Experience). Todo lo nuevo vive en
**Ajustes → Apariencia → JullExperience** (visible con JullExperience ON) y se guarda por nombre en las mismas SharedPreferences.
Con JullExperience OFF todo vuelve a la v1.1/v1.2-A (los ajustes se conservan pero no actúan).

## Ambient Background (OFF · Static · Lava · Aurora · Glow) + intensidad (Sutil · Normal · Intenso)
- Fondo detrás de Home/Biblioteca/Playlists/Mood/Ajustes/detalles y del Player. Solo gradientes nativos (sin vídeo/GIF/blur).
- Colores = `MaterialTheme.colorScheme`: con Dynamic Experience ON son los de la portada actual (con su transición); con OFF, los del tema.
  No existe un segundo extractor y Ambient nunca genera ni analiza una paleta.
- Static: sin animación. Lava (3 manchas, 15 fps), Aurora (3 bandas, 20 fps), Glow (halo que respira, 12 fps).
- Rendimiento: reloj propio que solo corre mientras suena la música, la app está visible, la pantalla lo muestra
  (se detiene bajo el Player, bajo un detalle, con Always-On, en la página de letras) y Motion/animaciones no están reducidos.
  Solo redibuja (sin recomposición).

## Music Motion (Disabled · Cover · Info · Progress) + intensidad
- Cover: deriva/parallax mínimo de la portada (30 fps, solo sonando; vuelve suave a su sitio al parar).
- Info: entrada escalonada de título/artista/álbum + deriva mínima.
- Progress: halo pulsante en el pulgar y "cola" luminosa en el borde de avance.
- NO toca las letras sincronizadas (LyricsPage sin cambios).

## Player Styles (Minimal · Classic · Cinematic · Immersive)
- Classic = reproductor v1.1 exacto. Mismo `NowPlayingV11`, mismos controles/seek/estado/gestos; solo cambia la presentación
  (Minimal: aire, portada pequeña, controles en anillo, barra fina · Cinematic: portada a sangre con fundido ·
  Immersive: portada a pantalla completa con velo oscuro y textos claros). En horizontal se usa la distribución de siempre.

## Mini-player Styles (Classic · Compact · Floating · Glow)
- Todos conservan portada, título/artista, play/pause, progreso y apertura del Player (toque o deslizar hacia arriba).
  Classic = v1.1 exacto.

## Motion System (OFF · Sutil · Normal · Intenso)
- Normal = animaciones de v1.1. Escala duraciones y amplitudes de: navegación entre pestañas y pantallas, Mini-player → Player,
  cambio de canción (portada/información/mini), play/pause, favorito, pulsaciones y estados del reproductor.
- OFF reutiliza el modo "Animaciones reducidas" de v1.1 (todas las animaciones existentes ya lo respetan) y detiene los efectos de Ambient/Music Motion.
  Ninguna función depende de las animaciones.

## Archivos
- Nuevo: `JullFx.kt`. Modificados: `PlayerV11.kt`, `PlayerViewModel.kt`, `Theme.kt`, `Ui.kt`, `Settings.kt`, `MainActivity.kt`, `Home.kt` (1 línea), `build.gradle.kts`.
- Sin cambios: reproducción, servicio, Lyrics, Dynamic Experience, extracción de colores, temas, biblioteca, búsqueda, historial, estadísticas, recomendaciones, favoritos.
