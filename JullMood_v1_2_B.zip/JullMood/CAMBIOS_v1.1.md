# JullMood Music v1.1 (versionCode 2)

Base: v1.0 intacta (biblioteca, historial, estadísticas, recomendaciones, temas, metadata, letras, Always-On, favoritos, búsqueda, ajustes).

## Branding
- Nuevo logo oficial (fondo negro eliminado, PNG transparente): `logo_jullmood_transparente.png`.
- Iconos del launcher por densidad (mdpi–xxxhdpi), adaptativo + monocromo (Android 13 themed icons) + redondo.
- Logo en bienvenida y tarjeta "Tu semana en JullMood" (sin teñir). Splash de Android 12+ con el nuevo logo.
- Nombre de la app: "JullMood Music". Icono de notificación propio (auriculares).

## Reproductor (PlayerV11.kt)
- Portada protagonista, jerarquía título/artista/álbum, controles más claros, barra de progreso propia (arrastre con feedback).
- Shuffle/repeat con estado visible (fondo + punto + descripción accesible).
- Estados: cargando, error, archivo eliminado, fin de cola, pausa; portada inexistente = carátula por defecto.

## Motion
- Mini-player -> reproductor: entrada coordinada (portada, info, controles), deslizar hacia arriba en el mini-player para abrir.
- Cambio de canción: portada e información con transición direccional (sin parpadeo; caché de portadas).
- Play/Pause animado, corazón con microanimación + háptico, progreso fluido por fotograma (solo redibuja).
- Navegación: pestañas con fundido + escala; álbum/artista/lista con deslizamiento lateral.
- Respeta "Reducir animaciones" de Ajustes.

## Letras
- Transición entre estados, línea activa con escala/opacidad por cercanía, bordes que se desvanecen (sin blur).
- Estados nuevos: buscando, error, sin letras, sin sincronizar. Proveedor/backend y Always-On sin cambios.

## Controles externos
- Portada real en notificación y pantalla bloqueada (misma caché que la app) mediante `JmBitmapLoader`.
- Tras un error, "siguiente/anterior" vuelven a preparar el reproductor. Sin servicios nuevos.

## Sin cambios
Sin dependencias nuevas, sin ecualizador/IA, base de datos y arquitectura intactas.
