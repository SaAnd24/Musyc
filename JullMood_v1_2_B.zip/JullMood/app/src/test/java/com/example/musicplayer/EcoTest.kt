package com.example.musicplayer

import android.content.SharedPreferences
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pruebas de JVM del ecosistema: logros, álbumes, olvidadas/rescatadas, rachas, niveles y persistencia. */
class EcoTest {
    private val day = 86_400_000L
    private val t0 = 1_800_000_000_000L

    private class FakePrefs : SharedPreferences {
        val m = HashMap<String, Any?>()
        override fun getAll(): MutableMap<String, *> = m
        override fun getString(k: String?, d: String?): String? = (m[k] as? String) ?: d
        override fun getStringSet(k: String?, d: MutableSet<String>?): MutableSet<String>? = d
        override fun getInt(k: String?, d: Int) = (m[k] as? Int) ?: d
        override fun getLong(k: String?, d: Long) = (m[k] as? Long) ?: d
        override fun getFloat(k: String?, d: Float) = (m[k] as? Float) ?: d
        override fun getBoolean(k: String?, d: Boolean) = (m[k] as? Boolean) ?: d
        override fun contains(k: String?) = m.containsKey(k)
        override fun registerOnSharedPreferenceChangeListener(l: SharedPreferences.OnSharedPreferenceChangeListener?) {}
        override fun unregisterOnSharedPreferenceChangeListener(l: SharedPreferences.OnSharedPreferenceChangeListener?) {}
        override fun edit(): SharedPreferences.Editor = object : SharedPreferences.Editor {
            override fun putString(k: String?, v: String?) = apply { m[k!!] = v }
            override fun putStringSet(k: String?, v: MutableSet<String>?) = this
            override fun putInt(k: String?, v: Int) = apply { m[k!!] = v }
            override fun putLong(k: String?, v: Long) = apply { m[k!!] = v }
            override fun putFloat(k: String?, v: Float) = apply { m[k!!] = v }
            override fun putBoolean(k: String?, v: Boolean) = apply { m[k!!] = v }
            override fun remove(k: String?) = apply { m.remove(k) }
            override fun clear() = apply { m.clear() }
            override fun commit() = true
            override fun apply() {}
        }
    }

    private fun tr(id: Long, artist: String = "A", album: String = "Al") = EcoTrack(id, "k$id", artist, album)
    private fun album(n: Int, name: String = "Al", artist: String = "A", from: Long = 1) = (0 until n).map { tr(from + it, artist, name) }
    private fun st(plays: Int, last: Long) = SongStat(plays, last, 0L, listOf(last))

    /** Simula una reproducción contada: actualiza el historial y llama al motor como lo hace el ViewModel. */
    private class Sim(val e: EcoEngine, val tracks: List<EcoTrack>) {
        var stats = HashMap<Long, SongStat>()
        fun play(id: Long, now: Long, hour: Int = 12): EcoEvents {
            val old = stats[id]
            val prev = old?.recent?.lastOrNull() ?: 0L
            val before = old?.plays ?: 0
            stats[id] = SongStat(before + 1, now, 0L, ((old?.recent ?: emptyList()) + now).takeLast(10))
            val snap = Eco.snapshot(tracks, stats, now)
            return e.onCounted(tracks.first { it.id == id }, prev, before, now, hour, snap, 0)
        }
    }

    @Test fun firstSongUnlocksFirstAndOnlyOnce() {
        val sim = Sim(EcoEngine(FakePrefs()), album(10))
        val ev = sim.play(1, t0)
        assertTrue(ev.newAch.any { it.id == "first" })
        assertTrue(sim.play(1, t0 + 1000).newAch.none { it.id == "first" })
    }

    @Test fun albumNotCompleteEarlyAndCompletesOnlyOnce() {
        val tracks = album(4)
        val sim = Sim(EcoEngine(FakePrefs()), tracks)
        for (i in 1L..3L) assertNull("no completo con $i/4", sim.play(i, t0 + i).albumDone)
        val last = sim.play(4, t0 + 10)
        assertNotNull(last.albumDone); assertEquals(4, last.albumDone!!.heard)
        // Repetir canciones del álbum no vuelve a completarlo (ni a mostrar la animación)
        for (i in 1L..4L) assertNull(sim.play(i, t0 + 100 + i).albumDone)
        assertTrue(last.newAch.any { it.id == "alb1" })
    }

    @Test fun repeatedSongDoesNotCompleteAlbumAndSmallAlbumsDontCount() {
        val sim = Sim(EcoEngine(FakePrefs()), album(4) + album(2, "Pequeño", "B", 100))
        repeat(6) { assertNull(sim.play(1, t0 + it).albumDone) }
        sim.play(100, t0 + 50); assertNull(sim.play(101, t0 + 51).albumDone)   // 2 canciones < MIN_ALBUM
    }

    @Test fun duplicatedFilesCountAsOneSong() {
        val a = listOf(EcoTrack(1, "x", "A", "Al"), EcoTrack(2, "x", "A", "Al"), tr(3), tr(4))
        val s = Eco.snapshot(a, mapOf(2L to st(1, t0)), t0)
        assertEquals(3, s.total); assertEquals(1, s.heard)
    }

    @Test fun libraryExplorationAndLevels() {
        val tracks = album(10)
        val stats = (1L..5L).associateWith { st(1, t0) }
        val s = Eco.snapshot(tracks, stats, t0)
        assertEquals(50.0, s.pct, 0.001); assertEquals(5, s.neverIds.size)
        assertEquals(EcoLevel.EXPLORADOR, s.level)
        assertEquals(EcoLevel.CURIOSO, Eco.levelOf(19.9)); assertEquals(EcoLevel.OYENTE, Eco.levelOf(20.0))
        assertEquals(EcoLevel.COLECCIONISTA, Eco.levelOf(75.0)); assertEquals(EcoLevel.CONOCEDOR, Eco.levelOf(100.0))
    }

    @Test fun artistProgressUsesDistinctSongsNotPlays() {
        val tracks = album(8, "X", "Art")
        val s = Eco.snapshot(tracks, mapOf(1L to st(50, t0), 2L to st(1, t0)), t0)
        val g = s.artists.first { it.name == "Art" }
        assertEquals(2, g.heard); assertEquals(8, g.total); assertEquals(25, g.pct)
        assertEquals(1, s.lowArtists.size)
    }

    @Test fun forgottenNeedsPastPlayAndEnoughTime() {
        val tracks = album(4)
        val stats = mapOf(1L to st(1, t0 - 200 * day), 2L to st(1, t0 - 10 * day), 3L to st(1, t0 - 100 * day))
        val s = Eco.snapshot(tracks, stats, t0)
        assertEquals(listOf(1L, 3L), s.forgottenIds)          // la nunca escuchada (4) no es "olvidada"
        assertEquals(1, s.staleCount)                          // solo la de 200 días supera 6 meses
        assertTrue(4L in s.neverIds)
    }

    @Test fun rescueRequiresRealAbsence() {
        val sim = Sim(EcoEngine(FakePrefs()), album(5))
        sim.play(1, t0)
        assertEquals(0, sim.play(1, t0 + 20 * day).rescuedDays)           // 20 días: no es rescate
        val ev = sim.play(1, t0 + 20 * day + 200 * day)                    // 200 días: sí
        assertEquals(200, ev.rescuedDays)
        assertEquals(1, sim.e.rescuedTotal)
        assertTrue(ev.newAch.any { it.id == "res1" })
        assertEquals(0, sim.play(2, t0 + 400 * day).rescuedDays)           // primera escucha de otra canción: no es rescate
    }

    @Test fun streakContinuesAndBreaks() {
        val sim = Sim(EcoEngine(FakePrefs()), album(5))
        val base = t0 - t0 % day + 12 * 3_600_000L
        for (d in 0..3) sim.play(1, base + d * day)
        assertEquals(4, sim.e.streak(base + 3 * day).current)
        assertEquals(4, sim.e.streak(base + 4 * day).current)              // aún se puede continuar hoy
        val broken = sim.e.streak(base + 6 * day)
        assertEquals(0, broken.current); assertEquals(4, broken.endedLen); assertEquals(4, broken.best)
        sim.play(2, base + 6 * day)
        assertEquals(1, sim.e.streak(base + 6 * day).current); assertEquals(4, sim.e.streak(base + 6 * day).best)
    }

    @Test fun severalAchievementsAtOnce() {
        val sim = Sim(EcoEngine(FakePrefs()), album(12))
        var all = emptyList<AchDef>()
        for (i in 1L..10L) all = all + sim.play(i, t0 + i).newAch
        assertTrue(all.any { it.id == "first" } && all.any { it.id == "heard10" })
        assertEquals(all.size, all.map { it.id }.toSet().size)
    }

    @Test fun persistenceSurvivesRestartAndClearKeepsAchievements() {
        val p = FakePrefs(); val tracks = album(4)
        val sim = Sim(EcoEngine(p), tracks)
        for (i in 1L..4L) sim.play(i, t0 + i)
        val e2 = EcoEngine(p)
        assertTrue("alb1" in e2.unlocked); assertNotNull(e2.albumInfo("Al")); assertEquals(4, e2.albumInfo("Al")!![2].toInt())
        // Álbum ya completado + reinicio de la app: no vuelve a animarse
        val sim2 = Sim(e2, tracks); sim2.stats = sim.stats
        assertNull(sim2.play(1, t0 + 100).albumDone)
        e2.clearProgress()
        assertTrue("alb1" in e2.unlocked); assertNull(e2.albumInfo("Al")); assertEquals(0, e2.rescuedTotal)
    }

    @Test fun existingHistoryIsRegisteredSilently() {
        val tracks = album(4)
        val stats = (1L..4L).associateWith { st(2, t0 - day) }
        val e = EcoEngine(FakePrefs())
        e.ensureInit(Eco.snapshot(tracks, stats, t0), 0, t0)
        assertTrue("alb1" in e.unlocked && "first" in e.unlocked)
        val sim = Sim(e, tracks); sim.stats = HashMap(stats)
        val ev = sim.play(1, t0)
        assertNull(ev.albumDone); assertTrue(ev.newAch.isEmpty())
    }

    @Test fun progressOfAndSpan() {
        val items = listOf("a" to 1L, "a" to 2L, "b" to 3L, "c" to 4L)
        assertEquals(2 to 3, Eco.progressOf(items, mapOf(2L to st(1, t0), 3L to st(1, t0), 4L to st(0, t0))))
        assertEquals("12 días", Eco.span(12)); assertEquals("7 meses", Eco.span(215)); assertEquals("2 años", Eco.span(800))
    }

    @Test fun achievementIdsUniqueAndTargetsPositive() {
        assertEquals(Achievements.all.size, Achievements.all.map { it.id }.toSet().size)
        assertTrue(Achievements.all.all { it.target > 0 && it.cat in Achievements.cats })
        assertFalse(Achievements.all.isEmpty())
    }
}
