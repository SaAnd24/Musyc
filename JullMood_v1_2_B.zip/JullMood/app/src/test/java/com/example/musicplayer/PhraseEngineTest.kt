package com.example.musicplayer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Random

/** Pruebas de JVM del módulo de frases (sin Android: PhraseContext se construye directamente). */
class PhraseEngineTest {
    private val day = 86_400_000L
    private val t0 = 1_800_000_000_000L

    private val surpriseAll = SurpriseCat.values().flatMap { PhraseBank.surprise(it) }
    private val normalAll = NormalCat.values().flatMap { PhraseBank.normal(it) } + Mood.values().flatMap { PhraseBank.normalMood(it) }
    private val moodPhrases = Mood.values().flatMap { PhraseBank.normalMood(it) }.toSet()

    private fun ctx(
        mode: PhraseMode = PhraseMode.NORMAL, id: Long = 1, plays: Int = 5, last: Long = t0 - day, fav: Boolean = false,
        moods: List<Mood> = emptyList(), hour: Int = 20, now: Long = t0, same: Boolean = false,
        type: SurpriseType? = null, heavy: Int = 10
    ) = PhraseContext(mode, id, plays, last, fav, moods, hour, now, same, heavy, type)

    /** Una frase por motor nuevo (sin memoria): mide con qué frecuencia el contexto manda. */
    private fun sample(n: Int, c: PhraseContext): List<String> = (1..n).mapNotNull { i ->
        val e = PhraseEngine(Random(i.toLong()))
        if (c.mode == PhraseMode.SURPRISE) e.surprise(c) else e.playback(c)
    }

    private fun share(l: List<String>, of: Collection<String>) = l.count { it in of }

    @Test fun bank_has_about_300_each_with_no_duplicates_or_overlap() {
        assertEquals(300, PhraseBank.surpriseTotal())
        assertEquals(300, PhraseBank.normalTotal())
        assertEquals(surpriseAll.size, surpriseAll.toSet().size)
        assertEquals(normalAll.size, normalAll.toSet().size)
        assertTrue(surpriseAll.intersect(normalAll.toSet()).isEmpty())
        assertTrue((surpriseAll + normalAll).all { it.split(" ").size <= 8 })
    }

    @Test fun modes_never_mix_phrase_sets() {
        val e = PhraseEngine(Random(3))
        var now = t0
        repeat(400) { i ->
            assertTrue(e.surprise(ctx(PhraseMode.SURPRISE, id = i.toLong(), now = now)) in surpriseAll)
            now += 10_000
            e.playback(ctx(id = i.toLong(), now = now, moods = listOf(Mood.ROCK)))?.let { assertTrue(it in normalAll) }
        }
    }

    @Test fun surprise_does_not_repeat_within_last_40() {
        val e = PhraseEngine(Random(11))
        val out = ArrayList<String>()
        repeat(150) { out += e.surprise(ctx(PhraseMode.SURPRISE, id = it.toLong())) }
        for (i in out.indices) assertFalse("repetida: ${out[i]}", out.subList(maxOf(0, i - 40), i).contains(out[i]))
    }

    @Test fun normal_does_not_repeat_within_last_20_shown() {
        val e = PhraseEngine(Random(5))
        var now = t0
        val out = ArrayList<String>()
        repeat(400) { i -> now += 10_000; e.playback(ctx(id = i.toLong(), now = now))?.let { out += it } }
        assertTrue(out.size > 150)
        for (i in out.indices) assertFalse("repetida: ${out[i]}", out.subList(maxOf(0, i - 20), i).contains(out[i]))
    }

    @Test fun repeating_a_song_changes_the_kind_of_comment() {
        val e = PhraseEngine(Random(7))
        var now = t0
        e.playback(ctx(id = 9, now = now))                                    // 1.ª vez: comentario normal (o ninguno)
        now += 10_000; val a = e.playback(ctx(id = 9, now = now))
        now += 10_000; val b = e.playback(ctx(id = 9, now = now))
        now += 10_000; val c = e.playback(ctx(id = 9, now = now))
        assertNotNull(a); assertNotNull(b); assertNotNull(c)
        assertTrue(PhraseBank.normal(NormalCat.REPETIDA_1).contains(a!!))
        assertTrue(PhraseBank.normal(NormalCat.REPETIDA_2).contains(b!!))
        assertTrue(PhraseBank.normal(NormalCat.REPETIDA_3).contains(c!!))
    }

    @Test fun repeat_streak_expires_and_resets_with_other_songs_or_clear() {
        val e = PhraseEngine(Random(2))
        e.playback(ctx(id = 1, now = t0))
        e.playback(ctx(id = 2, now = t0 + 10_000))                            // otra canción: racha a 0
        val r = e.playback(ctx(id = 1, now = t0 + 20_000))
        assertTrue(r == null || r !in PhraseBank.normal(NormalCat.REPETIDA_1))
        e.playback(ctx(id = 1, now = t0 + 30_000))
        e.clear()
        val c = e.playback(ctx(id = 1, now = t0 + 40_000))
        assertTrue(c == null || c !in PhraseBank.normal(NormalCat.REPETIDA_1))
        val late = PhraseEngine(Random(2)).also { it.playback(ctx(id = 4, now = t0)) }.playback(ctx(id = 4, now = t0 + 30 * 60_000L))
        assertTrue(late == null || late !in PhraseBank.normal(NormalCat.REPETIDA_1))
    }

    @Test fun tapping_current_song_counts_as_repeat() {
        val r = PhraseEngine(Random(1)).playback(ctx(id = 3, same = true))
        assertTrue(r != null && r in PhraseBank.normal(NormalCat.REPETIDA_1))
    }

    @Test fun very_rapid_taps_do_not_produce_two_phrases() {
        val e = PhraseEngine(Random(4))
        var shown = 0
        repeat(5) { i -> if (e.playback(ctx(id = 100L + i, now = t0 + i * 400L, plays = 1)) != null) shown++ }
        assertTrue(shown <= 1)
    }

    @Test fun heavily_played_song_gets_contextual_comment_and_others_dont() {
        val classic = PhraseBank.normal(NormalCat.CLASICO).toSet()
        assertTrue(share(sample(300, ctx(plays = 30)), classic) >= 60)
        assertEquals(0, share(sample(300, ctx(plays = 3)), classic))
    }

    @Test fun forgotten_song_gets_reunion_comment_only_when_true() {
        val forgotten = PhraseBank.normal(NormalCat.OLVIDADA).toSet()
        assertTrue(share(sample(300, ctx(plays = 5, last = t0 - 90 * day)), forgotten) >= 100)
        assertEquals(0, share(sample(300, ctx(plays = 5, last = t0 - 2 * day)), forgotten))
        assertEquals(0, share(sample(300, ctx(plays = 1, last = t0 - 90 * day)), forgotten))   // poca evidencia
        assertEquals(0, share(sample(300, ctx(plays = 0, last = 0L)), forgotten))              // sin historial
    }

    @Test fun favorites_and_new_songs_get_their_comments() {
        val fav = PhraseBank.normal(NormalCat.FAVORITA).toSet()
        val fresh = PhraseBank.normal(NormalCat.NUEVA).toSet()
        assertTrue(share(sample(300, ctx(fav = true)), fav) >= 60)
        assertEquals(0, share(sample(300, ctx(fav = false)), fav))
        assertTrue(share(sample(300, ctx(plays = 0, last = 0L)), fresh) >= 60)
        assertEquals(0, share(sample(300, ctx(plays = 8)), fresh))
    }

    @Test fun mood_influences_only_when_the_song_has_that_mood() {
        val night = PhraseBank.normalMood(Mood.NOCTURNA).toSet()
        assertTrue(share(sample(300, ctx(moods = listOf(Mood.NOCTURNA))), night) >= 40)
        assertEquals(0, share(sample(300, ctx(moods = emptyList())), moodPhrases))
        assertEquals(0, share(sample(300, ctx(moods = listOf(Mood.ROCK))), night))
    }

    @Test fun hour_influences_normal_and_surprise_when_it_applies() {
        val tNight = PhraseBank.normal(NormalCat.TIEMPO_NOCHE).toSet()
        val tMorning = PhraseBank.normal(NormalCat.TIEMPO_MANANA).toSet()
        assertTrue(share(sample(300, ctx(hour = 2)), tNight) >= 20)
        assertEquals(0, share(sample(300, ctx(hour = 15)), tNight))
        assertTrue(share(sample(300, ctx(hour = 8)), tMorning) >= 20)
        assertEquals(0, share(sample(300, ctx(hour = -1)), tNight + tMorning))
        val sNight = PhraseBank.surprise(SurpriseCat.NOCHE).toSet()
        val s = ctx(PhraseMode.SURPRISE, hour = 23, moods = listOf(Mood.NOCTURNA), type = SurpriseType.MOOD)
        assertTrue(share(sample(300, s), sNight) >= 150)
        assertEquals(0, share(sample(300, ctx(PhraseMode.SURPRISE, hour = 23, moods = emptyList(), type = SurpriseType.MOOD)), sNight))
        assertEquals(0, share(sample(300, ctx(PhraseMode.SURPRISE, hour = 14, moods = listOf(Mood.NOCTURNA), type = SurpriseType.MOOD)), sNight))
    }

    @Test fun surprise_phrase_follows_recommendation_type() {
        fun pool(c: SurpriseCat) = PhraseBank.surprise(c).toSet()
        fun s(t: SurpriseType?) = sample(300, ctx(PhraseMode.SURPRISE, type = t))
        assertTrue(share(s(SurpriseType.REDISCOVER), pool(SurpriseCat.NOSTALGIA)) >= 150)
        assertTrue(share(s(SurpriseType.FAVORITE), pool(SurpriseCat.FAVORITA)) >= 150)
        assertTrue(share(s(SurpriseType.WILDCARD), pool(SurpriseCat.RUTINA)) >= 150)
        assertTrue(share(s(SurpriseType.DISCOVERY), pool(SurpriseCat.DESCUBRIMIENTO)) >= 150)
        // Recomendación general: nunca frases que afirmen un motivo concreto.
        val specific = pool(SurpriseCat.NOSTALGIA) + pool(SurpriseCat.FAVORITA) + pool(SurpriseCat.DESCUBRIMIENTO) + pool(SurpriseCat.RUTINA)
        assertEquals(0, share(s(null), specific))
        assertEquals(0, share(s(SurpriseType.MOOD), specific))
    }

    @Test fun missing_metadata_never_crashes() {
        val e = PhraseEngine(Random(8))
        var shown = 0
        repeat(60) { i -> if (e.playback(PhraseContext(PhraseMode.NORMAL, i.toLong(), 0, 0L, false, emptyList(), -1, t0 + i * 10_000L)) != null) shown++ }
        assertTrue(shown > 0)
        assertTrue(e.surprise(PhraseContext(PhraseMode.SURPRISE, 1L, 0, 0L, false, emptyList(), -1, t0)).isNotBlank())
    }

    @Test fun heavy_threshold_adapts_but_stays_bounded() {
        assertEquals(ContextAnalyzer.HEAVY_FALLBACK, ContextAnalyzer.heavyThreshold(emptyMap()))
        val big = (1L..100L).associateWith { SongStat(plays = it.toInt()) }
        assertEquals(ContextAnalyzer.HEAVY_MAX, ContextAnalyzer.heavyThreshold(big))
        val small = (1L..100L).associateWith { SongStat(plays = 1 + (it % 3).toInt()) }
        assertEquals(ContextAnalyzer.HEAVY_MIN, ContextAnalyzer.heavyThreshold(small))
    }

    @Test fun analyzer_ignores_unclassified_moods() {
        val c = ContextAnalyzer.build(PhraseMode.NORMAL, 1L, emptyMap(), emptySet(), listOf(Mood.SIN_CLASIFICAR, Mood.MIXTO, Mood.ROCK, Mood.ROCK), 10, t0)
        assertEquals(listOf(Mood.ROCK), c.moods)
    }
}
