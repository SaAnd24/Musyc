package com.example.musicplayer

import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import kotlin.math.roundToInt

/*
 * Personalidad de JullMood (100 % local, sin red, sin servicios).
 * NO hay historial ni clasificación nuevos: todo se calcula sobre lo que ya existe
 * (SongStat.recent, plays, skips, favoritos, moodsOf, género/artista/álbum) y solo se guarda un pequeño JSON
 * con "lo último que se mostró" en las mismas SharedPreferences del reproductor.
 */

/** Una observación musical lista para pintarse en una tarjeta del Home. */
class Insight(val key: String, val kind: String, val title: String, val text: String, val songs: List<Song>)

/** Resumen semanal ya calculado (Tu identidad musical). */
class WeeklySummary(
    val plays: Int, val distinct: Int, val approxMs: Long,
    val moods: List<Pair<Mood, Int>>,          // Mood -> % de las reproducciones clasificadas
    val genre: String?, val daypart: String?, val favPlays: Int,
    val topArtist: TopEntry?, val topSong: TopEntry?, val topAlbum: TopEntry?,
    val weekSongs: List<Song>
)

enum class SurpriseType { REDISCOVER, FAVORITE, DISCOVERY, MOOD, DEEP_CUT, WILDCARD }
class SurprisePick(val song: Song, val type: SurpriseType, val phrase: String)

// ---------- Resumen semanal ----------

object WeeklyCalc {
    const val MIN_PLAYS = 12       // por debajo de esto el resumen sería poco representativo
    const val MIN_DISTINCT = 5
    private const val UNKNOWN_ARTIST = "Artista desconocido"
    private const val UNKNOWN_ALBUM = "Álbum desconocido"

    private class Acc(var rep: Song) { var n = 0; var best = 0; val songs = ArrayList<Song>() }

    private fun part(h: Int) = when (h) { in 0..5 -> 0; in 6..11 -> 1; in 12..19 -> 2; else -> 3 }
    private val partLabel = listOf("de madrugada", "por la mañana", "por la tarde", "por la noche")

    /** Usa las fechas de `SongStat.recent` (las mismas de "Tu música de esta semana"). Null si hay pocos datos. */
    fun compute(
        songs: List<Song>, stats: Map<Long, SongStat>, favs: Set<Long>,
        moodsOf: (Song) -> List<Mood>, now: Long
    ): WeeklySummary? {
        val cut = now - StatsCalc.WEEK
        val bySong = HashMap<String, Acc>(); val byArtist = HashMap<String, Acc>(); val byAlbum = HashMap<String, Acc>()
        val moodW = HashMap<Mood, Double>(); val genreN = HashMap<String, Int>()
        val parts = IntArray(4)
        val cal = Calendar.getInstance()
        var plays = 0; var ms = 0L; var fav = 0; var classified = 0

        for (s in songs) {
            val st = stats[s.id] ?: continue
            var w = 0
            for (t in st.recent) if (t >= cut) { w++; cal.timeInMillis = t; parts[part(cal.get(Calendar.HOUR_OF_DAY))]++ }
            if (w == 0) continue
            plays += w; ms += w * s.durationMs
            if (s.id in favs) fav += w
            val mm = moodsOf(s).filter { it != Mood.SIN_CLASIFICAR && it != Mood.MIXTO }
            if (mm.isNotEmpty()) {
                classified += w
                for (m in mm) moodW[m] = (moodW[m] ?: 0.0) + w.toDouble() / mm.size
            }
            if (s.genre.isNotBlank()) genreN[s.genre.trim()] = (genreN[s.genre.trim()] ?: 0) + w
            fun add(map: HashMap<String, Acc>, key: String) {
                val a = map.getOrPut(key) { Acc(s) }
                a.n += w; a.songs += s
                if (w > a.best) { a.best = w; a.rep = s }
            }
            add(bySong, StatsCalc.songKey(s))
            if (s.artist != UNKNOWN_ARTIST) add(byArtist, s.artist)
            if (s.album != UNKNOWN_ALBUM) add(byAlbum, s.album)
        }
        if (plays < MIN_PLAYS || bySong.size < MIN_DISTINCT) return null

        val moods = if (classified >= 6) moodW.entries.sortedByDescending { it.value }.take(4)
            .map { it.key to (it.value / classified * 100).roundToInt() }.filter { it.second >= 5 } else emptyList()
        val genre = genreN.entries.maxByOrNull { it.value }?.takeIf { it.value >= 3 && it.value * 4 >= plays }?.key
        val pi = parts.indices.maxByOrNull { parts[it] } ?: 0
        val daypart = if (parts[pi] * 100 >= plays * 35) partLabel[pi] else null

        fun top(map: Map<String, Acc>, min: Int) = map.values.maxByOrNull { it.n }?.takeIf { it.n >= min }
        val artist = top(byArtist, 3)?.let { TopEntry(it.rep.artist, "${it.songs.size} ${if (it.songs.size == 1) "canción" else "canciones"}", it.n, it.songs.take(5)) }
        val song = top(bySong, 2)?.let { TopEntry(it.rep.title, it.rep.artist, it.n, listOf(it.rep)) }
        val album = top(byAlbum, 3)?.let { TopEntry(it.rep.album, it.rep.artist, it.n, it.songs.take(5)) }
        val weekSongs = bySong.values.sortedByDescending { it.n }.map { it.rep }.take(20)
        return WeeklySummary(plays, bySong.size, ms, moods, genre, daypart, fav, artist, song, album, weekSongs)
    }
}

// ---------- Memoria musical (observaciones con evidencia suficiente) ----------

object MemoryCalc {
    private const val DAY = StatsCalc.DAY
    private const val UNKNOWN_ARTIST = "Artista desconocido"
    private const val UNKNOWN_ALBUM = "Álbum desconocido"
    class Scored(val score: Double, val insight: Insight)

    private fun ago(days: Int) = when {
        days < 60 -> "$days días"
        days < 365 -> "${days / 30} meses"
        else -> "más de un año"
    }

    /** Solo devuelve observaciones respaldadas por datos reales; si no hay evidencia, la lista queda vacía. */
    fun insights(
        songs: List<Song>, stats: Map<Long, SongStat>, skips: Map<Long, Int>,
        moodsOf: (Song) -> List<Mood>, now: Long
    ): List<Scored> {
        val out = ArrayList<Scored>()
        val rnd = java.util.Random(now / DAY)
        fun plays(s: Song) = stats[s.id]?.plays ?: 0
        fun last(s: Song) = stats[s.id]?.last ?: 0L
        val cut14 = now - 14 * DAY

        // Canciones que llevan mucho tiempo sin sonar (pero que sí sonaron bastante).
        songs.filter { plays(it) >= 4 && last(it) in 1L until now - 45 * DAY && (skips[it.id] ?: 0) < 3 }
            .sortedByDescending { plays(it) }.take(3).forEach { s ->
                val d = ((now - last(s)) / DAY).toInt()
                out += Scored(1.0 + plays(s) * 0.05 + d / 400.0, Insight("forgot:${s.id}", "hace", "Hace tiempo...", "Hace ${ago(d)} que no escuchas esto...", listOf(s)))
            }

        // Álbumes que solías poner y llevan meses parados.
        songs.filter { it.album != UNKNOWN_ALBUM }.groupBy { it.album }
            .filter { (_, l) -> l.size >= 3 && l.sumOf { plays(it) } >= 8 && l.maxOf { last(it) } in 1L until now - 60 * DAY }
            .entries.sortedByDescending { e -> e.value.sumOf { plays(it) } }.take(2).forEach { (name, l) ->
                val d = ((now - l.maxOf { last(it) }) / DAY).toInt()
                val t = if (rnd.nextBoolean()) "Hace ${ago(d)} que no escuchas este álbum." else "Llevabas bastante tiempo sin escuchar este álbum."
                out += Scored(1.6, Insight("album:$name", "hace", "Hace tiempo...", t, l.sortedWith(AlbumOrder)))
            }

        // Cambio reciente en los Moods (últimos 14 días frente a todo el historial).
        val rm = HashMap<Mood, Double>(); val am = HashMap<Mood, Double>()
        var rt = 0.0; var at = 0.0; var recentAll = 0; var recentClassics = 0
        val classics = ArrayList<Song>()
        for (s in songs) {
            val st = stats[s.id] ?: continue
            val r = st.recent.count { it >= cut14 }
            recentAll += r
            if (st.plays >= 10) { classics += s; recentClassics += r }
            val mm = moodsOf(s).filter { it != Mood.SIN_CLASIFICAR && it != Mood.MIXTO }
            if (mm.isEmpty()) continue
            for (m in mm) { rm[m] = (rm[m] ?: 0.0) + r.toDouble() / mm.size; am[m] = (am[m] ?: 0.0) + st.plays.toDouble() / mm.size }
            rt += r; at += st.plays
        }
        if (rt >= 10 && at >= 30) {
            rm.entries.map { (m, v) -> Triple(m, v / rt, v / rt - (am[m] ?: 0.0) / at) }
                .filter { it.second >= 0.25 && it.third >= 0.12 }.maxByOrNull { it.third }?.let { (m, _, diff) ->
                    val l = songs.filter { m in moodsOf(it) && (stats[it.id]?.recent?.any { t -> t >= cut14 } == true) }
                        .sortedByDescending { stats[it.id]?.recent?.count { t -> t >= cut14 } ?: 0 }.take(12)
                    if (l.size >= 3) {
                        val t = when (m) {
                            Mood.NOCTURNA -> "Últimamente estás escuchando más música nocturna."
                            Mood.ROCK -> "Últimamente estás escuchando más Rock."
                            Mood.TRISTE -> "Últimamente escuchas más canciones clasificadas como Melancólicas."
                            else -> "Últimamente escuchas más canciones clasificadas como ${m.label}."
                        }
                        out += Scored(2.0 + diff, Insight("mood:${m.name}", "mood", "Últimamente...", t, l))
                    }
                }
        }

        // Volver a los clásicos.
        if (classics.size >= 3 && recentAll >= 10 && recentClassics >= 6 && recentClassics * 2 >= recentAll) {
            val l = classics.sortedByDescending { stats[it.id]?.recent?.count { t -> t >= cut14 } ?: 0 }.take(12)
            out += Scored(1.8, Insight("classics", "classics", "Últimamente...", "Parece que últimamente estás volviendo a tus clásicos.", l))
        }

        // Tu clásico (canción muy reproducida).
        songs.filter { plays(it) >= 10 }.sortedByDescending { plays(it) }.take(2).forEach { s ->
            out += Scored(1.2, Insight("classic:${s.id}", "classic", "Tu clásico", "Esta es una de tus canciones más reproducidas.", listOf(s)))
        }

        // Descubrimiento: canción casi nunca escuchada de un artista muy frecuente.
        val artistPlays = HashMap<String, Int>()
        for (s in songs) if (s.artist != UNKNOWN_ARTIST) artistPlays[s.artist] = (artistPlays[s.artist] ?: 0) + plays(s)
        songs.filter { it.artist != UNKNOWN_ARTIST && plays(it) <= 1 && (artistPlays[it.artist] ?: 0) >= 12 && (skips[it.id] ?: 0) < 2 }
            .groupBy { it.artist }.entries.sortedByDescending { artistPlays[it.key] ?: 0 }.take(2).forEach { (a, l) ->
                val s = l[rnd.nextInt(l.size)]
                out += Scored(1.4, Insight("deep:${s.id}", "discover", "Descubrimiento",
                    "Encontramos una canción que casi nunca escuchas de un artista que frecuentas.", listOf(s)))
            }

        // De noche: canciones cuyas reproducciones recientes son casi todas nocturnas.
        val cal = Calendar.getInstance()
        songs.filter { (stats[it.id]?.recent?.size ?: 0) >= 3 }.mapNotNull { s ->
            val r = stats.getValue(s.id).recent
            val n = r.count { t -> cal.timeInMillis = t; val h = cal.get(Calendar.HOUR_OF_DAY); h >= 22 || h < 6 }
            if (n >= 3 && n * 4 >= r.size * 3) s to n else null
        }.sortedByDescending { it.second }.take(2).forEach { (s, _) ->
            out += Scored(1.5, Insight("night:${s.id}", "night", "De noche", "Esta canción suele aparecer en tus sesiones nocturnas.", listOf(s)))
        }

        // Artista recurrente en los últimos 14 días.
        if (recentAll >= 12) {
            songs.filter { it.artist != UNKNOWN_ARTIST }.groupBy { it.artist }.mapNotNull { (a, l) ->
                val r = l.sumOf { s -> stats[s.id]?.recent?.count { it >= cut14 } ?: 0 }
                val distinct = l.count { s -> stats[s.id]?.recent?.any { it >= cut14 } == true }
                if (r >= 8 && distinct >= 3 && r * 4 >= recentAll) Triple(a, r, l) else null
            }.maxByOrNull { it.second }?.let { (a, _, l) ->
                val top = l.sortedByDescending { s -> stats[s.id]?.recent?.count { it >= cut14 } ?: 0 }.take(12)
                out += Scored(1.7, Insight("artist:$a", "artist", "Últimamente...", "$a ha estado apareciendo bastante últimamente.", top))
            }
        }
        return out.sortedByDescending { it.score }
    }
}

// ---------- Sorpréndeme: elección por motivo ----------

object SurprisePicker {
    private const val UNKNOWN_ARTIST = "Artista desconocido"
    private const val DAY = StatsCalc.DAY
    private val weight = mapOf(
        SurpriseType.REDISCOVER to 1.0, SurpriseType.FAVORITE to 0.8, SurpriseType.DISCOVERY to 1.0,
        SurpriseType.MOOD to 1.0, SurpriseType.DEEP_CUT to 0.9, SurpriseType.WILDCARD to 0.7
    )

    /**
     * Elige la canción con la que abre Sorpréndeme, con un motivo. Usa las mismas señales que el resto de la app
     * (historial, favoritos, omisiones, Mood, afinidad de artista). Evita lo reciente (`avoid` + últimas sorpresas),
     * artistas repetidos y el mismo motivo dos veces seguidas. Null = sin candidatas (se queda la mezcla normal).
     * La frase NO se elige aquí: la pone el PhraseEngine (PhraseEngine.kt) a partir del motivo; aquí `phrase` va vacía.
     */
    fun pick(
        songs: List<Song>, stats: Map<Long, SongStat>, favs: Set<Long>, skips: Map<Long, Int>,
        moodsOf: (Song) -> List<Mood>, now: Long, avoid: Set<Long>, hour: Int, seed: Long,
        recentPicks: List<Pair<Long, String>>
    ): SurprisePick? {
        if (songs.isEmpty()) return null
        val rnd = java.util.Random(seed)
        val byId = songs.associateBy { it.id }
        val recentIds = recentPicks.map { it.first }.toSet()
        val recentArtists = recentPicks.takeLast(4).mapNotNull { byId[it.first]?.artist }.filter { it != UNKNOWN_ARTIST }.toSet()
        val lastTypes = recentPicks.takeLast(2).map { it.second }
        val pool = songs.filter { it.id !in avoid && it.id !in recentIds && (skips[it.id] ?: 0) < 3 }
            .ifEmpty { songs.filter { it.id !in avoid } }
        if (pool.isEmpty()) return null

        fun plays(s: Song) = stats[s.id]?.plays ?: 0
        fun last(s: Song) = stats[s.id]?.last ?: 0L
        fun fresh(l: List<Song>) = l.filter { it.artist !in recentArtists }.ifEmpty { l }

        val artistTotal = HashMap<String, Double>()
        for (s in songs) {
            val v = plays(s) + (if (s.id in favs) 3 else 0)
            if (v > 0) artistTotal[s.artist] = (artistTotal[s.artist] ?: 0.0) + v
        }
        val mx = artistTotal.values.maxOrNull() ?: 0.0
        fun affinity(a: String) = if (mx <= 0.0 || a == UNKNOWN_ARTIST) 0.0 else (artistTotal[a] ?: 0.0) / mx
        val favGenres = songs.filter { it.id in favs && it.genre.isNotBlank() }.map { it.genre.trim().lowercase() }.toSet()

        // Mood relevante: el de la semana o uno acorde a la hora (mismo criterio que Recommender).
        val weekCut = now - 7 * DAY
        val moodCount = HashMap<Mood, Int>(); val weekly = HashMap<Mood, Int>()
        for (s in songs) for (m in moodsOf(s)) {
            if (m == Mood.SIN_CLASIFICAR || m == Mood.MIXTO) continue
            moodCount[m] = (moodCount[m] ?: 0) + 1
            if (last(s) >= weekCut) weekly[m] = (weekly[m] ?: 0) + 1
        }
        val moodOptions = ArrayList<Mood>()
        weekly.entries.filter { it.value >= 3 }.maxByOrNull { it.value }?.key?.let { moodOptions += it }
        Recommender.timeMoods(hour).forEach { moodOptions += it.first }
        val target = moodOptions.filter { (moodCount[it] ?: 0) >= 8 }.let { if (it.isEmpty()) null else it[rnd.nextInt(it.size)] }

        val artistPlays = HashMap<String, Int>()
        for (s in songs) if (s.artist != UNKNOWN_ARTIST) artistPlays[s.artist] = (artistPlays[s.artist] ?: 0) + plays(s)

        val pools = HashMap<SurpriseType, List<Song>>()
        pools[SurpriseType.REDISCOVER] = pool.filter { plays(it) >= 2 && last(it) in 1L until now - 30 * DAY }
            .sortedByDescending { plays(it) + rnd.nextDouble() * 3 }.let { fresh(it) }
        pools[SurpriseType.FAVORITE] = pool.filter { it.id in favs && (last(it) == 0L || now - last(it) >= 5 * DAY) }
            .shuffled(rnd).let { fresh(it) }
        pools[SurpriseType.DISCOVERY] = pool.filter {
            plays(it) <= 1 && (affinity(it.artist) > 0.15 || (it.genre.isNotBlank() && it.genre.trim().lowercase() in favGenres))
        }.sortedByDescending { affinity(it.artist) + rnd.nextDouble() * 0.5 }.let { fresh(it) }
        pools[SurpriseType.MOOD] = if (target == null) emptyList() else
            pool.filter { target in moodsOf(it) && (last(it) == 0L || now - last(it) >= DAY) }.shuffled(rnd).let { fresh(it) }
        pools[SurpriseType.DEEP_CUT] = pool.filter { plays(it) <= 1 && it.artist != UNKNOWN_ARTIST && (artistPlays[it.artist] ?: 0) >= 8 }
            .shuffled(rnd).let { fresh(it) }
        pools[SurpriseType.WILDCARD] = pool.filter { plays(it) <= 2 && (last(it) == 0L || now - last(it) >= 3 * DAY) }
            .sortedBy { affinity(it.artist) + rnd.nextDouble() * 0.6 }.let { fresh(it) }

        val types = SurpriseType.values().filter { pools[it].orEmpty().isNotEmpty() }
        if (types.isEmpty()) return null
        val w = types.map { t -> (weight[t] ?: 1.0) * (if (t.name in lastTypes) 0.3 else 1.0) }
        var r = rnd.nextDouble() * w.sum()
        var type = types.last()
        for (i in types.indices) { r -= w[i]; if (r <= 0) { type = types[i]; break } }

        val cands = pools.getValue(type).take(8)
        val song = cands[rnd.nextInt(cands.size)]
        return SurprisePick(song, type, "")
    }
}

// ---------- Estado y persistencia ligera ----------

/**
 * Estado observable (Compose) + memoria de lo ya mostrado. Se guarda en las SharedPreferences "player" ya existentes
 * (una sola clave JSON pequeña: nada de base de datos nueva). Se prepara una vez por sesión, fuera del hilo principal.
 */
class Personality(private val prefs: SharedPreferences) {
    var weeklyReady by mutableStateOf(false); private set
    var micro by mutableStateOf<Insight?>(null); private set
    var reveal by mutableStateOf<SurprisePick?>(null); private set

    private class Pick(val id: Long, val type: String, val ts: Long)
    private var weeklyAt = 0L                 // última vez que se generó/vio el resumen semanal
    private var microAt = 0L                  // última vez que se mostró una tarjeta del Home
    private var microKind = ""
    private val shown = LinkedHashMap<String, Long>()      // observaciones ya mostradas (clave -> fecha)
    private val phrases = ArrayList<String>()              // frases recientes de Sorpréndeme
    private val picks = ArrayList<Pick>()                  // sorpresas recientes y su motivo
    private var lastWeekly: JSONObject? = null             // instantánea del último resumen
    private var prepared = false

    init { load() }

    companion object {
        private const val KEY = "personality"
        private const val WEEKLY_GAP = 6 * StatsCalc.DAY     // ~1 vez por semana, y solo si hay datos suficientes
        private const val MICRO_GAP = 36 * 3_600_000L        // como mucho una tarjeta cada ~36 h
        private const val REPEAT_GAP = 21 * StatsCalc.DAY    // no repetir la misma observación en 3 semanas
    }

    /** Una vez por sesión: decide si hay resumen semanal y si toca una tarjeta. Cálculo en segundo plano. */
    fun prepare(
        scope: CoroutineScope, songs: List<Song>, stats: Map<Long, SongStat>, favs: Set<Long>,
        skips: Map<Long, Int>, moodsOf: (Song) -> List<Mood>
    ) {
        if (prepared || songs.isEmpty() || stats.isEmpty()) return
        prepared = true
        val now = System.currentTimeMillis()
        scope.launch {
            val ready = now - weeklyAt >= WEEKLY_GAP
            val res = runCatching {
                withContext(Dispatchers.Default) {
                    val w = ready && WeeklyCalc.compute(songs, stats, favs, moodsOf, now) != null
                    val ins = if (!w && now - microAt >= MICRO_GAP) MemoryCalc.insights(songs, stats, skips, moodsOf, now) else emptyList()
                    w to ins
                }
            }.getOrNull() ?: return@launch
            weeklyReady = res.first
            pickMicro(res.second, now)
        }
    }

    private fun pickMicro(all: List<MemoryCalc.Scored>, now: Long) {
        val ok = all.filter { (shown[it.insight.key] ?: 0L) < now - REPEAT_GAP }
        if (ok.isEmpty()) return
        val varied = ok.filter { it.insight.kind != microKind }.ifEmpty { ok }
        val top = varied.take(3)
        val c = top[kotlin.random.Random.nextInt(top.size)].insight
        micro = c
        microAt = now; microKind = c.kind
        shown[c.key] = now
        while (shown.size > 60) shown.remove(shown.keys.first())
        save()
    }

    fun dismissMicro() { micro = null }

    fun markWeeklySeen(w: WeeklySummary) {
        val now = System.currentTimeMillis()
        weeklyAt = now; weeklyReady = false
        lastWeekly = JSONObject().put("at", now).put("plays", w.plays).put("distinct", w.distinct)
            .put("artist", w.topArtist?.title ?: "").put("song", w.topSong?.title ?: "")
            .put("moods", JSONArray(w.moods.map { "${it.first.name}:${it.second}" }))
        save()
    }

    fun recentPicks(): List<Pair<Long, String>> = picks.map { it.id to it.type }
    fun recentPhrases(): List<String> = phrases.toList()

    /** [show] = false (Personalidad Juli desactivada): se recuerda el motivo para variar, pero no se muestra ninguna frase. */
    fun recordSurprise(p: SurprisePick, show: Boolean = true) {
        reveal = if (show) p else null
        picks += Pick(p.song.id, p.type.name, System.currentTimeMillis())
        while (picks.size > 30) picks.removeAt(0)
        if (p.phrase.isNotBlank()) {
            phrases += p.phrase
            while (phrases.size > 6) phrases.removeAt(0)
        }
        save()
    }

    fun dismissReveal() { reveal = null }

    /** "Borrar historial" también borra lo derivado de él. */
    fun clear() {
        weeklyAt = 0L; microAt = 0L; microKind = ""; shown.clear(); phrases.clear(); picks.clear(); lastWeekly = null
        weeklyReady = false; micro = null; reveal = null; prepared = false
        prefs.edit().remove(KEY).apply()
    }

    private fun load() {
        runCatching {
            val o = JSONObject(prefs.getString(KEY, null) ?: return)
            weeklyAt = o.optLong("weeklyAt", 0L); microAt = o.optLong("microAt", 0L); microKind = o.optString("microKind", "")
            o.optJSONObject("shown")?.let { j -> j.keys().forEach { k -> shown[k] = j.getLong(k) } }
            o.optJSONArray("phrases")?.let { a -> for (i in 0 until a.length()) phrases += a.getString(i) }
            o.optJSONArray("picks")?.let { a ->
                for (i in 0 until a.length()) a.getJSONArray(i).let { picks += Pick(it.getLong(0), it.getString(1), it.getLong(2)) }
            }
            lastWeekly = o.optJSONObject("weekly")
        }
    }

    private fun save() {
        runCatching {
            val o = JSONObject().put("weeklyAt", weeklyAt).put("microAt", microAt).put("microKind", microKind)
            o.put("shown", JSONObject().also { j -> shown.forEach { (k, v) -> j.put(k, v) } })
            o.put("phrases", JSONArray(phrases))
            o.put("picks", JSONArray().also { a -> picks.forEach { a.put(JSONArray().put(it.id).put(it.type).put(it.ts)) } })
            lastWeekly?.let { o.put("weekly", it) }
            prefs.edit().putString(KEY, o.toString()).apply()
        }
    }
}
