package com.example.musicplayer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONException
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/*
 * Corrección automática de canciones con nombre poco claro y sin carátula.
 *
 *   Song (metadatos locales)
 *     → VagueNames (¿nombre vago? ¿qué buscar?)
 *       → MusicBrainzFixProvider (opcional, online) + Cover Art Archive (carátula)
 *         → SongFixCache (disco: songfix.json + filesDir/covers)
 *           → SongFixRepository.apply() se aplica sobre la lista de canciones al cargar
 *
 * NO modifica los archivos mp3: los datos corregidos viven solo dentro de la app y se pueden deshacer.
 * Solo sale del dispositivo título (limpio), artista y duración. Nunca rutas, URIs ni audio.
 */

/** Datos corregidos de una canción. `found = false` es una entrada negativa (no se vuelve a consultar hasta [retryAfter]). */
data class SongFix(
    val title: String = "", val artist: String = "", val album: String = "", val coverFile: String = "",
    val origTitle: String = "", val source: String = "", val updatedAt: Long = 0L,
    val found: Boolean = true, val retryAfter: Long = 0L
) {
    /** Hay algo que aplicar (texto y/o carátula). Los campos vacíos significan "dejar el original". */
    val usable: Boolean get() = found && (title.isNotBlank() || artist.isNotBlank() || album.isNotBlank() || coverFile.isNotBlank())
}

// ---------------------------------------------------------------------------------------------
// Detección de nombres vagos
// ---------------------------------------------------------------------------------------------

/** Lo único que se envía al servicio. */
data class FixQuery(val title: String, val artistHint: String, val durationSec: Int)

object VagueNames {
    private val I = RegexOption.IGNORE_CASE
    private val GENERIC = Regex(
        "^(track|pista|audio|sin t[ií]tulo|untitled|unknown|desconocid[oa]|new recording|grabaci[oó]n|recording|voice|" +
            "whatsapp audio|ptt|aud|mp3|song|canci[oó]n|cancion|music|m[uú]sica|musica)[\\s_\\-]*\\d*$", I
    )
    private val DIGITS = Regex("^[\\d\\s_\\-.()]*$")
    private val SITE = Regex("(www\\.)?[a-z0-9\\-]+\\.(com|net|org|co|me|io|ru|fm|info)\\b", I)
    // Basura típica de descargas: entre corchetes/paréntesis, o frases completas sueltas ("official video", "video oficial"...).
    private val NOISE = Regex(
        "[(\\[][^)\\]]*(official|oficial|lyric|letra|video|audio|\\bhd\\b|\\bhq\\b|4k|kbps|visuali[sz]er)[^)\\]]*[)\\]]|" +
            "\\b(official\\s*(music\\s*)?(video|audio)|video\\s*oficial|audio\\s*oficial|lyric\\s*video)\\b", I
    )
    private val LEADING_NUM = Regex("^\\s*(\\(?\\d{1,3}\\)?\\s*[-._)]+\\s*|0\\d\\s+(?=\\p{L}))")
    private val DASH = Regex("\\s[-–—]\\s")
    private val SPACES = Regex("\\s+")

    private fun unknownArtist(a: String) = a.isBlank() || a.startsWith("Artista desconocido")
    private fun unknownAlbum(a: String) = a.isBlank() || a.startsWith("Álbum desconocido")

    /** MediaStore pone como álbum el nombre de la carpeta cuando el archivo no trae etiqueta de álbum ("Download", "Music"...). */
    private fun albumIsFolder(s: Song): Boolean {
        val parts = s.pathKey.split('/').filter { it.isNotEmpty() }
        if (parts.size < 2) return false
        return MusicInfoKey.norm(s.album) == MusicInfoKey.norm(parts[parts.size - 2])
    }

    private fun scrub(raw: String): String {
        var t = raw.replace('_', ' ')
        t = t.replace(SITE, " ").replace(NOISE, " ")
        t = t.replace(LEADING_NUM, "")
        return t.replace(SPACES, " ").trim(' ', '-', '–', '—')
    }

    private fun isGeneric(t: String): Boolean {
        val s = t.trim()
        return s.isEmpty() || s.equals("Sin título", true) || DIGITS.matches(s) || GENERIC.matches(s)
    }

    /** ¿El nombre es poco claro? (con basura de descarga, número de pista, "Artista - Título" en el título, o sin artista ni álbum). */
    fun isVague(s: Song): Boolean {
        val t = s.title
        if (isGeneric(t)) return true
        if (scrub(t) != t.trim()) return true
        if (DASH.containsMatchIn(t) && unknownArtist(s.artist)) return true
        return unknownArtist(s.artist) && (unknownAlbum(s.album) || albumIsFolder(s))
    }

    /** Título limpio + pista de artista a partir de un título sucio y un artista (puede ser ""). Sirve también para la búsqueda manual. */
    fun searchTerms(rawTitle: String, artistHint: String): Pair<String, String> {
        var title = scrub(rawTitle)
        var hint = artistHint.trim()
        val m = DASH.find(title)
        if (m != null) {
            val left = title.substring(0, m.range.first).trim()
            val right = title.substring(m.range.last + 1).trim()
            if (left.isNotEmpty() && right.isNotEmpty()) {
                if (hint.isEmpty()) { hint = left; title = right }
                else {
                    val l = MusicInfoKey.norm(left); val h = MusicInfoKey.norm(hint)
                    if (l == h || l.contains(h) || h.contains(l)) title = right
                }
            }
        }
        return title to hint
    }

    /** Qué buscar. `null` si no hay base para buscar (p. ej. "Track 03": no hay con qué coincidir). */
    fun queryFor(s: Song): FixQuery? {
        if (isGeneric(s.title)) return null
        val (title, hint) = searchTerms(s.title, if (unknownArtist(s.artist)) "" else s.artist)
        if (title.count { it.isLetter() } < 2) return null
        val dur = (s.durationMs / 1000).toInt()
        if (dur <= 0) return null                                   // sin duración no se puede verificar la coincidencia
        return FixQuery(title, hint, dur)
    }
}

// ---------------------------------------------------------------------------------------------
// Carátula: ¿falta o es genérica?
// ---------------------------------------------------------------------------------------------

object CoverProbe {
    /**
     * `true` si la canción necesita carátula: no tiene ninguna, o la incrustada NO es cuadrada. Las descargas de
     * YouTube suelen traer un fotograma del vídeo (16:9 o 4:3) y las carátulas de álbum casi siempre son cuadradas.
     * Fuera del hilo principal.
     */
    fun needsCover(ctx: Context, s: Song): Boolean {
        val dims = embeddedSize(ctx, s)
        if (dims != null) return isFrameLike(dims.first, dims.second)
        return ArtCache.load(ctx, s, 128) == null              // sin imagen incrustada: ¿hay miniatura del sistema?
    }

    fun isFrameLike(w: Int, h: Int): Boolean {
        if (w <= 0 || h <= 0) return false
        val ratio = w.toFloat() / h
        return ratio > 1.25f || ratio < 0.8f
    }

    private fun embeddedSize(ctx: Context, s: Song): Pair<Int, Int>? = runCatching {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, s.uri)
            val b = r.embeddedPicture ?: return@runCatching null
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(b, 0, b.size, o)
            if (o.outWidth > 0 && o.outHeight > 0) o.outWidth to o.outHeight else null
        } finally { r.release() }
    }.getOrNull()
}

// ---------------------------------------------------------------------------------------------
// Proveedor (MusicBrainz)
// ---------------------------------------------------------------------------------------------

data class FixCandidate(val title: String, val artist: String, val album: String, val releaseIds: List<String>)

/** Opción de la búsqueda manual: una grabación en un lanzamiento concreto (el lanzamiento da el álbum y la carátula). */
data class ManualHit(val title: String, val artist: String, val album: String, val releaseId: String, val year: String)

sealed class FixResult {
    data class Found(val c: FixCandidate) : FixResult()
    object NotFound : FixResult()
    data class Failure(val reason: String, val transient: Boolean) : FixResult()
}

/** Límite de MusicBrainz: 1 petición/s EN TOTAL (lo comparten el Mood online y esta corrección). */
object MbRateLimiter {
    private val lock = Mutex()
    private var last = 0L
    suspend fun await() = lock.withLock {
        val wait = 1_100L - (SystemClock.elapsedRealtime() - last)
        if (wait > 0) delay(wait)
        last = SystemClock.elapsedRealtime()
    }
}

class MusicBrainzFixProvider {
    val name = "musicbrainz"
    private val base = "https://musicbrainz.org/ws/2"
    private val userAgent = "JullMood/1.0 (Android music player)"

    /** Una búsqueda. [fuzzy] tolera erratas (más permisivo, pero con umbrales más estrictos al aceptar). Fuera del hilo principal. */
    fun search(q: FixQuery, fuzzy: Boolean): FixResult = try {
        val r = get("$base/recording?query=" + URLEncoder.encode(buildQuery(q, fuzzy), "UTF-8") + "&fmt=json&limit=10")
        when {
            r.code == 200 -> pick(JSONObject(r.body), q, fuzzy)?.let { FixResult.Found(it) } ?: FixResult.NotFound
            r.code == 429 || r.code == 503 -> FixResult.Failure("HTTP ${r.code}", true)
            else -> FixResult.Failure("HTTP ${r.code}", false)
        }
    } catch (e: IOException) {
        FixResult.Failure("red: ${e.javaClass.simpleName}", true)
    } catch (e: JSONException) {
        FixResult.Failure("JSON inválido", false)
    } catch (e: Exception) {
        FixResult.Failure(e.javaClass.simpleName, false)
    }

    private fun esc(s: String) = s.trim().replace("\\", "\\\\").replace("\"", "\\\"")

    private fun buildQuery(q: FixQuery, fuzzy: Boolean): String {
        val rec = if (!fuzzy) "recording:\"${esc(q.title)}\""
        else {
            val terms = q.title.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }
            "recording:(" + terms.joinToString(" AND ") { if (it.length >= 4) "$it~" else it } + ")"
        }
        return if (q.artistHint.isBlank()) rec else "$rec AND artist:\"${esc(q.artistHint)}\""
    }

    private class Http(val code: Int, val body: String)

    private fun get(url: String): Http {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8_000; c.readTimeout = 10_000; c.requestMethod = "GET"
            c.setRequestProperty("User-Agent", userAgent); c.setRequestProperty("Accept", "application/json")
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            return Http(code, stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText().take(1_000_000) }.orEmpty())
        } finally { c.disconnect() }
    }

    /** Parecido entre 0 y 1 (distancia de edición normalizada) sobre títulos sin paréntesis. */
    private fun sim(a: String, b: String): Double {
        fun n(s: String) = MusicInfoKey.norm(s.replace(Regex("\\s*[(\\[].*?[)\\]]"), ""))
        val x = n(a); val y = n(b)
        if (x.isEmpty() || y.isEmpty()) return 0.0
        if (x == y) return 1.0
        val d = Array(x.length + 1) { IntArray(y.length + 1) }
        for (i in 0..x.length) d[i][0] = i
        for (j in 0..y.length) d[0][j] = j
        for (i in 1..x.length) for (j in 1..y.length)
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + if (x[i - 1] == y[j - 1]) 0 else 1)
        return 1.0 - d[x.length][y.length].toDouble() / max(x.length, y.length)
    }

    private fun creditName(o: JSONObject): String {
        val credits = o.optJSONArray("artist-credit") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until credits.length()) {
            val c = credits.optJSONObject(i) ?: continue
            sb.append(c.optString("name").ifBlank { c.optJSONObject("artist")?.optString("name").orEmpty() })
            sb.append(c.optString("joinphrase"))
        }
        return sb.toString().trim()
    }

    private fun artistMatches(o: JSONObject, want: String): Boolean {
        val credits = o.optJSONArray("artist-credit") ?: return false
        for (i in 0 until credits.length()) {
            val c = credits.optJSONObject(i) ?: continue
            for (raw in listOf(c.optString("name"), c.optJSONObject("artist")?.optString("name").orEmpty())) {
                val a = MusicInfoKey.norm(raw)
                if (a.isEmpty()) continue
                if (a == want || (a.length >= 3 && want.length >= 3 && (a.contains(want) || want.contains(a)))) return true
            }
        }
        return false
    }

    private data class RelInfo(val id: String, val title: String, val year: String, val score: Int)

    /** Lanzamientos de una grabación, de mejor a peor: oficiales de álbum/sencillo primero; recopilatorios y directos al final. */
    private fun releasesOf(o: JSONObject): List<RelInfo> {
        val out = ArrayList<RelInfo>()
        val rs = o.optJSONArray("releases") ?: return out
        for (k in 0 until rs.length()) {
            val r = rs.optJSONObject(k) ?: continue
            val id = r.optString("id"); val title = r.optString("title")
            if (id.isEmpty() || title.isBlank()) continue
            val rg = r.optJSONObject("release-group")
            var sc = 0
            if (r.optString("status").equals("Official", true)) sc += 3
            when (rg?.optString("primary-type")) { "Album" -> sc += 2; "Single" -> sc += 1; "EP" -> sc += 1 }
            if ((rg?.optJSONArray("secondary-types")?.length() ?: 0) > 0) sc -= 3
            out += RelInfo(id, title, r.optString("date").take(4), sc)
        }
        return out.sortedByDescending { it.score }                   // estable: a igualdad, el orden del servicio
    }

    private fun primaryArtist(o: JSONObject): String {
        val c = o.optJSONArray("artist-credit")?.optJSONObject(0) ?: return ""
        return MusicInfoKey.norm(c.optString("name").ifBlank { c.optJSONObject("artist")?.optString("name").orEmpty() })
    }

    /**
     * Acepta solo coincidencias muy claras: puntuación alta, título parecido, artista coincidente (si hay pista),
     * duración parecida y UNA sola canción distinta (mismo artista principal y título). Si hay duda, no se cambia nada.
     * Con artista confirmado se tolera más diferencia de duración (±12 s: las descargas de vídeo suelen traer intros/finales).
     */
    private fun pick(root: JSONObject, q: FixQuery, fuzzy: Boolean): FixCandidate? {
        val arr = root.optJSONArray("recordings") ?: return null
        val wantArtist = MusicInfoKey.norm(q.artistHint)
        val minScore = if (fuzzy) 85 else 90
        val minSim = if (fuzzy) 0.8 else 0.95
        val tolerance = if (wantArtist.isNotEmpty()) 12 else 3
        val accepted = ArrayList<JSONObject>()
        for (i in 0 until minOf(arr.length(), 10)) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optInt("score", 0) < minScore) continue
            if (sim(o.optString("title"), q.title) < minSim) continue
            if (wantArtist.isNotEmpty() && !artistMatches(o, wantArtist)) continue
            val lenSec = o.optInt("length", 0) / 1000
            if (lenSec <= 0 || abs(lenSec - q.durationSec) > tolerance) continue
            accepted += o
        }
        if (accepted.isEmpty()) return null
        val identities = accepted.map { primaryArtist(it) + "|" + MusicInfoKey.norm(it.optString("title")) }.toSet()
        if (identities.size > 1) return null                       // ambiguo: varias canciones distintas encajan

        val best = accepted.first()
        val rels = accepted.flatMap { releasesOf(it) }.distinctBy { it.id }.sortedByDescending { it.score }
        return FixCandidate(
            title = best.optString("title").trim(),
            artist = creditName(best),
            album = rels.firstOrNull()?.title.orEmpty(),
            releaseIds = rels.take(3).map { it.id }
        )
    }

    /** Búsqueda manual y permisiva (sin filtros de duración): devuelve opciones para que el usuario elija. `null` = error de red/servicio. */
    fun searchLoose(title: String, artist: String): List<ManualHit>? = try {
        fun tokens(s: String) = s.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }
        val tt = tokens(title); val at = tokens(artist)
        if (tt.isEmpty() && at.isEmpty()) emptyList()
        else {
            val parts = ArrayList<String>()
            if (tt.isNotEmpty()) parts += "recording:(" + tt.joinToString(" AND ") + ")"
            if (at.isNotEmpty()) parts += "artist:(" + at.joinToString(" AND ") + ")"
            val r = get("$base/recording?query=" + URLEncoder.encode(parts.joinToString(" AND "), "UTF-8") + "&fmt=json&limit=25")
            if (r.code != 200) null else {
                val arr = JSONObject(r.body).optJSONArray("recordings")
                val hits = ArrayList<ManualHit>()
                val seen = HashSet<String>()
                for (i in 0 until (arr?.length() ?: 0)) {
                    val o = arr!!.optJSONObject(i) ?: continue
                    if (o.optInt("score", 0) < 50) continue
                    val t = o.optString("title").trim(); val a = creditName(o)
                    for (rel in releasesOf(o).take(3)) {
                        val key = MusicInfoKey.norm(t) + "|" + MusicInfoKey.norm(a) + "|" + MusicInfoKey.norm(rel.title)
                        if (seen.add(key)) hits += ManualHit(t, a, rel.title, rel.id, rel.year)
                    }
                }
                hits.take(24)
            }
        }
    } catch (e: Exception) { null }
}

// ---------------------------------------------------------------------------------------------
// Caché local
// ---------------------------------------------------------------------------------------------

/** Un solo archivo JSON (filesDir/songfix.json) con una entrada pequeña por canción; escritura atómica y por lotes. */
class SongFixCache(private val ctx: Context) {
    private val file = File(ctx.filesDir, "songfix.json")
    private val map = ConcurrentHashMap<String, SongFix>()
    private val loadLock = Mutex()
    @Volatile private var loaded = false
    @Volatile private var dirty = false

    suspend fun ensureLoaded() {
        if (loaded) return
        loadLock.withLock {
            if (loaded) return
            withContext(Dispatchers.IO) { readFile() }
            loaded = true
        }
    }

    private fun readFile() {
        runCatching {
            if (!file.exists()) return
            val items = JSONObject(file.readText()).optJSONObject("items") ?: return
            items.keys().forEach { k ->
                val o = items.optJSONObject(k) ?: return@forEach
                map[k] = SongFix(
                    title = o.optString("t"), artist = o.optString("a"), album = o.optString("al"), coverFile = o.optString("c"),
                    origTitle = o.optString("ot"), source = o.optString("src"), updatedAt = o.optLong("u"),
                    found = o.optInt("f", 1) == 1, retryAfter = o.optLong("r")
                )
            }
        }
    }

    fun get(key: String): SongFix? = map[key]
    fun put(key: String, f: SongFix) { map[key] = f; dirty = true }
    fun snapshot(): Map<String, SongFix> = HashMap(map)
    fun usableCount(): Int = map.values.count { it.usable }

    suspend fun flush() { withContext(Dispatchers.IO) { writeFile() } }

    private fun writeFile() {
        if (!dirty) return
        dirty = false
        runCatching {
            val items = JSONObject()
            map.forEach { (k, v) ->
                val o = JSONObject().put("f", if (v.found) 1 else 0).put("src", v.source).put("u", v.updatedAt)
                if (v.title.isNotEmpty()) o.put("t", v.title)
                if (v.artist.isNotEmpty()) o.put("a", v.artist)
                if (v.album.isNotEmpty()) o.put("al", v.album)
                if (v.coverFile.isNotEmpty()) o.put("c", v.coverFile)
                if (v.origTitle.isNotEmpty()) o.put("ot", v.origTitle)
                if (v.retryAfter > 0L) o.put("r", v.retryAfter)
                items.put(k, o)
            }
            val tmp = File(file.parentFile, "songfix.tmp")
            tmp.writeText(JSONObject().put("v", 1).put("items", items).toString())
            if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file) }
        }.onFailure { dirty = true }
    }
}

// ---------------------------------------------------------------------------------------------
// Repositorio
// ---------------------------------------------------------------------------------------------

/** Resultado de una revisión automática (se muestra en Ajustes para entender por qué se corrigió o no). */
class FixStats {
    var checked = 0; var goodCover = 0; var noMatch = 0; var fixed = 0; var failed = 0; var offline = false
}

class SongFixRepository(
    private val ctx: Context,
    private val provider: MusicBrainzFixProvider = MusicBrainzFixProvider(),
    private val cache: SongFixCache = SongFixCache(ctx)
) {
    companion object {
        private const val NOT_FOUND_TTL = 30L * 24 * 3600 * 1000     // sin coincidencia clara: no se reintenta en 30 días
        private const val HARD_ERROR_TTL = 7L * 24 * 3600 * 1000
        private const val REJECTED_TTL = Long.MAX_VALUE / 2          // el usuario la deshizo: no se vuelve a tocar
        private const val MAX_CONSECUTIVE_FAILURES = 3
        private const val FLUSH_EVERY = 10
        private const val NOTIFY_EVERY = 5                           // cada cuántas correcciones se refresca la lista
        private const val UA = "JullMood/1.0 (Android music player)"
    }

    private val coversDir get() = File(ctx.filesDir, "covers")

    suspend fun ensureLoaded() = cache.ensureLoaded()

    /** Aplica las correcciones guardadas sobre la lista ORIGINAL del escaneo. Solo toca canciones cuyo título sigue siendo el original. */
    fun apply(list: List<Song>): List<Song> {
        val fixes = cache.snapshot().filterValues { it.usable }
        if (fixes.isEmpty()) return list
        return list.map { s ->
            val f = fixes[s.id.toString()]
            if (f == null || (s.title != f.origTitle && s.title != f.title)) s
            else s.copy(
                title = f.title.ifBlank { s.title },
                artist = f.artist.ifBlank { s.artist },
                album = f.album.ifBlank { s.album },
                customArt = f.coverFile.takeIf { it.isNotBlank() && File(it).exists() }.orEmpty(),
                autoFixed = true
            )
        }
    }

    /** ¿Merece una consulta? Nombre vago, con base de búsqueda, sin respuesta vigente y sin corregir ya. [force] reintenta también los "sin coincidencia". */
    fun isCandidate(s: Song, now: Long = System.currentTimeMillis(), force: Boolean = false): Boolean {
        if (s.autoFixed || !VagueNames.isVague(s) || VagueNames.queryFor(s) == null) return false
        val e = cache.get(s.id.toString()) ?: return true
        if (e.source == "revertido") return false                  // el usuario la deshizo: nunca más
        if (force) return !e.found
        if (e.source == "con-caratula") return true               // veredicto de una versión anterior (no miraba fotogramas)
        return !(e.found || now < e.retryAfter)
    }

    /** Deshace la corrección de una canción y evita que se vuelva a aplicar sola. */
    suspend fun revert(songId: Long) {
        cache.ensureLoaded()
        reject(songId.toString())
        cache.flush()
    }

    suspend fun revertAll() {
        cache.ensureLoaded()
        cache.snapshot().filterValues { it.usable }.keys.forEach { reject(it) }
        cache.flush()
    }

    private fun reject(key: String) {
        val old = cache.get(key)
        if (old?.coverFile?.isNotBlank() == true) runCatching { File(old.coverFile).delete() }
        cache.put(key, SongFix(found = false, source = "revertido", updatedAt = System.currentTimeMillis(), retryAfter = REJECTED_TTL))
    }

    /** Edición manual: solo cambia lo que se pasa (null = dejar como está) y conserva el resto de la corrección previa. */
    suspend fun applyManual(song: Song, title: String?, artist: String?, album: String?, coverPath: String?) {
        cache.ensureLoaded()
        val key = song.id.toString()
        val old = cache.get(key)?.takeIf { it.usable }
        cache.put(key, SongFix(
            title = title ?: old?.title.orEmpty(),
            artist = artist ?: old?.artist.orEmpty(),
            album = album ?: old?.album.orEmpty(),
            coverFile = coverPath ?: old?.coverFile.orEmpty(),
            origTitle = old?.origTitle?.takeIf { it.isNotBlank() } ?: song.title,
            source = "manual", updatedAt = System.currentTimeMillis()
        ))
        cache.flush()
    }

    /**
     * Revisión automática de las canciones candidatas (máx. [maxRequests]). Solo se consulta si NO tienen una
     * carátula buena ([hasCover] = false): ni carátula, ni una cuadrada (un fotograma de vídeo cuenta como genérica).
     * [onNew] se llama cada pocas correcciones y al final.
     */
    suspend fun run(songs: List<Song>, maxRequests: Int, force: Boolean, hasCover: suspend (Song) -> Boolean, onNew: suspend () -> Unit): FixStats {
        cache.ensureLoaded()
        val st = FixStats()
        var requests = 0; var fails = 0; var sinceFlush = 0; var sinceNotify = 0
        try {
            for (s in songs) {
                if (requests >= maxRequests || fails >= MAX_CONSECUTIVE_FAILURES) break
                if (!isCandidate(s, force = force)) continue
                val q = VagueNames.queryFor(s) ?: continue
                val key = s.id.toString()
                val t0 = System.currentTimeMillis()
                st.checked++
                if (hasCover(s)) {                                    // ya tiene una carátula buena (cuadrada): no es el caso
                    st.goodCover++
                    cache.put(key, SongFix(found = false, source = "caratula-ok", updatedAt = t0, retryAfter = t0 + NOT_FOUND_TTL))
                    continue
                }
                if (!isOnline()) { st.offline = true; break }
                requests++

                var outcome: FixResult = FixResult.NotFound
                val attempts = if (q.artistHint.isNotBlank()) listOf(false, true) else listOf(false)   // la búsqueda con erratas exige artista
                for (fuzzy in attempts) {
                    MbRateLimiter.await()
                    outcome = withContext(Dispatchers.IO) {
                        runCatching { provider.search(q, fuzzy) }.getOrElse { FixResult.Failure(it.javaClass.simpleName, true) }
                    }
                    if (outcome !is FixResult.NotFound) break
                }
                val t = System.currentTimeMillis()
                when (val r = outcome) {
                    is FixResult.Found -> {
                        fails = 0
                        val cover = withContext(Dispatchers.IO) { downloadCover(s.id, r.c.releaseIds) }
                        cache.put(key, SongFix(
                            title = r.c.title, artist = r.c.artist, album = r.c.album, coverFile = cover.orEmpty(),
                            origTitle = s.title, source = provider.name, updatedAt = t
                        ))
                        st.fixed++; sinceNotify++
                    }
                    is FixResult.NotFound -> {
                        fails = 0; st.noMatch++
                        cache.put(key, SongFix(found = false, source = provider.name, updatedAt = t, retryAfter = t + NOT_FOUND_TTL))
                    }
                    is FixResult.Failure -> {
                        st.failed++
                        if (r.transient) fails++
                        else { fails = 0; cache.put(key, SongFix(found = false, source = provider.name, updatedAt = t, retryAfter = t + HARD_ERROR_TTL)) }
                    }
                }
                if (++sinceFlush >= FLUSH_EVERY) { sinceFlush = 0; cache.flush() }
                if (sinceNotify >= NOTIFY_EVERY) { sinceNotify = 0; onNew() }
            }
        } finally {
            withContext(NonCancellable) { cache.flush() }
        }
        if (sinceNotify > 0) onNew()
        return st
    }

    // ---- Búsqueda manual (menú de la canción) ----

    suspend fun searchLoose(title: String, artist: String): List<ManualHit>? {
        MbRateLimiter.await()
        return withContext(Dispatchers.IO) { provider.searchLoose(title, artist) }
    }

    /** Miniatura de 250 px del Cover Art Archive para elegir; `null` si ese lanzamiento no tiene carátula. */
    suspend fun thumb(releaseId: String): ByteArray? = withContext(Dispatchers.IO) {
        runCatching { fetchBytes("https://coverartarchive.org/release/$releaseId/front-250") }.getOrNull()
    }

    suspend fun downloadReleaseCover(songId: Long, releaseId: String): String? =
        withContext(Dispatchers.IO) { downloadCover(songId, listOf(releaseId)) }

    /** Carátula elegida de la galería: se reduce a ≤ 800 px y se guarda como JPEG. */
    suspend fun coverFromImage(songId: Long, uri: Uri): String? = withContext(Dispatchers.IO) {
        runCatching {
            val bytes = ctx.contentResolver.openInputStream(uri)?.use { readLimited(it, 25_000_000) } ?: return@runCatching null
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
            if (o.outWidth <= 0 || o.outHeight <= 0) return@runCatching null
            o.inSampleSize = max(1, min(o.outWidth, o.outHeight) / 800)
            o.inJustDecodeBounds = false
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o) ?: return@runCatching null
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 90, out)
            bmp.recycle()
            writeCover(songId, out.toByteArray())
        }.getOrNull()
    }

    // ---- Carátulas en disco ----

    /** Cover Art Archive (https://coverartarchive.org): carátula frontal de 500 px del primer lanzamiento que la tenga. */
    private fun downloadCover(songId: Long, releaseIds: List<String>): String? {
        for (id in releaseIds) {
            val bytes = runCatching { fetchBytes("https://coverartarchive.org/release/$id/front-500") }.getOrNull() ?: continue
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
            if (o.outWidth <= 0 || o.outHeight <= 0) continue          // no es una imagen válida
            writeCover(songId, bytes)?.let { return it }
        }
        return null
    }

    /** Nombre único por escritura: la caché de imágenes se invalida sola al cambiar la ruta. Borra las versiones anteriores. */
    private fun writeCover(songId: Long, bytes: ByteArray): String? = runCatching {
        coversDir.mkdirs()
        val out = File(coversDir, "$songId-${System.currentTimeMillis()}.img")
        out.writeBytes(bytes)
        coversDir.listFiles { f -> f.name.startsWith("$songId-") && f.name != out.name }?.forEach { it.delete() }
        out.absolutePath
    }.getOrNull()

    private fun readLimited(ins: java.io.InputStream, max: Int): ByteArray? {
        val buf = ByteArrayOutputStream()
        val chunk = ByteArray(8192)
        var total = 0
        while (true) {
            val n = ins.read(chunk)
            if (n < 0) break
            total += n
            if (total > max) return null
            buf.write(chunk, 0, n)
        }
        return buf.toByteArray()
    }

    private fun fetchBytes(url: String): ByteArray? {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8_000; c.readTimeout = 12_000; c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", UA)
            if (c.responseCode != 200) return null
            return c.inputStream.use { readLimited(it, 3_000_000) }
        } finally { c.disconnect() }
    }

    @Suppress("DEPRECATION")
    private fun isOnline(): Boolean = runCatching {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }.getOrDefault(true)
}
