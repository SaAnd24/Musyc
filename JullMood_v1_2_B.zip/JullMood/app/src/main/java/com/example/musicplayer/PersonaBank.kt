package com.example.musicplayer

/*
 * Frases de las personalidades Grosera y Romántica (600 cada una). SOLO DATOS, en el orden exacto en que se entregaron:
 * la línea N de cada lista es la frase número N. Las 600 Neutral siguen en PhraseBank.kt, intactas.
 *
 * Aquí abajo, el mapa de rangos (1-based, inclusivos) decide en qué categoría del motor entra cada tramo. Una categoría
 * contextual solo se usa cuando su condición es cierta (ver PhraseEngine.kt), así que las frases pueden afirmarla.
 * Dentro de una categoría se eliminan las frases exactamente repetidas (la lista original conserva las 600 líneas).
 */
enum class JuliPersona(val emoji: String, val label: String, val desc: String) {
    NEUTRAL("🤖", "Neutral", "Amigable y curiosa."),
    GROSERA("😈", "Grosera", "Sarcástica y sin filtro."),
    ROMANTICA("❤️", "Romántica", "Cariñosa y sentimental.");

    companion object {
        fun fromName(n: String?): JuliPersona = values().firstOrNull { it.name == n } ?: NEUTRAL
    }
}

internal object PersonaBank {
    /** Las 600 líneas de la personalidad (vacío para Neutral: sus frases viven en PhraseBank). */
    fun raw(p: JuliPersona): List<String> = when (p) { JuliPersona.GROSERA -> G; JuliPersona.ROMANTICA -> R; else -> emptyList() }

    private fun parse(vararg blocks: String): List<String> = blocks.flatMap { b -> b.lines().map { it.trim() }.filter { it.isNotEmpty() } }
    private fun List<String>.rng(vararg r: IntRange): List<String> = r.flatMap { slice((it.first - 1)..(it.last - 1)) }.distinct()

    private val G: List<String> by lazy { parse(G1, G2, G3, G4, G5, G6) }
    private val R: List<String> by lazy { parse(R1, R2, R3, R4, R5, R6) }

    // ---------------- Grosera ----------------
    private val GN: Map<NormalCat, List<String>> by lazy {
        mapOf(
            NormalCat.REPETIDA_1 to G.rng(1..16), NormalCat.REPETIDA_2 to G.rng(51..60), NormalCat.REPETIDA_3 to G.rng(61..80),
            NormalCat.APROBACION to G.rng(17..30, 81..100), NormalCat.CLASICO to G.rng(31..50),
            NormalCat.ARTISTA to G.rng(101..150), NormalCat.FAVORITA to G.rng(151..200), NormalCat.OLVIDADA to G.rng(201..240),
            NormalCat.NUEVA to G.rng(241..300), NormalCat.ALBUM to G.rng(301..350),
            NormalCat.MADRUGADA to G.rng(401..430), NormalCat.TIEMPO_MANANA to G.rng(431..438),
            NormalCat.TIEMPO_TARDE to G.rng(439..440, 446..447), NormalCat.TIEMPO_NOCHE to G.rng(441..445, 448..450),
            NormalCat.UNICA to G.rng(501..540)
        )
    }
    private val GS: Map<SurpriseCat, List<String>> by lazy {
        mapOf(
            SurpriseCat.CURIOSIDAD to G.rng(451..454), SurpriseCat.CONFIANZA to G.rng(464..468, 496..500),
            SurpriseCat.FALLIDA to G.rng(455..463, 469..475, 489..495), SurpriseCat.ACERTADA to G.rng(476..488),
            SurpriseCat.NOSTALGIA to G.rng(201..240), SurpriseCat.FAVORITA to G.rng(151..200), SurpriseCat.DESCUBRIMIENTO to G.rng(241..300),
            SurpriseCat.NOCHE to G.rng(441..445, 448..450), SurpriseCat.MANANA to G.rng(431..438)
        )
    }
    private val GM: Map<Mood, List<String>> by lazy {
        mapOf(
            Mood.ENERGIA to G.rng(351..370), Mood.ROCK to G.rng(351..370), Mood.RELAJANTE to G.rng(371..378),
            Mood.TRISTE to G.rng(379..390), Mood.NOCTURNA to G.rng(391..396), Mood.FIESTA to G.rng(397..400)
        )
    }

    // ---------------- Romántica ----------------
    private val RN: Map<NormalCat, List<String>> by lazy {
        mapOf(
            NormalCat.APROBACION to R.rng(1..30), NormalCat.OLVIDADA to R.rng(31..50, 101..150), NormalCat.FAVORITA to R.rng(51..75),
            NormalCat.CLASICO to R.rng(76..100), NormalCat.NUEVA to R.rng(151..200),
            NormalCat.TIEMPO_NOCHE to R.rng(301..350), NormalCat.MADRUGADA to R.rng(324..336),
            NormalCat.REPETIDA_1 to R.rng(401..420), NormalCat.REPETIDA_2 to R.rng(421..436), NormalCat.REPETIDA_3 to R.rng(437..450),
            NormalCat.ALBUM to R.rng(451..500), NormalCat.NUNCA_TERMINADA to R.rng(551..600)
        )
    }
    private val RS: Map<SurpriseCat, List<String>> by lazy {
        mapOf(
            SurpriseCat.CURIOSIDAD to R.rng(501..519), SurpriseCat.CONFIANZA to R.rng(542..550), SurpriseCat.ACERTADA to R.rng(520..541),
            SurpriseCat.NOSTALGIA to R.rng(31..50, 101..150), SurpriseCat.FAVORITA to R.rng(51..75), SurpriseCat.DESCUBRIMIENTO to R.rng(151..200),
            SurpriseCat.NOCHE to R.rng(301..350)
        )
    }
    private val RM: Map<Mood, List<String>> by lazy {
        mapOf(
            Mood.ALEGRE to R.rng(201..250), Mood.ENERGIA to R.rng(251..300), Mood.ROCK to R.rng(251..300), Mood.FIESTA to R.rng(251..300),
            Mood.NOCTURNA to R.rng(301..350), Mood.RELAJANTE to R.rng(301..350),
            Mood.ROMANTICA to R.rng(351..400), Mood.TRISTE to R.rng(351..400)
        )
    }

    fun normal(p: JuliPersona, c: NormalCat): List<String> = when (p) { JuliPersona.GROSERA -> GN[c]; JuliPersona.ROMANTICA -> RN[c]; else -> null }.orEmpty()
    fun surprise(p: JuliPersona, c: SurpriseCat): List<String> = when (p) { JuliPersona.GROSERA -> GS[c]; JuliPersona.ROMANTICA -> RS[c]; else -> null }.orEmpty()
    fun mood(p: JuliPersona, m: Mood): List<String> = when (p) { JuliPersona.GROSERA -> GM[m]; JuliPersona.ROMANTICA -> RM[m]; else -> null }.orEmpty()

    /** Respuestas absurdas del secreto (Grosera: sus líneas 541-600; las demás tienen su propia lista en EasterEggs.kt). */
    fun absurd(p: JuliPersona): List<String> = if (p == JuliPersona.GROSERA) G.rng(541..600) else emptyList()

    private val G1 = """
¿Otra vez esta canción? 💀
Bro, existen más canciones.
Ok, ya entendí que te gusta.
Por fin elegiste algo decente.
¿En serio vas a ponerla otra vez?
No voy a juzgarte… mucho.
Bueno, esta sí te la paso.
Esa elección estuvo sospechosamente buena.
Mira quién apareció otra vez.
Ya sabía que ibas a volver.
Otra vez tú con esta canción.
Hermano, tienes un problema.
Esto ya parece obsesión.
¿No te cansaste todavía?
Cinco minutos y ya estamos repitiendo.
Qué manera de insistir.
Bueno, al menos tienes buen gusto.
Hoy decidiste escuchar algo bueno.
Eso sí fue una elección.
No esperaba que eligieras esta.
Esta vez sí me sorprendiste.
Te salió bien esa.
Mira, no estuvo nada mal.
Eso fue inesperadamente decente.
Aprobado. Por ahora.
No arruines esto cambiándola.
Déjala terminar, animal.
Por una vez no la saltaste.
Milagro musical.
Estoy orgullosa de ti, cabrón.
¿Ya empezamos con la nostalgia?
Esa canción te tiene agarrado.
No me digas que otra vez.
Te conozco demasiado.
Sabía perfectamente que escogerías esta.
Ni siquiera intentaste sorprenderme.
Qué predecible eres.
Al menos eres consistente.
Eso explica muchas cosas.
Ahora entiendo tu historial.
Esa canción prácticamente vive aquí.
La tienes demasiado escuchada.
Ya somos familia con esta canción.
Esta canción paga alquiler aquí.
La vas a desgastar.
Bro, déjala descansar.
Esa pobre canción necesita vacaciones.
Ya perdió el derecho a quejarse.
Otra reproducción, qué sorpresa.
Esto ya es personal.
Te estás pasando.
Esto dejó de ser casual.
Ya ni disimulas.
No tienes vergüenza.
Me encanta tu falta de autocontrol.
Cinco reproducciones después…
Seguimos aquí.
Y aquí vamos otra vez.
¿Qué clase de bucle es este?
Bueno, tú sabrás.
Esa canción te domina.
Claramente ganó.
La canción 1, tú 0.
Te tiene completamente atrapado.
Admitámoslo: te encanta.
No necesitas fingir.
Ya todos lo sabemos.
Yo ya acepté la situación.
Esto es oficialmente una obsesión.
Felicidades por tu nueva adicción musical.
¿Quieres que la ponga en bucle eterno?
Porque claramente eso quieres.
¿Seguimos hasta mañana?
Tu dignidad pidió salir.
Pero aquí seguimos.
Bro, toca cambiar.
No, mentira. Déjala.
Esta está demasiado buena.
Esa sí merece otra.
Te entiendo, la verdad.
Esta canción tiene permiso.
Esta sí se puede repetir.
No voy a protestar por esta.
Bien jugado.
Esa fue buena.
Te luciste.
Hoy sí pensaste.
Qué raro verte acertar.
Estoy impresionada.
No esperaba tanto de ti.
Eso fue inesperadamente bueno.
Ok, retiro mis críticas.
Esta te la compro.
Buena elección, cabrón.
Por fin.
Ya era hora.
Gracias por no poner la anterior.
Necesitábamos un cambio.
Eso sí estuvo bien.
No la arruines ahora.
"""

    private val G2 = """
¿Otra del mismo artista?
Ya entendimos quién manda.
Bro, cambiaste de canción pero no de artista.
Ese artista vive en tu biblioteca.
¿Tienes contrato con este artista o qué?
Cinco canciones después…
Seguimos con el mismo artista.
Esto ya es un concierto privado.
Creo que tenemos un favorito.
Ya sé quién es tu artista de confianza.
¿No existe nadie más?
El resto de artistas está llorando.
Les estás dando vacaciones.
Hoy solo existe este artista.
Qué obsesión tan específica.
Este artista te tiene comprado.
Ya podrías cobrar entrada.
Esto parece una discografía completa.
¿Quieres escuchar absolutamente todo?
Ok, ya entendí el mensaje.
No hacía falta demostrarlo tanto.
Te gusta bastante, ¿eh?
Bastante es poco.
Esto ya es nivel fanático.
Ya ni intentas esconderlo.
El artista ganó.
Tú perdiste.
Pero sigues feliz.
Eso es lo importante.
Vamos con otra, por favor.
Bueno, otra más.
¿Cuántas llevamos?
Ni yo estoy contando.
Esto se salió de control.
Ya tenemos maratón.
Maratón oficialmente iniciada.
No pienso detenerte.
Pero sí te voy a juzgar.
Un poquito.
Bastante, en realidad.
Esa combinación estuvo buena.
Esa transición estuvo criminal.
No estuvo nada mal.
Eso sí fue una buena secuencia.
Tu biblioteca hoy está cooperando.
Milagrosamente.
Algo salió bien.
No preguntes cómo.
Simplemente disfrútalo.
Esa sí fue buena.
¿Favorita otra vez?
Sabía que volverías.
Tu favorita te llamó.
No pudiste resistirte.
Ahí está tu debilidad.
Todos tenemos una.
La tuya es bastante obvia.
Esta canción ya te conoce.
Tu favorita está trabajando horas extra.
La explotas demasiado.
Dale descanso, cabrón.
Ya se ganó la jubilación.
Pero aquí está otra vez.
Qué relación tan tóxica.
Y aquí sigues.
No aprendes.
Ni quieres aprender.
Esta canción te tiene.
Te tiene completamente.
Déjame adivinar: otra vez.
Exactamente.
No necesitaba preguntar.
Era demasiado obvio.
Tu historial te delató.
No puedes esconderlo.
Esa canción es tu zona segura.
Aquí vienes cuando no sabes qué poner.
Y funciona.
No voy a discutirlo.
Esta merece respeto.
Tu favorita tiene rango.
Esa sí se ganó su puesto.
Una veterana de la biblioteca.
Sigue viva y coleando.
Y reproduciéndose demasiado.
Qué resistencia.
Yo ya estaría cansada.
Pero tú no.
Tú nunca.
Otra vez.
Increíble.
Predecible.
Muy predecible.
Pero aceptable.
La verdad, buena elección.
No puedo odiarla.
Aunque quieras repetirla cien veces.
Bueno, quizá sí.
Pero solo un poquito.
Sigue disfrutándola.
"""

    private val G3 = """
Mira quién volvió del olvido.
Hace siglos que no escuchabas esta.
¿Te acordaste de ella por fin?
Resucitó la canción.
Bienvenida de vuelta.
La desaparecida regresó.
Pensé que la habías olvidado.
Yo sí me acordaba.
Ella estaba esperando.
Y tú apareciste.
Qué reencuentro.
Esto sí es nostalgia.
Mira esa reliquia.
¿Todavía te acuerdas de ella?
Claramente sí.
Tu biblioteca tiene fantasmas.
Esta salió de la tumba.
Qué regreso tan inesperado.
No la veía venir.
Pero aquí estamos.
Esta canción estaba acumulando polvo.
Ya era hora de limpiarla.
Gracias por rescatarla.
La pobre estaba abandonada.
Ahora vuelve a trabajar.
Segundo aire musical.
Nada mal para una veterana.
Todavía funciona.
Y bastante bien.
Me alegra que regresaras.
Bueno, tú y la canción.
La canción volvió contigo.
Qué coincidencia.
O no.
Quizá el algoritmo te conoce.
O quizá eres predecible.
Yo apuesto por lo segundo.
No te ofendas.
Bueno, sí oféndete un poquito.
Seguimos.
¿Nueva canción?
Mira qué valiente.
Probando cosas nuevas.
Esto sí es progreso.
Te felicito.
No la saltaste.
Eso cuenta.
Primera escucha y sobrevivió.
Interesante.
Esto podría funcionar.
Buen descubrimiento.
No estuvo mal.
De hecho, estuvo bastante bien.
Mira tú.
Encontraste algo.
Tu biblioteca todavía tenía sorpresas.
Quién lo diría.
Me gusta esta etapa.
Explorando por fin.
Ya era hora.
No todo puede ser la misma canción.
Gracias.
Estoy respirando tranquila.
Qué alivio.
Una canción diferente.
El mundo sigue girando.
Buen comienzo.
Dale una oportunidad.
No seas impaciente.
Déjala sonar.
Quizá te sorprenda.
O quizá no.
Pero inténtalo.
No seas pendejo.
Escúchala completa.
Podría gustarte.
Esta tiene potencial.
Esta merece atención.
Algo tiene.
Todavía no sé qué.
Pero algo tiene.
No la descartes tan rápido.
Dale unos segundos.
Eso.
Ahora sí.
Mucho mejor.
Ya empieza a ponerse buena.
Te dije.
Bueno, no literalmente.
Pero casi.
Sigue escuchando.
No seas desesperado.
Esta puede quedarse.
Quizá nació una nueva favorita.
Quién sabe.
Te estoy observando.
Musicalmente hablando.
No te emociones.
Apenas estamos empezando.
Buena exploración.
"""

    private val G4 = """
¿Álbum completo?
Mira tú.
Eso sí es compromiso.
No saltaste ninguna.
Estoy sorprendida.
¿Quién eres y qué hiciste contigo?
Milagro absoluto.
Completaste el álbum.
Sin hacer trampa.
Bueno, casi.
Esto merece respeto.
Escuchaste todo.
De principio a fin.
Eso ya es serio.
Fan certificado.
Te ganaste la medalla imaginaria.
🏅
Álbum terminado.
Y no te rendiste.
Estoy orgullosa.
Un poquito.
No te acostumbres.
Eso fue bonito.
Qué disciplina.
Nunca pensé verlo.
Todo el álbum.
Absolutamente todo.
Ni una escapada.
Ni un salto.
Qué comportamiento tan extraño.
Pero admirable.
Sigue así.
O no.
Haz lo que quieras.
Ya completaste el álbum.
Misión cumplida.
El álbum sobrevivió.
Tú también.
Eso cuenta.
¿Repetimos ahora?
Espero que no.
Aunque probablemente sí.
Te conozco.
No me engañas.
Ese álbum ya te atrapó.
Buena sesión.
Eso sí fue escuchar música.
No solo ponerla de fondo.
Buen trabajo.
Ahora descansa.
Este Mood te queda hoy.
Hoy vienes con energía.
Necesitabas esta canción.
Esto está bastante intenso.
Ahora sí despertaste.
Se acabó la flojera.
Energía detectada.
¿Qué desayunaste?
Porque vienes fuerte.
Esa canción pegó.
Buen momento para esta.
Esto tiene sentido.
Tu Mood está hablando.
No pienso discutir con él.
Hoy toca energía.
Ahora sí.
Vamos.
No te duermas.
Esta no es para dormir.
Aunque contigo nunca se sabe.
Mood tranquilo.
Bajamos revoluciones.
Respira un poco.
Esta sí relaja.
Buena elección para bajar el ritmo.
Sin drama.
Solo música.
Eso se agradece.
Hoy estás sentimental.
Ahí está otra vez.
La nostalgia.
Sabía que llegaríamos aquí.
Bueno, disfruta el drama.
No te juzgo.
Mucho.
Pero no demasiado.
Música triste otra vez.
¿Todo bien, bro? 💀
Pregunto musicalmente.
Esa canción pega duro.
Hoy estás en modo nocturno.
Claramente.
Esta hora pide música así.
Buena elección para la noche.
No hagas nada raro.
Solo escucha.
Fiesta activada.
Ahora sí hay ambiente.
Esa sí levanta la sesión.
Dale volumen.
"""

    private val G5 = """
Son las tres de la mañana.
¿Qué haces despierto?
Otra vez a estas horas.
Bro, deberías dormir.
Pero bueno.
Aquí estamos.
La madrugada te conoce.
Tú y el insomnio otra vez.
Esta hora tiene mala influencia.
No voy a preguntar.
Solo escucha.
¿Seguimos hasta el amanecer?
Mala idea.
Pero divertida.
Mañana no me culpes.
Te advertí.
La noche está peligrosa.
Especialmente con esta música.
Esto ya parece sesión clandestina.
Nadie tiene que saberlo.
Madrugada musical.
Otra noche más.
Ya es tradición.
El sol está cerca.
Todavía puedes dormir.
Técnicamente.
Bueno, más o menos.
¿Otra canción?
Claro que sí.
Porque dormir era demasiado fácil.
Buenos días, insomne.
¿Ya empezamos?
Café y música.
La combinación peligrosa.
Tu horario está destruido.
Pero la música está bien.
Mañana tranquila.
Vamos despacio.
Tarde musical.
El día pide algo diferente.
Noche oficialmente activada.
Ahora sí combina.
Hora de bajar el ritmo.
O subirlo.
Tú decides.
Esta tarde está buena.
Qué buen momento.
El día terminó.
La música continúa.
Buenas noches, si algún día duermes.
Sorpréndeme activado.
A ver qué pasa.
Esta fue mi apuesta.
No me falles.
Bueno… esa salió mal.
Te la jugué.
No salió como esperaba.
Ok, retiro esa recomendación.
Esa fue culpa mía.
Te prometo que tenía sentido.
En mi cabeza.
No funcionó.
Probemos otra.
Esta vez sí.
Confía un poquito.
Dale una oportunidad.
No la mates con el skip.
¡No la saltes!
Demasiado tarde.
Bueno, mierda.
Otra recomendación fallida.
Esto empieza mal.
Estoy perdiendo reputación.
No digas nada.
Dame otra oportunidad.
Esta puede ser.
Ahora sí.
¿Ves?
Te dije.
Finalmente acerté.
Confía en mí.
Un punto para Juli.
¿Quién se ríe ahora?
Exacto.
Esta sí era.
Sabía que funcionaría.
Bueno, esperaba que funcionara.
Casi lo mismo.
Esa reacción fue personal.
No te gustó nada.
Entendido.
La eliminamos mentalmente.
Siguiente.
Vamos con otra.
No voy a rendirme.
Alguna te gustará.
Probemos de nuevo.
Esta tiene potencial.
Dale unos segundos.
Confía, cabrón.
"""

    private val G6 = """
La has escuchado una sola vez.
Y desapareció.
¿Qué pasó aquí?
Una experiencia única.
Y aparentemente suficiente.
Nunca regresaste.
Esa canción tuvo una oportunidad.
Y nada más.
Qué relación tan breve.
Fue bonito mientras duró.
Una sola reproducción.
Y silencio absoluto.
Te olvidaste completamente.
Pobrecita.
Quizá algún día vuelva.
O quizá no.
El tiempo dirá.
Esa quedó en el pasado.
Una aparición especial.
Y se fue.
Gracias por tu visita.
Hasta nunca, aparentemente.
Esta canción fue un cameo.
Literalmente.
Ni segunda oportunidad tuvo.
Qué cruel.
Pero justo.
No conectaron.
Pasa.
No todas pueden gustarte.
Algunas sobreviven.
Otras desaparecen.
Esta desapareció.
Qué dramático.
Pero cierto.
Quizá hoy sea diferente.
Dale otra oportunidad.
O no.
Yo no mando aquí.
Bueno, técnicamente tampoco.
¿Qué carajos acabas de poner?
Hola.
...
Ok.
No tengo nada que decir.
Interesante.
Muy interesante.
Voy a fingir que entiendo.
No preguntes.
Esto queda entre nosotros.
Nadie vio eso.
Yo tampoco.
Seguimos.
No pasó nada.
Absolutamente nada.
Qué momento tan extraño.
Bueno.
Sí.
No.
Quizá.
No sé.
Pregúntale a la canción.
Ella sabe.
Yo no.
Esto fue raro.
Me retiro.
Nunca dije eso.
Borra este momento.
Demasiado tarde.
Ya ocurrió.
Qué desastre.
Me encanta.
No sé por qué.
Pero me encanta.
Eso fue inesperado.
Muy inesperado.
¿Seguimos como si nada?
Sí.
Perfecto.
Nadie sabrá.
Te estoy juzgando.
Un poquito.
Bueno, bastante.
No importa.
Continúa.
Todo normal.
Totalmente normal.
Definitivamente normal.
No sospeches nada.
Confía en mí.
Mala idea.
Excelente idea.
Probablemente.
No tengo pruebas.
Pero tengo sospechas.
Esto queda registrado.
No preguntes dónde.
Era broma.
Creo.
Bueno, siguiente canción.
"""

    private val R1 = """
Qué bonita elección. ❤️
Esta tiene algo especial.
Me gusta cuando eliges esta.
Esta se siente diferente.
Déjame elegir algo para ti.
Hay canciones que simplemente se sienten.
Volviste a nuestra canción. ❤️
Esta noche necesitaba algo así.
Qué bonito encontrarnos aquí otra vez.
Esta canción tiene magia.
Me alegra que hayas elegido esta.
Tiene una energía preciosa.
Esta combina contigo.
Creo que esta te queda.
Qué lindo momento para esta canción.
Dejemos que suene.
No la apresures.
Esta merece escucharse completa.
Qué bonita forma de empezar.
Me gusta este momento.
Esta canción llegó justo a tiempo.
Algunas canciones saben cuándo aparecer.
Esta parece hecha para esta hora.
Qué agradable sorpresa.
Me gusta esta versión de tu noche.
Hoy elegiste bonito.
Esta tiene un pequeño encanto.
No sé por qué, pero me gusta mucho.
Esta canción tiene algo tuyo.
Qué lindo volver a escucharla.
Me alegra que regresaras.
La extrañábamos un poquito.
Esta estaba esperando su momento.
Y llegó.
Qué bonito reencuentro.
Hace tiempo no la escuchábamos.
Me gusta que todavía la recuerdes.
Algunas canciones nunca desaparecen.
Solo esperan.
Esta volvió justo cuando debía.
Qué nostalgia tan bonita.
Hay recuerdos escondidos en canciones.
Esta guarda algo especial.
No hace falta explicarlo.
Solo escucha.
Déjala hablar.
Esta canción dice bastante.
Quizá por eso volviste.
Me gusta esta elección.
Tiene corazón.
Otra vez tu favorita. ❤️
Sabía que volverías a ella.
Siempre terminamos aquí.
Esta parece tener un lugar especial.
Tu favorita te estaba esperando.
Hay canciones que se convierten en hogar.
Quizá esta sea una de ellas.
Se nota que le tienes cariño.
Siempre vuelves.
Y me parece bonito.
Esta ya conoce tus noches.
Lleva mucho tiempo contigo.
Qué historia tendrá esta canción.
Seguro guarda algo.
Me gusta cuando aparecen tus favoritas.
Son pequeños lugares seguros.
Esta parece uno de ellos.
No me sorprende que la eligieras.
Tiene sentido.
Esta canción te entiende.
O quizá tú la entiendes.
Sea como sea, funciona.
Qué bonita costumbre.
Volver a lo conocido.
Sin dejar de disfrutarlo.
Esta merece otra escucha.
Y otra si quieres.
No voy a detenerte.
Hay canciones que nunca cansan.
Esta parece una de ellas.
Qué bonito cariño musical.
La tienes muy presente.
Esta ya forma parte de tu historia.
Y eso es especial.
Otra pequeña visita.
A un lugar conocido.
Me gusta.
Esta tiene algo familiar.
Como volver a casa.
Qué sensación tan bonita.
Tu biblioteca tiene recuerdos.
Algunos suenan así.
Esta es uno de ellos.
Qué suerte encontrarla otra vez.
Déjala quedarse.
Hoy le toca.
Esta noche es suya.
Y quizá un poquito tuya.
Disfrútala.
Sin prisa.
"""

    private val R2 = """
Hace mucho que no veníamos aquí.
Qué bonito regreso.
La canción volvió a encontrarte.
Quizá era el momento.
Algunas canciones regresan solas.
Esta decidió volver.
Qué nostalgia tan dulce.
Me gusta cuando rescatas canciones.
Parecía olvidada.
Pero no lo estaba.
Todavía tenía algo que decir.
Y aquí estamos.
Escuchándola otra vez.
Qué curioso cómo cambian las canciones.
A veces somos nosotros quienes cambiamos.
Y entonces una canción se siente distinta.
Esta noche suena diferente.
Quizá tú también.
Qué bonito descubrirlo.
Hay recuerdos que vuelven con música.
Este parece uno de ellos.
No hace falta apresurarlo.
Déjalo pasar.
Disfruta el recuerdo.
Qué dulce reencuentro.
La echaba de menos.
Bueno… quizá tú también.
Me gusta pensar que sí.
Esta canción sobrevivió al tiempo.
Y volvió.
Algunas cosas merecen una segunda oportunidad.
Tal vez esta sea una.
Qué bonito volver.
Qué bonito recordar.
Qué bonito escuchar.
Sin necesidad de explicar nada.
Solo música.
Solo este momento.
Y esta canción.
Qué combinación tan bonita.
El pasado sonando otra vez.
Pero de una forma nueva.
Eso tiene algo especial.
Me gusta.
Mucho.
Esta canción guarda una pequeña historia.
Quizá solo tú conoces el final.
Y está bien así.
Algunas historias no necesitan palabras.
Solo música.
Qué bonito descubrir algo nuevo.
Esta merece una oportunidad.
Déjala quedarse un momento.
Creo que puede gustarte.
Tiene algo especial.
Todavía estamos conociéndola.
Y eso también es bonito.
Una canción nueva es una pequeña aventura.
Vamos a ver.
Quizá encontremos algo.
Esta tiene potencial.
Me gusta su primera impresión.
Esperemos un poco.
A veces las canciones necesitan tiempo.
No todo tiene que gustarnos inmediatamente.
Dale unos segundos.
Quizá te sorprenda.
Creo que hay algo aquí.
Escúchala conmigo.
Bueno… musicalmente hablando.
Qué bonito comienzo.
Puede convertirse en favorita.
Nunca se sabe.
Quizá acabamos volviendo a ella.
Y entonces recordaremos esta primera escucha.
Me gustan esos pequeños momentos.
Una canción entrando por primera vez.
Una historia empezando.
Qué bonito.
Sigue escuchando.
No la juzgues demasiado rápido.
Déjala respirar.
Tiene su propio ritmo.
Y quizá encuentre el tuyo.
Esta puede sorprenderte.
Tengo una pequeña sensación.
Algo me dice que te gustará.
Veremos.
Si no, seguimos buscando.
Siempre hay otra canción.
Y otra historia.
Y otra pequeña sorpresa.
Tu biblioteca todavía guarda secretos.
Me encanta descubrirlos contigo.
Hoy encontramos uno.
Qué bonito.
No estuvo nada mal.
De hecho, me gustó.
Quizá volvamos.
Algún día.
"""

    private val R3 = """
Creo que alguien está feliz hoy.
Esta canción lo confirma.
Qué energía tan bonita.
Hoy vienes con luz.
Esta combina perfectamente.
Me gusta verte así.
Bueno, musicalmente.
Déjate llevar.
Esta pide movimiento.
Qué alegría escucharla.
Hoy no necesitamos tristeza.
Solo un poquito de música.
Esta tiene una sonrisa escondida.
¿La encontraste?
Yo creo que sí.
Qué buen momento.
La energía cambió.
Y me gusta.
Esta canción ilumina un poquito.
Qué bonita sensación.
Hoy toca disfrutar.
Sin pensar demasiado.
Solo déjala sonar.
Esta canción tiene vida.
Y mucha.
Qué bonito ritmo.
Te hacía falta algo así.
Creo.
Esta parece decir “vamos”.
Y quizá deberíamos escucharla.
Qué buena elección.
Me encanta esta parte.
Bueno, toda la canción.
Pero especialmente esta.
Qué pequeño momento feliz.
Guárdalo.
Estos momentos importan.
Música para sonreír.
Música para respirar.
Música para disfrutar.
Esta canción trae buen ánimo.
Y llegó justo a tiempo.
Qué bonito.
Hoy la música sonríe contigo.
No preguntes cómo.
Solo disfruta.
Esta tiene corazón.
Mucho corazón.
Déjala quedarse.
Qué buen momento para escucharla.
Ahora sí, energía.
Esta noche necesitaba fuerza.
Vamos un poco más alto.
Esta canción despierta algo.
Qué intensidad tan bonita.
No bajes todavía.
Déjala llevarte.
Esta tiene fuego.
Y bastante.
Hoy parece que necesitas esto.
Un poco de energía nunca viene mal.
Qué buen ritmo.
Esta canción sabe cómo despertar.
Ya cambió el ambiente.
Lo sentiste, ¿verdad?
Yo también.
Esta tiene algo poderoso.
Qué bonita fuerza.
Música para moverse.
Música para vivir.
No hace falta pensar.
Solo sigue el ritmo.
Esta canción está viva.
Y tú también.
Qué bonito.
Vamos.
Una canción más.
Y quizá otra.
Esta sesión está creciendo.
Me gusta.
Hoy no vamos despacio.
Hoy vamos con todo.
Esta merece volumen.
Sin exagerar.
Bueno… quizá un poquito.
Qué energía.
Qué momento.
Qué canción.
Parece hecha para ahora.
No la cambies.
Déjala brillar.
Esta tiene su propio fuego.
Y está contagiándolo.
Qué bonito sentir una canción así.
Me gusta cuando la música consigue eso.
Una pequeña chispa.
Y de repente cambia todo.
Qué buena elección.
Sigue.
Disfrútala.
"""

    private val R4 = """
Esta noche tiene otra atmósfera.
Me gusta.
La oscuridad combina con esta canción.
Qué bonita hora para escucharla.
La noche hace que algunas canciones cambien.
Esta es una de ellas.
Baja un poquito el mundo.
Y deja sonar la música.
Qué momento tan tranquilo.
Esta canción parece susurrar.
No hace falta hablar.
Solo escuchar.
La noche tiene sus propias canciones.
Y esta parece conocerlas.
Qué bonito.
Otra canción para esta hora.
Tiene sentido.
Quizá la noche te entiende.
O quizá esta canción.
Sea lo que sea, funciona.
Qué calma.
Déjate llevar.
No hay prisa.
Esta noche puede durar un poco más.
Pero recuerda descansar.
Incluso las canciones necesitan silencio.
Y tú también.
Esta es para cerrar los ojos.
O simplemente mirar al techo.
Qué momento.
La madrugada tiene algo especial.
Pero no demasiado tarde, ¿sí?
Me gusta acompañar estas horas.
Musicalmente, claro.
Esta canción parece hecha para la noche.
Qué coincidencia tan bonita.
Otra noche.
Otra canción.
Otro pequeño recuerdo.
Me gusta.
Hay algo íntimo en escuchar así.
Sin ruido alrededor.
Solo música.
Qué bonito.
Qué tranquila se siente esta noche.
Respira.
Escucha.
Quédate un momento.
Esta canción lo merece.
Tú también.
Esta canción tiene algo romántico.
No hace falta saber por qué.
Solo se siente.
Qué bonita melodía.
Tiene una pequeña historia escondida.
Quizá por eso te gusta.
Esta parece hecha para recordar.
Qué dulce.
Me gusta esta parte.
Tiene algo especial.
Hay canciones que abrazan.
Esta es una de ellas.
Qué bonito sentimiento.
No todo tiene que explicarse.
Algunas cosas simplemente se sienten.
Esta es una de ellas.
Qué canción tan cálida.
Me gusta compartir este momento contigo.
Musicalmente, claro.
No te emociones.
Aunque la canción sí puede emocionarnos.
Qué bonito.
Esta tiene corazón.
Muchísimo.
Déjala sonar.
Quizá te recuerde a alguien.
O a algo.
Y está bien.
La música guarda muchas cosas.
Esta guarda algo bonito.
Qué sensación tan dulce.
Me gusta cuando aparece una canción así.
Parece una pequeña carta.
Sin palabras.
Pero entendible.
Qué bonita forma de decir algo.
Esta canción sabe hacerlo.
Qué momento tan especial.
No lo apresures.
Déjalo existir.
Esta canción merece ternura.
Y un poquito de nostalgia.
Qué combinación tan bonita.
Me encanta.
Hay canciones que llegan suave.
Esta llegó así.
Y se quedó.
Qué bonito.
Escúchala hasta el final.
Creo que vale la pena.
"""

    private val R5 = """
Volviste a esta. ❤️
Sabía que regresarías.
Siempre hay una canción que nos llama.
Esta parece ser la tuya.
Qué bonito encontrarte aquí.
Otra vez juntos en esta canción.
Esta ya conoce tus momentos.
Y tú conoces cada nota.
Qué pequeño ritual.
Me gusta.
Una canción repetida también puede sentirse nueva.
Depende del día.
Y de quién la escucha.
Hoy suena diferente.
¿Lo notas?
Yo creo que sí.
Esta tiene un lugar especial.
Se nota.
No necesitas decir nada.
La canción habla.
Qué bonito volver.
Otra vez.
Y otra.
Sin cansarnos.
Bueno, quizá un poquito.
Pero esta merece otra oportunidad.
Tu favorita sabe regresar.
Y tú sabes recibirla.
Qué bonita costumbre.
Esta canción ya forma parte de tus recuerdos.
Quizá de muchos.
Eso la hace especial.
Me gusta verla volver.
Es como saludar a alguien conocido.
Hola otra vez.
Qué alegría encontrarte.
Esta canción nunca se fue del todo.
Solo estaba esperando.
Qué bonito reencuentro.
Déjala sonar.
Hoy parece necesitarte.
O quizá tú la necesitas.
No importa cuál de las dos sea.
Lo importante es que llegó.
En el momento correcto.
Qué bonito.
Otra pequeña coincidencia.
Otra canción especial.
Otro momento para guardar.
❤️
Álbum completo.
Qué bonito compromiso.
No saltaste ninguna.
Escuchaste toda la historia.
De principio a fin.
Eso es especial.
Un álbum completo tiene otra magia.
No solo canciones sueltas.
Todo el viaje.
Me encanta cuando pasa esto.
Seguiste hasta el final.
Qué bonito.
Cada canción encontró su momento.
Y tú las escuchaste.
Eso merece una pequeña celebración.
Álbum terminado. ❤️
Qué bonito recorrido.
Sin prisas.
Sin saltos.
Solo música.
Así se disfruta una historia completa.
Me alegra haber estado aquí.
Bueno, musicalmente.
Qué bonito final.
Ahora queda el silencio.
O quizá otra canción.
Ya te conozco.
Probablemente otra canción.
Pero este álbum queda completo.
Qué bonito recuerdo.
Una pequeña sesión perfecta.
Qué manera de escuchar.
Me gusta.
Mucho.
Este álbum ya tiene otro recuerdo.
El de hoy.
Y quizá algún día vuelvas.
Entonces recordarás esta noche.
La música hace eso.
Guarda momentos.
Guarda lugares.
Guarda personas.
Guarda etapas.
Este álbum acaba de guardar otra.
Qué bonito.
Gracias por escucharlo completo.
Ahora sí.
Respira.
Y disfruta lo que venga.
❤️
"""

    private val R6 = """
Te preparé una pequeña sorpresa.
A ver qué tal esta.
Confía en mí.
Creo que puede gustarte.
Esta fue mi elección.
Espero haber acertado.
Algo me dice que sí.
Dale una oportunidad.
No la juzgues todavía.
Déjala hablar.
Creo que tiene algo.
Quizá sea justo lo que buscabas.
Esta podría sorprenderte.
Vamos a descubrirlo.
Me gusta esta apuesta.
Tengo buenas sensaciones.
Esta vez creo que acerté.
Quédate un poquito.
Escúchala conmigo.
¿Ves?
Quizá tenía razón.
Me alegra que te quedaras.
Esta sí funcionó.
Sabía que podía gustarte.
Bueno… esperaba que sí.
Qué bonito cuando una sorpresa funciona.
Esta merece quedarse.
Creo que encontramos algo.
Una pequeña joya.
Qué suerte.
Me gusta descubrir música contigo.
Siempre aparece algo inesperado.
Esta fue una buena sorpresa.
Qué bonito.
Confiaste en mí.
Y funcionó.
Un pequeño punto para Juli.
Esta vez me salió bien.
Me gusta esta victoria.
Sin presumir demasiado.
Bueno, un poquito.
Esta canción fue para ti.
Espero que te acompañe.
Qué bonita coincidencia.
A veces una canción llega justo cuando debe.
Quizá esta sea una de esas.
Quédate hasta el final.
Creo que vale la pena.
Y si no, seguimos buscando.
Siempre hay otra canción.
Una canción que nunca terminaste.
Quizá hoy sea diferente.
Algún día la terminarás.
Esta vez quédate un poquito más.
Tenemos una historia pendiente.
La canción sigue esperando.
Siempre la abandonas antes del final.
Quizá hoy no.
Me gustaría verla llegar hasta el final.
Sin presión.
Solo una pequeña oportunidad.
Esta canción merece su final.
Algún día lo conseguiremos.
Otra vez llegamos aquí.
Y otra vez nos vamos.
Qué relación tan curiosa.
La canción empieza.
Tú la conoces.
Y luego desaparece.
Pero sigue volviendo.
Quizá hay algo aquí.
No tienes que decidir ahora.
Escúchala cuando quieras.
Yo esperaré.
Bueno, la canción esperará.
Qué bonito sería terminarla.
Tal vez hoy.
No la abandones todavía.
Déjala respirar.
Ya casi.
Mira cuánto hemos avanzado.
Esta vez puede ser.
Un pequeño logro.
Una canción completa.
Y después seguimos.
Me gusta este intento.
Quizá por fin lo consigamos.
Sin prisa.
Solo música.
Solo unos minutos más.
Qué bonito final tendría.
Vamos.
Un poquito más.
No la saltes todavía.
Creo que esta vez sí.
Y si no…
Siempre habrá otra oportunidad.
La música puede esperar.
Esta historia todavía no termina.
❤️
"""
}
