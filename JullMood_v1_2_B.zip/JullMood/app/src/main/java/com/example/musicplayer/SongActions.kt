@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.example.musicplayer

import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/*
 * Menú de una canción (⋮ o pulsación larga): acciones de siempre + buscar carátula, editar/buscar datos,
 * compartir, detalles y eliminar. Los cambios de carátula y datos se guardan dentro de la app (SongFix.kt);
 * el archivo mp3 no se modifica.
 */

private enum class Dlg { NONE, MOOD, COVER, INFO, DETAILS, DELETE }

private fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

private fun knownArtist(s: Song) = s.artist.takeUnless { it.startsWith("Artista desconocido") }.orEmpty()
private fun knownAlbum(s: Song) = s.album.takeUnless { it.startsWith("Álbum desconocido") }.orEmpty()

@Composable
internal fun SongActions(vm: PlayerViewModel, song: Song, onAdd: (Song) -> Unit, onRemove: ((Song) -> Unit)?, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var dlg by remember { mutableStateOf(Dlg.NONE) }

    // Android 11+: la propia petición del sistema borra el archivo. Android 10: tras el permiso hay que repetir el borrado.
    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            if (Build.VERSION.SDK_INT == 29) runCatching { ctx.contentResolver.delete(song.uri, null, null) }
            vm.onSongDeleted()
            onDismiss()
        } else dlg = Dlg.NONE
    }

    if (dlg == Dlg.NONE) ModalBottomSheet(onDismissRequest = onDismiss, containerColor = MaterialTheme.colorScheme.surface) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Cover(song, Modifier.size(56.dp))
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text("${song.artist} · ${song.album}", maxLines = 1, overflow = TextOverflow.Ellipsis, color = Gray, fontSize = 13.sp)
                }
            }
            ActionRow(R.drawable.ic_next, "Reproducir siguiente") { vm.playNext(song); onDismiss() }
            ActionRow(R.drawable.ic_queue, "Añadir a la cola") { vm.addToQueue(song); onDismiss() }
            ActionRow(R.drawable.ic_add, "Añadir a una lista") { onAdd(song); onDismiss() }
            ActionRow(R.drawable.ic_note, "Cambiar Mood") { dlg = Dlg.MOOD }
            ActionRow(R.drawable.ic_search, "Buscar carátula") { dlg = Dlg.COVER }
            ActionRow(R.drawable.ic_edit, "Editar o buscar datos (título, artista, álbum)") { dlg = Dlg.INFO }
            ActionRow(R.drawable.ic_share, "Compartir") { shareSong(ctx, song); onDismiss() }
            ActionRow(R.drawable.ic_info, "Detalles") { dlg = Dlg.DETAILS }
            if (onRemove != null) ActionRow(R.drawable.ic_close, "Quitar de esta lista") { onRemove(song); onDismiss() }
            if (song.autoFixed) ActionRow(R.drawable.ic_prev, "Deshacer cambios de datos y carátula") { vm.revertFix(song); onDismiss() }
            ActionRow(R.drawable.ic_delete, "Eliminar del dispositivo", danger = true) { dlg = Dlg.DELETE }
        }
    }

    when (dlg) {
        Dlg.MOOD -> ChangeMoodDialog(vm, song) { onDismiss() }
        Dlg.COVER -> CoverDialog(vm, song, onBack = { dlg = Dlg.NONE }, onDone = onDismiss)
        Dlg.INFO -> InfoDialog(vm, song, onBack = { dlg = Dlg.NONE }, onDone = onDismiss)
        Dlg.DETAILS -> DetailsDialog(song) { dlg = Dlg.NONE }
        Dlg.DELETE -> AlertDialog(
            onDismissRequest = { dlg = Dlg.NONE },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text("Eliminar canción") },
            text = { Text("«${song.title}» se borrará del dispositivo. Esta acción no se puede deshacer.") },
            confirmButton = {
                TextButton(onClick = {
                    requestDelete(
                        ctx, song,
                        launch = { sender -> deleteLauncher.launch(IntentSenderRequest.Builder(sender).build()) },
                        onDone = { vm.onSongDeleted(); onDismiss() },
                        onError = { msg -> toast(ctx, msg); dlg = Dlg.NONE }
                    )
                }) { Text("Eliminar", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { dlg = Dlg.NONE }) { Text("Cancelar") } }
        )
        Dlg.NONE -> Unit
    }
}

@Composable
private fun ActionRow(icon: Int, label: String, danger: Boolean = false, onClick: () -> Unit) {
    val c = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(painterResource(icon), null, tint = c, modifier = Modifier.size(22.dp))
        Text(label, color = c, modifier = Modifier.padding(start = 16.dp))
    }
}

// ---------- Compartir y eliminar ----------

private fun shareSong(ctx: Context, song: Song) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "audio/*"
        putExtra(Intent.EXTRA_STREAM, song.uri)
        putExtra(Intent.EXTRA_TITLE, song.title)
        clipData = ClipData.newRawUri(song.title, song.uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    runCatching { ctx.startActivity(Intent.createChooser(send, "Compartir canción")) }
}

/** Solo canciones de MediaStore. Las de una carpeta elegida con el selector (SAF) no tienen permiso de escritura. */
private fun requestDelete(ctx: Context, song: Song, launch: (IntentSender) -> Unit, onDone: () -> Unit, onError: (String) -> Unit) {
    if (song.uri.authority != MediaStore.AUTHORITY) {
        onError("Esta canción viene de una carpeta elegida: bórrala desde tu gestor de archivos.")
        return
    }
    try {
        if (Build.VERSION.SDK_INT >= 30) {
            launch(MediaStore.createDeleteRequest(ctx.contentResolver, listOf(song.uri)).intentSender)
        } else if (ctx.contentResolver.delete(song.uri, null, null) > 0) onDone()
        else onError("No se pudo borrar el archivo.")
    } catch (e: SecurityException) {
        if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) launch(e.userAction.actionIntent.intentSender)
        else onError("Android no permite borrar este archivo desde la app en esta versión.")
    } catch (e: Exception) {
        onError("No se pudo borrar el archivo.")
    }
}

// ---------- Detalles ----------

@Composable
private fun DetailsDialog(song: Song, onBack: () -> Unit) {
    @Composable fun line(k: String, v: String) {
        if (v.isNotBlank()) Column(Modifier.padding(bottom = 8.dp)) {
            Text(k, color = Gray, fontSize = 12.sp)
            Text(v)
        }
    }
    AlertDialog(
        onDismissRequest = onBack,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("Detalles") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                line("Título", song.title)
                line("Artista", song.artist)
                line("Álbum", song.album)
                line("Duración", formatTime(song.durationMs))
                line("Año", if (song.year > 0) song.year.toString() else "")
                line("Género", song.genre)
                line("Ubicación", song.pathKey)
                if (song.autoFixed) line("Datos", "Corregidos dentro de la app (el archivo no se modificó)")
            }
        },
        confirmButton = { TextButton(onClick = onBack) { Text("Cerrar") } }
    )
}

// ---------- Buscar carátula ----------

@Composable
private fun CoverDialog(vm: PlayerViewModel, song: Song, onBack: () -> Unit, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val initial = remember { VagueNames.searchTerms(song.title, knownArtist(song)) }
    var title by remember { mutableStateOf(initial.first) }
    var artist by remember { mutableStateOf(initial.second) }
    var hits by remember { mutableStateOf<List<ManualHit>?>(null) }
    var busy by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }

    fun search() {
        scope.launch {
            busy = true; msg = ""
            val (t, a) = VagueNames.searchTerms(title, artist)
            hits = vm.searchSongInfo(t, a)
            if (hits == null) msg = "No se pudo buscar. Revisa tu conexión."
            busy = false
        }
    }
    LaunchedEffect(Unit) { search() }

    fun finish(ok: Boolean) {
        saving = false
        if (ok) { toast(ctx, "Carátula actualizada"); onDone() } else msg = "No se pudo guardar esa carátula."
    }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) { saving = true; vm.applyCoverFromUri(song, uri) { finish(it) } }
    }

    AlertDialog(
        onDismissRequest = onBack,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("Buscar carátula") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(title, { title = it }, label = { Text("Título") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(artist, { artist = it }, label = { Text("Artista (opcional)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                Row(Modifier.padding(top = 4.dp)) {
                    TextButton(onClick = { search() }, enabled = !busy && !saving) { Text("Buscar") }
                    TextButton(onClick = { gallery.launch("image/*") }, enabled = !saving) { Text("Elegir de la galería") }
                }
                if (busy || saving) LinearProgressIndicator(Modifier.fillMaxWidth())
                if (msg.isNotEmpty()) Text(msg, color = Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                val covers = hits.orEmpty().distinctBy { it.releaseId }
                if (hits != null && covers.isEmpty() && !busy && msg.isEmpty())
                    Text("Sin resultados. Prueba con otro título o artista.", color = Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                covers.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { h ->
                            Column(Modifier.weight(1f)) {
                                CoverThumb(vm, h.releaseId) {
                                    if (!saving) { saving = true; vm.applyCoverFromRelease(song, h.releaseId) { ok -> finish(ok) } }
                                }
                                Text(h.album, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = Gray)
                                if (h.year.isNotBlank()) Text(h.year, fontSize = 10.sp, color = Gray)
                            }
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onBack) { Text("Cerrar") } }
    )
}

@Composable
private fun CoverThumb(vm: PlayerViewModel, releaseId: String, onClick: () -> Unit) {
    val state by produceState<Pair<Boolean, Bitmap?>>(false to null, releaseId) {
        val bytes = vm.coverThumb(releaseId)
        val bmp = bytes?.let { b -> withContext(Dispatchers.IO) { BitmapFactory.decodeByteArray(b, 0, b.size) } }
        value = true to bmp
    }
    val (loaded, bmp) = state
    val shape = Modifier.fillMaxWidth().aspectRatio(1f).clip(androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
    Box(shape.background(MaterialTheme.colorScheme.surfaceVariant), Alignment.Center) {
        when {
            bmp != null -> Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize().clickable(onClick = onClick), contentScale = ContentScale.Crop)
            loaded -> Text("Sin imagen", color = Gray, fontSize = 11.sp)
            else -> CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
        }
    }
}

// ---------- Editar o buscar datos ----------

@Composable
private fun InfoDialog(vm: PlayerViewModel, song: Song, onBack: () -> Unit, onDone: () -> Unit) {
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf(song.title) }
    var artist by remember { mutableStateOf(knownArtist(song)) }
    var album by remember { mutableStateOf(knownAlbum(song)) }
    var hits by remember { mutableStateOf<List<ManualHit>?>(null) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }

    fun search() {
        scope.launch {
            busy = true; msg = ""
            val (t, a) = VagueNames.searchTerms(title, artist)
            hits = vm.searchSongInfo(t, a)
            if (hits == null) msg = "No se pudo buscar. Revisa tu conexión."
            busy = false
        }
    }
    LaunchedEffect(Unit) { search() }

    AlertDialog(
        onDismissRequest = onBack,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("Datos de la canción") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(title, { title = it }, label = { Text("Título") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(artist, { artist = it }, label = { Text("Artista") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                OutlinedTextField(album, { album = it }, label = { Text("Álbum") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                TextButton(onClick = { search() }, enabled = !busy) { Text("Buscar coincidencias") }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                if (msg.isNotEmpty()) Text(msg, color = Gray, fontSize = 12.sp)
                val list = hits.orEmpty()
                if (hits != null && list.isEmpty() && !busy && msg.isEmpty())
                    Text("Sin resultados. Prueba con otro título o artista.", color = Gray, fontSize = 13.sp)
                if (list.isNotEmpty()) Text("Toca una opción para rellenar los campos:", color = Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                list.forEach { h ->
                    Column(
                        Modifier.fillMaxWidth().clickable { title = h.title; artist = h.artist; album = h.album }.padding(vertical = 8.dp)
                    ) {
                        Text(h.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                        Text(
                            "${h.artist} · ${h.album}" + if (h.year.isNotBlank()) " (${h.year})" else "",
                            maxLines = 1, overflow = TextOverflow.Ellipsis, color = Gray, fontSize = 12.sp
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val t = title.trim().takeIf { it.isNotEmpty() && it != song.title }
                val a = artist.trim().takeIf { it.isNotEmpty() && it != song.artist }
                val al = album.trim().takeIf { it.isNotEmpty() && it != song.album }
                if (t != null || a != null || al != null) vm.applyManualInfo(song, t, a, al)
                onDone()
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onBack) { Text("Cancelar") } }
    )
}
