package com.example.musicplayer

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** Entrada suave de una tarjeta (una sola vez). Con animaciones reducidas aparece sin animar. */
@Composable
private fun CardEntrance(content: @Composable () -> Unit) {
    if (rememberReducedMotion()) { content(); return }
    val state = remember { MutableTransitionState(false).apply { targetState = true } }
    AnimatedVisibility(state, enter = fadeIn(tween(500)) + expandVertically(tween(500))) { content() }
}

/** "Tu semana en JullMood": solo aparece cuando hay datos suficientes y toca (≈ una vez por semana). */
@Composable
internal fun WeeklyInviteCard(onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    CardEntrance {
        Row(
            Modifier.padding(horizontal = 20.dp, vertical = 6.dp).fillMaxWidth().pressable(onClick)
                .clip(uiShape(24.dp)).background(cs.primaryContainer).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            androidx.compose.foundation.Image(painterResource(R.drawable.logo_jm), "JullMood Music", Modifier.size(48.dp))
            Column(Modifier.weight(1f).padding(start = 14.dp)) {
                Text(
                    "TU SEMANA EN JULLMOOD", color = cs.onPrimaryContainer.copy(alpha = 0.7f),
                    fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp
                )
                Text("Tu identidad musical", color = cs.onPrimaryContainer, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Text("Mira cómo sonó tu semana", color = cs.onPrimaryContainer.copy(alpha = 0.8f), fontSize = 13.sp)
            }
        }
    }
}

/** Observación de la memoria musical ("Hace tiempo...", "Últimamente...", "Tu clásico"...). Se puede cerrar. */
@Composable
internal fun MicroCard(ins: Insight, onPlay: () -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    CardEntrance {
        Row(
            Modifier.padding(horizontal = 20.dp, vertical = 6.dp).fillMaxWidth()
                .clip(uiShape(24.dp)).background(cs.surface).padding(start = 14.dp, top = 14.dp, bottom = 10.dp, end = 4.dp),
            verticalAlignment = Alignment.Top
        ) {
            GroupCover(ins.songs, Modifier.size(76.dp), px = 240, radius = 16.dp)
            Column(Modifier.weight(1f).padding(start = 14.dp)) {
                Text(ins.title, color = cs.primary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Text(ins.text, fontSize = 15.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 2.dp, end = 8.dp))
                FilledTonalButton(onClick = onPlay, shape = uiShape(14.dp), modifier = Modifier.padding(top = 8.dp)) {
                    Icon(painterResource(R.drawable.ic_play), null, Modifier.size(18.dp))
                    Text("  Escuchar")
                }
            }
            IconBtn(R.drawable.ic_close, "Cerrar", Gray, size = 20.dp, onClick = onDismiss)
        }
    }
}

/**
 * Se muestra al pulsar Sorpréndeme: primero la frase (según el motivo de la elección) y un instante después la canción.
 * La música ya está sonando; esto es solo la presentación. Se cierra sola a los pocos segundos.
 */
@Composable
internal fun SurpriseReveal(pick: SurprisePick, modifier: Modifier, onOpen: () -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val reduced = rememberReducedMotion()
    var showSong by remember(pick) { mutableStateOf(reduced) }
    LaunchedEffect(pick) {
        if (!reduced) { delay(550); showSong = true }
        delay(4_000)
        onDismiss()
    }
    val a by animateFloatAsState(if (showSong) 1f else 0f, if (reduced) tween<Float>(0) else tween<Float>(450), label = "revealSong")
    val state = remember(pick) { MutableTransitionState(reduced).apply { targetState = true } }
    AnimatedVisibility(
        state, modifier,
        enter = if (reduced) fadeIn(tween(0)) else fadeIn(tween(350)) + slideInVertically(tween(420)) { -it / 2 } + scaleIn(tween(420), initialScale = 0.92f)
    ) {
        Surface(
            Modifier.padding(horizontal = 20.dp, vertical = 10.dp).fillMaxWidth(),
            shape = uiShape(22.dp), color = cs.primaryContainer, shadowElevation = 6.dp
        ) {
            Row(Modifier.clickable { onDismiss(); onOpen() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Cover(pick.song, Modifier.size(56.dp).graphicsLayer { alpha = a; scaleX = 0.85f + 0.15f * a; scaleY = 0.85f + 0.15f * a }, px = 200, radius = 12.dp)
                Column(Modifier.weight(1f).padding(start = 14.dp), verticalArrangement = Arrangement.Center) {
                    Text(pick.phrase, color = cs.onPrimaryContainer, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2)
                    Text(
                        "${pick.song.title} · ${pick.song.artist}", color = cs.onPrimaryContainer.copy(alpha = 0.8f), fontSize = 13.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp).graphicsLayer { alpha = a }
                    )
                }
            }
        }
    }
}

/** Frase corta de Juli al elegir una canción. `id` distingue dos frases iguales seguidas para que la animación se repita. */
class JuliLine(val text: String, val id: Long, val heading: String? = null)

/**
 * Frase breve al elegir una canción normalmente: misma entrada que la revelación de Sorpréndeme (aparece, se queda ~2 s y
 * se va). No intercepta toques ni detiene nada: la música ya está sonando. Con animaciones reducidas aparece sin animar.
 */
@Composable
internal fun JuliToast(line: JuliLine, modifier: Modifier, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val reduced = rememberReducedMotion()
    val state = remember(line.id) { MutableTransitionState(reduced).apply { targetState = true } }
    LaunchedEffect(line.id) {
        delay(if (line.heading != null) 3_800L else 2_200L)   // un Easter Egg nuevo se queda un poco más
        state.targetState = false
        delay(if (reduced) 0L else 350L)
        onDismiss()
    }
    AnimatedVisibility(
        state, modifier,
        enter = if (reduced) fadeIn(tween(0)) else fadeIn(tween(300)) + slideInVertically(tween(360)) { -it / 2 } + scaleIn(tween(360), initialScale = 0.92f),
        exit = if (reduced) fadeOut(tween(0)) else fadeOut(tween(300))
    ) {
        val shape = uiShape(20.dp)
        Box(
            Modifier.padding(horizontal = 24.dp, vertical = 10.dp).shadow(6.dp, shape).clip(shape)
                .background(cs.primaryContainer).padding(horizontal = 18.dp, vertical = 11.dp)
        ) {
            Column {
                line.heading?.let { Text(it, color = cs.onPrimaryContainer, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 2) }
                Text(line.text, color = cs.onPrimaryContainer, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2)
            }
        }
    }
}
