package com.example.musicplayer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.media3.common.util.BitmapLoader
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import java.util.concurrent.Callable
import java.util.concurrent.Executors

/**
 * Puente entre la biblioteca y el servicio de reproducción (v1.1).
 * Cada canción se publica con una URI propia ("jullmood-art://song/ID"); el servicio la convierte en la carátula
 * real usando la MISMA caché que la interfaz (ArtCache), incluidas las carátulas descargadas por la corrección
 * automática y las incrustadas en el archivo. Así la notificación y la pantalla bloqueada muestran la portada correcta.
 */
object SongArt {
    @Volatile var songs: Map<Long, Song> = emptyMap()
    fun uriOf(id: Long): Uri = Uri.parse("jullmood-art://song/$id")
}

/** Carga carátulas para la sesión multimedia en un hilo propio (nunca bloquea el reproductor ni la interfaz). */
class JmBitmapLoader(private val ctx: Context) : BitmapLoader {
    private val exec = MoreExecutors.listeningDecorator(Executors.newSingleThreadExecutor())

    override fun supportsMimeType(mimeType: String): Boolean = mimeType.startsWith("image/")

    override fun decodeBitmap(data: ByteArray): ListenableFuture<Bitmap> =
        exec.submit(Callable<Bitmap> {
            BitmapFactory.decodeByteArray(data, 0, data.size) ?: fallback()
        })

    override fun loadBitmap(uri: Uri): ListenableFuture<Bitmap> =
        exec.submit(Callable<Bitmap> {
            val id = uri.lastPathSegment?.toLongOrNull()
            val song = if (id != null) SongArt.songs[id] else null
            (if (song != null) ArtCache.load(ctx, song, 512) else null) ?: fallback()
        })

    /** Sin carátula: el logo oficial de JullMood Music. */
    private fun fallback(): Bitmap =
        BitmapFactory.decodeResource(ctx.resources, R.drawable.logo_jm)
            ?: Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
}
