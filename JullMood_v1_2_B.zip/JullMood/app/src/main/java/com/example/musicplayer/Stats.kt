package com.example.musicplayer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.Normalizer

// ---------- Cálculo (100 % local, sobre el historial existente: stats + skips de PlayerViewModel) ----------

/** Un elemento del ranking (canción, artista o álbum). `songs` sirve para pintar su carátula. */
class TopEntry(val title: String, val subtitle: String, val plays: Int, val songs: List<Song>)

class StatsData(
    val totalPlays: Int, val songs: Int, val artists: Int, val albums: Int, val listenedMs: Long,
    val enough: Boolean,
    val topSong: TopEntry?, val topArtist: TopEntry?, val topAlbum: TopEntry?,
    val weekPlays: Int, val weekSong: TopEntry?, val weekArtist: TopEntry?,
    val topMood: Pair<Mood, Int>?
)

/** Secciones del Home basadas en el historial: "Tu música de esta semana" y "Volviste a escuchar…". */
class Memory(val thisWeek: List<Song>, val comeback: List<Song>)

object StatsCalc {
    const val DAY = 86_400_000L
    const val WEEK = 7 * DAY          // "esta semana" = los últimos 7 días (no depende del día en que empieza la semana)
    private const val MIN_PLAYS = 5   // por debajo de esto no se muestran rankings: serían engañosos
    private const val UNKNOWN_ARTIST = "Artista desconocido"
    private const val UNKNOWN_ALBUM = "Álbum desconocido"

    private fun norm(s: String): String =
        Normalizer.normalize(s.lowercase().trim(), Normalizer.Form.NFD).filter { it.isLetterOrDigit() }

    /** Misma canción aunque esté duplicada en dos archivos (distinto id): título + artista normalizados. */
    internal fun songKey(s: Song) = norm(s.title) + "|" + norm(s.artist)

    private class Acc(var rep: Song) {
        var plays = 0; var week = 0; var last = 0L; var repPlays = 0
        val songs = ArrayList<Song>()
    }

    fun compute(songs: List<Song>, stats: Map<Long, SongStat>, moodsOf: (Song) -> List<Mood>, now: Long): StatsData {
        val weekCut = now - WEEK
        val bySong = HashMap<String, Acc>()
        val byArtist = HashMap<String, Acc>()
        val byAlbum = HashMap<String, Acc>()
        val moodPlays = HashMap<Mood, Int>()
        var total = 0; var week = 0; var ms = 0L

        // Solo cuentan canciones que siguen en la biblioteca: si se borra un archivo, sus datos dejan de sumar.
        for (s in songs) {
            val st = stats[s.id] ?: continue
            val p = st.plays
            if (p <= 0) continue
            val w = st.recent.count { it >= weekCut }
            total += p; week += w; ms += st.listenedMs
            fun add(map: HashMap<String, Acc>, key: String) {
                val a = map.getOrPut(key) { Acc(s) }
                a.plays += p; a.week += w
                if (st.last > a.last) a.last = st.last
                a.songs += s
                if (p > a.repPlays) { a.repPlays = p; a.rep = s }
            }
            add(bySong, songKey(s))
            if (s.artist != UNKNOWN_ARTIST) add(byArtist, s.artist)
            if (s.album != UNKNOWN_ALBUM) add(byAlbum, s.album)
            for (m in moodsOf(s)) if (m != Mood.SIN_CLASIFICAR && m != Mood.MIXTO) moodPlays[m] = (moodPlays[m] ?: 0) + p
        }

        fun top(map: Map<String, Acc>, weekly: Boolean): Acc? =
            map.values.maxWithOrNull(compareBy<Acc>({ if (weekly) it.week else it.plays }, { it.last }))

        fun entry(a: Acc?, kind: Int, weekly: Boolean, min: Int): TopEntry? {
            if (a == null) return null
            val n = if (weekly) a.week else a.plays
            if (n < min) return null
            return when (kind) {
                0 -> TopEntry(a.rep.title, a.rep.artist, n, listOf(a.rep))
                1 -> TopEntry(a.rep.artist, "${a.songs.size} ${if (a.songs.size == 1) "canción escuchada" else "canciones escuchadas"}", n, a.songs.take(5))
                else -> TopEntry(a.rep.album, a.rep.artist, n, a.songs.take(5))
            }
        }

        val enough = total >= MIN_PLAYS
        val weekEnough = week >= 3
        val mood = moodPlays.entries.maxByOrNull { it.value }?.takeIf { enough && it.value >= MIN_PLAYS }
        return StatsData(
            totalPlays = total, songs = bySong.size, artists = byArtist.size, albums = byAlbum.size, listenedMs = ms,
            enough = enough,
            topSong = if (enough) entry(top(bySong, false), 0, false, 2) else null,
            topArtist = if (enough) entry(top(byArtist, false), 1, false, 3) else null,
            topAlbum = if (enough) entry(top(byAlbum, false), 2, false, 3) else null,
            weekPlays = week,
            weekSong = if (weekEnough) entry(top(bySong, true), 0, true, 2) else null,
            weekArtist = if (weekEnough) entry(top(byArtist, true), 1, true, 2) else null,
            topMood = mood?.let { it.key to it.value }
        )
    }

    fun memory(songs: List<Song>, stats: Map<Long, SongStat>, now: Long): Memory {
        val weekCut = now - WEEK
        val gap = 30 * DAY
        class W(val song: Song, val week: Int, val last: Long)
        val weekly = ArrayList<W>()
        val comeback = ArrayList<Pair<Song, Long>>()
        for (s in songs) {
            val st = stats[s.id] ?: continue
            val inWeek = st.recent.filter { it >= weekCut }
            if (inWeek.isEmpty()) continue
            weekly += W(s, inWeek.size, st.last)
            // "Volviste a escuchar…": la primera reproducción de esta semana llegó tras >30 días sin sonar.
            val prev = st.recent.filter { it < weekCut }.maxOrNull()
            if (prev != null && inWeek.min() - prev >= gap) comeback += s to inWeek.min()
        }
        val thisWeek = weekly.sortedWith(compareByDescending<W> { it.week }.thenByDescending { it.last })
            .map { it.song }.distinctBy { songKey(it) }.take(15)
        val back = comeback.sortedByDescending { it.second }.map { it.first }.distinctBy { songKey(it) }.take(12)
        return Memory(
            thisWeek = if (thisWeek.size >= 3) thisWeek else emptyList(),
            comeback = if (back.size >= 2) back else emptyList()
        )
    }
}

private fun formatLong(ms: Long): String {
    val h = ms / 3_600_000L
    val m = (ms / 60_000L) % 60
    return when {
        ms <= 0L -> "—"
        h > 0 -> "$h h $m min"
        else -> "${maxOf(m, 1L)} min"
    }
}

// ---------- Pantalla de estadísticas ----------

@Composable
internal fun StatsScreen(vm: PlayerViewModel, onBack: () -> Unit) {
    val songs = vm.songs; val stats = vm.stats; val auto = vm.autoMoods; val manual = vm.manualMoods
    // Se calcula fuera del hilo principal y solo cuando cambian la biblioteca, el historial o los Moods.
    val data by produceState<StatsData?>(null, songs, stats, auto, manual) {
        value = withContext(Dispatchers.Default) {
            StatsCalc.compute(songs, stats, { s -> manual[s.id] ?: auto[s.id] ?: emptyList() }, System.currentTimeMillis())
        }
    }
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(R.drawable.ic_down, "Volver", rotate = true, onClick = onBack)
            Text("Tu música en números", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
        val d = data
        when {
            d == null -> Empty("Calculando…")
            d.totalPlays == 0 -> Empty("Todavía no hay reproducciones. Escucha algunas canciones y aquí aparecerán tus estadísticas.")
            else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
                item {
                    Text(
                        "Todo se calcula en este dispositivo a partir de tu historial. Nada se envía a ningún servidor.",
                        color = Gray, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                    )
                }
                item {
                    Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            StatCard("Canciones escuchadas", d.songs.toString(), Modifier.weight(1f))
                            StatCard("Reproducciones", d.totalPlays.toString(), Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            StatCard("Artistas", d.artists.toString(), Modifier.weight(1f))
                            StatCard("Álbumes", d.albums.toString(), Modifier.weight(1f))
                        }
                        StatCard("Tiempo de escucha", formatLong(d.listenedMs), Modifier.fillMaxWidth())
                    }
                }
                item {
                    Text(
                        "El tiempo y la actividad por semana se registran desde esta versión; tus reproducciones anteriores sí cuentan en los totales.",
                        color = Gray, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
                    )
                }
                if (!d.enough) item {
                    Text(
                        "Todavía hay pocos datos para mostrar rankings. Con unas cuantas reproducciones más verás tus favoritos.",
                        color = cs.primary, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp)
                    )
                } else {
                    val all = listOfNotNull(
                        d.topSong?.let { "Canción más escuchada" to it },
                        d.topArtist?.let { "Artista más escuchado" to it },
                        d.topAlbum?.let { "Álbum más escuchado" to it }
                    )
                    if (all.isNotEmpty()) {
                        item { StatsTitle("Lo más escuchado") }
                        items(all.size) { i -> TopRow(all[i].first, all[i].second) }
                    }
                    val wk = listOfNotNull(
                        d.weekSong?.let { "Canción de la semana" to it },
                        d.weekArtist?.let { "Artista de la semana" to it }
                    )
                    if (wk.isNotEmpty()) {
                        item { StatsTitle("Esta semana", "Últimos 7 días · ${d.weekPlays} reproducciones") }
                        items(wk.size) { i -> TopRow(wk[i].first, wk[i].second) }
                    }
                    d.topMood?.let { (m, n) ->
                        item { StatsTitle("Tu Mood más escuchado") }
                        item {
                            Row(
                                Modifier.padding(horizontal = 20.dp).fillMaxWidth().clip(uiShape(24.dp)).background(cs.surface).padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(m.emoji, fontSize = 34.sp)
                                Column(Modifier.weight(1f).padding(start = 14.dp)) {
                                    Text(m.label, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                    Text("$n reproducciones en canciones de este Mood", color = Gray, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier) {
    Column(modifier.clip(uiShape(20.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp)) {
        Text(value, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary, maxLines = 1)
        Text(label, color = Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun StatsTitle(title: String, subtitle: String? = null) {
    Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 10.dp)) {
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        if (subtitle != null) Text(subtitle, color = Gray, fontSize = 13.sp)
    }
}

@Composable
private fun TopRow(label: String, e: TopEntry) {
    Row(
        Modifier.padding(horizontal = 20.dp, vertical = 5.dp).fillMaxWidth().clip(uiShape(20.dp))
            .background(MaterialTheme.colorScheme.surface).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GroupCover(e.songs, Modifier.size(56.dp), radius = 12.dp)
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(label, color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(e.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
            Text(
                "${e.subtitle} · ${e.plays} ${if (e.plays == 1) "reproducción" else "reproducciones"}",
                maxLines = 1, overflow = TextOverflow.Ellipsis, color = Gray, fontSize = 13.sp
            )
        }
    }
}
