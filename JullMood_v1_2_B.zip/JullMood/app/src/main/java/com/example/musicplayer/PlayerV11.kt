@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class, androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.example.musicplayer

import android.content.res.Configuration
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import kotlin.math.min
import kotlin.math.sin
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Curva "emphasized decelerate": entra rápido y se asienta suave. Se usa en casi todo el movimiento de v1.1. */
internal val JmEase = CubicBezierEasing(0.2f, 0f, 0f, 1f)

// ---------- Utilidades de movimiento (baratas: solo escalas/alphas en la capa gráfica) ----------

/** Pulsación con rebote ligero. No usa ripple ni recomposición: la escala se aplica en la capa gráfica. */
internal fun Modifier.jmPress(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val reduced = LocalUi.current.reducedMotion
    val depth = 1f - 0.1f * LocalJull.current.motion.amp      // Motion: Normal = 0.9 (v1.1)
    val s by animateFloatAsState(
        if (pressed && !reduced) depth else 1f,
        spring(dampingRatio = 0.55f, stiffness = 520f), label = "jmPress"
    )
    this
        .graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, enabled = enabled, role = Role.Button, onClick = onClick)
}

/** Entrada escalonada: desde transparente y ligeramente abajo hasta su sitio. */
private fun Modifier.staged(p: Animatable<Float, AnimationVector1D>, dy: Float = 28f): Modifier = graphicsLayer {
    val v = p.value
    alpha = v
    translationY = (1f - v) * dy.dp.toPx()
}

/** Icono Play/Pausa: los dos símbolos se cruzan con escala + fundido. */
@Composable
internal fun PlayPauseGlyph(playing: Boolean, size: Dp, tint: Color) {
    val reduced = LocalUi.current.reducedMotion
    val mo = LocalJull.current.motion
    val z = 1f - 0.5f * mo.amp.coerceAtMost(1.5f).coerceAtLeast(0.55f)   // escala inicial (Normal = 0.5)
    AnimatedContent(
        targetState = playing, label = "playPause",
        transitionSpec = {
            if (reduced) EnterTransition.None togetherWith ExitTransition.None
            else (fadeIn(tween(mo.ms(150), mo.ms(50))) + scaleIn(tween(mo.ms(200), easing = JmEase), initialScale = z)) togetherWith
                (fadeOut(tween(mo.ms(90))) + scaleOut(tween(mo.ms(120)), targetScale = z))
        }
    ) { p ->
        Icon(
            painterResource(if (p) R.drawable.ic_pause else R.drawable.ic_play),
            if (p) "Pausa" else "Reproducir", Modifier.size(size), tint = tint
        )
    }
}

/** Botón de favoritos con microanimación: rebote al añadir, pequeño "pulso" al quitar. */
@Composable
internal fun HeartButton(fav: Boolean, accent: Color, size: Dp = 28.dp, onClick: () -> Unit) {
    val reduced = LocalUi.current.reducedMotion
    val haptic = LocalHapticFeedback.current
    val scale = remember { Animatable(1f) }
    val amp = LocalJull.current.motion.amp
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(fav) {
        if (first) { first = false; return@LaunchedEffect }
        if (reduced) return@LaunchedEffect
        if (fav) {
            scale.snapTo(1f - 0.4f * amp)
            scale.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = 380f))
        } else {
            scale.animateTo(1f - 0.2f * amp, tween(80))
            scale.animateTo(1f, tween(140))
        }
    }
    val off = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
    val tint by animateColorAsState(if (fav) accent else off, tween(200), label = "heartTint")
    IconButton(onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onClick() }) {
        Icon(
            painterResource(if (fav) R.drawable.ic_heart else R.drawable.ic_heart_outline),
            if (fav) "Quitar de favoritos" else "Añadir a favoritos",
            Modifier.size(size).graphicsLayer { scaleX = scale.value; scaleY = scale.value },
            tint = tint
        )
    }
}

// ---------- Barra de progreso ----------

/**
 * Barra de progreso propia: avanza fotograma a fotograma leyendo la posición real del reproductor y SOLO se
 * redibuja (no recompone). Al arrastrar, la pista y el pulgar crecen y los tiempos siguen al dedo.
 */
@Composable
internal fun SeekBarV11(vm: PlayerViewModel, accent: Color, thin: Boolean = false) {
    val reduced = LocalUi.current.reducedMotion
    // Music Motion · Progress: halo que late y "cola" luminosa en el borde de avance. Solo dibujo (sin recomposición).
    val fx = LocalJull.current
    val progFx = fx.musicMotion == MusicMotionMode.PROGRESS && !reduced
    val fxK = fx.musicMotionLevel.k * fx.motion.amp
    val haptic = LocalHapticFeedback.current
    var drag by remember { mutableStateOf<Float?>(null) }
    val frac = remember { mutableFloatStateOf(0f) }
    var widthPx by remember { mutableIntStateOf(1) }

    LaunchedEffect(vm.isPlaying, reduced) {
        while (true) {
            if (drag == null) {
                val d = vm.duration
                frac.floatValue = if (d > 0) (vm.livePosition().toFloat() / d).coerceIn(0f, 1f) else 0f
            }
            if (vm.isPlaying && !reduced) withFrameNanos { } else delay(250)
        }
    }

    val active = drag != null
    val trackH by animateDpAsState(if (thin) (if (active) 7.dp else 3.dp) else (if (active) 10.dp else 5.dp), tween(150), label = "trackH")
    val thumbR by animateFloatAsState(if (thin) (if (active) 9f else 5f) else (if (active) 11f else 6.5f), spring(dampingRatio = 0.6f, stiffness = 500f), label = "thumbR")

    Box(
        Modifier.fillMaxWidth().height(36.dp)
            .onSizeChanged { widthPx = it.width.coerceAtLeast(1) }
            .pointerInput(vm.duration) {
                detectTapGestures { o ->
                    val d = vm.duration
                    if (d > 0) {
                        val f = (o.x / widthPx).coerceIn(0f, 1f)
                        frac.floatValue = f
                        vm.seekTo((f * d).toLong())
                    }
                }
            }
            .pointerInput(vm.duration) {
                detectHorizontalDragGestures(
                    onDragStart = { o ->
                        drag = (o.x / widthPx).coerceIn(0f, 1f)
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    },
                    onDragEnd = {
                        drag?.let { f -> frac.floatValue = f; vm.seekTo((f * vm.duration).toLong()) }
                        drag = null
                    },
                    onDragCancel = { drag = null },
                    onHorizontalDrag = { change, amount ->
                        change.consume()
                        drag = ((drag ?: frac.floatValue) + amount / widthPx).coerceIn(0f, 1f)
                    }
                )
            }
            .drawBehind {
                val f = drag ?: frac.floatValue
                val th = trackH.toPx()
                val cy = size.height / 2f
                val r = CornerRadius(th / 2f)
                drawRoundRect(accent.copy(alpha = 0.22f), Offset(0f, cy - th / 2f), Size(size.width, th), r)
                val w = (size.width * f).coerceAtLeast(th)
                drawRoundRect(accent, Offset(0f, cy - th / 2f), Size(w, th), r)
                val tr = thumbR.dp.toPx()
                val thumbC = Offset((size.width * f).coerceIn(tr, size.width - tr), cy)
                if (progFx && fxK > 0f) {
                    val playing = vm.isPlaying
                    val pulse = if (playing) 0.5f + 0.5f * sin(System.nanoTime() / 1e9f * 2.6f) else 0f
                    val fillW = size.width * f
                    val tail = min(fillW, size.width * 0.22f)
                    if (tail > 4f) drawRoundRect(
                        Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = (0.35f * fxK).coerceAtMost(0.7f))), startX = fillW - tail, endX = fillW),
                        Offset(fillW - tail, cy - th / 2f), Size(tail, th), r
                    )
                    drawCircle(accent.copy(alpha = ((0.10f + 0.16f * pulse) * fxK).coerceAtMost(0.5f)), tr * (1.9f + 0.5f * pulse * fxK), thumbC)
                }
                drawCircle(accent, tr, thumbC)
            }
    )

    val secs by remember { derivedStateOf { (((drag ?: frac.floatValue) * vm.duration) / 1000f).toLong() } }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(formatTime(secs * 1000), color = if (active) accent else Gray, fontSize = 12.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal)
        Text(formatTime(vm.duration), color = Gray, fontSize = 12.sp)
    }
}

// ---------- Controles ----------

/** Shuffle / repetir: activo = fondo de acento + punto indicador; apagado = gris. El estado se ve sin leer el icono. */
@Composable
private fun ToggleChip(res: Int, desc: String, active: Boolean, accent: Color, onClick: () -> Unit) {
    val off = Gray
    val bg by animateColorAsState(if (active) accent.copy(alpha = 0.2f) else Color.Transparent, tween(200), label = "chipBg")
    val tint by animateColorAsState(if (active) accent else off, tween(200), label = "chipTint")
    val dot by animateFloatAsState(if (active) 1f else 0f, tween(200), label = "chipDot")
    Box(Modifier.size(48.dp).clip(CircleShape).background(bg).jmPress(onClick = onClick), Alignment.Center) {
        Icon(painterResource(res), desc, Modifier.size(24.dp), tint = tint)
        Box(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp).size(4.dp)
                .graphicsLayer { alpha = dot; scaleX = dot; scaleY = dot }.clip(CircleShape).background(accent)
        )
    }
}

@Composable
private fun ControlsV11(vm: PlayerViewModel, accent: Color, ring: Boolean = false) {
    val haptic = LocalHapticFeedback.current
    val onAccent = MaterialTheme.colorScheme.onPrimary
    val onBg = MaterialTheme.colorScheme.onBackground
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        ToggleChip(R.drawable.ic_shuffle, if (vm.shuffle) "Aleatorio activado" else "Aleatorio desactivado", vm.shuffle, accent) { vm.toggleShuffle() }
        Box(Modifier.size(56.dp).jmPress { vm.previous() }, Alignment.Center) {
            Icon(painterResource(R.drawable.ic_prev), "Anterior", Modifier.size(38.dp), tint = onBg)
        }
        // Minimal: botón en anillo (sin relleno). Mismo gesto, mismo estado.
        val playFg = if (ring) accent else onAccent
        Box(
            Modifier.size(if (ring) 72.dp else 78.dp).clip(CircleShape)
                .then(if (ring) Modifier.border(2.dp, accent, CircleShape) else Modifier.background(accent))
                .jmPress { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); vm.togglePlay() },
            Alignment.Center
        ) {
            PlayPauseGlyph(vm.isPlaying, if (ring) 36.dp else 42.dp, playFg)
            if (vm.buffering) CircularProgressIndicator(Modifier.fillMaxSize().padding(4.dp), color = playFg.copy(alpha = 0.6f), strokeWidth = 2.dp)
        }
        Box(Modifier.size(56.dp).jmPress { vm.next() }, Alignment.Center) {
            Icon(painterResource(R.drawable.ic_next), "Siguiente", Modifier.size(38.dp), tint = onBg)
        }
        val rep = vm.repeatMode
        ToggleChip(
            if (rep == Player.REPEAT_MODE_ONE) R.drawable.ic_repeat_one else R.drawable.ic_repeat,
            when (rep) { Player.REPEAT_MODE_ONE -> "Repetir canción"; Player.REPEAT_MODE_ALL -> "Repetir cola"; else -> "Repetir desactivado" },
            rep != Player.REPEAT_MODE_OFF, accent
        ) { vm.cycleRepeat() }
    }
}

// ---------- Estados del reproductor ----------

/** Carga, error, archivo eliminado y fin de cola: una tarjeta integrada, no un mensaje suelto. */
@Composable
private fun StateBanner(vm: PlayerViewModel, accent: Color) {
    val kind = when {
        vm.playbackIssue == 1 -> 1
        vm.playbackIssue == 2 -> 2
        vm.ended -> 3
        else -> 0
    }
    val mo = LocalJull.current.motion
    val shown = remember { intArrayOf(0) }
    if (kind != 0) shown[0] = kind
    val cs = MaterialTheme.colorScheme
    AnimatedVisibility(
        visible = kind != 0,
        enter = fadeIn(tween(mo.ms(200))) + expandVertically(tween(mo.ms(260), easing = JmEase)),
        exit = fadeOut(tween(mo.ms(120))) + shrinkVertically(tween(mo.ms(200)))
    ) {
        val k = shown[0]
        val tone = if (k == 3) accent else cs.error
        Row(
            Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(uiShape(16.dp)).background(tone.copy(alpha = 0.14f)).padding(start = 14.dp, end = 4.dp, top = 2.dp, bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(painterResource(if (k == 3) R.drawable.ic_check else R.drawable.ic_info), null, Modifier.size(20.dp), tint = tone)
            Column(Modifier.weight(1f).padding(start = 10.dp, top = 8.dp, bottom = 8.dp)) {
                Text(
                    when (k) { 1 -> "Este archivo ya no está en tu dispositivo"; 2 -> "No se pudo reproducir esta canción"; else -> "Has llegado al final de la cola" },
                    fontSize = 14.sp, fontWeight = FontWeight.SemiBold
                )
                Text(
                    when (k) { 1 -> "Puede que se haya movido o eliminado."; 2 -> "El archivo puede estar dañado."; else -> "Pulsa repetir para volver a empezar." },
                    fontSize = 12.sp, color = Gray
                )
            }
            if (k == 2) TextButton(onClick = { vm.togglePlay() }) { Text("Reintentar", color = tone) }
            if (k != 3) TextButton(onClick = { vm.next() }) { Text("Siguiente", color = tone) }
            else TextButton(onClick = { vm.togglePlay() }) { Text("Repetir", color = tone) }
        }
    }
}

/** Texto pequeño de la cabecera: refleja el estado real (reproduciendo, pausa, cargando, error, fin). */
@Composable
private fun statusText(vm: PlayerViewModel): String = when {
    vm.playbackIssue != 0 -> "No se pudo reproducir"
    vm.ended -> "Fin de la cola"
    vm.buffering -> "Cargando…"
    vm.isPlaying -> "Reproduciendo"
    else -> "En pausa"
}

// ---------- Reproductor completo ----------

/** Sobre una imagen (portada a pantalla completa) los textos e iconos son claros para garantizar contraste. */
@Composable
private fun OnMediaTheme(content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    MaterialTheme(
        colorScheme = cs.copy(onBackground = Color.White, onSurface = Color.White, onSurfaceVariant = Color.White.copy(alpha = 0.78f)),
        shapes = MaterialTheme.shapes, typography = MaterialTheme.typography
    ) { CompositionLocalProvider(LocalContentColor provides Color.White, content = content) }
}

/** Cabecera común a todos los estilos: cerrar, estado real y "añadir a lista". */
@Composable
private fun PlayerTopBar(vm: PlayerViewModel, song: Song, onClose: () -> Unit, onAdd: (Song) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        IconBtn(R.drawable.ic_down, "Cerrar", onClick = onClose)
        Crossfade(targetState = statusText(vm), label = "status", animationSpec = tween(180), modifier = Modifier.weight(1f)) { t ->
            Text(t, color = Gray, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        }
        IconBtn(R.drawable.ic_queue, "Añadir a lista", Gray) { onAdd(song) }
    }
}

@Composable
internal fun NowPlayingV11(
    vm: PlayerViewModel, song: Song, onClose: () -> Unit, onQueue: () -> Unit, onSleep: () -> Unit, onAdd: (Song) -> Unit
) {
    val fx = LocalJull.current
    val mo = fx.motion
    val accent = MaterialTheme.colorScheme.primary
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    // Los estilos nuevos son verticales; en horizontal se usa la distribución de siempre (Classic).
    val style = if (landscape) PlayerStyle.CLASSIC else fx.playerStyle
    val reduced = LocalUi.current.reducedMotion
    val pager = rememberPagerState(pageCount = { 2 })
    val scope = rememberCoroutineScope()
    val goTo: (Int) -> Unit = { p -> scope.launch { if (reduced) pager.scrollToPage(p) else pager.animateScrollToPage(p) } }
    BackHandler { if (pager.currentPage == 1) goTo(0) else onClose() }

    // Entrada coordinada (portada → información → controles): sustituye al "salto" de pantalla.
    val coverIn = remember { Animatable(if (reduced) 1f else 0f) }
    val infoIn = remember { Animatable(if (reduced) 1f else 0f) }
    val ctrlIn = remember { Animatable(if (reduced) 1f else 0f) }
    LaunchedEffect(Unit) {
        if (!reduced) {
            launch { coverIn.animateTo(1f, tween(mo.ms(380), easing = JmEase)) }
            launch { infoIn.animateTo(1f, tween(mo.ms(360), delayMillis = mo.ms(70), easing = JmEase)) }
            launch { ctrlIn.animateTo(1f, tween(mo.ms(360), delayMillis = mo.ms(130), easing = JmEase)) }
        }
    }

    // Fondo: Classic = degradado de la v1.1. Con Ambient Background activo, éste lo sustituye (y se detiene en la página de letras).
    val classicGradient = !fx.ambientOn && style == PlayerStyle.CLASSIC
    Box(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .then(if (classicGradient) Modifier.background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.32f), Color.Transparent))) else Modifier)
    ) {
        val ambientPlaying = vm.isPlaying && pager.currentPage == 0
        if (style != PlayerStyle.IMMERSIVE) AmbientLayer(playing = ambientPlaying, focus = Offset(0.5f, 0.34f))
        VerticalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            if (page == 1) LyricsPage(vm, song, accent) { goTo(0) }
            else if (landscape) Column(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 8.dp)) {
                PlayerTopBar(vm, song, onClose, onAdd)
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(24.dp), verticalAlignment = Alignment.CenterVertically) {
                    BoxWithConstraints(Modifier.weight(1f).fillMaxHeight().padding(vertical = 8.dp), Alignment.Center) {
                        BigCover(vm, song, Modifier.size(minOf(maxWidth, maxHeight)), coverIn)
                    }
                    Column(Modifier.weight(1.2f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.Center) {
                        Column(Modifier.staged(infoIn)) { InfoV11(vm, song, accent); StateBanner(vm, accent) }
                        Column(Modifier.staged(ctrlIn)) {
                            SeekBarV11(vm, accent)
                            ControlsV11(vm, accent)
                            NpExtras(accent, onSleep, onQueue, { goTo(1) }, vm.lyrics)
                        }
                    }
                }
            } else when (style) {
                PlayerStyle.CLASSIC -> Column(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 8.dp)) {
                    PlayerTopBar(vm, song, onClose, onAdd)
                    BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().padding(vertical = 10.dp), Alignment.Center) {
                        BigCover(vm, song, Modifier.size(minOf(maxWidth, maxHeight)), coverIn)
                    }
                    Column(Modifier.staged(infoIn)) {
                        StateBanner(vm, accent)
                        InfoV11(vm, song, accent)
                    }
                    Column(Modifier.staged(ctrlIn)) {
                        SeekBarV11(vm, accent)
                        ControlsV11(vm, accent)
                        NpExtras(accent, onSleep, onQueue, { goTo(1) }, vm.lyrics)
                    }
                }

                // Minimal: mucho aire, portada más pequeña y discreta, controles en anillo, barra fina.
                PlayerStyle.MINIMAL -> Column(Modifier.fillMaxSize().padding(horizontal = 36.dp, vertical = 8.dp)) {
                    PlayerTopBar(vm, song, onClose, onAdd)
                    BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().padding(vertical = 18.dp), Alignment.Center) {
                        BigCover(vm, song, Modifier.size(minOf(maxWidth, maxHeight) * 0.82f), coverIn, radius = 18.dp)
                    }
                    Column(Modifier.staged(infoIn)) {
                        StateBanner(vm, accent)
                        InfoV11(vm, song, accent)
                    }
                    Column(Modifier.staged(ctrlIn)) {
                        SeekBarV11(vm, accent, thin = true)
                        ControlsV11(vm, accent, ring = true)
                        NpExtras(accent, onSleep, onQueue, { goTo(1) }, vm.lyrics)
                    }
                }

                // Cinematic: portada a sangre arriba que se funde con el fondo; información y controles debajo.
                PlayerStyle.CINEMATIC -> {
                    val bg = MaterialTheme.colorScheme.background
                    Column(Modifier.fillMaxSize()) {
                        Box(Modifier.fillMaxWidth().weight(1.1f)) {
                            BigCover(vm, song, Modifier.fillMaxSize(), coverIn, radius = 0.dp, flat = true)
                            Box(Modifier.fillMaxWidth().height(96.dp).align(Alignment.TopStart)
                                .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.55f), Color.Transparent))))
                            Box(Modifier.fillMaxWidth().fillMaxHeight(0.42f).align(Alignment.BottomStart)
                                .background(Brush.verticalGradient(listOf(Color.Transparent, bg))))
                            OnMediaTheme {
                                Box(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) { PlayerTopBar(vm, song, onClose, onAdd) }
                            }
                        }
                        Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 8.dp)) {
                            Column(Modifier.staged(infoIn)) {
                                StateBanner(vm, accent)
                                InfoV11(vm, song, accent)
                            }
                            Column(Modifier.staged(ctrlIn)) {
                                SeekBarV11(vm, accent)
                                ControlsV11(vm, accent)
                                NpExtras(accent, onSleep, onQueue, { goTo(1) }, vm.lyrics)
                            }
                        }
                    }
                }

                // Immersive: la portada ocupa toda la pantalla y los controles flotan sobre un velo oscuro.
                PlayerStyle.IMMERSIVE -> Box(Modifier.fillMaxSize()) {
                    BigCover(vm, song, Modifier.fillMaxSize(), coverIn, radius = 0.dp, flat = true)
                    AmbientLayer(playing = ambientPlaying, focus = Offset(0.5f, 0.3f))
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
                        0f to Color.Black.copy(alpha = 0.50f), 0.30f to Color.Black.copy(alpha = 0.12f),
                        0.58f to Color.Black.copy(alpha = 0.62f), 1f to Color.Black.copy(alpha = 0.92f))))
                    OnMediaTheme {
                        Column(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 8.dp)) {
                            PlayerTopBar(vm, song, onClose, onAdd)
                            Spacer(Modifier.weight(1f))
                            Column(Modifier.staged(infoIn)) {
                                StateBanner(vm, accent)
                                InfoV11(vm, song, accent)
                            }
                            Column(Modifier.staged(ctrlIn)) {
                                SeekBarV11(vm, accent)
                                ControlsV11(vm, accent)
                                NpExtras(accent, onSleep, onQueue, { goTo(1) }, vm.lyrics)
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Dirección del cambio de canción (1 = siguiente, -1 = anterior) para que la portada entre por el lado correcto. */
@Composable
private fun rememberDirection(vm: PlayerViewModel): Int {
    val idx = vm.currentIndex
    val prev = remember { intArrayOf(idx) }
    val dir = if (idx >= prev[0]) 1 else -1
    SideEffect { prev[0] = idx }
    return dir
}

/**
 * Portada protagonista: grande, esquinas amplias, "respira" (escala) con play/pausa y se desliza al cambiar de canción.
 * `flat` (Cinematic/Immersive): a sangre, sin escala ni esquinas. Music Motion · Cover: deriva/parallax muy sutil mientras suena.
 */
@Composable
private fun BigCover(
    vm: PlayerViewModel, song: Song, modifier: Modifier, appear: Animatable<Float, AnimationVector1D>,
    radius: Dp = 28.dp, flat: Boolean = false
) {
    val reduced = LocalUi.current.reducedMotion
    val fx = LocalJull.current
    val mo = fx.motion
    val playScale by animateFloatAsState(
        if (vm.isPlaying || reduced) 1f else 0.92f, spring(dampingRatio = 0.75f, stiffness = 260f), label = "coverBreath"
    )
    val dir = rememberDirection(vm)

    // Parallax: reloj a 30 fps que solo corre mientras suena, la app está visible y la portada está en pantalla.
    val coverFx = fx.musicMotion == MusicMotionMode.COVER && !reduced && !flat
    val running = coverFx && vm.isPlaying && rememberAppVisible()
    val clock = rememberFxClock(running, 30)
    val fade = animateFloatAsState(if (running) 1f else 0f, tween(500), label = "coverFx")   // vuelve suave a su sitio al parar
    val k = fx.musicMotionLevel.k * mo.amp
    Box(
        modifier.graphicsLayer {
            val a = appear.value
            val s = if (flat) 1f else playScale * (0.78f + 0.22f * a)
            scaleX = s; scaleY = s; alpha = a
            if (coverFx) {
                val t = clock.value; val f = fade.value * k
                translationX = drift(t, 9f) * 3.dp.toPx() * f
                translationY = drift(t, 11f, 1.3f) * 2.5.dp.toPx() * f
                rotationZ = drift(t, 13f, 2.4f) * 0.6f * f
            }
        }
    ) {
        AnimatedContent(
            targetState = song, contentKey = { it.id }, label = "cover", modifier = Modifier.fillMaxSize(),
            transitionSpec = {
                if (reduced) EnterTransition.None togetherWith ExitTransition.None
                else (fadeIn(tween(mo.ms(260), mo.ms(40))) + slideInHorizontally(tween(mo.ms(320), easing = JmEase)) { (dir * it * 0.125f * mo.amp).toInt() } +
                    scaleIn(tween(mo.ms(320), easing = JmEase), initialScale = 1f - 0.06f * mo.amp)) togetherWith
                    (fadeOut(tween(mo.ms(160))) + scaleOut(tween(mo.ms(220)), targetScale = 1f - 0.06f * mo.amp))
            }
        ) { s -> Cover(s, Modifier.fillMaxSize(), px = 700, radius = radius) }
    }
}

/** Entrada escalonada de cada línea de texto + deriva mínima mientras suena (Music Motion · Info). */
private fun Modifier.infoFx(order: Int, key: Any, k: Float, clock: State<Float>, on: State<Float>): Modifier = composed {
    val st = remember(key) { Animatable(0f) }
    LaunchedEffect(key) { delay(order * 60L); st.animateTo(1f, tween(340, easing = JmEase)) }
    graphicsLayer {
        translationX = (1f - st.value) * 14.dp.toPx() * k + drift(clock.value, 7f + order, order * 1.3f) * 1.8.dp.toPx() * k * on.value
        alpha = 0.35f + 0.65f * st.value
    }
}

/** Jerarquía: título (grande) → artista (medio) → álbum (discreto). Cambian con fundido + desplazamiento corto. */
@Composable
private fun InfoV11(vm: PlayerViewModel, song: Song, accent: Color) {
    val reduced = LocalUi.current.reducedMotion
    val fx = LocalJull.current
    val mo = fx.motion
    val infoFx = fx.musicMotion == MusicMotionMode.INFO && !reduced
    val k = fx.musicMotionLevel.k * mo.amp
    val running = infoFx && vm.isPlaying && rememberAppVisible()
    val clock = rememberFxClock(running, 20)
    val on = animateFloatAsState(if (running) 1f else 0f, tween(500), label = "infoFx")
    fun line(i: Int, s: Song): Modifier = if (infoFx) Modifier.infoFx(i, s.id, k, clock, on) else Modifier
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        AnimatedContent(
            targetState = song, contentKey = { it.id }, label = "info", modifier = Modifier.weight(1f),
            transitionSpec = {
                if (reduced) EnterTransition.None togetherWith ExitTransition.None
                else (fadeIn(tween(mo.ms(240), mo.ms(60))) + slideInVertically(tween(mo.ms(280), easing = JmEase)) { (it * 0.2f * mo.amp).toInt() }) togetherWith fadeOut(tween(mo.ms(120)))
            }
        ) { s ->
            Column(Modifier.fillMaxWidth()) {
                Text(s.title, line(0, s), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                Text(s.artist, line(1, s), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.85f))
                Text(s.album, line(2, s), maxLines = 1, overflow = TextOverflow.Ellipsis, color = Gray, fontSize = 13.sp)
            }
        }
        HeartButton(song.id in vm.favorites, accent) { vm.toggleFavorite(song.id) }
    }
}

// ---------- Mini-reproductor ----------

/** Progreso suavizado: llega cada 500 ms; esta interpolación lineal lo convierte en movimiento continuo sin coste extra. */
@Composable
private fun rememberMiniProgress(vm: PlayerViewModel): Float {
    val reduced = LocalUi.current.reducedMotion
    val frac = if (vm.duration > 0) (vm.position.toFloat() / vm.duration).coerceIn(0f, 1f) else 0f
    val smooth by animateFloatAsState(frac, if (reduced) tween(0) else tween(520, easing = LinearEasing), label = "miniProgress")
    return smooth
}

/** Despliegue del reproductor: toque o deslizar hacia arriba (igual en todos los estilos). */
private fun Modifier.miniOpen(onOpen: () -> Unit): Modifier = composed {
    var acc by remember { mutableFloatStateOf(0f) }
    this
        .pointerInput(Unit) {
            detectVerticalDragGestures(
                onDragStart = { acc = 0f },
                onDragEnd = { if (acc < -40f) onOpen() },
                onVerticalDrag = { _, dy -> acc += dy }
            )
        }
        .clickable(onClickLabel = "Abrir reproductor", onClick = onOpen)
}

@Composable
private fun MiniCover(song: Song, size: Dp, radius: Dp) {
    val mo = LocalJull.current.motion
    AnimatedContent(
        targetState = song, contentKey = { it.id }, label = "miniCover",
        transitionSpec = { fadeIn(tween(mo.ms(220))) togetherWith fadeOut(tween(mo.ms(160))) }
    ) { s -> Cover(s, Modifier.size(size), radius = radius) }
}

@Composable
private fun MiniInfo(
    vm: PlayerViewModel, song: Song, modifier: Modifier, titleColor: Color = Color.Unspecified, subColor: Color = Gray,
    titleSp: Int = 15, subSp: Int = 13
) {
    val cs = MaterialTheme.colorScheme
    val reduced = LocalUi.current.reducedMotion
    val mo = LocalJull.current.motion
    val issue = vm.playbackIssue != 0
    AnimatedContent(
        targetState = song, contentKey = { it.id }, label = "miniInfo", modifier = modifier,
        transitionSpec = {
            if (reduced) EnterTransition.None togetherWith ExitTransition.None
            else (fadeIn(tween(mo.ms(200), mo.ms(40))) + slideInVertically(tween(mo.ms(240), easing = JmEase)) { (it * 0.33f * mo.amp).toInt() }) togetherWith fadeOut(tween(mo.ms(100)))
        }
    ) { s ->
        Column(Modifier.fillMaxWidth()) {
            Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = titleSp.sp, color = titleColor)
            Text(
                if (issue) "No se pudo reproducir" else if (vm.buffering) "Cargando…" else s.artist,
                maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = subSp.sp,
                color = if (issue) cs.error else subColor
            )
        }
    }
}

@Composable
private fun MiniPlayBtn(vm: PlayerViewModel, size: Dp, glyph: Dp) {
    val cs = MaterialTheme.colorScheme
    Box(Modifier.size(size).clip(CircleShape).background(cs.primary).jmPress { vm.togglePlay() }, Alignment.Center) {
        PlayPauseGlyph(vm.isPlaying, glyph, cs.onPrimary)
    }
}

@Composable
private fun MiniNextBtn(vm: PlayerViewModel, tint: Color) {
    Box(Modifier.size(44.dp).jmPress { vm.next() }, Alignment.Center) {
        Icon(painterResource(R.drawable.ic_next), "Siguiente", Modifier.size(26.dp), tint = tint)
    }
}

/** El estilo se elige en Ajustes → JullExperience. Todos usan los mismos controles, estado y gestos. */
@Composable
internal fun MiniBarV11(vm: PlayerViewModel, song: Song, onOpen: () -> Unit) {
    when (LocalJull.current.miniStyle) {
        MiniStyle.CLASSIC -> MiniClassic(vm, song, onOpen)
        MiniStyle.COMPACT -> MiniCompact(vm, song, onOpen)
        MiniStyle.FLOATING -> MiniFloating(vm, song, onOpen)
        MiniStyle.GLOW -> MiniGlow(vm, song, onOpen)
    }
}

/** Compact: barra baja a todo el ancho, sin tarjeta; progreso como línea fina en el borde superior. */
@Composable
private fun MiniCompact(vm: PlayerViewModel, song: Song, onOpen: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val primary = cs.primary
    val smooth = rememberMiniProgress(vm)
    Column(Modifier.fillMaxWidth().background(cs.surface).miniOpen(onOpen)) {
        Box(Modifier.fillMaxWidth().height(2.dp).drawBehind {
            drawRect(primary.copy(alpha = 0.22f)); drawRect(primary, size = Size(size.width * smooth, size.height))
        })
        Row(Modifier.padding(horizontal = 12.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            MiniCover(song, 38.dp, 8.dp)
            MiniInfo(vm, song, Modifier.weight(1f).padding(horizontal = 12.dp), titleSp = 14, subSp = 12)
            MiniPlayBtn(vm, 36.dp, 20.dp)
        }
    }
}

/** Floating: tarjeta flotante con sombra, portada redonda y el progreso como anillo alrededor de play. */
@Composable
private fun MiniFloating(vm: PlayerViewModel, song: Song, onOpen: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val primary = cs.primary
    val smooth = rememberMiniProgress(vm)
    val shape = uiShape(30.dp)
    val on = cs.onPrimaryContainer
    Box(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp)) {
        Row(
            Modifier.fillMaxWidth().shadow(8.dp, shape).clip(shape).background(cs.primaryContainer).miniOpen(onOpen)
                .padding(start = 10.dp, top = 8.dp, bottom = 8.dp, end = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MiniCover(song, 46.dp, 50.dp)
            MiniInfo(vm, song, Modifier.weight(1f).padding(horizontal = 12.dp), titleColor = on, subColor = on.copy(alpha = 0.75f))
            Box(
                Modifier.size(50.dp).drawBehind {
                    val st = 3.dp.toPx(); val inset = st / 2f
                    val arc = Size(size.width - st, size.height - st)
                    drawArc(primary.copy(alpha = 0.25f), 0f, 360f, false, Offset(inset, inset), arc, style = Stroke(st))
                    drawArc(primary, -90f, 360f * smooth, false, Offset(inset, inset), arc, style = Stroke(st))
                },
                Alignment.Center
            ) { MiniPlayBtn(vm, 40.dp, 22.dp) }
        }
    }
}

/** Glow: tarjeta con degradado del acento (paleta dinámica si está activa), borde luminoso y halo tras la portada. */
@Composable
private fun MiniGlow(vm: PlayerViewModel, song: Song, onOpen: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val primary = cs.primary
    val smooth = rememberMiniProgress(vm)
    val shape = uiShape(22.dp)
    Box(Modifier.fillMaxWidth().background(cs.surface).padding(horizontal = 8.dp, vertical = 6.dp)) {
        Column(
            Modifier.fillMaxWidth().clip(shape).background(cs.surfaceVariant)
                .drawBehind { drawRect(Brush.horizontalGradient(listOf(primary.copy(alpha = 0.34f), Color.Transparent))) }
                .border(1.dp, primary.copy(alpha = 0.45f), shape)
                .miniOpen(onOpen)
        ) {
            Row(Modifier.padding(start = 8.dp, top = 8.dp, bottom = 6.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.drawBehind {
                    drawCircle(Brush.radialGradient(listOf(primary.copy(alpha = 0.45f), Color.Transparent), radius = size.maxDimension * 0.95f), size.maxDimension * 0.95f)
                }) { MiniCover(song, 48.dp, 12.dp) }
                MiniInfo(vm, song, Modifier.weight(1f).padding(start = 12.dp))
                MiniPlayBtn(vm, 42.dp, 24.dp)
                MiniNextBtn(vm, cs.onSurfaceVariant)
            }
            Box(Modifier.fillMaxWidth().height(3.dp).drawBehind {
                drawRect(primary.copy(alpha = 0.22f)); drawRect(primary, size = Size(size.width * smooth, size.height))
            })
        }
    }
}

/** Classic = mini-reproductor de la v1.1 (sin cambios de diseño). */
@Composable
private fun MiniClassic(vm: PlayerViewModel, song: Song, onOpen: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val primary = cs.primary
    val smooth = rememberMiniProgress(vm)
    var acc by remember { mutableFloatStateOf(0f) }

    Box(Modifier.fillMaxWidth().background(cs.surface).padding(horizontal = 8.dp, vertical = 6.dp)) {
        Column(
            Modifier.fillMaxWidth().clip(uiShape(22.dp)).background(cs.surfaceVariant)
                .pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onDragStart = { acc = 0f },
                        onDragEnd = { if (acc < -40f) onOpen() },
                        onVerticalDrag = { _, dy -> acc += dy }
                    )
                }
                .clickable(onClickLabel = "Abrir reproductor", onClick = onOpen)
        ) {
            Row(Modifier.padding(start = 8.dp, top = 8.dp, bottom = 6.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                MiniCover(song, 48.dp, 12.dp)
                MiniInfo(vm, song, Modifier.weight(1f).padding(start = 12.dp))
                MiniPlayBtn(vm, 42.dp, 24.dp)
                MiniNextBtn(vm, cs.onSurfaceVariant)
            }
            Box(
                Modifier.fillMaxWidth().height(3.dp).drawBehind {
                    drawRect(primary.copy(alpha = 0.22f))
                    drawRect(primary, size = Size(size.width * smooth, size.height))
                }
            )
        }
    }
}
