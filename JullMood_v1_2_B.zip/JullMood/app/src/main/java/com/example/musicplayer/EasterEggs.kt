package com.example.musicplayer

import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.DateFormat
import java.util.Calendar
import java.util.Date
import java.util.Random

/*
 * Easter Eggs de Juli (100 % local). Cada uno se evalúa SOLO cuando ocurre un evento relevante (elegir una canción,
 * contar una reproducción, saltarla, pedir Sorpréndeme, terminar de escanear la biblioteca): no hay análisis continuo,
 * ni servicios, ni hilos. Todo parte de lo que JullMood ya sabe (SongStat, favoritos, hora) más unos pocos contadores
 * pequeños que se guardan en las mismas SharedPreferences ("eggs" y "eggsLib"). Sin XP, puntos ni cuentas.
 */

enum class Rarity(val label: String, val icon: String) {
    COMMON("Común", "⚪"), UNCOMMON("Poco común", "🟢"), RARE("Raro", "🔵"), EASTER_EGG("Easter Egg", "🟣"), SECRET("Secreto", "🟡")
}

internal class EggDef(val id: String, val name: String, val rarity: Rarity, val desc: String, val hint: String)

internal object Eggs {
    const val REPEAT = "repeat"; const val NIGHT = "night"; const val NEVER = "never"; const val MARATHON = "marathon"
    const val ALBUM = "album"; const val SURPRISE = "surprise"; const val FAV = "fav"; const val RETURNED = "returned"
    const val DOMINANT = "dominant"; const val SINGLE = "single"; const val ABSURD = "absurd"; const val REVIVED = "revived"

    val all = listOf(
        EggDef(ALBUM, "Álbum de principio a fin", Rarity.COMMON, "Escuchaste un álbum completo sin saltar ninguna canción.",
            "Algunas historias se disfrutan mejor completas…"),
        EggDef(REPEAT, "Bucle infinito", Rarity.UNCOMMON, "La misma canción, una vez tras otra.",
            "Parece que te gusta demasiado una canción…"),
        EggDef(MARATHON, "Maratón de artista", Rarity.UNCOMMON, "Un mismo artista, canción tras canción.",
            "Cuando alguien te cae bien, no quieres que se vaya…"),
        EggDef(NEVER, "Final pendiente", Rarity.UNCOMMON, "Empezaste una canción una y otra vez, pero nunca la dejaste terminar.",
            "Hay canciones que empiezas… y no te atreves a terminar."),
        EggDef(SINGLE, "Cameo", Rarity.UNCOMMON, "Una canción que sonó una sola vez y estuvo mucho tiempo olvidada.",
            "Algunas canciones pasan por tu vida demasiado rápido…"),
        EggDef(NIGHT, "Insomnio musical", Rarity.RARE, "Tu música también trasnocha de madrugada.",
            "Hay horas en las que casi nadie debería estar escuchando música…"),
        EggDef(SURPRISE, "Mala racha", Rarity.RARE, "Varias sorpresas fallidas seguidas… hasta que una por fin funcionó.",
            "No todas las sorpresas salen bien, pero hay que insistir."),
        EggDef(FAV, "Favorita gastada", Rarity.RARE, "Una favorita con una cantidad exagerada de reproducciones.",
            "Hay favoritas que ya deberían pedir vacaciones…"),
        EggDef(DOMINANT, "Artista dominante", Rarity.RARE, "Un solo artista se adueñó de tu escucha reciente.",
            "Alguien está acaparando tu música últimamente…"),
        EggDef(RETURNED, "Regreso inesperado", Rarity.EASTER_EGG, "Una canción desapareció de tu biblioteca y volvió.",
            "Lo que desaparece, a veces vuelve…"),
        EggDef(REVIVED, "Del olvido", Rarity.RARE, "Una canción olvidada durante meses volvió a sonar.",
            "Hay canciones que esperan, pacientes, a que vuelvas…"),
        EggDef(ABSURD, "Respuesta absurda", Rarity.SECRET, "Juli, sin nada que decir.",
            "Este no te lo voy a poner fácil.")
    )
    private val byId = all.associateBy { it.id }
    fun get(id: String): EggDef = byId.getValue(id)
}

/** Reacciones de Juli por Easter Egg y personalidad. Formato: clave|N, G o R|frase. */
internal object EggLines {
    private const val SRC = """
repeat|N|Esa canción ya es parte de la casa.
repeat|N|Récord personal de repeticiones. Impresionante.
repeat|G|Bro, ¿vas a casarte con la canción o qué?
repeat|G|Esto ya no es gusto, es una condena.
repeat|R|Hay canciones a las que uno vuelve como a casa.
repeat|R|A veces una canción es justo lo que necesitas… otra vez.
night|N|Son horas raras para escuchar música. Aquí estoy.
night|N|La madrugada tiene su propia banda sonora.
night|G|¿Qué haces despierto a esta hora, cabrón?
night|G|Las tres de la mañana y tú con música. Obvio.
night|R|La madrugada suena distinta, ¿verdad?
night|R|Desvelos con música: me gusta acompañarte.
night2|N|Otra noche en vela. Ya empieza a ser costumbre.
night2|G|Otra vez de madrugada. Ya ni te pregunto.
night2|R|Otra noche en vela, otra canción… ya es una pequeña tradición.
never|N|Siempre la dejas a medias. Yo sigo esperando el final.
never|N|Esta canción todavía no ha llegado a su final.
never|G|La empiezas, la abandonas… ¿qué te hizo la canción?
never|G|Cuarta vez que la matas antes del coro. Qué crueldad.
never|R|Esta canción todavía espera su final.
never|R|Quizá algún día la termines. Yo espero.
marathon|N|Un artista, canción tras canción. Esto ya es un maratón.
marathon|N|Hoy solo existe este artista, por lo visto.
marathon|G|¿Tienes contrato con este artista? Esto ya es maratón.
marathon|G|El resto de artistas te manda saludos.
marathon|R|Cuando algo te gusta, no quieres que termine. Lo entiendo.
marathon|R|Qué bonito quedarse con una sola voz toda la tarde.
album|N|Álbum completo, de principio a fin. Eso sí es escuchar.
album|N|Sin saltos y hasta el final. Bien hecho.
album|G|¿Un álbum entero sin saltar? ¿Quién eres tú?
album|G|Esto merece una medalla imaginaria. 🏅
album|R|Un álbum entero, sin saltos. Qué bonito recorrido.
album|R|Cada canción encontró su momento.
surprise|N|Por fin una recomendación que sí funcionó.
surprise|N|Tercera vez es la vencida.
surprise|G|Por fin acerté, cabrón. Después de tantos fracasos.
surprise|G|Cuenta como victoria, no lo discutas.
surprise|R|A veces la sorpresa tarda en llegar. Esta sí llegó.
surprise|R|Me alegra que esta te haya gustado.
fav|N|Esa favorita ya tiene más repeticiones que nadie.
fav|N|Tu favorita merece un homenaje.
fav|G|Esa favorita ya pidió vacaciones y no se las das.
fav|G|La tienes más gastada que un disco de vinilo.
fav|R|Hay favoritas que se quedan a vivir contigo.
fav|R|Algunas canciones se vuelven casa.
returned|N|Mira quién volvió a la biblioteca.
returned|N|Esa canción se había ido… y regresó.
returned|G|Se fue, volvió y ni avisó. Qué drama.
returned|G|La canción regresó. Yo no dije nada, pero la extrañé.
returned|R|Algunas canciones se pierden… y regresan.
returned|R|Qué bonito reencuentro con una canción perdida.
dominant|N|Hay un artista que domina tu música últimamente.
dominant|N|Tu escucha reciente tiene un claro protagonista.
dominant|G|Este artista ya es dueño de tu biblioteca.
dominant|G|Ya podrías pagarle alquiler a este artista.
dominant|R|Últimamente suena una sola voz. Me gusta cómo se siente.
dominant|R|Qué bonito dejarse acompañar siempre por la misma voz.
single|N|Esta canción sonó una vez y se perdió. Ya volvió.
single|N|Un cameo que regresa después de mucho tiempo.
single|G|La escuchaste una vez y la abandonaste. Qué cruel.
single|G|Mira, la del cameo. Sobrevivió.
single|R|Una canción que pasó una sola vez… y aquí está otra vez.
single|R|Quizá esta vez se quede más tiempo.
revived|N|Esa llevaba meses sin sonar. Qué bueno que volvió.
revived|N|Rescatada del olvido. Bien hecho.
revived|G|¿Ahora sí te acuerdas de esta? Meses, cabrón.
revived|G|La sacaste del baúl. Ya era hora.
revived|R|Hay canciones que esperan pacientes a que vuelvas. ❤️
revived|R|Qué bonito reencuentro con algo que habías olvidado.
ecoalbum|N|Álbum completado. Lo escuchaste entero.
ecoalbum|N|Todas las pistas, sin dejar ninguna. Eso es escuchar.
ecoalbum|N|Otro álbum que ya conoces de principio a fin.
ecoalbum|G|Ya te sabes el álbum entero, cabrón. Respeto.
ecoalbum|G|Hasta la última pista. No me lo esperaba.
ecoalbum|G|Álbum completo. Ahora presume.
ecoalbum|R|No saltaste ninguna. Estoy orgullosa de ti. ❤️
ecoalbum|R|Lo escuchaste entero… me encanta cómo escuchas música.
ecoalbum|R|Cada canción tuvo su momento contigo. ❤️
ecoach|N|Logro desbloqueado. Y sin esforzarte.
ecoach|N|Escuchar música también cuenta como progreso.
ecoach|N|Pequeño logro, buen rumbo.
ecoach|G|Otro logro. No te lo creas tanto.
ecoach|G|Mira tú, escuchar música da medallas.
ecoach|G|Logro desbloqueado. Qué talento el tuyo, ni que fuera difícil.
ecoach|R|Me encanta verte avanzar así. ❤️
ecoach|R|Un logro más, y yo aquí para verlo.
ecoach|R|Cada logro cuenta una parte de tu historia musical. ❤️
ecorescue|N|Esa llevaba tiempo sin sonar. Qué bueno que volvió.
ecorescue|N|Rescatada del olvido.
ecorescue|N|Volviste a ella después de mucho tiempo.
ecorescue|G|¿Ahora sí te acuerdas de esta? Qué tal.
ecorescue|G|La sacaste del olvido. Ya era hora.
ecorescue|G|Meses sin tocarla y ahora te pones nostálgico.
ecorescue|R|Hay canciones que esperan pacientes a que vuelvas. ❤️
ecorescue|R|Qué bonito reencuentro con algo que habías olvidado.
ecorescue|R|Algunas canciones nunca se van del todo. ❤️
absurd|N|Hola.
absurd|N|...
absurd|N|Ok.
absurd|N|No tengo nada que decir.
absurd|R|Hola.
absurd|R|...
absurd|R|Ok.
absurd|R|No tengo nada que decir.
"""
    private val map: Map<String, List<String>> by lazy {
        SRC.lines().map { it.trim() }.filter { it.isNotEmpty() }.groupBy({ it.substringBefore('|') + "|" + it.substringAfter('|').substringBefore('|') }) {
            it.substringAfter('|').substringAfter('|')
        }
    }

    fun pick(key: String, p: JuliPersona, rnd: Random): String {
        val tag = when (p) { JuliPersona.GROSERA -> "G"; JuliPersona.ROMANTICA -> "R"; else -> "N" }
        val own = if (key == Eggs.ABSURD && p == JuliPersona.GROSERA) PersonaBank.absurd(p) else map["$key|$tag"].orEmpty()
        val l = own.ifEmpty { map["$key|N"].orEmpty() }.ifEmpty { map["${Eggs.ABSURD}|N"].orEmpty() }
        return l[rnd.nextInt(l.size)]
    }
}

internal class EggHit(val def: EggDef, val isNew: Boolean, val line: String)

internal class EggEngine(
    private val prefs: SharedPreferences,
    private val persona: () -> JuliPersona,
    private val rnd: Random = Random()
) {
    /** id -> fecha de descubrimiento. Observable para la colección. */
    var found by mutableStateOf<Map<String, Long>>(emptyMap()); private set

    private val lastAt = HashMap<String, Long>()          // última reacción de cada Easter Egg (cooldown)
    private var globalAt = 0L                             // última reacción de cualquiera
    private var lastSong = 0L; private var sameStreak = 0
    private var lastArtist = ""; private var artistRun = 0
    private val recentArtists = ArrayDeque<String>()       // artistas de las últimas reproducciones contadas
    private val earlySkips = LinkedHashMap<Long, Int>()    // canción -> omisiones tempranas desde la última vez que se escuchó
    private var albumName = ""; private val albumIds = LinkedHashSet<Long>()
    private var nightKey = ""; private var nightCount = 0; private val nights = ArrayList<String>()
    private var pendingSurprise = 0L; private var surpriseFails = 0
    private var recovered = 0
    private var albumFlag = false
    private val known = LinkedHashSet<String>()            // canciones que se escucharon bastante (clave título|artista)
    private val missing = LinkedHashMap<String, Long>()    // ...y que dejaron de estar en la biblioteca

    val total: Int get() = Eggs.all.size
    val failedSurprises: Int get() = surpriseFails

    init { load() }

    companion object {
        private const val KEY = "eggs"; private const val KEY_LIB = "eggsLib"
        private const val DAY = 86_400_000L
        const val REPEAT_N = 6              // reproducciones contadas seguidas de la misma canción
        const val MARATHON_N = 8            // canciones contadas seguidas del mismo artista
        const val NEVER_SKIPS = 4           // omisiones tempranas de la misma canción sin llegar a escucharla
        const val FAV_PLAYS = 40            // reproducciones de una favorita
        const val DOMINANT_WINDOW = 40      // últimas reproducciones contadas...
        const val DOMINANT_SHARE = 0.7      // ...de las que un solo artista tiene al menos el 70 %
        const val NIGHT_N = 3               // reproducciones entre las 03:00 y las 04:59 en la misma noche
        const val ALBUM_MIN = 4             // un álbum de menos canciones no cuenta
        const val SINGLE_MS = 90 * DAY      // una sola escucha y 90 días sin volver
        const val SURPRISE_FAILS = 3        // sorpresas saltadas seguidas antes de acertar
        const val REACT_GAP = 7 * DAY       // ya descubierto: la reacción puede repetirse como mucho cada 7 días...
        const val REACT_P = 0.5             // ...y solo la mitad de las veces
        const val GLOBAL_GAP = 20 * 60_000L // entre reacciones de Easter Eggs ya descubiertos
        const val ABSURD_ONE_IN = 250       // el secreto: 1 de cada 250 selecciones...
        const val ABSURD_GAP = 10 * DAY     // ...con 10 días de descanso...
        const val ABSURD_MIN_PLAYS = 40     // ...y solo con un historial mínimo
        const val GONE_MIN = 60 * 60_000L   // una canción "desaparecida" debe llevar al menos 1 h fuera para contar como regreso
        private const val UNKNOWN_ARTIST = "Artista desconocido"
        private const val UNKNOWN_ALBUM = "Álbum desconocido"
    }

    fun artistStreakFor(song: Song): Int = if (song.artist != UNKNOWN_ARTIST && song.artist == lastArtist) artistRun else 0

    /** Veces que se acertó una Sorpréndeme tras fallar (se lee una sola vez, justo después de [onCounted]). */
    fun takeRecovered(): Int { val r = recovered; recovered = 0; return r }

    /** True si la última reproducción contada completó un álbum (se lee una sola vez). */
    fun takeAlbumDone(): Boolean { val r = albumFlag; albumFlag = false; return r }

    // ---------- Núcleo: marcar, guardar y devolver la reacción ----------

    private fun fire(id: String, now: Long, lineKey: String = id, certain: Boolean = false): EggHit? {
        val isNew = id !in found
        if (!isNew) {
            // Ya descubierto: nunca vuelve a ser "nuevo descubrimiento"; la reacción solo se repite rara vez.
            if (now - (lastAt[id] ?: 0L) < REACT_GAP || now - globalAt < GLOBAL_GAP) return null
            if (!certain && rnd.nextDouble() > REACT_P) return null
        }
        if (isNew) found = found + (id to now)
        lastAt[id] = now; globalAt = now
        return EggHit(Eggs.get(id), isNew, EggLines.pick(lineKey, persona(), rnd))
    }

    private fun chk(cond: Boolean, id: String, now: Long, lineKey: String = id): EggHit? = if (cond) fire(id, now, lineKey) else null

    // ---------- Eventos ----------

    /** El usuario elige una canción: Una sola escucha y el secreto absurdo. */
    fun onSelect(song: Song, stat: SongStat?, stats: Map<Long, SongStat>, now: Long): EggHit? {
        var hit: EggHit? = null
        if (stat != null && stat.plays == 1 && stat.last > 0L && now - stat.last >= SINGLE_MS) hit = fire(Eggs.SINGLE, now)
        if (hit == null && rnd.nextInt(ABSURD_ONE_IN) == 0 && now - (lastAt[Eggs.ABSURD] ?: 0L) >= ABSURD_GAP &&
            stats.values.sumOf { it.plays } >= ABSURD_MIN_PLAYS
        ) hit = fire(Eggs.ABSURD, now, certain = true)
        if (hit != null) save()
        return hit
    }

    /** Una canción cuenta como reproducida (≥30 s o la mitad). [stat] ya incluye esta reproducción. */
    fun onCounted(song: Song, stat: SongStat?, fav: Boolean, hour: Int, now: Long, albumSize: Int): EggHit? {
        val plays = stat?.plays ?: 0
        sameStreak = if (song.id == lastSong) sameStreak + 1 else 1
        lastSong = song.id
        val hasArtist = song.artist != UNKNOWN_ARTIST
        if (hasArtist && song.artist == lastArtist) artistRun++ else { lastArtist = if (hasArtist) song.artist else ""; artistRun = if (hasArtist) 1 else 0 }
        recentArtists.addLast(if (hasArtist) song.artist else "")
        while (recentArtists.size > DOMINANT_WINDOW) recentArtists.removeFirst()
        earlySkips.remove(song.id)

        // Álbum: canciones distintas del mismo álbum, seguidas y sin ninguna omisión.
        if (song.album != UNKNOWN_ALBUM && song.album == albumName) albumIds += song.id
        else { albumName = if (song.album != UNKNOWN_ALBUM) song.album else ""; albumIds.clear(); if (albumName.isNotEmpty()) albumIds += song.id }
        val albumDone = albumName.isNotEmpty() && albumSize >= ALBUM_MIN && albumIds.size >= albumSize

        // Madrugada: reproducciones entre las 03:00 y las 04:59, agrupadas por noche.
        var nightOk = false
        if (hour in 3..4) {
            val cal = Calendar.getInstance().also { it.timeInMillis = now }
            val k = "${cal.get(Calendar.YEAR)}-${cal.get(Calendar.DAY_OF_YEAR)}"
            if (k == nightKey) nightCount++ else { nightKey = k; nightCount = 1; nights += k; while (nights.size > 10) nights.removeAt(0) }
            nightOk = nightCount >= NIGHT_N || (nights.size >= 3 && nightCount >= 2)
        }

        // Sorpréndeme: se acertó (la canción propuesta se llegó a escuchar).
        var surpriseOk = false
        if (song.id == pendingSurprise) {
            recovered = surpriseFails
            surpriseOk = surpriseFails >= SURPRISE_FAILS
            pendingSurprise = 0L; surpriseFails = 0
        }

        val dominant = recentArtists.size >= DOMINANT_WINDOW &&
            recentArtists.filter { it.isNotEmpty() }.groupingBy { it }.eachCount().values.maxOrNull().let { (it ?: 0) >= DOMINANT_WINDOW * DOMINANT_SHARE }

        albumFlag = albumDone
        val hit = chk(albumDone, Eggs.ALBUM, now)
            ?: chk(surpriseOk, Eggs.SURPRISE, now)
            ?: chk(nightOk, Eggs.NIGHT, now, if (nights.size >= 3) "night2" else "night")
            ?: chk(sameStreak >= REPEAT_N, Eggs.REPEAT, now)
            ?: chk(artistRun >= MARATHON_N, Eggs.MARATHON, now)
            ?: chk(dominant, Eggs.DOMINANT, now)
            ?: chk(fav && plays >= FAV_PLAYS, Eggs.FAV, now)
        if (albumDone) albumIds.clear()
        if (dominant && hit?.def?.id == Eggs.DOMINANT) recentArtists.clear()
        save()
        return hit
    }

    /** Una canción se abandonó en los primeros segundos (misma regla que las omisiones del historial). */
    fun onSkip(songId: Long, now: Long): EggHit? {
        if (songId == pendingSurprise) { surpriseFails++; pendingSurprise = 0L }
        val n = (earlySkips[songId] ?: 0) + 1
        earlySkips[songId] = n
        while (earlySkips.size > 30) earlySkips.remove(earlySkips.keys.first())
        albumIds.clear(); albumName = ""
        var hit: EggHit? = null
        if (n >= NEVER_SKIPS) { earlySkips[songId] = 0; hit = fire(Eggs.NEVER, now) }
        save()
        return hit
    }

    /** Se pidió Sorpréndeme: si la anterior seguía sin escucharse, cuenta como fallo. */
    fun onSurprisePick(songId: Long) {
        if (pendingSurprise != 0L && pendingSurprise != songId) surpriseFails++
        pendingSurprise = songId
        save()
    }

    /** Secreto: una canción olvidada durante meses (ver [Eco.RESCUE_DAYS]) volvió a sonar. La condición la comprueba el ecosistema. */
    fun onRevived(now: Long): EggHit? {
        val hit = fire(Eggs.REVIVED, now)
        if (hit != null) save()
        return hit
    }

    /** Fin de un escaneo de la biblioteca: canciones muy escuchadas que desaparecieron y luego volvieron. */
    fun onLibrary(songs: List<Song>, stats: Map<Long, SongStat>, now: Long): EggHit? {
        if (songs.isEmpty()) return null
        val keys = HashSet<String>(songs.size * 2)
        for (s in songs) keys += StatsCalc.songKey(s)
        var hit: EggHit? = null
        val back = missing.filter { (k, t) -> k in keys && now - t >= GONE_MIN }.keys.toList()
        for (k in back) { missing.remove(k); if (hit == null) hit = fire(Eggs.RETURNED, now) }
        // Si desaparece más de la mitad de lo conocido es un cambio de carpeta o de permisos, no canciones borradas.
        val gone = known.filter { it !in keys && it !in missing }
        if (gone.isNotEmpty() && gone.size * 2 <= known.size) gone.forEach { missing[it] = now }
        songs.filter { (stats[it.id]?.plays ?: 0) >= 3 }.sortedByDescending { stats[it.id]?.plays ?: 0 }.take(150)
            .forEach { known += StatsCalc.songKey(it) }
        while (known.size > 250) known.remove(known.first())
        while (missing.size > 50) missing.remove(missing.keys.first())
        saveLib()
        if (hit != null) save()
        return hit
    }

    /** "Borrar historial": se reinician contadores y rachas; los Easter Eggs ya descubiertos se conservan. */
    fun clearProgress() {
        lastSong = 0L; sameStreak = 0; lastArtist = ""; artistRun = 0; recentArtists.clear(); earlySkips.clear(); albumFlag = false
        albumName = ""; albumIds.clear(); nightKey = ""; nightCount = 0; nights.clear()
        pendingSurprise = 0L; surpriseFails = 0; recovered = 0; known.clear(); missing.clear()
        save(); saveLib()
    }

    // ---------- Persistencia (SharedPreferences ya existentes) ----------

    private fun save() {
        try {
            val o = JSONObject()
            o.put("f", JSONObject().also { j -> found.forEach { (k, v) -> j.put(k, v) } })
            o.put("la", JSONObject().also { j -> lastAt.forEach { (k, v) -> j.put(k, v) } })
            o.put("g", globalAt).put("ls", lastSong).put("ss", sameStreak).put("a", lastArtist).put("ar", artistRun)
            o.put("ra", JSONArray(recentArtists.toList()))
            o.put("es", JSONObject().also { j -> earlySkips.forEach { (k, v) -> j.put(k.toString(), v) } })
            o.put("al", albumName).put("ai", JSONArray(albumIds.toList()))
            o.put("nk", nightKey).put("nc", nightCount).put("nn", JSONArray(nights))
            o.put("ps", pendingSurprise).put("sf", surpriseFails)
            prefs.edit().putString(KEY, o.toString()).apply()
        } catch (_: Exception) { }
    }

    private fun saveLib() {
        try {
            val o = JSONObject().put("kn", JSONArray(known.toList()))
            o.put("ms", JSONObject().also { j -> missing.forEach { (k, v) -> j.put(k, v) } })
            prefs.edit().putString(KEY_LIB, o.toString()).apply()
        } catch (_: Exception) { }
    }

    private fun load() {
        try {
            val s = prefs.getString(KEY, null)
            if (s != null) {
                val o = JSONObject(s)
                o.optJSONObject("f")?.let { j -> found = j.keys().asSequence().filter { k -> Eggs.all.any { it.id == k } }.associateWith { j.getLong(it) } }
                o.optJSONObject("la")?.let { j -> j.keys().forEach { lastAt[it] = j.getLong(it) } }
                globalAt = o.optLong("g", 0L); lastSong = o.optLong("ls", 0L); sameStreak = o.optInt("ss", 0)
                lastArtist = o.optString("a", ""); artistRun = o.optInt("ar", 0)
                o.optJSONArray("ra")?.let { a -> for (i in 0 until a.length()) recentArtists.addLast(a.getString(i)) }
                o.optJSONObject("es")?.let { j -> j.keys().forEach { earlySkips[it.toLong()] = j.getInt(it) } }
                albumName = o.optString("al", "")
                o.optJSONArray("ai")?.let { a -> for (i in 0 until a.length()) albumIds += a.getLong(i) }
                nightKey = o.optString("nk", ""); nightCount = o.optInt("nc", 0)
                o.optJSONArray("nn")?.let { a -> for (i in 0 until a.length()) nights += a.getString(i) }
                pendingSurprise = o.optLong("ps", 0L); surpriseFails = o.optInt("sf", 0)
            }
            val l = prefs.getString(KEY_LIB, null)
            if (l != null) {
                val o = JSONObject(l)
                o.optJSONArray("kn")?.let { a -> for (i in 0 until a.length()) known += a.getString(i) }
                o.optJSONObject("ms")?.let { j -> j.keys().forEach { missing[it] = j.getLong(it) } }
            }
        } catch (_: Exception) { }
    }
}

// ---------- Colección (Ajustes → Personalidad de Juli → Easter Eggs) ----------

@Composable
internal fun EasterEggScreen(vm: PlayerViewModel, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val found = vm.eggs.found
    val got = Eggs.all.filter { it.id in found }.sortedByDescending { found[it.id] ?: 0L }
    val locked = Eggs.all.filter { it.id !in found }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(R.drawable.ic_down, "Volver", rotate = true, onClick = onBack)
            Text("Easter Eggs", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Column(Modifier.fillMaxWidth().clip(uiShape(24.dp)).background(cs.primaryContainer).padding(20.dp)) {
                    Text("🥚 Easter Eggs de Juli", color = cs.onPrimaryContainer, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    Text("${got.size} / ${Eggs.all.size} descubiertos", color = cs.onPrimaryContainer, fontSize = 15.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
            if (got.isNotEmpty()) {
                item { Text("Descubiertos", color = cs.primary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp, top = 6.dp)) }
                items(got, key = { it.id }) { d ->
                    Column(Modifier.fillMaxWidth().clip(uiShape(20.dp)).background(cs.surface).padding(16.dp)) {
                        Text(d.name, fontWeight = FontWeight.Bold)
                        Text("${d.rarity.icon} ${d.rarity.label}", color = cs.primary, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                        Text(d.desc, color = cs.onSurfaceVariant, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                        val at = found[d.id] ?: 0L
                        Text(
                            if (at > 0L) "✓ Descubierto · ${DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(at))}" else "✓ Descubierto",
                            color = cs.primary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            }
            if (locked.isNotEmpty()) {
                item { Text("Bloqueados", color = cs.primary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp, top = 6.dp)) }
                items(locked, key = { it.id }) { d ->
                    Column(Modifier.fillMaxWidth().clip(uiShape(20.dp)).background(cs.surface).padding(16.dp)) {
                        Text("🔒 ???", fontWeight = FontWeight.Bold, color = cs.onSurfaceVariant)
                        // El rango se muestra salvo en los SECRET, que permanecen completamente ocultos.
                        if (d.rarity != Rarity.SECRET) Text("${d.rarity.icon} ${d.rarity.label}", color = cs.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                        Text(if (d.rarity == Rarity.SECRET) "“${d.hint}”" else "Pista: ${d.hint}", color = cs.onSurfaceVariant, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
        }
    }
}
