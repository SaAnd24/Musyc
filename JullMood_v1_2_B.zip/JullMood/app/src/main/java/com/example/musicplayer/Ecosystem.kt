package com.example.musicplayer

import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.util.TimeZone

/*
 * Ecosistema musical de JullMood (100 % local). NO crea una base de datos paralela: el progreso (canciones/álbumes/artistas
 * explorados, olvidadas, nivel, identidad) se DERIVA del historial existente (SongStat) bajo demanda. Lo único que se guarda
 * es lo que el historial no puede reconstruir: fechas de álbumes, logros, rachas, rescatadas y unos contadores.
 * Todo vive en una sola clave de las mismas SharedPreferences ("eco"). Sin servicios ni procesos en segundo plano:
 * se evalúa solo al contar una reproducción real y al abrir pantallas.
 */

/** Vista mínima de una canción para el ecosistema (sin dependencias de Android: se puede probar en JVM). */
internal class EcoTrack(val id: Long, val key: String, val artist: String, val album: String, val added: Long = 0L)

internal enum class AlbumState(val label: String) {
    NOT_STARTED("NO INICIADO"), IN_PROGRESS("EN PROGRESO"), ALMOST("CASI COMPLETO"), DONE("COMPLETADO")
}

/** Progreso de un álbum o artista: canciones DISTINTAS (título+artista) conocidas / disponibles. */
internal class GroupProg(val name: String, val total: Int, val heard: Int, val ids: List<Long>, val last: Long) {
    val pct: Int get() = if (total <= 0) 0 else heard * 100 / total
    val state: AlbumState get() = when {
        heard <= 0 -> AlbumState.NOT_STARTED
        heard >= total -> AlbumState.DONE
        pct >= 75 -> AlbumState.ALMOST
        else -> AlbumState.IN_PROGRESS
    }
}

internal enum class EcoLevel(val emoji: String, val label: String, val from: Int) {
    CURIOSO("🌱", "CURIOSO", 0), OYENTE("🎧", "OYENTE", 20), EXPLORADOR("🗺️", "EXPLORADOR", 50),
    COLECCIONISTA("💿", "COLECCIONISTA", 75), CONOCEDOR("👑", "CONOCEDOR", 90)
}

internal class EcoSnap(
    val total: Int, val heard: Int, val plays: Int, val maxPlays: Int,
    val albums: List<GroupProg>, val artists: List<GroupProg>,
    val neverIds: List<Long>, val forgottenIds: List<Long>, val staleCount: Int,
    val newUnheard: Int, val oldUnheard: Int
) {
    val pct: Double get() = if (total <= 0) 0.0 else heard * 100.0 / total
    val level: EcoLevel get() = Eco.levelOf(pct)
    val artistsHeard: Int get() = artists.count { it.heard > 0 }
    val albumsHeard: Int get() = albums.count { it.heard > 0 }
    val completedAlbums: Int get() = albums.count { it.total >= Eco.MIN_ALBUM && it.heard >= it.total }
    val openAlbums: List<GroupProg> get() = albums.filter { it.total >= Eco.MIN_ALBUM && it.heard < it.total }
    val lowArtists: List<GroupProg> get() = artists.filter { it.total >= Eco.MIN_ARTIST && it.heard >= 1 && it.pct < 50 }
}

internal object Eco {
    const val DAY = 86_400_000L
    /** Umbrales internos (configurables aquí): "olvidada" = escuchada alguna vez y sin sonar este tiempo; rescatada = volvió tras esto. */
    const val FORGOTTEN_DAYS = 90
    const val RESCUE_DAYS = 90
    const val STALE_DAYS = 180
    const val MIN_ALBUM = 3        // un álbum de menos canciones no cuenta para completar / logros
    const val MIN_ARTIST = 5       // un artista con menos canciones no se considera "poco explorado"
    const val MIN_LIB = 30         // por debajo no hay logros de % de biblioteca (se desbloquearían al instante)
    private const val UNKNOWN_ARTIST = "Artista desconocido"
    private const val UNKNOWN_ALBUM = "Álbum desconocido"

    fun levelOf(pct: Double): EcoLevel = EcoLevel.values().last { pct >= it.from }
    fun nextLevel(l: EcoLevel): EcoLevel? = EcoLevel.values().getOrNull(l.ordinal + 1)

    /** Todo sale de una pasada sobre biblioteca + historial. Una canción cuenta como descubierta solo si se reprodujo de verdad (plays > 0). */
    fun snapshot(tracks: List<EcoTrack>, stats: Map<Long, SongStat>, now: Long): EcoSnap {
        class K(val rep: EcoTrack) { var plays = 0; var last = 0L; var dup = ArrayList<Long>(1) }
        val byKey = LinkedHashMap<String, K>(tracks.size * 2)
        for (t in tracks) {
            val k = byKey.getOrPut(t.key) { K(t) }
            val st = stats[t.id] ?: continue
            if (st.plays > 0) { k.plays += st.plays; if (st.last > k.last) k.last = st.last }
        }
        class Acc { var total = 0; var heard = 0; var last = 0L; val ids = ArrayList<Long>() }
        val albums = HashMap<String, Acc>(); val artists = HashMap<String, Acc>()
        val never = ArrayList<Long>(); val forgotten = ArrayList<Pair<Long, Long>>()
        var heard = 0; var plays = 0; var maxPlays = 0; var stale = 0; var newU = 0; var oldU = 0
        for (k in byKey.values) {
            val r = k.rep; val h = k.plays > 0
            if (h) { heard++; plays += k.plays; if (k.plays > maxPlays) maxPlays = k.plays }
            fun add(m: HashMap<String, Acc>, n: String) {
                val a = m.getOrPut(n) { Acc() }
                a.total++; if (h) { a.heard++; if (k.last > a.last) a.last = k.last }; a.ids += r.id
            }
            if (r.album != UNKNOWN_ALBUM) add(albums, r.album)
            if (r.artist != UNKNOWN_ARTIST) add(artists, r.artist)
            if (!h) {
                never += r.id
                if (r.added > 0L) { val age = now - r.added; if (age <= 30 * DAY) newU++ else if (age >= 365 * DAY) oldU++ }
            } else {
                val gap = now - k.last
                if (gap >= FORGOTTEN_DAYS * DAY) forgotten += r.id to k.last
                if (gap >= STALE_DAYS * DAY) stale++
            }
        }
        fun groups(m: HashMap<String, Acc>) = m.map { (n, a) -> GroupProg(n, a.total, a.heard, a.ids, a.last) }
        return EcoSnap(
            byKey.size, heard, plays, maxPlays, groups(albums), groups(artists), never,
            forgotten.sortedBy { it.second }.map { it.first }, stale, newU, oldU
        )
    }

    /** Progreso de un conjunto de canciones (álbum o artista abierto): (clave, id) -> (escuchadas, total). */
    fun progressOf(items: List<Pair<String, Long>>, stats: Map<Long, SongStat>): Pair<Int, Int> {
        val heard = HashSet<String>(); val all = HashSet<String>()
        for ((k, id) in items) { all += k; if ((stats[id]?.plays ?: 0) > 0) heard += k }
        return heard.size to all.size
    }

    fun localDay(now: Long): Long = (now + TimeZone.getDefault().getOffset(now)) / DAY

    /** "7 meses", "12 días", "2 años" (español). */
    fun span(days: Long): String = when {
        days < 1 -> "menos de un día"
        days < 60 -> "$days ${if (days == 1L) "día" else "días"}"
        days < 365 -> "${days / 30} meses"
        else -> (days / 365).let { "$it ${if (it == 1L) "año" else "años"}" }
    }
}

// ---------- Logros de JullMood (visibles; distintos de los Secretos de Juli) ----------

internal class EcoMetrics(val snap: EcoSnap, val favMax: Int, val rescued: Int, val surpriseUsed: Int, val surpriseDone: Int, val bestStreak: Int)

internal class AchDef(val id: String, val cat: String, val emoji: String, val name: String, val desc: String, val target: Int, val value: (EcoMetrics) -> Int)

internal object Achievements {
    val cats = listOf("Escucha", "Álbumes", "Artistas", "Exploración", "Repetición", "Recuperación", "Sorpréndeme", "Rachas")

    val all: List<AchDef> = buildList {
        fun tiers(cat: String, id: String, emoji: String, ts: List<Int>, name: (Int) -> String, desc: (Int) -> String, v: (EcoMetrics) -> Int) {
            ts.forEach { add(AchDef("$id$it", cat, emoji, name(it), desc(it), it, v)) }
        }
        add(AchDef("first", "Escucha", "🎵", "Primera canción", "Escucha tu primera canción en JullMood.", 1) { it.snap.heard })
        tiers("Escucha", "heard", "🎧", listOf(10, 100, 500, 1000, 2500), { "$it canciones" }, { "Escucha $it canciones distintas." }) { it.snap.heard }
        tiers("Álbumes", "alb", "💿", listOf(1, 5, 10, 25, 50), { if (it == 1) "Primer álbum completo" else "$it álbumes completos" },
            { "Completa $it ${if (it == 1) "álbum" else "álbumes"} (todas sus canciones reproducidas)." }) { it.snap.completedAlbums }
        tiers("Artistas", "art", "🎤", listOf(10, 50, 100, 250), { "$it artistas" }, { "Escucha canciones de $it artistas distintos." }) { it.snap.artistsHeard }
        tiers("Exploración", "lib", "🗺️", listOf(10, 25, 50, 75, 90), { "$it % explorado" }, { "Explora el $it % de tu biblioteca (mín. ${Eco.MIN_LIB} canciones)." }) {
            if (it.snap.total >= Eco.MIN_LIB) it.snap.pct.toInt() else 0
        }
        tiers("Exploración", "albd", "🧭", listOf(10, 50), { "$it álbumes distintos" }, { "Escucha canciones de $it álbumes distintos." }) { it.snap.albumsHeard }
        tiers("Repetición", "rep", "🔁", listOf(10, 25, 50), { "Otra vez, $it" }, { "Reproduce la misma canción $it veces." }) { it.snap.maxPlays }
        tiers("Repetición", "fav", "❤️", listOf(25), { "Favorita de siempre" }, { "Escucha una favorita $it veces." }) { it.favMax }
        tiers("Recuperación", "res", "🕰️", listOf(1, 5, 15), { if (it == 1) "Primera rescatada" else "$it rescatadas" },
            { "Vuelve a escuchar $it ${if (it == 1) "canción" else "canciones"} tras más de ${Eco.RESCUE_DAYS} días." }) { it.rescued }
        tiers("Sorpréndeme", "sup", "🎲", listOf(1, 10, 50), { "Sorpréndeme ×$it" }, { "Usa Sorpréndeme $it ${if (it == 1) "vez" else "veces"}." }) { it.surpriseUsed }
        tiers("Sorpréndeme", "supd", "🎁", listOf(1, 10, 25), { "Buena recomendación ×$it" }, { "Escucha $it canciones recomendadas por Sorpréndeme." }) { it.surpriseDone }
        tiers("Rachas", "str", "🔥", listOf(3, 7, 30), { "$it días seguidos" }, { "Escucha música $it días seguidos." }) { it.bestStreak }
    }
}

// ---------- Estado persistente + eventos ----------

internal class EcoEvents(val albumDone: GroupProg?, val newAch: List<AchDef>, val rescuedDays: Int, val levelUp: EcoLevel?)

internal class StreakView(val current: Int, val best: Int, val startDay: Long, val endedLen: Int, val nights: Int)

internal class EcoEngine(private val prefs: SharedPreferences) {
    /** Cambia cada vez que cambia algo guardado; las pantallas lo usan como clave para recalcular. */
    var rev by mutableIntStateOf(0); private set
    var unlocked by mutableStateOf<Map<String, Long>>(emptyMap()); private set   // id -> fecha (-1 = anterior a esta función)

    /** Álbum -> [primera escucha, finalización (0 = no completo, -1 = fecha desconocida), canciones al completar]. */
    private val albums = HashMap<String, LongArray>()
    private val rescued = LinkedHashMap<String, LongArray>()   // clave canción -> [fecha, días de ausencia]
    private val firstKeys = ArrayList<String>()                // primeras canciones distintas escuchadas
    private var rescuedCount = 0; private var surpriseUsed = 0; private var surpriseDone = 0; private var pendingSurprise = 0L
    private var inited = false; private var levelOrd = 0
    private class Run { var cur = 0; var best = 0; var start = 0L; var last = 0L; var ended = 0 }
    private val day = Run(); private val night = Run()

    companion object { private const val KEY = "eco"; private const val MAX_RESCUED = 100; private const val FIRST_N = 20 }

    init { load() }

    val rescuedEntries: List<Triple<String, Long, Int>> get() = rescued.map { (k, v) -> Triple(k, v[0], v[1].toInt()) }.sortedByDescending { it.second }
    val firstSongKeys: List<String> get() = firstKeys
    val rescuedTotal: Int get() = rescuedCount
    fun albumInfo(name: String): LongArray? = albums[name]

    fun streak(now: Long): StreakView {
        val today = Eco.localDay(now)
        fun alive(r: Run) = r.cur > 0 && r.last >= today - 1
        return StreakView(
            if (alive(day)) day.cur else 0, day.best, day.start,
            if (alive(day)) 0 else if (day.cur > 0) day.cur else day.ended, if (alive(night)) night.cur else 0
        )
    }

    fun metrics(snap: EcoSnap, favMax: Int) = EcoMetrics(snap, favMax, rescuedCount, surpriseUsed, surpriseDone, day.best)

    private fun Run.touch(d: Long) {
        when {
            last == d -> return
            last == d - 1 && cur > 0 -> cur++
            else -> { if (cur > 0) ended = cur; cur = 1; start = d }
        }
        last = d; if (cur > best) best = cur
    }

    /**
     * Primera vez con historial previo: se registran en silencio los logros y álbumes que ya se cumplían
     * (sin animaciones ni toasts) para no inundar al usuario ni marcar fechas inventadas.
     */
    fun ensureInit(snap: EcoSnap, favMax: Int, now: Long) {
        if (inited || snap.total == 0) return
        inited = true
        for (g in snap.albums) if (g.total >= Eco.MIN_ALBUM && g.heard >= g.total) albums[g.name] = longArrayOf(0L, -1L, g.heard.toLong())
        val m = metrics(snap, favMax)
        unlocked = unlocked + Achievements.all.filter { it.id !in unlocked && it.value(m) >= it.target }.associate { it.id to -1L }
        levelOrd = snap.level.ordinal
        save()
    }

    fun onSurprise(firstId: Long) { surpriseUsed++; pendingSurprise = firstId; save() }

    /** Una canción cuenta como reproducida (≥30 s o la mitad). [snap] ya incluye esta reproducción; [prevLast] = último contacto anterior. */
    fun onCounted(t: EcoTrack, prevLast: Long, playsBefore: Int, now: Long, hour: Int, snap: EcoSnap, favMax: Int): EcoEvents {
        val d = Eco.localDay(now)
        day.touch(d)
        if (hour >= 21 || hour < 5) night.touch(if (hour < 5) d - 1 else d)

        // Rescatada: ya se había escuchado de verdad y estuvo realmente ausente al menos RESCUE_DAYS.
        var gap = 0
        if (playsBefore > 0 && prevLast > 0L && now - prevLast >= Eco.RESCUE_DAYS * Eco.DAY) {
            gap = ((now - prevLast) / Eco.DAY).toInt()
            rescued.remove(t.key); rescued[t.key] = longArrayOf(now, gap.toLong())
            while (rescued.size > MAX_RESCUED) rescued.remove(rescued.keys.first())
            rescuedCount++
        }
        if (playsBefore == 0 && firstKeys.size < FIRST_N && t.key !in firstKeys) firstKeys += t.key
        if (t.id == pendingSurprise) { surpriseDone++; pendingSurprise = 0L }

        // Álbum: solo se completa si TODAS sus canciones tienen una reproducción real, y solo la primera vez.
        var done: GroupProg? = null
        if (t.album != "Álbum desconocido") {
            val rec = albums.getOrPut(t.album) { longArrayOf(now, 0L, 0L) }
            val g = snap.albums.firstOrNull { it.name == t.album }
            if (g != null && g.total >= Eco.MIN_ALBUM && g.heard >= g.total && rec[1] == 0L) {
                rec[1] = now; rec[2] = g.heard.toLong(); done = g
            }
        }

        val m = metrics(snap, favMax)
        val fresh = Achievements.all.filter { it.id !in unlocked && it.value(m) >= it.target }
        if (fresh.isNotEmpty()) unlocked = unlocked + fresh.associate { it.id to now }

        val lvl = snap.level
        val up = if (lvl.ordinal > levelOrd) lvl else null
        levelOrd = lvl.ordinal
        save(); rev++
        return EcoEvents(done, fresh, gap, up)
    }

    /** "Borrar historial": se reinicia el progreso; los logros ya conseguidos se conservan (igual que los Easter Eggs). */
    fun clearProgress() {
        albums.clear(); rescued.clear(); firstKeys.clear()
        rescuedCount = 0; surpriseUsed = 0; surpriseDone = 0; pendingSurprise = 0L; levelOrd = 0
        day.cur = 0; day.best = 0; day.start = 0; day.last = 0; day.ended = 0
        night.cur = 0; night.best = 0; night.start = 0; night.last = 0; night.ended = 0
        save(); rev++
    }

    /** Quita de la lista de rescatadas las canciones que ya no existen (no se guarda nada de archivos borrados). */
    fun prune(existing: Set<String>) {
        if (rescued.keys.removeAll { it !in existing }) save()
    }

    // ---------- Persistencia ----------
    private fun save() {
        try {
            val o = JSONObject()
            o.put("i", inited).put("lv", levelOrd).put("rc", rescuedCount).put("su", surpriseUsed).put("sd", surpriseDone).put("ps", pendingSurprise)
            o.put("u", JSONObject().also { j -> unlocked.forEach { (k, v) -> j.put(k, v) } })
            o.put("al", JSONObject().also { j -> albums.forEach { (k, v) -> j.put(k, JSONArray(v.toList())) } })
            o.put("rs", JSONObject().also { j -> rescued.forEach { (k, v) -> j.put(k, JSONArray(v.toList())) } })
            o.put("fk", JSONArray(firstKeys))
            fun run(r: Run) = JSONArray(listOf(r.cur, r.best, r.start, r.last, r.ended))
            o.put("d", run(day)).put("n", run(night))
            prefs.edit().putString(KEY, o.toString()).apply()
        } catch (_: Exception) { }
    }

    private fun load() {
        try {
            val o = JSONObject(prefs.getString(KEY, null) ?: return)
            inited = o.optBoolean("i"); levelOrd = o.optInt("lv"); rescuedCount = o.optInt("rc")
            surpriseUsed = o.optInt("su"); surpriseDone = o.optInt("sd"); pendingSurprise = o.optLong("ps")
            o.optJSONObject("u")?.let { j -> unlocked = j.keys().asSequence().filter { k -> Achievements.all.any { it.id == k } }.associateWith { j.getLong(it) } }
            o.optJSONObject("al")?.let { j -> j.keys().forEach { k -> j.getJSONArray(k).let { a -> albums[k] = longArrayOf(a.getLong(0), a.getLong(1), a.getLong(2)) } } }
            o.optJSONObject("rs")?.let { j -> j.keys().forEach { k -> j.getJSONArray(k).let { a -> rescued[k] = longArrayOf(a.getLong(0), a.getLong(1)) } } }
            o.optJSONArray("fk")?.let { a -> for (i in 0 until a.length()) firstKeys += a.getString(i) }
            fun run(r: Run, a: JSONArray?) { if (a != null && a.length() >= 5) { r.cur = a.getInt(0); r.best = a.getInt(1); r.start = a.getLong(2); r.last = a.getLong(3); r.ended = a.getInt(4) } }
            run(day, o.optJSONArray("d")); run(night, o.optJSONArray("n"))
        } catch (_: Exception) { }
    }
}

/** Contextos de "Sorpréndeme" basados en la biblioteca (usan el historial local; sin recomendaciones pesadas). */
internal enum class EcoPick(val emoji: String, val label: String, val hint: String) {
    NEVER("🧭", "Explorar algo que todavía no conoces", "Una canción que nunca has reproducido"),
    FORGOTTEN("🕰️", "Rescatar algo del olvido", "Canciones que llevan meses sin sonar"),
    ALBUM("💿", "Continuar un álbum", "Retoma un álbum empezado por las pistas que faltan"),
    ARTIST("🎤", "Profundizar en un artista", "Un artista que apenas has explorado"),
    FAVORITE("❤️", "Una favorita", "Algo que ya sabes que te gusta"),
    NOW("🎲", "Lo que va con esta hora", "Según el momento del día")
}
