package com.example.musicplayer

import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/** Animaciones reducidas: el ajuste de JullMood o la escala de animaciones del sistema (Android) a 0. */
@Composable
internal fun rememberReducedMotion(): Boolean {
    val app = LocalUi.current.reducedMotion
    val ctx = LocalContext.current
    val system = remember {
        runCatching { Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f }.getOrDefault(false)
    }
    return app || system
}

private class WeeklyLoaded(val value: WeeklySummary?)

private const val LAST_STAGE = 6

@Composable
internal fun WeeklyIdentityScreen(vm: PlayerViewModel, onBack: () -> Unit) {
    val songs = vm.songs; val stats = vm.stats; val favs = vm.favorites; val auto = vm.autoMoods; val manual = vm.manualMoods
    // Se calcula una sola vez al abrir (fuera del hilo principal), con el mismo historial de siempre.
    val data by produceState<WeeklyLoaded?>(null) {
        value = withContext(Dispatchers.Default) {
            WeeklyLoaded(runCatching {
                WeeklyCalc.compute(songs, stats, favs, { s -> manual[s.id] ?: auto[s.id] ?: emptyList() }, System.currentTimeMillis())
            }.getOrNull())
        }
    }
    val cs = MaterialTheme.colorScheme
    val d = data
    LaunchedEffect(d) { d?.value?.let { vm.personality.markWeeklySeen(it) } }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(cs.primary.copy(alpha = 0.16f), Color.Transparent)))) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconBtn(R.drawable.ic_down, "Volver", rotate = true, onClick = onBack)
            }
            when {
                d == null -> Empty("Preparando tu semana…")
                d.value == null -> Empty("Todavía no hay música suficiente esta semana para dibujar tu identidad. Sigue escuchando y vuelve pronto.")
                else -> WeeklyStory(vm, d.value, onBack)
            }
        }
    }
}

@Composable
private fun WeeklyStory(vm: PlayerViewModel, w: WeeklySummary, onClose: () -> Unit) {
    val reduced = rememberReducedMotion()
    // La identidad se construye por etapas. Con animaciones reducidas aparece completa desde el principio.
    var stage by rememberSaveable { mutableIntStateOf(0) }
    LaunchedEffect(reduced) {
        if (reduced) { stage = LAST_STAGE; return@LaunchedEffect }
        while (stage < LAST_STAGE) { delay(if (stage == 0) 1200L else 1400L); stage++ }
    }
    val scroll = rememberScrollState()
    LaunchedEffect(stage) {
        if (!reduced && stage in 1 until LAST_STAGE) { delay(450); scroll.animateScrollTo(scroll.maxValue) }
    }
    val cs = MaterialTheme.colorScheme

    Column(Modifier.fillMaxSize().verticalScroll(scroll).padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
        // 0 · Apertura
        Reveal(true, reduced) {
            Column(Modifier.padding(top = 8.dp, bottom = 20.dp)) {
                Text("TU SEMANA EN JULLMOOD", color = cs.primary, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("Tu identidad musical", fontSize = 32.sp, lineHeight = 38.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 6.dp))
            }
        }

        // 1 · Cómo sonó la semana (Mood)
        if (w.moods.isNotEmpty()) Reveal(stage >= 1, reduced) {
            Card {
                Text("Esta semana sonaste así", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Box(Modifier.fillMaxWidth().padding(vertical = 18.dp), Alignment.Center) {
                    MoodDonut(w.moods, reduced, Modifier.size(150.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CountUp(w.plays, reduced, 1400) { Text(it.toString(), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold) }
                        Text("reproducciones", color = Gray, fontSize = 12.sp)
                    }
                }
                w.moods.forEachIndexed { i, (m, pct) -> MoodBar(m, pct, i, reduced) }
            }
        }

        // 2 · Números y horario
        Reveal(stage >= 2, reduced) {
            Column(Modifier.padding(top = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    NumberCard("Canciones distintas", Modifier.weight(1f)) { CountUp(w.distinct, reduced, 1100) { Num(it.toString()) } }
                    NumberCard("Tiempo aprox.", Modifier.weight(1f)) {
                        CountUp((w.approxMs / 60_000L).toInt(), reduced, 1300) { Num(fmtMinutes(it)) }
                    }
                }
                val extra = listOfNotNull(
                    w.daypart?.let { "Sueles escuchar $it" },
                    if (w.favPlays > 0) "${w.favPlays} ${if (w.favPlays == 1) "reproducción fue" else "reproducciones fueron"} de tus favoritas" else null
                )
                if (extra.isNotEmpty()) Card { extra.forEach { Text(it, fontSize = 15.sp, modifier = Modifier.padding(vertical = 2.dp)) } }
            }
        }

        // 3 · Artista de la semana
        w.topArtist?.let { a ->
            Reveal(stage >= 3, reduced) {
                Box(Modifier.padding(top = 14.dp)) {
                    Feature("Tu artista de la semana", a.title, "${a.plays} reproducciones", circle = true) {
                        GroupCover(a.songs, Modifier.size(88.dp), px = 300, radius = 44.dp)
                    }
                }
            }
        }

        // 4 · Canción de la semana
        w.topSong?.let { s ->
            Reveal(stage >= 4, reduced) {
                Box(Modifier.padding(top = 14.dp)) {
                    Feature("Tu canción de la semana", s.title, "${s.subtitle} · ${s.plays} reproducciones", circle = false) {
                        GroupCover(s.songs, Modifier.size(88.dp), px = 300, radius = 18.dp)
                    }
                }
            }
        }

        // 5 · Álbum y género
        val chips = listOfNotNull(
            w.topAlbum?.let { "Álbum" to it.title },
            w.genre?.let { "Género" to it }
        )
        if (chips.isNotEmpty()) Reveal(stage >= 5, reduced) {
            Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                chips.forEach { (label, value) ->
                    NumberCard(label, Modifier.weight(1f)) { Text(value, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                }
            }
        }

        // 6 · Cierre
        Reveal(stage >= LAST_STAGE, reduced) {
            Column(Modifier.fillMaxWidth().padding(top = 32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Esta fue tu semana musical.", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                Row(Modifier.padding(top = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { vm.playSong(w.weekSongs.first(), w.weekSongs); onClose() }, shape = uiShape(16.dp)) {
                        Icon16(R.drawable.ic_play); Text("  Reproducir mi semana")
                    }
                    FilledTonalButton(onClick = onClose, shape = uiShape(16.dp)) { Text("Cerrar") }
                }
            }
        }
    }
}

// ---------- Piezas ----------

@Composable
private fun Icon16(res: Int) = androidx.compose.material3.Icon(painterResource(res), null, Modifier.size(20.dp))

@Composable
private fun Card(content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(uiShape(24.dp)).background(MaterialTheme.colorScheme.surface).padding(18.dp)) { content() }
}

@Composable
private fun NumberCard(label: String, modifier: Modifier, value: @Composable () -> Unit) {
    Column(modifier.clip(uiShape(20.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp)) {
        value()
        Text(label, color = Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun Num(t: String) = Text(t, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary, maxLines = 1)

@Composable
private fun Feature(label: String, title: String, sub: String, circle: Boolean, cover: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(uiShape(if (circle) 28.dp else 24.dp)).background(MaterialTheme.colorScheme.surface).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        cover()
        Column(Modifier.weight(1f).padding(start = 16.dp)) {
            Text(label, color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
            Text(sub, color = Gray, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

/** Aparece con fundido + ligero desplazamiento y escala. Con animaciones reducidas, simplemente aparece. */
@Composable
private fun Reveal(visible: Boolean, reduced: Boolean, content: @Composable () -> Unit) {
    if (reduced) { if (visible) content(); return }
    // MutableTransitionState(false): incluso lo que está visible desde el inicio entra con animación.
    val state = remember { MutableTransitionState(false) }
    state.targetState = visible
    AnimatedVisibility(
        state,
        enter = fadeIn(tween(650)) + slideInVertically(tween(650)) { it / 6 } + scaleIn(tween(650), initialScale = 0.96f)
    ) { content() }
}

/** Número que cuenta hacia arriba una sola vez al aparecer. */
@Composable
private fun CountUp(target: Int, reduced: Boolean, ms: Int, content: @Composable (Int) -> Unit) {
    var shown by remember { mutableIntStateOf(if (reduced) target else 0) }
    LaunchedEffect(target, reduced) {
        if (reduced) { shown = target; return@LaunchedEffect }
        animate(0f, target.toFloat(), animationSpec = tween(ms, easing = FastOutSlowInEasing)) { v, _ -> shown = v.roundToInt() }
    }
    content(shown)
}

@Composable
private fun MoodBar(m: Mood, pct: Int, index: Int, reduced: Boolean) {
    var go by remember { mutableStateOf(reduced) }
    LaunchedEffect(Unit) { go = true }
    val f by animateFloatAsState(
        if (go) pct / 100f else 0f,
        if (reduced) tween<Float>(0) else tween<Float>(900, delayMillis = 250 + index * 140, easing = FastOutSlowInEasing), label = "moodbar"
    )
    Column(Modifier.padding(top = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${m.emoji}  ${m.label}", Modifier.weight(1f), fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${(f * 100).roundToInt()}%", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        Box(Modifier.padding(top = 6.dp).fillMaxWidth().height(8.dp).clip(uiShape(4.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
            Box(Modifier.fillMaxWidth(f.coerceIn(0f, 1f)).fillMaxHeight().clip(uiShape(4.dp)).background(m.color))
        }
    }
}

/** Anillo de Moods que se dibuja de 0 a 100 %. Un único Canvas; no hay nada animándose en segundo plano. */
@Composable
private fun MoodDonut(moods: List<Pair<Mood, Int>>, reduced: Boolean, modifier: Modifier) {
    var go by remember { mutableStateOf(reduced) }
    LaunchedEffect(Unit) { go = true }
    val p by animateFloatAsState(
        if (go) 1f else 0f, if (reduced) tween<Float>(0) else tween<Float>(1500, delayMillis = 200, easing = FastOutSlowInEasing), label = "donut"
    )
    val track = MaterialTheme.colorScheme.surfaceVariant
    Canvas(modifier) {
        val stroke = size.minDimension * 0.13f
        val tl = Offset(stroke / 2, stroke / 2)
        val sz = Size(size.width - stroke, size.height - stroke)
        drawArc(track, 0f, 360f, false, tl, sz, style = Stroke(stroke))
        var start = -90f
        val gap = if (moods.size > 1) 3f else 0f
        for ((m, pct) in moods) {
            val full = 360f * pct / 100f * p
            val sweep = (full - gap * p).coerceAtLeast(0f)
            if (sweep > 0f) drawArc(m.color, start, sweep, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Butt))
            start += full
        }
    }
}

private fun fmtMinutes(m: Int): String {
    val h = m / 60; val mm = m % 60
    return if (h > 0) "$h h $mm min" else "$mm min"
}
