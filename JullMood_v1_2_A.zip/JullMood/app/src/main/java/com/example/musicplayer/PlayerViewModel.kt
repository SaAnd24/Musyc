package com.example.musicplayer

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileNotFoundException
import java.util.Calendar
import kotlin.math.min

/** Tope de canciones que se consultan online por sesión (a 1 petición/s); el resto continúa en la siguiente. */
private const val MAX_ENRICH_PER_SESSION = 120
private const val MAX_FIX_PER_SESSION = 60   // consultas de corrección automática por sesión

class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("player", Context.MODE_PRIVATE)
    private var byId = emptyMap<Long, Song>()
        set(value) { field = value; SongArt.songs = value }      // el servicio lo usa para la portada de la notificación
    private var restored = false

    var favorites by mutableStateOf(readIds("fav")); private set
    var playlists by mutableStateOf(readPlaylists()); private set
    var queue by mutableStateOf<List<Song>>(emptyList()); private set
    var currentIndex by mutableIntStateOf(0); private set

    var songs by mutableStateOf<List<Song>>(emptyList()); private set
    var hasPermission by mutableStateOf(false); private set
    var loading by mutableStateOf(false); private set

    // ---- Biblioteca por carpeta y primer inicio ----
    var onboarded by mutableStateOf(
        prefs.getBoolean("onboarded", prefs.getString("userName", "").orEmpty().isNotBlank())
    ); private set
    var musicFolder by mutableStateOf(prefs.getString("musicFolder", null)?.let { Uri.parse(it) }); private set
    var scanFound by mutableIntStateOf(0); private set
    var scanFinished by mutableStateOf(false); private set
    private var scanJob: Job? = null
    private var scanToken = 0
    var query by mutableStateOf("")

    var isPlaying by mutableStateOf(false); private set
    // v1.1: estados que la interfaz muestra de forma integrada (carga, fin de cola, error / archivo eliminado).
    var buffering by mutableStateOf(false); private set
    var ended by mutableStateOf(false); private set
    var playbackIssue by mutableIntStateOf(0); private set      // 0 nada, 1 archivo no encontrado, 2 error de reproducción
    var currentId by mutableStateOf<String?>(null); private set
    var position by mutableLongStateOf(0L); private set
    var duration by mutableLongStateOf(0L); private set
    var shuffle by mutableStateOf(false); private set
    var repeatMode by mutableIntStateOf(Player.REPEAT_MODE_OFF); private set

    // ---- Perfil, apariencia e historial (mismas SharedPreferences "player") ----
    var userName by mutableStateOf(prefs.getString("userName", "").orEmpty()); private set
    var theme by mutableStateOf(
        AppTheme.values().firstOrNull { it.name == prefs.getString("theme", null) } ?: AppTheme.DARK
    ); private set
    var playerAccent by mutableStateOf(prefs.getBoolean("playerAccent", true)); private set
    var customTheme by mutableStateOf(readCustomTheme()); private set
    var userPhoto by mutableStateOf<Bitmap?>(readUserPhoto()); private set
    var uiStyle by mutableStateOf(readUiStyle()); private set
    var coverAccent by mutableStateOf<Color?>(null); private set

    // ---- JullExperience (v1.2-A): capa visual opcional; no interviene en la reproducción ----
    var jullExperience by mutableStateOf(prefs.getBoolean("jullExperience", false)); private set
    var dynamicExperience by mutableStateOf(prefs.getBoolean("dynamicExperience", false)); private set
    /** Última paleta calculada (se conserva mientras se calcula la siguiente: sin parpadeos). */
    var jullPalette by mutableStateOf<DynamicPalette?>(null); private set
    /** Paleta que debe aplicar el tema; null = capa apagada (la app se ve igual que la v1.1). */
    val activePalette: DynamicPalette?
        get() = if (jullExperience && dynamicExperience) (jullPalette ?: JullPalette.SAFE) else null
    var stats by mutableStateOf(readStats()); private set

    // ---- Mood: clasificación automática local + correcciones manuales (prioridad) y canciones omitidas ----
    var autoMoods by mutableStateOf<Map<Long, List<Mood>>>(emptyMap()); private set
    var manualMoods by mutableStateOf(readManualMoods()); private set
    var moodGroups by mutableStateOf<Map<Mood, List<Song>>>(emptyMap()); private set
    var skips by mutableStateOf(readSkips()); private set
    var lastSurpriseNote by mutableStateOf<String?>(null); private set
    private var moodJob: Job? = null
    private val surpriseHistory = ArrayDeque<Long>()

    // ---- Personalidad (identidad semanal, memoria musical, motivo de Sorpréndeme): estado ligero en las mismas prefs ----
    val personality = Personality(prefs)

    // ---- Personalidad de Juli: frases cortas en Sorpréndeme y al elegir una canción (PhraseEngine.kt). Se activa en Ajustes ----
    var juliPersonality by mutableStateOf(prefs.getBoolean("juliPersonality", true)); private set
    /** Frase pendiente de mostrarse al elegir una canción (la pinta una sola vez la UI y se descarta sola). */
    var juliLine by mutableStateOf<JuliLine?>(null); private set
    private var lineSeq = 0L
    private val phraseEngine = PhraseEngine(store = { s ->
        prefs.edit().apply { if (s == null) remove("phraseHistory") else putString("phraseHistory", s) }.apply()
    }).also { it.load(prefs.getString("phraseHistory", null)) }

    /** Personalidad elegida (Neutral / Grosera / Romántica). Persiste entre sesiones. */
    var juliPersona by mutableStateOf(JuliPersona.fromName(prefs.getString("juliPersona", null))); private set
    /** Easter Eggs de Juli: detección por eventos, estado local y colección (EasterEggs.kt). */
    internal val eggs = EggEngine(prefs, { juliPersona })

    // ---- Ecosistema (logros, progreso, rachas, rescatadas): estado mínimo en las mismas prefs; el resto se deriva del historial ----
    internal val eco = EcoEngine(prefs)
    internal var ecoToast by mutableStateOf<EcoToast?>(null); private set
    private var ecoSeq = 0L
    private var ecoPrev: Pair<Long, Long> = 0L to 0L          // (canción, último contacto antes del marcado de 5 s)
    private var ecoTracksFor: List<Song>? = null
    private var ecoTracksCache: List<EcoTrack> = emptyList()
    internal fun dismissEcoToast(t: EcoToast) { if (ecoToast?.id == t.id) ecoToast = null }

    fun changeJuliPersona(p: JuliPersona) {
        juliPersona = p
        prefs.edit().putString("juliPersona", p.name).apply()
    }

    private fun showEgg(h: EggHit) {
        juliLine = JuliLine(h.line, ++lineSeq, if (h.isNew) "🥚 Easter Egg descubierto\n${h.def.name}" else null)
    }

    fun changeJuliPersonality(on: Boolean) {
        juliPersonality = on
        prefs.edit().putBoolean("juliPersonality", on).apply()
        if (!on) { juliLine = null; personality.dismissReveal() }
    }

    fun dismissJuliLine(line: JuliLine) { if (juliLine?.id == line.id) juliLine = null }

    /**
     * Selección directa del usuario (fila de canción, tarjeta del Home): igual que [playSong] pero con un comentario
     * opcional de Juli. Si algo falla al elegir la frase, la canción suena igual.
     */
    fun selectSong(song: Song, list: List<Song> = filtered) {
        if (juliPersonality) runCatching {
            val now = System.currentTimeMillis()
            val ctx = ContextAnalyzer.build(
                PhraseMode.NORMAL, song.id, stats, favorites, moodsOf(song),
                Calendar.getInstance().get(Calendar.HOUR_OF_DAY), now, sameAsCurrent = song.id.toString() == currentId,
                persona = juliPersona, skipped = skips[song.id] ?: 0, artistStreak = eggs.artistStreakFor(song)
            )
            val line = phraseEngine.playback(ctx)          // siempre se evalúa: mantiene rachas y anti-repetición
            val hit = eggs.onSelect(song, stats[song.id], stats, now)
            if (hit != null) showEgg(hit) else line?.let { juliLine = JuliLine(it, ++lineSeq) }
        }
        playSong(song, list)
    }

    /** Lo llama Home una vez por sesión. El cálculo va en segundo plano y respeta límites de frecuencia. */
    fun prepareExperiences() {
        val manual = manualMoods; val auto = autoMoods
        personality.prepare(viewModelScope, songs, stats, favorites, skips) { s -> manual[s.id] ?: auto[s.id] ?: emptyList() }
    }

    // ---- Letras (Módulo 10A): caché local primero, Internet solo en segundo plano y si hace falta ----
    private val lyricsRepo = LyricsRepository(app)
    /** Letras de la canción actual. La UI solo lee este estado; nunca hace red. */
    var lyrics by mutableStateOf(LyricsData.NOT_QUERIED); private set
    /** Id de la canción a la que pertenece [lyrics]. */
    var lyricsSongId by mutableStateOf<Long?>(null); private set
    private var lyricsJob: Job? = null

    // ---- Always-On Lyrics (Módulo 11A): solo estado y un contador; la pantalla está en AlwaysOn.kt ----
    var alwaysOnEnabled by mutableStateOf(prefs.getBoolean("alwaysOn", true)); private set
    var alwaysOnActive by mutableStateOf(false); private set
    var alwaysOnDelayMs by mutableLongStateOf(
        prefs.getLong("alwaysOnDelayMs", AlwaysOnTimer.DEFAULT_MS).takeIf { d -> AlwaysOnTimer.OPTIONS.any { it.first == d } }
            ?: AlwaysOnTimer.DEFAULT_MS
    ); private set
    private val alwaysOnTimer = AlwaysOnTimer(alwaysOnDelayMs)
    private var appVisible = false

    // ---- Información musical para el Mood (Módulo 11B): caché local; Internet solo para enriquecer ----
    private val musicInfo = MusicInfoRepository(app)
    var moodOnline by mutableStateOf(prefs.getBoolean("moodOnline", true)); private set
    private var enrichJob: Job? = null

    // ---- Corrección automática de canciones con nombre vago y sin carátula (SongFix.kt): solo dentro de la app ----
    private val songFix = SongFixRepository(app)
    var autoFixOnline by mutableStateOf(prefs.getBoolean("autoFixOnline", true)); private set
    private var fixJob: Job? = null
    private var rawSongs = emptyList<Song>()   // lista tal como sale del escaneo, sin correcciones
    /** Resultado de la última revisión automática (se muestra en Ajustes). */
    var fixStatus by mutableStateOf(""); private set

    private var trackedId: String? = null
    private var listened = 0L
    private var marked = false
    private var counted = false
    private var lastPos = 0L
    private var trackedDur = 0L
    private var accentFor: String? = null
    private var paletteFor: String? = null
    private val accentCache = HashMap<String, Color>()   // color por canción: no se vuelve a analizar la carátula
    private var pendingMs = 0L                           // tiempo escuchado aún sin volcar al historial
    private var pendingId: Long? = null

    private var controller: MediaController? = null

    val filtered: List<Song>
        get() {
            val q = query.trim()
            if (q.isEmpty()) return songs
            return songs.filter {
                it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true)
            }
        }

    val current: Song?
        get() = songs.firstOrNull { it.id.toString() == currentId }

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) =
            sync(player, events.contains(Player.EVENT_TIMELINE_CHANGED))
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            runCatching { future.get() }.getOrNull()?.let {
                controller = it
                it.addListener(listener)
                sync(it, true)
                tryRestore()
            }
        }, ContextCompat.getMainExecutor(app))

        var ticks = 0
        viewModelScope.launch {
            while (true) {
                controller?.let {
                    position = it.currentPosition
                    if (it.duration != C.TIME_UNSET) duration = it.duration
                }
                trackListening()
                runCatching { alwaysOnTick() }     // aislado: un fallo aquí nunca detiene el bucle del historial
                if (++ticks % 10 == 0 && isPlaying) saveState()
                delay(500)
            }
        }
    }

    private fun sync(p: Player, rebuildQueue: Boolean = false) {
        currentIndex = p.currentMediaItemIndex
        // Un elemento por cada item del reproductor (los índices de la cola deben coincidir con los del player);
        // si la biblioteca aún no lo conoce se construye desde los metadatos del propio item.
        if (rebuildQueue) queue = List(p.mediaItemCount) { p.getMediaItemAt(it) }.mapNotNull { songOf(it) }
        isPlaying = p.isPlaying
        buffering = p.playbackState == Player.STATE_BUFFERING && p.playWhenReady
        ended = p.playbackState == Player.STATE_ENDED
        playbackIssue = p.playerError.let { e ->
            when {
                e == null -> 0
                generateSequence<Throwable>(e) { it.cause }.any { it is FileNotFoundException } ||
                    e.errorCode == PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND -> 1
                else -> 2
            }
        }
        currentId = p.currentMediaItem?.mediaId
        duration = if (p.duration == C.TIME_UNSET) 0L else p.duration
        shuffle = p.shuffleModeEnabled
        repeatMode = p.repeatMode
        updateAccent()
        updateJullPalette()
        updateLyrics()
        saveState()
    }

    private fun songOf(item: MediaItem): Song? {
        val id = item.mediaId.toLongOrNull() ?: return null
        byId[id]?.let { return it }
        val uri = item.localConfiguration?.uri ?: return null
        val m = item.mediaMetadata
        return Song(
            id = id, title = m.title?.toString() ?: "Sin título", artist = m.artist?.toString() ?: "Artista desconocido",
            album = m.albumTitle?.toString() ?: "Álbum desconocido", albumId = 0L, durationMs = 0L, uri = uri
        )
    }

    fun loadSongs() {
        val ctx = getApplication<Application>()
        val granted = ContextCompat.checkSelfPermission(ctx, storagePermission()) ==
            PackageManager.PERMISSION_GRANTED
        val folder = musicFolder
        hasPermission = granted || folder != null
        scanJob?.cancel()
        scanToken++
        if (!hasPermission) { loading = false; scanFinished = true; return }
        scanFinished = false
        scanFound = 0
        val token = ++scanToken
        scanJob = viewModelScope.launch {
            loading = true
            try {
                val scanned = withContext(Dispatchers.IO) {
                    val indexed = if (granted) runCatching { MusicRepository.load(ctx) }.getOrDefault(emptyList()) else emptyList()
                    if (folder == null) indexed
                    else try {
                        FolderScanner.scan(ctx, folder, indexed) { scanFound = it }
                    } catch (e: SecurityException) {
                        // Se perdió el acceso a la carpeta: se vuelve a usar todo el dispositivo.
                        musicFolder = null
                        prefs.edit().remove("musicFolder").apply()
                        indexed
                    }
                }
                runCatching { songFix.ensureLoaded() }
                rawSongs = scanned
                songs = runCatching { songFix.apply(scanned) }.getOrDefault(scanned)   // correcciones ya guardadas
                byId = songs.associateBy { it.id }
                scanFound = songs.size
                classifyLibrary()
                startSongFix()
                controller?.let { sync(it, true) }
                tryRestore()
                runCatching { ecoLibraryReady() }
        if (juliPersonality) runCatching { eggs.onLibrary(songs, stats, System.currentTimeMillis())?.let { showEgg(it) } }
            } finally {
                if (token == scanToken) { loading = false; scanFinished = true }   // una reescanada nueva no se pisa
            }
        }
    }

    /** Guarda la carpeta elegida con el selector nativo (con permiso persistente) y reescanea. */
    fun chooseMusicFolder(uri: Uri?) {
        val ctx = getApplication<Application>()
        if (uri != null) runCatching {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        musicFolder = uri
        prefs.edit().apply { if (uri != null) putString("musicFolder", uri.toString()) else remove("musicFolder") }.apply()
        loadSongs()
    }

    fun finishOnboarding(name: String) {
        changeUserName(name)
        onboarded = true
        prefs.edit().putBoolean("onboarded", true).apply()
    }

    private fun Song.toMediaItem() = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(SongArt.uriOf(id))      // la carátula real la resuelve JmBitmapLoader (caché propia)
                .build()
        )
        .build()

    fun playSong(song: Song, list: List<Song> = filtered) {
        val c = controller ?: return
        val index = list.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
        c.setMediaItems(list.map { it.toMediaItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else {
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            if (c.playbackState == Player.STATE_ENDED) c.seekTo(0, 0L)     // fin de cola: "repetir" vuelve al principio
            c.play()
        }
    }

    /** Tras un error el reproductor queda en reposo: al saltar de canción hay que prepararlo de nuevo. */
    private fun resumeIfFailed(c: MediaController) { if (c.playerError != null) { c.prepare(); c.play() } }
    fun next() { controller?.let { it.seekToNextMediaItem(); resumeIfFailed(it) } }
    fun previous() { controller?.let { it.seekToPrevious(); resumeIfFailed(it) } }
    fun seekTo(ms: Long) { controller?.seekTo(ms); position = ms }

    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }

    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    fun playShuffled(list: List<Song>) {
        if (list.isEmpty()) return
        val l = list.shuffled()
        playSong(l.first(), l)
    }

    // ---- Letras ----
    /** Al cambiar de canción: caché (instantánea) → si no hay nada, búsqueda en segundo plano. Nunca bloquea la reproducción. */
    private fun updateLyrics() {
        val id = currentId?.toLongOrNull() ?: return
        if (id == lyricsSongId) return
        val song = byId[id] ?: return
        lyricsSongId = id
        lyricsJob?.cancel()
        lyrics = LyricsData.NOT_QUERIED
        lyricsJob = viewModelScope.launch {
            val c = lyricsRepo.cached(song)
            if (c != null && (c.hasLyrics || System.currentTimeMillis() < c.retryAfter)) { lyrics = c; return@launch }
            lyrics = LyricsData.LOADING
            delay(1_000)                         // si el usuario salta canciones rápido, no se lanzan peticiones inútiles
            lyrics = lyricsRepo.load(song)
        }
    }

    /** Reintento manual (botón "Buscar de nuevo"): ignora el cooldown de NOT_FOUND / ERROR. */
    fun retryLyrics() {
        val id = lyricsSongId ?: return
        val song = byId[id] ?: return
        if (lyrics.isLoading) return
        lyricsJob?.cancel()
        lyrics = LyricsData.LOADING
        lyricsJob = viewModelScope.launch { lyrics = lyricsRepo.load(song, force = true) }
    }

    /**
     * Posición real del reproductor en este instante (el MediaController la extrapola entre actualizaciones).
     * `position` solo se refresca cada 500 ms; las letras necesitan precisión por fotograma. No es un segundo
     * temporizador: solo lee la posición del mismo reproductor.
     */
    fun livePosition(): Long = controller?.currentPosition ?: position

    fun clearLyricsCache() {
        viewModelScope.launch { lyricsRepo.clearAll(); lyricsSongId = null; updateLyrics() }
    }

    suspend fun lyricsCacheCount(): Int = lyricsRepo.cachedCount()

    // ---- Always-On Lyrics ----
    /** MainActivity avisa de si la app está en primer plano: el modo solo se activa con la app visible. */
    fun setAppVisible(v: Boolean) { appVisible = v }

    /**
     * Se llama en el tick de 500 ms que ya existía. Suma tiempo solo si suena una canción y, al llegar a 2 min de
     * reproducción real, activa el modo si la canción actual tiene letras utilizables (SYNCED o UNSYNCED) ya cargadas.
     * Nunca pide letras: usa el estado de 10A tal cual.
     */
    private fun alwaysOnTick() {
        val songId = currentId?.toLongOrNull()
        val reached = alwaysOnTimer.update(SystemClock.elapsedRealtime(), isPlaying && songId != null)
        if (alwaysOnActive) {
            // Se cierra solo si ya no hay canción, se apagó el ajuste o la canción actual terminó sin letras (NOT_FOUND / ERROR).
            val l = lyrics
            val noLyrics = songId != null && lyricsSongId == songId && !l.hasLyrics &&
                l.status != LyricsStatus.LOADING && l.status != LyricsStatus.NOT_QUERIED
            if (songId == null || !alwaysOnEnabled || noLyrics) alwaysOnActive = false
            return
        }
        if (!alwaysOnEnabled || !appVisible || !reached || songId == null) return
        if (lyricsSongId == songId && lyrics.hasLyrics) alwaysOnActive = true
    }

    /** Salida manual (toque o atrás): el contador vuelve a 0, así que no reaparece hasta otros 2 min de reproducción. */
    fun exitAlwaysOn() {
        alwaysOnActive = false
        alwaysOnTimer.reset()
    }

    /** Tiempo de reproducción continua antes de activar el modo. Reinicia el contador para que el cambio sea inmediato y predecible. */
    fun changeAlwaysOnDelay(ms: Long) {
        alwaysOnDelayMs = ms
        prefs.edit().putLong("alwaysOnDelayMs", ms).apply()
        alwaysOnTimer.thresholdMs = ms
        alwaysOnTimer.reset()
    }

    fun changeAlwaysOn(on: Boolean) {
        alwaysOnEnabled = on
        prefs.edit().putBoolean("alwaysOn", on).apply()
        alwaysOnActive = false
        alwaysOnTimer.reset()
    }

    // ---- Perfil y apariencia ----
    fun changeUserName(name: String) {
        userName = name.trim()
        prefs.edit().putString("userName", userName).apply()
    }
    // ---- Tema personalizado y foto de perfil ----
    fun changeCustomTheme(c: CustomTheme) {
        customTheme = c
        prefs.edit().putInt("ctAccent", c.accent).putInt("ctBg", c.background)
            .putInt("ctSurface", c.surface).putInt("ctText", c.text).apply()
    }
    private fun readCustomTheme(): CustomTheme {
        val d = CustomTheme()
        return CustomTheme(
            prefs.getInt("ctAccent", d.accent), prefs.getInt("ctBg", d.background),
            prefs.getInt("ctSurface", d.surface), prefs.getInt("ctText", d.text)
        )
    }

    private val photoFile get() = File(getApplication<Application>().filesDir, "profile_photo.jpg")
    private fun readUserPhoto(): Bitmap? = runCatching {
        photoFile.takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }
    }.getOrNull()

    /** Guarda la foto elegida (reducida a 512 px y con la orientación corregida) solo en este dispositivo. */
    fun changeUserPhoto(uri: Uri?) {
        if (uri == null) {
            runCatching { photoFile.delete() }
            userPhoto = null
            return
        }
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                runCatching {
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                    var sample = 1
                    while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 512) sample *= 2
                    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                    var b = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                        ?: return@runCatching null
                    val rot = ctx.contentResolver.openInputStream(uri)?.use {
                        when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                            else -> 0f
                        }
                    } ?: 0f
                    if (rot != 0f) b = Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(rot) }, true)
                    val scale = 512f / maxOf(b.width, b.height)
                    if (scale < 1f) b = Bitmap.createScaledBitmap(b, (b.width * scale).toInt().coerceAtLeast(1), (b.height * scale).toInt().coerceAtLeast(1), true)
                    photoFile.outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                    b
                }.getOrNull()
            }
            if (bmp != null) userPhoto = bmp
        }
    }

    fun changeTheme(t: AppTheme) {
        theme = t
        prefs.edit().putString("theme", t.name).apply()
        accentFor = null; updateAccent()     // el tema Dinámico necesita el color de la canción actual
    }
    fun changePlayerAccent(on: Boolean) {
        playerAccent = on
        prefs.edit().putBoolean("playerAccent", on).apply()
        accentFor = null; updateAccent()
    }
    fun changeJullExperience(on: Boolean) {
        jullExperience = on
        prefs.edit().putBoolean("jullExperience", on).apply()
        paletteFor = null; updateJullPalette()
    }
    fun changeDynamicExperience(on: Boolean) {
        dynamicExperience = on
        prefs.edit().putBoolean("dynamicExperience", on).apply()
        paletteFor = null; updateJullPalette()
    }
    fun changeUiStyle(st: UiStyle) {
        uiStyle = st
        prefs.edit().putString("density", st.density.name).putString("cardShape", st.cardShape.name)
            .putBoolean("reducedMotion", st.reducedMotion).apply()
    }
    private fun readUiStyle() = UiStyle(
        Density.values().firstOrNull { it.name == prefs.getString("density", null) } ?: Density.COMFORTABLE,
        CardShape.values().firstOrNull { it.name == prefs.getString("cardShape", null) } ?: CardShape.ROUNDED,
        prefs.getBoolean("reducedMotion", false)
    )

    /** Color predominante de la carátula actual (o el tono de su carátula por defecto). */
    private fun updateAccent() {
        // Sin colores dinámicos activos no se procesa ninguna carátula.
        if (!playerAccent && theme != AppTheme.DYNAMIC) return
        val id = currentId ?: return
        if (id == accentFor) return
        val song = byId[id.toLongOrNull() ?: return] ?: return
        accentFor = id
        accentCache[id]?.let { coverAccent = it; return }
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val c = withContext(Dispatchers.IO) {
                ArtCache.load(ctx, song, 96)?.let { CoverColors.accent(it) } ?: CoverColors.fallback(song.album)
            }
            if (accentCache.size > 300) accentCache.clear()
            accentCache[id] = c
            if (accentFor == id) coverAccent = c
        }
    }

    /**
     * Dynamic Experience: paleta de la canción actual. Solo trabaja si JullExperience y Dynamic Experience están ON,
     * una vez por canción (caché en memoria), en un hilo de fondo y reutilizando la carátula ya cacheada (ArtCache).
     */
    private fun updateJullPalette() {
        if (!jullExperience || !dynamicExperience) return
        val id = currentId ?: return
        if (id == paletteFor) return
        val song = byId[id.toLongOrNull() ?: return] ?: return
        paletteFor = id
        JullPaletteCache.get(song)?.let { jullPalette = it; return }
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val p = withContext(Dispatchers.IO) {
                ArtCache.load(ctx, song, 96)?.let { JullPalette.extract(it) } ?: JullPalette.fallbackFor(song.album)
            }
            JullPaletteCache.put(song, p)
            if (paletteFor == id) jullPalette = p
        }
    }

    // ---- Historial de escucha ----
    /**
     * Se llama cada 500 ms. Una canción cuenta como "reciente" tras ~5 s de escucha real
     * y como "reproducción" tras 30 s o la mitad de su duración (lo que sea menor).
     * Saltar canciones al instante no ensucia las recomendaciones.
     */
    private fun trackListening() {
        if (!isPlaying) { flushListened(); return }
        val id = currentId ?: return
        val songId = id.toLongOrNull() ?: return
        if (id != trackedId) {
            flushListened()
            registerSkip()
            trackedId = id; listened = 0L; marked = false; counted = false
        } else if (counted && position < 2_000 && lastPos > 10_000) {
            listened = 0L; marked = false; counted = false   // repetición de la misma canción
        }
        lastPos = position
        if (duration > 0) trackedDur = duration
        listened += 500
        pendingId = songId; pendingMs += 500
        if (pendingMs >= 180_000L) flushListened()
        val need = if (duration > 0) min(30_000L, duration / 2) else 30_000L
        if (!marked && listened >= min(5_000L, need)) { marked = true; touch(songId, false) }
        if (!counted && listened >= need) { counted = true; touch(songId, true) }
    }

    private fun touch(id: Long, played: Boolean) {
        val now = System.currentTimeMillis()
        val old = stats[id] ?: SongStat()
        if (!played) ecoPrev = id to old.last
        val ecoLast = if (played) (old.recent.lastOrNull() ?: ecoPrev.takeIf { it.first == id }?.second ?: 0L) else 0L
        // Mismo historial de siempre; solo se añaden la fecha de cada reproducción real (últimas 10) y el tiempo.
        val recent = if (played) (old.recent + now).takeLast(SongStat.MAX_RECENT) else old.recent
        stats = stats + (id to old.copy(plays = old.plays + if (played) 1 else 0, last = now, recent = recent))
        saveStats()
        // Escucharla completa compensa una omisión anterior.
        if (played && (skips[id] ?: 0) > 0) { skips = skips + (id to (skips.getValue(id) - 1)); saveSkips() }
        if (played) {
            val juliShown = eggCounted(id)
            runCatching { ecoCounted(id, ecoLast, old.plays, juliShown) }
        }
    }

    /** Evento "reproducción contada" para los Easter Eggs. Con la personalidad desactivada no se ejecuta nada. */
    private fun eggCounted(id: Long): Boolean {
        if (!juliPersonality) return false
        val s = byId[id] ?: return false
        return runCatching {
            val hit = eggs.onCounted(
                s, stats[id], id in favorites, Calendar.getInstance().get(Calendar.HOUR_OF_DAY),
                System.currentTimeMillis(), songs.count { it.album == s.album }
            )
            val recovered = eggs.takeRecovered()
            val albumDone = eggs.takeAlbumDone()
            if (hit != null) { showEgg(hit); true }
            else {
                // Sin Easter Egg nuevo: acertar una Sorpréndeme tras fallar, o terminar un álbum, puede tener su propia frase.
                val line = when {
                    recovered > 0 -> phraseEngine.eventLine(juliPersona, SurpriseCat.ACERTADA)
                    albumDone -> phraseEngine.eventLine(juliPersona, NormalCat.ALBUM)
                    else -> null
                }
                line?.let { juliLine = JuliLine(it, ++lineSeq) }
                line != null
            }
        }.getOrDefault(false)
    }

    /**
     * Vuelca al historial el tiempo escuchado acumulado. Se hace al cambiar de canción, al pausar y cada
     * pocos minutos (no en cada tick) para no recalcular el Home ni reescribir el historial constantemente.
     */
    private fun flushListened() {
        val id = pendingId ?: return
        val ms = pendingMs
        pendingMs = 0L
        if (ms <= 0L) return
        val old = stats[id] ?: return       // menos de 5 s de escucha: no cuenta
        stats = stats + (id to old.copy(listenedMs = old.listenedMs + ms))
        saveStats()
    }

    /** Una canción abandonada en los primeros segundos (sin llegar al final) cuenta como omitida. */
    private fun registerSkip() {
        val prev = trackedId?.toLongOrNull() ?: return
        val endedNaturally = trackedDur > 0 && lastPos >= trackedDur - 4_000
        if (listened in 1L until 10_000L && !endedNaturally) {
            skips = skips + (prev to ((skips[prev] ?: 0) + 1))
            saveSkips()
            if (juliPersonality) runCatching { eggs.onSkip(prev, System.currentTimeMillis())?.let { showEgg(it) } }
        }
    }

    fun clearHistory() {
        pendingMs = 0L
        stats = emptyMap()
        skips = emptyMap()
        prefs.edit().remove("stats").remove("skips").apply()
        personality.clear()
        eco.clearProgress()
        phraseEngine.clear()
        eggs.clearProgress()
        juliLine = null
    }

    private fun readStats(): Map<Long, SongStat> {
        val out = HashMap<Long, SongStat>()
        runCatching {
            val o = JSONObject(prefs.getString("stats", "{}") ?: "{}")
            o.keys().forEach { k ->
                val a = o.getJSONArray(k)
                val r = a.optJSONArray(3)
                val recent = if (r == null) emptyList() else List(r.length()) { r.getLong(it) }
                k.toLongOrNull()?.let { out[it] = SongStat(a.getInt(0), a.getLong(1), a.optLong(2, 0L), recent) }
            }
        }
        return out
    }

    private fun saveStats() {
        val o = JSONObject()
        stats.forEach { (k, v) ->
            val a = JSONArray().put(v.plays).put(v.last)
            if (v.listenedMs > 0L || v.recent.isNotEmpty()) a.put(v.listenedMs).put(JSONArray(v.recent))
            o.put(k.toString(), a)
        }
        prefs.edit().putString("stats", o.toString()).apply()
    }

    private fun readSkips(): Map<Long, Int> {
        val out = HashMap<Long, Int>()
        runCatching {
            val o = JSONObject(prefs.getString("skips", "{}") ?: "{}")
            o.keys().forEach { k -> k.toLongOrNull()?.let { out[it] = o.getInt(k) } }
        }
        return out
    }

    private fun saveSkips() {
        val o = JSONObject()
        skips.forEach { (k, v) -> if (v > 0) o.put(k.toString(), v) }
        prefs.edit().putString("skips", o.toString()).apply()
    }

    // ---- Mood ----
    /** Mood efectivo: lo elegido a mano manda; si no, el automático; si no hay señal, "Sin clasificar". */
    fun moodsOf(s: Song): List<Mood> = manualMoods[s.id] ?: autoMoods[s.id] ?: listOf(Mood.SIN_CLASIFICAR)

    /** MANUAL = lo eligió el usuario (tiene prioridad y ninguna actualización de datos lo sobrescribe); AUTO = lo calculó la app. */
    fun moodSourceOf(s: Song): MoodSource = if (s.id in manualMoods) MoodSource.MANUAL else MoodSource.AUTO

    fun songsFor(m: Mood?): List<Song> = if (m == null) emptyList() else moodGroups[m].orEmpty()

    /**
     * Clasifica la biblioteca fuera del hilo principal con metadatos + información ya guardada en caché (sin red).
     * Se repite cuando cambia la biblioteca o cuando llega información nueva; solo la primera vez [enrich] lanza
     * además la consulta online de las canciones que la necesitan.
     */
    private fun classifyLibrary(enrich: Boolean = true) {
        val list = songs
        val st = stats
        moodJob?.cancel()
        moodJob = viewModelScope.launch {
            runCatching { musicInfo.ensureLoaded() }
            val auto = withContext(Dispatchers.Default) {
                val info = runCatching { musicInfo.snapshot() }.getOrDefault(emptyMap())
                MoodClassifier.classify(list, { info[MusicInfoKey.of(it)] }, st)
            }
            autoMoods = auto
            rebuildMoodGroups()
            if (enrich) startEnrichment(list, auto)
        }
    }

    /**
     * Enriquecimiento online opcional y acotado: solo canciones sin Mood manual, sin clasificar/mixtas o sin género,
     * que aún no tengan respuesta vigente en caché. 1 petición/s, tope por sesión, solo con la app abierta y con
     * Internet. Lo obtenido se guarda en disco; después se reclasifica una vez por lote (no por canción).
     */
    private fun startEnrichment(list: List<Song>, auto: Map<Long, List<Mood>>) {
        enrichJob?.cancel()
        if (!moodOnline) return
        enrichJob = viewModelScope.launch {
            delay(5_000)                                  // deja terminar el arranque y el escaneo
            val cur = currentId?.toLongOrNull()
            val fav = favorites; val st = stats; val manual = manualMoods
            val cands = withContext(Dispatchers.Default) {
                list.filter { s ->
                    val m = auto[s.id]?.firstOrNull()
                    s.id !in manual &&
                        (m == null || m == Mood.SIN_CLASIFICAR || m == Mood.MIXTO || s.genre.isBlank()) &&
                        !musicInfo.isSettled(s)
                }.sortedByDescending {
                    (if (it.id == cur) 1_000_000 else 0) + (st[it.id]?.plays ?: 0) * 2 + if (it.id in fav) 3 else 0
                }
            }
            if (cands.isEmpty()) return@launch
            try {
                musicInfo.enrich(cands, MAX_ENRICH_PER_SESSION) { classifyLibrary(enrich = false) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // La información externa es opcional: cualquier fallo se ignora y el Mood sigue con lo local.
            }
        }
    }

    /**
     * Corrección automática y opcional: solo canciones con nombre vago Y sin carátula (o con una genérica, p. ej. un fotograma de vídeo),
     * con coincidencia clara en MusicBrainz. Guarda título/artista/álbum/carátula dentro de la app (los archivos no se tocan).
     * Solo con la app abierta y con Internet; el límite de 1 petición/s se comparte con el Mood online.
     * [force] = "Revisar ahora" desde Ajustes: sin espera y reintentando también las que no tuvieron coincidencia.
     */
    private fun startSongFix(force: Boolean = false) {
        fixJob?.cancel()
        if (!autoFixOnline && !force) return
        val ctx = getApplication<Application>()
        fixJob = viewModelScope.launch {
            try {
                if (!force) delay(8_000)                       // deja terminar el arranque y el escaneo
                songFix.ensureLoaded()
                val (vague, cands) = withContext(Dispatchers.Default) {
                    songs.count { !it.autoFixed && VagueNames.isVague(it) && VagueNames.queryFor(it) != null } to
                        songs.filter { songFix.isCandidate(it, force = force) }
                }
                if (cands.isEmpty()) {
                    fixStatus = if (vague == 0) "No se detectó ninguna canción con nombre vago. Para casos concretos usa «Buscar carátula» o «Editar datos» en el menú de la canción."
                    else "$vague canciones con nombre vago, todas ya revisadas. «Revisar ahora» vuelve a intentarlo."
                    return@launch
                }
                fixStatus = "Revisando ${cands.size} canciones…"
                val st = songFix.run(cands, MAX_FIX_PER_SESSION, force,
                    hasCover = { s -> withContext(Dispatchers.IO) { !CoverProbe.needsCover(ctx, s) } }
                ) { applyFixes() }
                fixStatus = buildString {
                    append("Última revisión: ${st.checked} con nombre vago · ${st.fixed} corregidas · ${st.noMatch} sin coincidencia clara")
                    if (st.goodCover > 0) append(" · ${st.goodCover} ya tenían carátula buena")
                    if (st.failed > 0) append(" · ${st.failed} con error de red")
                    if (st.offline) append(" · sin conexión")
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                fixStatus = "Error en la revisión: ${e.javaClass.simpleName}"
            }
        }
    }

    fun runFixNow() { fixStatus = "Revisando…"; startSongFix(force = true) }

    /** Vuelca las correcciones a la lista visible (mismos ids: favoritos, listas e historial no se tocan). */
    private fun applyFixes() {
        val fixed = songFix.apply(rawSongs)
        songs = fixed
        byId = fixed.associateBy { it.id }
        classifyLibrary(enrich = false)
    }

    fun changeAutoFixOnline(on: Boolean) {
        autoFixOnline = on
        prefs.edit().putBoolean("autoFixOnline", on).apply()
        if (on) startSongFix() else fixJob?.cancel()
    }

    /** Deshace la corrección de una canción y no vuelve a tocarla. */
    fun revertFix(song: Song) {
        viewModelScope.launch { songFix.revert(song.id); loadSongs() }
    }

    fun revertAllFixes() {
        viewModelScope.launch { songFix.revertAll(); loadSongs() }
    }

    // ---- Búsqueda y edición manual desde el menú de la canción ----

    suspend fun searchSongInfo(title: String, artist: String): List<ManualHit>? = songFix.searchLoose(title, artist)

    suspend fun coverThumb(releaseId: String): ByteArray? = songFix.thumb(releaseId)

    fun applyManualInfo(song: Song, title: String?, artist: String?, album: String?) {
        viewModelScope.launch { songFix.applyManual(song, title, artist, album, null); applyFixes() }
    }

    fun applyCoverFromRelease(song: Song, releaseId: String, done: (Boolean) -> Unit) {
        viewModelScope.launch {
            val path = songFix.downloadReleaseCover(song.id, releaseId)
            if (path != null) { songFix.applyManual(song, null, null, null, path); applyFixes() }
            done(path != null)
        }
    }

    fun applyCoverFromUri(song: Song, uri: Uri, done: (Boolean) -> Unit) {
        viewModelScope.launch {
            val path = songFix.coverFromImage(song.id, uri)
            if (path != null) { songFix.applyManual(song, null, null, null, path); applyFixes() }
            done(path != null)
        }
    }

    /** El archivo ya se borró del dispositivo: se reescanea la biblioteca. */
    fun onSongDeleted() { loadSongs() }

    fun changeMoodOnline(on: Boolean) {
        moodOnline = on
        prefs.edit().putBoolean("moodOnline", on).apply()
        if (on) startEnrichment(songs, autoMoods) else enrichJob?.cancel()
    }

    private fun rebuildMoodGroups() {
        val m = LinkedHashMap<Mood, MutableList<Song>>()
        for (s in songs) for (mo in moodsOf(s)) m.getOrPut(mo) { ArrayList() }.add(s)
        moodGroups = m
    }

    /** Lista vacía = volver a la clasificación automática. */
    fun setManualMoods(id: Long, moods: List<Mood>) {
        val l = moods.filter { it.assignable }.distinct()
        manualMoods = if (l.isEmpty()) manualMoods - id else manualMoods + (id to l)
        saveManualMoods()
        rebuildMoodGroups()
    }

    fun clearManualMoods() {
        manualMoods = emptyMap()
        saveManualMoods()
        rebuildMoodGroups()
    }

    fun playMood(m: Mood, shuffled: Boolean = true) {
        val l = songsFor(m)
        if (l.isEmpty()) return
        if (shuffled) playShuffled(l) else playSong(l.first(), l)
    }

    /** "Sorpréndeme": selección ponderada (favoritos, poco escuchadas, variedad, Mood), sin repetir lo reciente. */
    fun surpriseMe() {
        if (songs.isEmpty()) return
        val cur = currentId?.toLongOrNull()
        var avoid: Set<Long> = surpriseHistory.toSet() + listOfNotNull(cur)
        if (songs.size - avoid.size < 25) { surpriseHistory.clear(); avoid = setOfNotNull(cur) }
        val now = System.currentTimeMillis()
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val seed = System.nanoTime()
        val r = Recommender.surprise(songs, stats, favorites, skips, { moodsOf(it) }, now, avoid, hour, seed)
        if (r.songs.isEmpty()) return
        // La primera canción se elige por un motivo (redescubrir, favorita, descubrimiento, Mood, joya poco escuchada o
        // comodín) con las mismas señales de siempre; el resto de la cola es la mezcla ponderada de antes.
        val pick = runCatching {
            SurprisePicker.pick(
                songs, stats, favorites, skips, { moodsOf(it) }, now, avoid, hour, seed xor 0x5DEECE66DL,
                personality.recentPicks()
            )
        }.getOrNull()
        // La frase la elige el PhraseEngine según el motivo de la recomendación, el historial y la hora. Con la personalidad
        // desactivada no se genera ninguna (ni se guarda memoria de frases).
        val shown = if (pick == null || !juliPersonality) pick else runCatching {
            val ctx = ContextAnalyzer.build(
                PhraseMode.SURPRISE, pick.song.id, stats, favorites, moodsOf(pick.song), hour, now, type = pick.type,
                persona = juliPersona, failedSurprises = eggs.failedSurprises
            )
            SurprisePick(pick.song, pick.type, phraseEngine.surprise(ctx))
        }.getOrDefault(pick)
        val list = if (pick == null) r.songs else listOf(pick.song) + r.songs.filter { it.id != pick.song.id }
        list.forEach { surpriseHistory.addLast(it.id) }
        while (surpriseHistory.size > 80) surpriseHistory.removeFirst()
        lastSurpriseNote = r.note
        if (pick != null) personality.recordSurprise(shown ?: pick, show = juliPersonality && (shown ?: pick).phrase.isNotBlank())
        if (juliPersonality) runCatching { eggs.onSurprisePick(list.first().id) }
        eco.onSurprise(list.first().id)
        playSong(list.first(), list)
    }

    /** Modos de escucha: misma cola y mismo reproductor; solo cambia cómo se elige la lista. */
    fun playMode(mode: ListeningMode) {
        if (songs.isEmpty()) return
        if (mode == ListeningMode.RANDOM) { surpriseMe(); return }
        val cur = currentId?.toLongOrNull()
        val avoid: Set<Long> = surpriseHistory.toSet() + listOfNotNull(cur)
        val r = ListeningModes.build(
            mode, songs, stats, favorites, skips, { moodsOf(it) }, System.currentTimeMillis(), avoid,
            Calendar.getInstance().get(Calendar.HOUR_OF_DAY), System.nanoTime()
        )
        if (r.songs.isEmpty()) return
        r.songs.forEach { surpriseHistory.addLast(it.id) }
        while (surpriseHistory.size > 80) surpriseHistory.removeFirst()
        lastSurpriseNote = r.note
        playSong(r.songs.first(), r.songs)
    }

    // ---------- Ecosistema: cálculo bajo demanda y reacciones ----------

    private fun ecoTracks(): List<EcoTrack> {
        val cur = songs
        if (ecoTracksFor !== cur) {
            ecoTracksCache = cur.map { EcoTrack(it.id, StatsCalc.songKey(it), it.artist, it.album, it.dateAdded) }
            ecoTracksFor = cur
        }
        return ecoTracksCache
    }

    private fun favMax(): Int = favorites.maxOfOrNull { stats[it]?.plays ?: 0 } ?: 0

    internal fun ecoSnapshot(): EcoSnap = Eco.snapshot(ecoTracks(), stats, System.currentTimeMillis())
    internal fun ecoMetrics(s: EcoSnap) = eco.metrics(s, favMax())

    /** Tras el escaneo: registra en silencio el progreso previo (sin animaciones) y limpia rescatadas de archivos que ya no existen. */
    private fun ecoLibraryReady() {
        if (songs.isEmpty()) return
        val tr = ecoTracks()
        eco.ensureInit(Eco.snapshot(tr, stats, System.currentTimeMillis()), favMax(), System.currentTimeMillis())
        if (songs.size >= 20) eco.prune(tr.mapTo(HashSet()) { it.key })
    }

    /** Una reproducción real acaba de contarse: álbum completado, logros, rescatadas y nivel. Una sola pasada, sin hilos propios. */
    private fun ecoCounted(id: Long, prevLast: Long, playsBefore: Int, juliShown: Boolean) {
        val s = byId[id] ?: return
        val now = System.currentTimeMillis()
        val t = ecoTracks().firstOrNull { it.id == id } ?: return
        val snap = Eco.snapshot(ecoTracks(), stats, now)
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val ev = eco.onCounted(t, prevLast, playsBefore, now, hour, snap, favMax())
        val rnd = java.util.Random()
        // Aviso visual (una sola vez por álbum; los logros se agrupan en un único aviso).
        val done = ev.albumDone
        val ach = ev.newAch
        if (done != null) {
            ecoToast = EcoToast(++ecoSeq, "💿", "ÁLBUM COMPLETADO", s.album, "${done.heard} / ${done.total}")
        } else if (ach.isNotEmpty()) {
            ecoToast = EcoToast(
                ++ecoSeq, ach.first().emoji, if (ach.size == 1) "🏆 LOGRO DESBLOQUEADO" else "🏆 ${ach.size} LOGROS DESBLOQUEADOS",
                ach.first().name, if (ach.size > 1) "y ${ach.size - 1} más" else null
            )
        } else if (ev.levelUp != null) {
            ecoToast = EcoToast(++ecoSeq, ev.levelUp.emoji, "NUEVO NIVEL", ev.levelUp.label, "${snap.pct.toInt()}% de tu biblioteca")
        }
        if (!juliPersonality) return
        // Secreto de Juli: canción olvidada y recuperada (se guarda en la colección de secretos).
        val egg = if (ev.rescuedDays > 0) eggs.onRevived(now) else null
        if (egg != null) { showEgg(egg); return }
        if (juliShown) return
        val key = when {
            done != null -> "ecoalbum"
            ach.isNotEmpty() -> "ecoach"
            ev.rescuedDays > 0 -> "ecorescue"
            else -> return
        }
        juliLine = JuliLine(EggLines.pick(key, juliPersona, rnd), ++lineSeq)
    }

    /** Listas de las colecciones; el texto opcional es la nota factual de cada canción. */
    internal fun ecoList(key: String): List<Pair<Song, String?>> {
        val now = System.currentTimeMillis()
        return when (key) {
            "never", "forgotten" -> {
                val snap = ecoSnapshot()
                val ids = if (key == "never") snap.neverIds else snap.forgottenIds
                ids.mapNotNull { byId[it] }.map { s ->
                    s to if (key == "forgotten") "Esta canción lleva ${Eco.span((now - (stats[s.id]?.last ?: now)) / Eco.DAY)} sin sonar." else null
                }
            }
            "rescued" -> {
                val byKey = HashMap<String, Song>(); for (s in songs) byKey.getOrPut(StatsCalc.songKey(s)) { s }
                eco.rescuedEntries.mapNotNull { (k, _, gap) -> byKey[k]?.let { it to "Volviste a escuchar esta después de ${Eco.span(gap.toLong())}." } }
            }
            "fav" -> favorites.mapNotNull { byId[it] }.map { it to null }
            "repeat" -> songs.filter { (stats[it.id]?.plays ?: 0) >= 3 }.sortedByDescending { stats[it.id]?.plays ?: 0 }.take(100)
                .map { it to "${stats[it.id]?.plays ?: 0} reproducciones" }
            else -> songsFor(Mood.NOCTURNA).map { it to null }
        }
    }

    /** Sorpréndeme con contexto de biblioteca (mismas señales locales; sin recomendaciones pesadas). */
    internal fun playEco(kind: EcoPick) {
        if (songs.isEmpty()) return
        val rnd = java.util.Random(System.nanoTime())
        val snap = ecoSnapshot()
        val cur = currentId?.toLongOrNull()
        fun pickList(ids: List<Long>) = ids.filter { it != cur }.shuffled(rnd).take(30).mapNotNull { byId[it] }
        var phrase: SurpriseCat? = null
        val list: List<Song> = when (kind) {
            EcoPick.NEVER -> { phrase = SurpriseCat.DESCUBRIMIENTO; pickList(snap.neverIds) }
            EcoPick.FORGOTTEN -> { phrase = SurpriseCat.NOSTALGIA; pickList(snap.forgottenIds) }
            EcoPick.ALBUM -> {
                val g = snap.albums.filter { it.total >= Eco.MIN_ALBUM && it.heard in 1 until it.total }.maxByOrNull { it.last }
                if (g == null) emptyList() else {
                    val all = songs.filter { it.album == g.name }.sortedWith(AlbumOrder)
                    all.filter { (stats[it.id]?.plays ?: 0) == 0 } + all.filter { (stats[it.id]?.plays ?: 0) > 0 }
                }
            }
            EcoPick.ARTIST -> {
                val g = snap.lowArtists.let { l -> if (l.isEmpty()) null else l[rnd.nextInt(l.size)] }
                if (g == null) emptyList() else songs.filter { it.artist == g.name }.sortedBy { stats[it.id]?.plays ?: 0 }
            }
            EcoPick.FAVORITE -> { phrase = SurpriseCat.FAVORITA; pickList(favorites.toList()) }
            EcoPick.NOW -> {
                val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                playMode(if (h >= 21 || h < 6) ListeningMode.NIGHT else ListeningMode.RANDOM); return
            }
        }
        if (list.isEmpty()) { lastSurpriseNote = "Todavía no hay nada para «${kind.label}»"; return }
        lastSurpriseNote = "${kind.emoji} ${kind.label}"
        eco.onSurprise(list.first().id)
        val ph = phrase
        if (juliPersonality && ph != null) runCatching { phraseEngine.eventLine(juliPersona, ph) }.getOrNull()?.let { juliLine = JuliLine(it, ++lineSeq) }
        playSong(list.first(), list)
    }

    /** "Reproducir similares": mismo Mood o mismo artista que la canción dada, sin repetirla. */
    fun playSimilar(song: Song) {
        val moods = moodsOf(song).filter { it != Mood.SIN_CLASIFICAR && it != Mood.MIXTO }.toSet()
        val l = songs.filter { it.id != song.id && (it.artist == song.artist || moodsOf(it).any { m -> m in moods }) }
            .shuffled(java.util.Random(System.nanoTime())).take(30)
        if (l.isEmpty()) { surpriseMe(); return }
        val q = listOf(song) + l
        playSong(song, q)
    }

    private fun readManualMoods(): Map<Long, List<Mood>> {
        val out = HashMap<Long, List<Mood>>()
        runCatching {
            val o = JSONObject(prefs.getString("moods", "{}") ?: "{}")
            o.keys().forEach { k ->
                val a = o.getJSONArray(k)
                val l = (0 until a.length()).mapNotNull { Mood.fromName(a.getString(it)) }.filter { it.assignable }
                if (l.isNotEmpty()) k.toLongOrNull()?.let { out[it] = l }
            }
        }
        return out
    }

    private fun saveManualMoods() {
        val o = JSONObject()
        manualMoods.forEach { (k, v) -> o.put(k.toString(), JSONArray(v.map { it.name })) }
        prefs.edit().putString("moods", o.toString()).apply()
    }

    // ---- Cola ----
    fun playNext(s: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) playSong(s, listOf(s)) else c.addMediaItem(c.currentMediaItemIndex + 1, s.toMediaItem())
    }
    fun addToQueue(s: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) playSong(s, listOf(s)) else c.addMediaItem(s.toMediaItem())
    }
    fun moveQueue(from: Int, to: Int) { controller?.moveMediaItem(from, to) }
    fun removeFromQueue(i: Int) { controller?.removeMediaItem(i) }
    fun playQueueIndex(i: Int) { controller?.let { it.seekTo(i, 0L); it.play() } }

    // ---- Favoritos y listas ----
    fun toggleFavorite(id: Long) {
        favorites = if (id in favorites) favorites - id else favorites + id
        prefs.edit().putString("fav", favorites.joinToString(",")).apply()
    }
    fun createPlaylist(name: String, firstId: Long? = null) {
        val n = name.trim()
        if (n.isEmpty() || n in playlists) { firstId?.let { addToPlaylist(n, it) }; return }
        playlists = playlists + (n to listOfNotNull(firstId)); savePlaylists()
    }
    fun addToPlaylist(name: String, id: Long) {
        val l = playlists[name] ?: return
        if (id !in l) { playlists = playlists + (name to (l + id)); savePlaylists() }
    }
    fun removeFromPlaylist(name: String, id: Long) {
        playlists = playlists + (name to playlists[name].orEmpty().filter { it != id }); savePlaylists()
    }
    fun deletePlaylist(name: String) { playlists = playlists - name; savePlaylists() }
    fun playlistSongs(name: String) = playlists[name].orEmpty().mapNotNull { byId[it] }

    private fun readIds(key: String): Set<Long> =
        prefs.getString(key, "").orEmpty().split(",").mapNotNull { it.toLongOrNull() }.toSet()

    private fun readPlaylists(): Map<String, List<Long>> {
        val out = LinkedHashMap<String, List<Long>>()
        runCatching {
            val o = JSONObject(prefs.getString("playlists", "{}") ?: "{}")
            o.keys().forEach { k -> val a = o.getJSONArray(k); out[k] = List(a.length()) { a.getLong(it) } }
        }
        return out
    }

    private fun savePlaylists() {
        val o = JSONObject()
        playlists.forEach { (k, v) -> o.put(k, JSONArray(v)) }
        prefs.edit().putString("playlists", o.toString()).apply()
    }

    // ---- Recordar última canción y cola ----
    private fun saveState() {
        val c = controller ?: return
        if (c.mediaItemCount == 0) return
        prefs.edit()
            .putString("queue", (0 until c.mediaItemCount).joinToString(",") { c.getMediaItemAt(it).mediaId })
            .putLong("cur", c.currentMediaItem?.mediaId?.toLongOrNull() ?: -1L)
            .putLong("pos", c.currentPosition)
            .putBoolean("shuffle", c.shuffleModeEnabled)
            .putInt("repeat", c.repeatMode)
            .apply()
    }

    private fun tryRestore() {
        val c = controller ?: return
        if (restored || byId.isEmpty()) return
        restored = true
        if (c.mediaItemCount > 0) return // el servicio ya tenía cola
        val items = prefs.getString("queue", "").orEmpty().split(",")
            .mapNotNull { it.toLongOrNull() }.mapNotNull { byId[it] }
        if (items.isEmpty()) return
        val idx = items.indexOfFirst { it.id == prefs.getLong("cur", -1L) }.coerceAtLeast(0)
        c.shuffleModeEnabled = prefs.getBoolean("shuffle", false)
        c.repeatMode = prefs.getInt("repeat", Player.REPEAT_MODE_OFF)
        c.setMediaItems(items.map { it.toMediaItem() }, idx, prefs.getLong("pos", 0L))
        c.prepare()
    }

    override fun onCleared() {
        flushListened()
        saveState()
        controller?.removeListener(listener)
        controller?.release()
        controller = null
        super.onCleared()
    }
}
