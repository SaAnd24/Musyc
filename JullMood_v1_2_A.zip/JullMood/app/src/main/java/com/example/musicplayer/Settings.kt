package com.example.musicplayer

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
internal fun SettingsScreen(vm: PlayerViewModel, onOpenStats: () -> Unit, onOpenEggs: () -> Unit = {}, onOpenEco: (Int) -> Unit = {}) {
    var editName by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }
    var confirmMoods by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) vm.chooseMusicFolder(uri)
    }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.changeUserPhoto(uri)
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { Text("Ajustes", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(start = 20.dp, top = 20.dp, end = 20.dp)) }

        item {
            Group("Perfil") {
                Row(Modifier.fillMaxWidth().clickable { editName = true }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(vm, 44.dp, 18)
                    Column(Modifier.weight(1f).padding(start = 14.dp)) {
                        Text(vm.userName, fontWeight = FontWeight.SemiBold)
                        Text("Así te saludamos en Home", color = cs.onSurfaceVariant, fontSize = 13.sp)
                    }
                    Icon(painterResource(R.drawable.ic_edit), "Editar nombre", tint = cs.onSurfaceVariant, modifier = Modifier.size(22.dp))
                }
            }
        }

        item {
            Group("Apariencia") {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    AppTheme.values().toList().chunked(3).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            row.forEach { t ->
                                ThemeTile(t, vm.theme == t, vm.coverAccent, vm.customTheme, Modifier.weight(1f)) { vm.changeTheme(t) }
                            }
                            repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                    if (vm.theme == AppTheme.DYNAMIC)
                        Text("Toda la app toma los colores de la carátula que está sonando.", color = cs.onSurfaceVariant, fontSize = 13.sp)
                }
                if (vm.theme == AppTheme.CUSTOM) CustomThemeEditor(vm)
                Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Acento del reproductor según la carátula", fontWeight = FontWeight.Medium)
                        Text("El mini reproductor y la pantalla de reproducción usan el color predominante de la portada.", color = cs.onSurfaceVariant, fontSize = 13.sp)
                    }
                    Switch(checked = vm.playerAccent, onCheckedChange = { vm.changePlayerAccent(it) }, modifier = Modifier.padding(start = 8.dp))
                }
                val st = vm.uiStyle
                // JullExperience (v1.2-A): capa visual opcional. Apagada, la app se ve como la v1.1.
                Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("JullExperience", fontWeight = FontWeight.Medium)
                        Text("Capa visual opcional sobre tu tema. Desactivada, JullMood se ve igual que la v1.1.", color = cs.onSurfaceVariant, fontSize = 13.sp)
                    }
                    Switch(checked = vm.jullExperience, onCheckedChange = { vm.changeJullExperience(it) }, modifier = Modifier.padding(start = 8.dp))
                }
                if (vm.jullExperience) Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Dynamic Experience", fontWeight = FontWeight.Medium)
                        Text("Los colores de la interfaz se adaptan a la portada de cada canción, con transición suave.", color = cs.onSurfaceVariant, fontSize = 13.sp)
                    }
                    Switch(checked = vm.dynamicExperience, onCheckedChange = { vm.changeDynamicExperience(it) }, modifier = Modifier.padding(start = 8.dp))
                }
                ChoiceRow("Densidad", Density.values().map { it to it.label }, st.density) { vm.changeUiStyle(st.copy(density = it)) }
                ChoiceRow("Forma de las tarjetas", CardShape.values().map { it to it.label }, st.cardShape) { vm.changeUiStyle(st.copy(cardShape = it)) }
                ChoiceRow("Animaciones", listOf(false to "Completas", true to "Reducidas"), st.reducedMotion) { vm.changeUiStyle(st.copy(reducedMotion = it)) }
            }
        }

        item {
            Group("Tu música") {
                SettingRow("Estadísticas", "Lo que más escuchas, calculado solo en este dispositivo", onOpenStats)
                SettingRow("🪪 Identidad musical", "Nivel de exploración, rachas e historia", { onOpenEco(7) })
                SettingRow("🏆 Logros de JullMood", "${vm.eco.unlocked.size} / ${Achievements.all.size} conseguidos", { onOpenEco(8) })
                SettingRow("📚 Colecciones", "Completados, olvidadas, rescatadas…", { onOpenEco(10) })
            }
        }

        item {
            Group("Personalidad") {
                Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Activar personalidad Juli", fontWeight = FontWeight.Medium)
                        Text("Pequeños comentarios de Juli al pulsar Sorpréndeme y al elegir una canción. Se calculan en tu dispositivo, sin Internet.", color = cs.onSurfaceVariant, fontSize = 13.sp)
                    }
                    Switch(checked = vm.juliPersonality, onCheckedChange = { vm.changeJuliPersonality(it) }, modifier = Modifier.padding(start = 8.dp))
                }
                if (vm.juliPersonality) {
                    ChoiceRow("Personalidad", JuliPersona.values().map { it to "${it.emoji} ${it.label}" }, vm.juliPersona) { vm.changeJuliPersona(it) }
                    Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)) {
                        JuliPersona.values().forEach { p ->
                            Text(
                                "${p.emoji} ${p.label} — ${p.desc}", fontSize = 13.sp,
                                color = if (p == vm.juliPersona) cs.onSurface else cs.onSurfaceVariant,
                                fontWeight = if (p == vm.juliPersona) FontWeight.SemiBold else FontWeight.Normal
                            )
                        }
                    }
                    SettingRow("🥚 Easter Eggs", "${vm.eggs.found.size} / ${vm.eggs.total} descubiertos", onOpenEggs)
                }
            }
        }

        item {
            Group("Letras") {
                Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Always-On Lyrics", fontWeight = FontWeight.Medium)
                        Text("Pantalla completa negra solo con las letras tras un tiempo de reproducción continua. Toca la pantalla para salir.", color = cs.onSurfaceVariant, fontSize = 13.sp)
                    }
                    Switch(checked = vm.alwaysOnEnabled, onCheckedChange = { vm.changeAlwaysOn(it) }, modifier = Modifier.padding(start = 8.dp))
                }
                if (vm.alwaysOnEnabled) ChoiceRow("Activar tras", AlwaysOnTimer.OPTIONS, vm.alwaysOnDelayMs) { vm.changeAlwaysOnDelay(it) }
            }
        }

        item {
            Group("Mood") {
                Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Enriquecer Mood con Internet", fontWeight = FontWeight.Medium)
                        Text("Opcional. Consulta MusicBrainz solo con título y artista (nunca audio ni archivos) y guarda el resultado en el dispositivo. Sin esto, el Mood usa los metadatos locales.", color = cs.onSurfaceVariant, fontSize = 13.sp)
                    }
                    Switch(checked = vm.moodOnline, onCheckedChange = { vm.changeMoodOnline(it) }, modifier = Modifier.padding(start = 8.dp))
                }
            }
        }

        item {
            Group("Datos de canciones") {
                Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Completar canciones sin información", fontWeight = FontWeight.Medium)
                        Text("Opcional. Si una canción tiene un nombre poco claro y no tiene carátula (o tiene una genérica, como un fotograma de vídeo), busca una coincidencia clara en MusicBrainz (solo título, artista y duración; nunca audio ni archivos) y corrige título, artista, álbum y carátula dentro de la app. Tus archivos no se modifican.", color = cs.onSurfaceVariant, fontSize = 13.sp)
                    }
                    Switch(checked = vm.autoFixOnline, onCheckedChange = { vm.changeAutoFixOnline(it) }, modifier = Modifier.padding(start = 8.dp))
                }
                if (vm.fixStatus.isNotEmpty()) Text(vm.fixStatus, color = cs.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                SettingRow("Revisar ahora", "Busca de nuevo coincidencias para las canciones con nombre vago") { vm.runFixNow() }
                val fixedCount = vm.songs.count { it.autoFixed }
                if (fixedCount > 0) SettingRow("Deshacer correcciones automáticas", "Vuelve a los datos originales de $fixedCount canciones") { vm.revertAllFixes() }
            }
        }

        item {
            Group("Biblioteca") {
                SettingRow("Carpeta de música", vm.musicFolder?.let { FolderScanner.label(it) } ?: "Toda la música del dispositivo") { folderPicker.launch(null) }
                if (vm.musicFolder != null) SettingRow("Usar toda la música del dispositivo", "Deja de limitar la biblioteca a una carpeta") { vm.chooseMusicFolder(null) }
                SettingRow("Reescanear biblioteca", "Busca canciones nuevas en la carpeta elegida") { vm.loadSongs() }
                SettingRow("Borrar historial de escucha", "Reinicia las recomendaciones y las estadísticas") { confirmReset = true }
                if (vm.manualMoods.isNotEmpty()) SettingRow("Restablecer Moods manuales", "Vuelve a la clasificación automática en ${vm.manualMoods.size} canciones") { confirmMoods = true }
            }
        }

        item {
            Group("Acerca de") {
                Text(
                    "JullMood funciona sin conexión. Tus recomendaciones se calculan en este dispositivo a partir de tu biblioteca y tu historial. Solo si hay Internet se consultan, con título y artista, las letras (LRCLIB) y, si lo dejas activado, datos públicos de género y la información de canciones sin datos o sin carátula (MusicBrainz); lo obtenido se guarda localmente.",
                    color = cs.onSurfaceVariant, fontSize = 13.sp, modifier = Modifier.padding(16.dp)
                )
            }
        }
    }

    if (editName) {
        var text by remember { mutableStateOf(vm.userName) }
        AlertDialog(
            onDismissRequest = { editName = false },
            containerColor = cs.surface,
            title = { Text("Tu perfil") },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.clickable { photoPicker.launch("image/*") }) { Avatar(vm, 88.dp, 34) }
                    Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 8.dp)) {
                        TextButton(onClick = { photoPicker.launch("image/*") }) { Text(if (vm.userPhoto == null) "Añadir foto" else "Cambiar foto") }
                        if (vm.userPhoto != null) TextButton(onClick = { vm.changeUserPhoto(null) }) { Text("Quitar") }
                    }
                    OutlinedTextField(text, { if (it.length <= 24) text = it }, label = { Text("Tu nombre") }, singleLine = true, shape = uiShape(16.dp))
                }
            },
            confirmButton = { TextButton(onClick = { vm.changeUserName(text); editName = false }, enabled = text.isNotBlank()) { Text("Guardar") } },
            dismissButton = { TextButton(onClick = { editName = false }) { Text("Cancelar") } }
        )
    }
    if (confirmMoods) AlertDialog(
        onDismissRequest = { confirmMoods = false },
        containerColor = cs.surface,
        title = { Text("¿Restablecer Moods?") },
        text = { Text("Se olvidarán los Moods que elegiste a mano y se usará la clasificación automática.") },
        confirmButton = { TextButton(onClick = { vm.clearManualMoods(); confirmMoods = false }) { Text("Restablecer") } },
        dismissButton = { TextButton(onClick = { confirmMoods = false }) { Text("Cancelar") } }
    )
    if (confirmReset) AlertDialog(
        onDismissRequest = { confirmReset = false },
        containerColor = cs.surface,
        title = { Text("¿Borrar historial?") },
        text = { Text("Se olvidarán las reproducciones y las estadísticas, y las recomendaciones volverán a empezar. Tus favoritos y listas no se tocan.") },
        confirmButton = { TextButton(onClick = { vm.clearHistory(); confirmReset = false }) { Text("Borrar") } },
        dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancelar") } }
    )
}

@Composable
private fun Group(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.padding(horizontal = 20.dp).padding(top = LocalUi.current.d(22.dp))) {
        Text(title, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
        Column(Modifier.fillMaxWidth().clip(uiShape(24.dp)).background(MaterialTheme.colorScheme.surface), content = content)
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(16.dp)) {
        Text(title, fontWeight = FontWeight.Medium)
        Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
    }
}

/** Selector sencillo de una opción entre pocas (densidad, forma, animaciones). */
@Composable
private fun <T> ChoiceRow(title: String, options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 14.dp)) {
        Text(title, fontWeight = FontWeight.Medium, modifier = Modifier.padding(bottom = 8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (value, label) ->
                val on = value == selected
                Box(
                    Modifier.weight(1f).clip(uiShape(14.dp))
                        .background(if (on) cs.primary else cs.surfaceVariant)
                        .clickable { onSelect(value) }.padding(vertical = 10.dp),
                    Alignment.Center
                ) {
                    Text(label, color = if (on) cs.onPrimary else cs.onSurface, fontSize = 13.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal, maxLines = 1)
                }
            }
        }
    }
}

/** Mini maqueta del tema: fondo, tarjeta, acento y barra de navegación. */
@Composable
private fun ThemeTile(t: AppTheme, selected: Boolean, dyn: androidx.compose.ui.graphics.Color?, custom: CustomTheme, modifier: Modifier, onClick: () -> Unit) {
    val sc = remember(t, dyn, custom) { buildScheme(t, dyn ?: AppTheme.DYNAMIC.accent, custom) }
    val shape = uiShape(20.dp)
    Column(modifier.pressable(onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(0.85f).clip(shape).background(sc.background)
                .border(if (selected) 3.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant, shape)
                .padding(10.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.fillMaxWidth().height(30.dp).clip(uiShape(10.dp)).background(sc.surface))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(Modifier.size(20.dp).clip(CircleShape).background(sc.primary))
                    Box(Modifier.weight(1f).height(8.dp).clip(uiShape(4.dp)).background(sc.surfaceVariant))
                }
            }
            Box(Modifier.align(Alignment.BottomStart).fillMaxWidth(0.55f).height(10.dp).clip(uiShape(5.dp)).background(sc.primary))
            if (selected) Box(Modifier.align(Alignment.BottomEnd).size(22.dp).clip(CircleShape).background(sc.primary), Alignment.Center) {
                Icon(painterResource(R.drawable.ic_check), null, tint = sc.onPrimary, modifier = Modifier.size(14.dp))
            }
        }
        Text(t.label, fontSize = 13.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp))
    }
}


/** Foto de perfil (si hay) o la inicial del nombre sobre el color de acento. */
@Composable
private fun Avatar(vm: PlayerViewModel, size: Dp, letterSp: Int) {
    val cs = MaterialTheme.colorScheme
    val photo = vm.userPhoto
    Box(Modifier.size(size).clip(CircleShape).background(cs.primary), Alignment.Center) {
        if (photo != null) Image(photo.asImageBitmap(), "Foto de perfil", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(vm.userName.take(1).uppercase(), color = cs.onPrimary, fontWeight = FontWeight.Bold, fontSize = letterSp.sp)
    }
}

/** Editor del tema "Personalizado": elige qué color cambiar y ajústalo con sliders o con un código hex. */
@Composable
private fun CustomThemeEditor(vm: PlayerViewModel) {
    val cs = MaterialTheme.colorScheme
    val parts = listOf("Acento", "Fondo", "Tarjetas", "Texto")
    var part by remember { mutableIntStateOf(0) }
    var version by remember { mutableIntStateOf(0) }      // fuerza releer los sliders tras restablecer
    fun get(i: Int, t: CustomTheme) = when (i) { 0 -> t.accent; 1 -> t.background; 2 -> t.surface; else -> t.text }
    fun put(i: Int, t: CustomTheme, v: Int) = when (i) {
        0 -> t.copy(accent = v); 1 -> t.copy(background = v); 2 -> t.copy(surface = v); else -> t.copy(text = v)
    }
    val current = get(part, vm.customTheme)
    val init = remember(part, version) { FloatArray(3).also { android.graphics.Color.colorToHSV(current, it) } }
    var hue by remember(part, version) { mutableFloatStateOf(init[0]) }
    var sat by remember(part, version) { mutableFloatStateOf(init[1]) }
    var value by remember(part, version) { mutableFloatStateOf(init[2]) }
    var hex by remember(part, version, current) { mutableStateOf("%06X".format(current and 0xFFFFFF)) }
    fun push() { vm.changeCustomTheme(put(part, vm.customTheme, Color.hsv(hue, sat, value).toArgb())) }

    Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 14.dp)) {
        Text("Tus colores", fontWeight = FontWeight.Medium, modifier = Modifier.padding(bottom = 8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            parts.forEachIndexed { i, label ->
                val on = i == part
                Row(
                    Modifier.weight(1f).clip(uiShape(14.dp)).background(if (on) cs.primary else cs.surfaceVariant)
                        .clickable { part = i }.padding(vertical = 10.dp, horizontal = 4.dp),
                    horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(12.dp).clip(CircleShape).background(Color(get(i, vm.customTheme))).border(1.dp, if (on) cs.onPrimary else cs.outline, CircleShape))
                    Text(label, color = if (on) cs.onPrimary else cs.onSurface, fontSize = 12.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal, maxLines = 1, modifier = Modifier.padding(start = 4.dp))
                }
            }
        }
        val thumb = Color.hsv(hue, sat, value)
        val colors = SliderDefaults.colors(thumbColor = thumb, activeTrackColor = thumb)
        Text("Tono", fontSize = 13.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 10.dp))
        Slider(hue, { hue = it; push() }, valueRange = 0f..360f, colors = colors)
        Text("Saturación", fontSize = 13.sp, color = cs.onSurfaceVariant)
        Slider(sat, { sat = it; push() }, valueRange = 0f..1f, colors = colors)
        Text("Brillo", fontSize = 13.sp, color = cs.onSurfaceVariant)
        Slider(value, { value = it; push() }, valueRange = 0f..1f, colors = colors)
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) {
            OutlinedTextField(
                hex,
                { s ->
                    val t = s.uppercase().filter { it in "0123456789ABCDEF" }.take(6)
                    hex = t
                    if (t.length == 6) {
                        val argb = 0xFF000000.toInt() or t.toInt(16)
                        val hsv = FloatArray(3).also { android.graphics.Color.colorToHSV(argb, it) }
                        hue = hsv[0]; sat = hsv[1]; value = hsv[2]
                        vm.changeCustomTheme(put(part, vm.customTheme, argb))
                    }
                },
                label = { Text("Código hex") }, prefix = { Text("#") }, singleLine = true,
                shape = uiShape(16.dp), modifier = Modifier.weight(1f)
            )
            TextButton(onClick = { vm.changeCustomTheme(CustomTheme()); version++ }, modifier = Modifier.padding(start = 8.dp)) { Text("Restablecer") }
        }
    }
}
