package com.example.musicplayer

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.drawable.ColorDrawable
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import kotlin.math.abs

/** Temas completos: cada uno define fondo, superficies, acento, contenedores y textos. */
enum class AppTheme(val label: String, val accent: Color, val light: Boolean = false) {
    DARK("Oscuro", Color(0xFF8EA8FF)),
    AMOLED("AMOLED", Color(0xFF5EEAD4)),
    LIGHT("Claro", Color(0xFF5B5BD6), true),
    PURPLE("Púrpura", Color(0xFFB388FF)),
    BLUE("Azul", Color(0xFF4DA3FF)),
    RED("Rojo", Color(0xFFFF5A6A)),
    GREEN("Verde", Color(0xFF3DDC97)),
    PINK("Rosa", Color(0xFFFF7EB6)),
    ORANGE("Naranja", Color(0xFFFF9F43)),
    DYNAMIC("Dinámico", Color(0xFFB388FF)),
    CUSTOM("Personalizado", Color(0xFFFF7EB6))   // siempre el último: usa los colores de CustomTheme
}

/** Colores elegidos por la persona para el tema "Personalizado" (ARGB). */
data class CustomTheme(
    val accent: Int = 0xFFFF7EB6.toInt(),
    val background: Int = 0xFF14101A.toInt(),
    val surface: Int = 0xFF211A2B.toInt(),
    val text: Int = 0xFFF4EEF9.toInt()
)

fun onColorFor(c: Color): Color = if (c.luminance() > 0.5f) Color(0xFF101014) else Color.White

// ---------- Personalización visual: densidad, forma de tarjetas y animaciones ----------

enum class Density(val label: String) { COMFORTABLE("Cómoda"), COMPACT("Compacta") }

/** `factor` escala los radios de las esquinas: Redondeada = diseño original. */
enum class CardShape(val label: String, val factor: Float) {
    ROUNDED("Redondeada", 1f), SOFT("Suave", 0.55f), RECT("Rectangular", 0.15f)
}

data class UiStyle(
    val density: Density = Density.COMFORTABLE,
    val cardShape: CardShape = CardShape.ROUNDED,
    val reducedMotion: Boolean = false
) {
    /** Los círculos (radio >= 40 dp, p. ej. artistas) no se tocan; el resto sigue la forma elegida. */
    fun radius(base: Dp): Dp = if (base >= 40.dp) base else base * cardShape.factor
    /** Espaciado vertical: en modo compacto se reduce un 25 %. */
    fun d(v: Dp): Dp = if (density == Density.COMPACT) v * 0.75f else v
}

val LocalUi = staticCompositionLocalOf { UiStyle() }

@Composable
fun uiShape(base: Dp): RoundedCornerShape = RoundedCornerShape(LocalUi.current.radius(base))

private fun hueOf(c: Color): Float {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(c.toArgb(), hsv)
    return hsv[0]
}

private fun tint(h: Float, s: Float, v: Float) = Color.hsv(h, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f))

private fun darkScheme(accent: Color, bg: Color, surface: Color, variant: Color, muted: Color, on: Color, container: Color) =
    darkColorScheme(
        primary = accent, onPrimary = onColorFor(accent),
        primaryContainer = container, onPrimaryContainer = on,
        secondary = accent, onSecondary = onColorFor(accent),
        secondaryContainer = container, onSecondaryContainer = on,
        tertiary = accent, onTertiary = onColorFor(accent),
        background = bg, onBackground = on,
        surface = surface, onSurface = on,
        surfaceVariant = variant, onSurfaceVariant = muted,
        outline = muted.copy(alpha = 0.6f), outlineVariant = variant,
        surfaceTint = Color.Transparent
    )

private fun lightScheme(accent: Color, bg: Color, surface: Color, variant: Color, muted: Color, on: Color, container: Color) =
    lightColorScheme(
        primary = accent, onPrimary = onColorFor(accent),
        primaryContainer = container, onPrimaryContainer = on,
        secondary = accent, onSecondary = onColorFor(accent),
        secondaryContainer = container, onSecondaryContainer = on,
        tertiary = accent, onTertiary = onColorFor(accent),
        background = bg, onBackground = on,
        surface = surface, onSurface = on,
        surfaceVariant = variant, onSurfaceVariant = muted,
        outline = muted.copy(alpha = 0.6f), outlineVariant = variant,
        surfaceTint = Color.Transparent
    )

/** Los temas de color (y el dinámico) derivan fondo/superficies del tono del acento. */
fun buildScheme(theme: AppTheme, dynamicAccent: Color, custom: CustomTheme = CustomTheme()): ColorScheme {
    val accent = when (theme) {
        AppTheme.DYNAMIC -> dynamicAccent
        AppTheme.CUSTOM -> Color(custom.accent)
        else -> theme.accent
    }
    val h = hueOf(accent)
    return when (theme) {
        AppTheme.DARK -> darkScheme(accent, Color(0xFF0F1115), Color(0xFF181B22), Color(0xFF252935), Color(0xFFA3A8B8), Color(0xFFEEF0F6), Color(0xFF2B3350))
        AppTheme.AMOLED -> darkScheme(accent, Color.Black, Color(0xFF0C0C0E), Color(0xFF1A1A1E), Color(0xFF9A9AA4), Color.White, Color(0xFF12302C))
        AppTheme.LIGHT -> lightScheme(accent, Color(0xFFF6F5FB), Color.White, Color(0xFFE7E6F2), Color(0xFF5C5B72), Color(0xFF17161F), Color(0xFFE1E0FA))
        AppTheme.CUSTOM -> {
            val bg = Color(custom.background); val sf = Color(custom.surface); val tx = Color(custom.text)
            val variant = lerp(sf, tx, 0.14f)
            val muted = lerp(tx, bg, 0.35f)
            val container = lerp(sf, accent, 0.30f)
            // Fondo claro -> esquema claro; fondo oscuro -> esquema oscuro.
            if (bg.luminance() > 0.5f) lightScheme(accent, bg, sf, variant, muted, tx, container)
            else darkScheme(accent, bg, sf, variant, muted, tx, container)
        }
        else -> darkScheme(
            accent, tint(h, 0.42f, 0.10f), tint(h, 0.38f, 0.15f), tint(h, 0.32f, 0.24f),
            tint(h, 0.16f, 0.76f), tint(h, 0.05f, 0.97f), tint(h, 0.50f, 0.32f)
        )
    }
}

private fun appShapes(style: UiStyle) = Shapes(
    extraSmall = RoundedCornerShape(style.radius(8.dp)),
    small = RoundedCornerShape(style.radius(12.dp)),
    medium = RoundedCornerShape(style.radius(16.dp)),
    large = RoundedCornerShape(style.radius(24.dp)),
    extraLarge = RoundedCornerShape(style.radius(32.dp))
)

@Composable
fun MusicTheme(
    theme: AppTheme, coverAccent: Color?, style: UiStyle = UiStyle(), custom: CustomTheme = CustomTheme(),
    palette: DynamicPalette? = null,   // JullExperience: null = capa apagada (idéntico a la v1.1)
    content: @Composable () -> Unit
) {
    val spec: AnimationSpec<Color> = if (style.reducedMotion) snap() else tween(600)
    val animated by animateColorAsState(coverAccent ?: AppTheme.DYNAMIC.accent, spec, label = "dynAccent")
    val baseScheme = if (theme == AppTheme.DYNAMIC) buildScheme(theme, animated)
    else remember(theme, custom) { buildScheme(theme, theme.accent, custom) }
    // JullExperience: capa opcional sobre el tema elegido (transición suave entre paletas).
    val live = rememberAnimatedPalette(palette, style.reducedMotion)
    val scheme = if (live == null) baseScheme else JullPalette.apply(baseScheme, theme, live)
    val shapes = remember(style.cardShape) { appShapes(style) }

    // Barras del sistema acordes al tema (y iconos claros/oscuros según el fondo).
    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window ?: return@SideEffect
        window.statusBarColor = scheme.background.toArgb()
        window.navigationBarColor = scheme.surface.toArgb()
        window.setBackgroundDrawable(ColorDrawable(scheme.background.toArgb()))
        val light = if (theme == AppTheme.CUSTOM) scheme.background.luminance() > 0.5f else theme.light
        WindowCompat.getInsetsController(window, view).apply {
            isAppearanceLightStatusBars = light
            isAppearanceLightNavigationBars = light
        }
    }
    MaterialTheme(colorScheme = scheme, shapes = shapes) {
        // Surface fija el color de contenido: sin ella los textos sin color explícito (p. ej. el primer
        // inicio) saldrían negros sobre los temas oscuros.
        Surface(Modifier.fillMaxSize(), color = scheme.background, contentColor = scheme.onBackground) {
            CompositionLocalProvider(LocalUi provides style, content = content)
        }
    }
}

/**
 * Acento del reproductor: si está activado, mini reproductor y pantalla completa toman el color
 * predominante de la carátula (en el tema dinámico ya lo hace toda la app).
 */
@Composable
internal fun PlayerAccent(vm: PlayerViewModel, content: @Composable () -> Unit) {
    val a = vm.coverAccent
    // Con Dynamic Experience la paleta ya llega a todo el tema (incluido el reproductor): no se superpone otro acento.
    if (vm.playerAccent && a != null && vm.theme != AppTheme.DYNAMIC && vm.activePalette == null) {
        val spec: AnimationSpec<Color> = if (LocalUi.current.reducedMotion) snap() else tween(500)
        val anim by animateColorAsState(a, spec, label = "playerAccent")
        MaterialTheme(
            colorScheme = MaterialTheme.colorScheme.copy(primary = anim, onPrimary = onColorFor(anim)),
            shapes = MaterialTheme.shapes,
            typography = MaterialTheme.typography,
            content = content
        )
    } else content()
}

/** Extrae el color predominante de una carátula con un histograma de tonos (sin librerías). */
object CoverColors {
    /** Sin carátula, la app pinta un degradado a partir del álbum; el acento usa el mismo tono. */
    fun fallback(seed: String): Color = Color.hsv((abs(seed.hashCode()) % 360).toFloat(), 0.6f, 0.9f)

    fun accent(src: Bitmap): Color? = runCatching {
        val soft = if (src.config == Bitmap.Config.HARDWARE) src.copy(Bitmap.Config.ARGB_8888, false) else src
        val n = 24
        val b = Bitmap.createScaledBitmap(soft, n, n, true)
        val px = IntArray(n * n)
        b.getPixels(px, 0, n, 0, 0, n, n)

        val hsv = FloatArray(3)
        val wSum = DoubleArray(12); val relSum = DoubleArray(12)
        val sSum = DoubleArray(12); val vSum = DoubleArray(12)
        for (p in px) {
            android.graphics.Color.colorToHSV(p, hsv)
            val s = hsv[1]; val v = hsv[2]
            if (s < 0.18f || v < 0.18f) continue          // ignora grises, blancos y negros
            val bin = ((hsv[0] + 15f) / 30f).toInt() % 12
            val w = (s * (0.4f + v)).toDouble()
            wSum[bin] += w
            relSum[bin] += w * (((hsv[0] - bin * 30f + 540f) % 360f) - 180f)
            sSum[bin] += w * s
            vSum[bin] += w * v
        }
        var best = 0
        for (i in 1 until 12) if (wSum[i] > wSum[best]) best = i
        if (wSum[best] < 6.0) return@runCatching null        // carátula casi en escala de grises
        val hue = (best * 30f + (relSum[best] / wSum[best]).toFloat() + 360f) % 360f
        val s = (sSum[best] / wSum[best]).toFloat().coerceIn(0.5f, 0.9f)
        val v = (vSum[best] / wSum[best]).toFloat().coerceIn(0.75f, 0.95f)
        Color.hsv(hue, s, v)
    }.getOrNull()
}
