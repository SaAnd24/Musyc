@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.example.musicplayer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Collections
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private val Gray = Color(0xFFB3B3B3)

private data class Detail(val kind: Int, val name: String) // 0 álbum, 1 artista, 2 lista

// ---------- Raíz ----------

@Composable
fun PlayerApp(vm: PlayerViewModel, onRequestPermission: () -> Unit) {
    var showPlayer by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    var addTarget by remember { mutableStateOf<Song?>(null) }
    var newList by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        Library(vm, onRequestPermission, onOpenPlayer = { showPlayer = true },
            onAdd = { addTarget = it }, onNewList = { newList = true })
        if (showPlayer && vm.current != null) {
            NowPlaying(vm, onClose = { showPlayer = false }, onQueue = { showQueue = true },
                onSleep = { showSleep = true }, onAdd = { addTarget = it })
        }
        if (showQueue) QueueScreen(vm) { showQueue = false }
    }

    if (showSleep) SleepDialog { showSleep = false }
    addTarget?.let { s -> AddToPlaylistDialog(vm, s) { addTarget = null } }
    if (newList) NameDialog(onCreate = { vm.createPlaylist(it) }) { newList = false }
}

// ---------- Biblioteca ----------

@Composable
private fun Library(
    vm: PlayerViewModel, onRequestPermission: () -> Unit,
    onOpenPlayer: () -> Unit, onAdd: (Song) -> Unit, onNewList: () -> Unit
) {
    val tabs = listOf("Canciones", "Álbumes", "Artistas", "Favoritos", "Listas")
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var detail by remember { mutableStateOf<Detail?>(null) }
    BackHandler(enabled = detail != null) { detail = null }

    val albums = remember(vm.songs, vm.query) { vm.filtered.groupBy { it.album } }
    val artists = remember(vm.songs, vm.query) { vm.filtered.groupBy { it.artist } }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = { if (vm.current != null) MiniBar(vm, onOpenPlayer) }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Mi música", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                TextButton(onClick = { vm.loadSongs() }) { Text("Reescanear") }
            }
            OutlinedTextField(
                value = vm.query, onValueChange = { vm.query = it },
                placeholder = { Text("Buscar canciones, artistas o álbumes") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            )
            if (!vm.hasPermission) {
                Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Se necesita permiso para leer tu música", color = Gray)
                        Button(onClick = onRequestPermission, modifier = Modifier.padding(top = 12.dp)) {
                            Text("Conceder permiso")
                        }
                    }
                }
                return@Column
            }
            if (vm.loading) { Empty("Escaneando…"); return@Column }

            val d = detail
            if (d != null) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconBtn(R.drawable.ic_down, "Volver", rotate = true) { detail = null }
                    Text(d.name, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                val list = when (d.kind) {
                    0 -> vm.songs.filter { it.album == d.name }
                    1 -> vm.songs.filter { it.artist == d.name }
                    else -> vm.playlistSongs(d.name)
                }
                SongList(vm, list, onAdd, onRemove = if (d.kind == 2) ({ s: Song -> vm.removeFromPlaylist(d.name, s.id) }) else null)
                return@Column
            }

            ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp, containerColor = Color.Transparent) {
                tabs.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
            }
            when (tab) {
                0 -> SongList(vm, vm.filtered, onAdd)
                1 -> GroupList(albums) { detail = Detail(0, it) }
                2 -> GroupList(artists) { detail = Detail(1, it) }
                3 -> SongList(vm, vm.songs.filter { it.id in vm.favorites }, onAdd, emptyText = "Toca el ♥ en una canción para añadirla")
                else -> Column {
                    TextButton(onClick = onNewList, modifier = Modifier.padding(horizontal = 8.dp)) { Text("+ Nueva lista") }
                    if (vm.playlists.isEmpty()) Empty("Aún no tienes listas")
                    LazyColumn {
                        items(vm.playlists.keys.toList(), key = { it }) { name ->
                            Row(
                                Modifier.fillMaxWidth().clickable { detail = Detail(2, name) }.padding(start = 16.dp, top = 4.dp, bottom = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(painterResource(R.drawable.ic_queue), null, tint = Gray, modifier = Modifier.size(28.dp))
                                Column(Modifier.weight(1f).padding(start = 16.dp)) {
                                    Text(name, fontWeight = FontWeight.Medium)
                                    Text("${vm.playlists[name].orEmpty().size} canciones", color = Gray, fontSize = 13.sp)
                                }
                                IconBtn(R.drawable.ic_delete, "Eliminar lista", Gray) { vm.deletePlaylist(name) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Empty(text: String) =
    Box(Modifier.fillMaxWidth().padding(32.dp), Alignment.Center) { Text(text, color = Gray) }

@Composable
private fun SongList(
    vm: PlayerViewModel, list: List<Song>, onAdd: (Song) -> Unit,
    onRemove: ((Song) -> Unit)? = null, emptyText: String = "No hay canciones"
) {
    if (list.isEmpty()) { Empty(emptyText); return }
    LazyColumn(Modifier.fillMaxSize()) {
        items(list, key = { it.id }) { SongRow(vm, it, list, onAdd, onRemove) }
    }
}

@Composable
private fun GroupList(groups: Map<String, List<Song>>, onClick: (String) -> Unit) {
    if (groups.isEmpty()) { Empty("No hay resultados"); return }
    LazyColumn(Modifier.fillMaxSize()) {
        items(groups.keys.sortedBy { it.lowercase() }, key = { it }) { name ->
            val songs = groups.getValue(name)
            Row(
                Modifier.fillMaxWidth().clickable { onClick(name) }.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Cover(songs.first(), Modifier.size(52.dp))
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    Text("${songs.size} canciones", color = Gray, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun SongRow(vm: PlayerViewModel, song: Song, context: List<Song>, onAdd: (Song) -> Unit, onRemove: ((Song) -> Unit)?) {
    val selected = song.id.toString() == vm.currentId
    val fav = song.id in vm.favorites
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clickable { vm.playSong(song, context) }.padding(start = 16.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Cover(song, Modifier.size(52.dp))
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(
                song.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (selected) MaterialTheme.colorScheme.primary else Color.White, fontWeight = FontWeight.Medium
            )
            Text("${song.artist} · ${song.album}", maxLines = 1, overflow = TextOverflow.Ellipsis, color = Gray, fontSize = 13.sp)
        }
        IconBtn(if (fav) R.drawable.ic_heart else R.drawable.ic_heart_outline, "Favorito",
            if (fav) MaterialTheme.colorScheme.primary else Gray) { vm.toggleFavorite(song.id) }
        Box {
            IconBtn(R.drawable.ic_more, "Más", Gray) { menu = true }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Reproducir siguiente") }, onClick = { menu = false; vm.playNext(song) })
                DropdownMenuItem(text = { Text("Añadir a la cola") }, onClick = { menu = false; vm.addToQueue(song) })
                DropdownMenuItem(text = { Text("Añadir a una lista") }, onClick = { menu = false; onAdd(song) })
                if (onRemove != null)
                    DropdownMenuItem(text = { Text("Quitar de esta lista") }, onClick = { menu = false; onRemove(song) })
            }
        }
    }
}

// ---------- Barra mini ----------

@Composable
private fun MiniBar(vm: PlayerViewModel, onOpen: () -> Unit) {
    val song = vm.current ?: return
    val frac = if (vm.duration > 0) (vm.position.toFloat() / vm.duration).coerceIn(0f, 1f) else 0f
    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).clickable(onClick = onOpen)) {
        Box(Modifier.fillMaxWidth().height(2.dp).background(Color(0xFF3A3A3A))) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(MaterialTheme.colorScheme.primary))
        }
        Row(Modifier.padding(start = 12.dp, top = 6.dp, bottom = 6.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Cover(song, Modifier.size(44.dp))
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Text(song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Gray, fontSize = 13.sp)
            }
            IconBtn(if (vm.isPlaying) R.drawable.ic_pause else R.drawable.ic_play, "Play/Pausa", size = 30.dp) { vm.togglePlay() }
            IconBtn(R.drawable.ic_next, "Siguiente") { vm.next() }
        }
    }
}

// ---------- Pantalla completa ----------

@Composable
private fun NowPlaying(vm: PlayerViewModel, onClose: () -> Unit, onQueue: () -> Unit, onSleep: () -> Unit, onAdd: (Song) -> Unit) {
    val song = vm.current ?: return
    BackHandler(onBack = onClose)
    var drag by remember { mutableStateOf<Float?>(null) }
    val accent = MaterialTheme.colorScheme.primary
    val fav = song.id in vm.favorites
    val left = SleepTimer.leftMs

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(horizontal = 24.dp, vertical = 8.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(R.drawable.ic_down, "Cerrar", onClick = onClose)
            Text("Reproduciendo", Modifier.weight(1f), color = Gray, fontSize = 14.sp)
            IconBtn(R.drawable.ic_queue, "Añadir a lista", Gray) { onAdd(song) }
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp), Alignment.Center) {
            Cover(song, Modifier.fillMaxWidth().aspectRatio(1f), px = 700, radius = 12.dp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Gray)
            }
            IconBtn(if (fav) R.drawable.ic_heart else R.drawable.ic_heart_outline, "Favorito",
                if (fav) accent else Color.White, 28.dp) { vm.toggleFavorite(song.id) }
        }
        Slider(
            value = drag ?: vm.position.toFloat(),
            onValueChange = { drag = it },
            onValueChangeFinished = { drag?.let { vm.seekTo(it.toLong()) }; drag = null },
            valueRange = 0f..max(vm.duration, 1L).toFloat()
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime((drag ?: vm.position.toFloat()).toLong()), color = Gray, fontSize = 12.sp)
            Text(formatTime(vm.duration), color = Gray, fontSize = 12.sp)
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconBtn(R.drawable.ic_shuffle, "Aleatorio", if (vm.shuffle) accent else Gray, 26.dp) { vm.toggleShuffle() }
            IconBtn(R.drawable.ic_prev, "Anterior", size = 36.dp) { vm.previous() }
            FilledIconButton(onClick = { vm.togglePlay() }, modifier = Modifier.size(72.dp)) {
                Icon(painterResource(if (vm.isPlaying) R.drawable.ic_pause else R.drawable.ic_play), "Play/Pausa", Modifier.size(40.dp))
            }
            IconBtn(R.drawable.ic_next, "Siguiente", size = 36.dp) { vm.next() }
            IconBtn(
                if (vm.repeatMode == Player.REPEAT_MODE_ONE) R.drawable.ic_repeat_one else R.drawable.ic_repeat,
                "Repetir", if (vm.repeatMode != Player.REPEAT_MODE_OFF) accent else Gray, 26.dp
            ) { vm.cycleRepeat() }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onSleep) {
                Icon(painterResource(R.drawable.ic_timer), null, tint = if (left > 0) accent else Gray, modifier = Modifier.size(22.dp))
                Text(if (left > 0) "  " + formatTime(left) else "  Dormir", color = if (left > 0) accent else Gray)
            }
            TextButton(onClick = onQueue) {
                Icon(painterResource(R.drawable.ic_queue), null, tint = Gray, modifier = Modifier.size(22.dp))
                Text("  Cola", color = Gray)
            }
        }
    }
}

// ---------- Cola ----------

@Composable
private fun QueueScreen(vm: PlayerViewModel, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Row(Modifier.fillMaxWidth().padding(end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(R.drawable.ic_down, "Cerrar", onClick = onClose)
            Text("Cola de reproducción", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("${vm.queue.size}", color = Gray)
        }
        if (vm.queue.isEmpty()) Empty("La cola está vacía")
        LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(vm.queue) { i, s ->
                val now = i == vm.currentIndex
                Row(
                    Modifier.fillMaxWidth().clickable { vm.playQueueIndex(i) }.padding(start = 16.dp, top = 2.dp, bottom = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Cover(s, Modifier.size(44.dp))
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = if (now) MaterialTheme.colorScheme.primary else Color.White)
                        Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Gray, fontSize = 13.sp)
                    }
                    if (i > 0) IconBtn(R.drawable.ic_up, "Subir", Gray, 20.dp) { vm.moveQueue(i, i - 1) } else Spacer(Modifier.size(48.dp))
                    if (i < vm.queue.lastIndex) IconBtn(R.drawable.ic_arrow_down, "Bajar", Gray, 20.dp) { vm.moveQueue(i, i + 1) } else Spacer(Modifier.size(48.dp))
                    IconBtn(R.drawable.ic_close, "Quitar", Gray, 20.dp) { vm.removeFromQueue(i) }
                }
            }
        }
    }
}

// ---------- Diálogos ----------

@Composable
private fun SleepDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Temporizador para dormir") },
        text = {
            Column {
                if (SleepTimer.leftMs > 0) Text("Se detendrá en ${formatTime(SleepTimer.leftMs)}", color = MaterialTheme.colorScheme.primary)
                listOf(5, 15, 30, 45, 60, 90).forEach { m ->
                    TextButton(onClick = { SleepTimer.start(m); onDismiss() }) { Text("$m minutos") }
                }
                if (SleepTimer.leftMs > 0) TextButton(onClick = { SleepTimer.cancel(); onDismiss() }) { Text("Cancelar temporizador") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }
    )
}

@Composable
private fun AddToPlaylistDialog(vm: PlayerViewModel, song: Song, onDismiss: () -> Unit) {
    var creating by remember { mutableStateOf(false) }
    if (creating) { NameDialog(onCreate = { vm.createPlaylist(it, song.id) }) { creating = false; onDismiss() }; return }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Añadir a una lista") },
        text = {
            LazyColumn {
                item { TextButton(onClick = { creating = true }) { Text("+ Nueva lista") } }
                items(vm.playlists.keys.toList(), key = { it }) { n ->
                    TextButton(onClick = { vm.addToPlaylist(n, song.id); onDismiss() }) { Text(n) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }
    )
}

@Composable
private fun NameDialog(onCreate: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nueva lista") },
        text = { OutlinedTextField(name, { name = it }, singleLine = true, placeholder = { Text("Nombre") }) },
        confirmButton = { TextButton(onClick = { onCreate(name); onDismiss() }, enabled = name.isNotBlank()) { Text("Crear") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

// ---------- Componentes ----------

@Composable
private fun IconBtn(res: Int, desc: String, tint: Color = Color.White, size: Dp = 24.dp, rotate: Boolean = false, onClick: () -> Unit) {
    IconButton(onClick = onClick) {
        Icon(
            painterResource(res), desc, tint = tint,
            modifier = Modifier.size(size).then(if (rotate) Modifier.rotate(90f) else Modifier)
        )
    }
}

@Composable
fun Cover(song: Song, modifier: Modifier = Modifier, px: Int = 256, radius: Dp = 6.dp) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, song.id, px) {
        value = null
        value = withContext(Dispatchers.IO) { ArtCache.load(ctx, song, px) }
    }
    Box(modifier.clip(RoundedCornerShape(radius)), Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else DefaultCover(song.album)
    }
}

/** Carátula por defecto: degradado único por álbum + nota musical. */
@Composable
private fun DefaultCover(seed: String) {
    val hue = (abs(seed.hashCode()) % 360).toFloat()
    Box(
        Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(Color.hsv(hue, 0.45f, 0.45f), Color.hsv((hue + 40) % 360, 0.55f, 0.22f)))
        ),
        Alignment.Center
    ) {
        Icon(painterResource(R.drawable.ic_note), null, tint = Color.White.copy(alpha = 0.75f), modifier = Modifier.fillMaxSize(0.45f))
    }
}

/** Busca carátula: miniatura del sistema → imagen incrustada en el archivo → null (se usa la de por defecto). */
object ArtCache {
    private val cache = LruCache<String, Bitmap>(60)
    private val missing: MutableSet<String> = Collections.synchronizedSet(HashSet())

    fun load(ctx: Context, song: Song, px: Int): Bitmap? {
        val key = "${song.id}:$px"
        cache.get(key)?.let { return it }
        if (key in missing) return null
        val bmp = runCatching {
            if (Build.VERSION.SDK_INT >= 29) ctx.contentResolver.loadThumbnail(song.uri, Size(px, px), null)
            else ctx.contentResolver.openInputStream(song.artUri)?.use { BitmapFactory.decodeStream(it) }
        }.getOrNull() ?: embedded(ctx, song, px)
        if (bmp != null) cache.put(key, bmp) else missing.add(key)
        return bmp
    }

    private fun embedded(ctx: Context, song: Song, px: Int): Bitmap? = runCatching {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, song.uri)
            val b = r.embeddedPicture ?: return@runCatching null
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(b, 0, b.size, o)
            o.inSampleSize = max(1, min(o.outWidth, o.outHeight) / px)
            o.inJustDecodeBounds = false
            BitmapFactory.decodeByteArray(b, 0, b.size, o)
        } finally { r.release() }
    }.getOrNull()
}

fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(total / 60, total % 60)
}
