package com.example.musicplayer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Collections

private val Gray = Color(0xFFB3B3B3)

@Composable
fun PlayerApp(vm: PlayerViewModel, onRequestPermission: () -> Unit) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = { if (vm.current != null) PlayerBar(vm) }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Mi música", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                TextButton(onClick = { vm.loadSongs() }) { Text("Reescanear") }
            }
            OutlinedTextField(
                value = vm.query,
                onValueChange = { vm.query = it },
                placeholder = { Text("Buscar canciones, artistas o álbumes") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            )
            when {
                !vm.hasPermission -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Se necesita permiso para leer tu música", color = Gray)
                        Button(onClick = onRequestPermission, modifier = Modifier.padding(top = 12.dp)) {
                            Text("Conceder permiso")
                        }
                    }
                }
                vm.loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text("Escaneando…", color = Gray) }
                vm.filtered.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Text("No hay canciones", color = Gray)
                }
                else -> LazyColumn(Modifier.fillMaxSize()) {
                    items(vm.filtered, key = { it.id }) { song ->
                        SongRow(song, song.id.toString() == vm.currentId) { vm.playSong(song) }
                    }
                }
            }
        }
    }
}

@Composable
fun SongRow(song: Song, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Cover(song, 52.dp)
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(
                song.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (selected) MaterialTheme.colorScheme.primary else Color.White,
                fontWeight = FontWeight.Medium
            )
            Text(
                "${song.artist} · ${song.album}", maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = Gray, fontSize = 13.sp
            )
        }
        Text(formatTime(song.durationMs), color = Gray, fontSize = 12.sp)
    }
}

@Composable
fun PlayerBar(vm: PlayerViewModel) {
    val song = vm.current ?: return
    var drag by remember { mutableStateOf<Float?>(null) }
    val accent = MaterialTheme.colorScheme.primary

    Column(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Cover(song, 48.dp)
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Text(song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Gray, fontSize = 13.sp)
            }
        }
        Slider(
            value = drag ?: vm.position.toFloat(),
            onValueChange = { drag = it },
            onValueChangeFinished = { drag?.let { vm.seekTo(it.toLong()) }; drag = null },
            valueRange = 0f..maxOf(vm.duration, 1L).toFloat()
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime((drag ?: vm.position.toFloat()).toLong()), color = Gray, fontSize = 12.sp)
            Text(formatTime(vm.duration), color = Gray, fontSize = 12.sp)
        }
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { vm.toggleShuffle() }) {
                Text("⇄", fontSize = 24.sp, color = if (vm.shuffle) accent else Gray)
            }
            TextButton(onClick = { vm.previous() }) { Text("⏮", fontSize = 26.sp, color = Color.White) }
            Button(onClick = { vm.togglePlay() }) {
                Text(if (vm.isPlaying) "⏸" else "▶", fontSize = 24.sp)
            }
            TextButton(onClick = { vm.next() }) { Text("⏭", fontSize = 26.sp, color = Color.White) }
            TextButton(onClick = { vm.cycleRepeat() }) {
                val on = vm.repeatMode != Player.REPEAT_MODE_OFF
                Text(
                    if (vm.repeatMode == Player.REPEAT_MODE_ONE) "⟳¹" else "⟳",
                    fontSize = 24.sp, color = if (on) accent else Gray
                )
            }
        }
    }
}

@Composable
fun Cover(song: Song, size: Dp) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, song.id) {
        value = withContext(Dispatchers.IO) { ArtCache.load(ctx, song) }
    }
    Box(
        Modifier.size(size).clip(RoundedCornerShape(6.dp)).background(Color(0xFF2A2A2A)),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Text("♪", color = Gray, fontSize = 20.sp)
        }
    }
}

object ArtCache {
    private val cache = LruCache<Long, Bitmap>(80)
    private val missing: MutableSet<Long> = Collections.synchronizedSet(HashSet())

    fun load(ctx: Context, song: Song): Bitmap? {
        val key = if (song.albumId > 0) song.albumId else -song.id
        cache.get(key)?.let { return it }
        if (key in missing) return null
        val bmp = runCatching {
            if (Build.VERSION.SDK_INT >= 29) {
                ctx.contentResolver.loadThumbnail(song.uri, Size(256, 256), null)
            } else {
                ctx.contentResolver.openInputStream(song.artUri)?.use { BitmapFactory.decodeStream(it) }
            }
        }.getOrNull()
        if (bmp != null) cache.put(key, bmp) else missing.add(key)
        return bmp
    }
}

fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(total / 60, total % 60)
}
