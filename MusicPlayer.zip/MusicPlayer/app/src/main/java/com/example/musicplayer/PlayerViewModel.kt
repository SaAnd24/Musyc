package com.example.musicplayer

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("player", Context.MODE_PRIVATE)
    private var byId = emptyMap<Long, Song>()
    private var restored = false

    var favorites by mutableStateOf(readIds("fav")); private set
    var playlists by mutableStateOf(readPlaylists()); private set
    var queue by mutableStateOf<List<Song>>(emptyList()); private set
    var currentIndex by mutableIntStateOf(0); private set

    var songs by mutableStateOf<List<Song>>(emptyList()); private set
    var hasPermission by mutableStateOf(false); private set
    var loading by mutableStateOf(false); private set
    var query by mutableStateOf("")

    var isPlaying by mutableStateOf(false); private set
    var currentId by mutableStateOf<String?>(null); private set
    var position by mutableLongStateOf(0L); private set
    var duration by mutableLongStateOf(0L); private set
    var shuffle by mutableStateOf(false); private set
    var repeatMode by mutableIntStateOf(Player.REPEAT_MODE_OFF); private set

    private var controller: MediaController? = null

    val filtered: List<Song>
        get() {
            val q = query.trim()
            if (q.isEmpty()) return songs
            return songs.filter {
                it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true)
            }
        }

    val current: Song?
        get() = songs.firstOrNull { it.id.toString() == currentId }

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) =
            sync(player, events.contains(Player.EVENT_TIMELINE_CHANGED))
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            runCatching { future.get() }.getOrNull()?.let {
                controller = it
                it.addListener(listener)
                sync(it, true)
                tryRestore()
            }
        }, ContextCompat.getMainExecutor(app))

        var ticks = 0
        viewModelScope.launch {
            while (true) {
                controller?.let {
                    position = it.currentPosition
                    if (it.duration != C.TIME_UNSET) duration = it.duration
                }
                if (++ticks % 10 == 0 && isPlaying) saveState()
                delay(500)
            }
        }
    }

    private fun sync(p: Player, rebuildQueue: Boolean = false) {
        currentIndex = p.currentMediaItemIndex
        if (rebuildQueue) queue = List(p.mediaItemCount) { p.getMediaItemAt(it).mediaId.toLongOrNull() }
            .mapNotNull { byId[it] }
        isPlaying = p.isPlaying
        currentId = p.currentMediaItem?.mediaId
        duration = if (p.duration == C.TIME_UNSET) 0L else p.duration
        shuffle = p.shuffleModeEnabled
        repeatMode = p.repeatMode
        saveState()
    }

    fun loadSongs() {
        val ctx = getApplication<Application>()
        val granted = ContextCompat.checkSelfPermission(ctx, storagePermission()) ==
            PackageManager.PERMISSION_GRANTED
        hasPermission = granted
        if (!granted) return
        viewModelScope.launch {
            loading = true
            songs = withContext(Dispatchers.IO) { MusicRepository.load(ctx) }
            byId = songs.associateBy { it.id }
            loading = false
            controller?.let { sync(it, true) }
            tryRestore()
        }
    }

    private fun Song.toMediaItem() = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(artUri)
                .build()
        )
        .build()

    fun playSong(song: Song, list: List<Song> = filtered) {
        val c = controller ?: return
        val index = list.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
        c.setMediaItems(list.map { it.toMediaItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else {
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            c.play()
        }
    }

    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPrevious() }
    fun seekTo(ms: Long) { controller?.seekTo(ms); position = ms }

    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }

    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    // ---- Cola ----
    fun playNext(s: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) playSong(s, listOf(s)) else c.addMediaItem(c.currentMediaItemIndex + 1, s.toMediaItem())
    }
    fun addToQueue(s: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) playSong(s, listOf(s)) else c.addMediaItem(s.toMediaItem())
    }
    fun moveQueue(from: Int, to: Int) { controller?.moveMediaItem(from, to) }
    fun removeFromQueue(i: Int) { controller?.removeMediaItem(i) }
    fun playQueueIndex(i: Int) { controller?.let { it.seekTo(i, 0L); it.play() } }

    // ---- Favoritos y listas ----
    fun toggleFavorite(id: Long) {
        favorites = if (id in favorites) favorites - id else favorites + id
        prefs.edit().putString("fav", favorites.joinToString(",")).apply()
    }
    fun createPlaylist(name: String, firstId: Long? = null) {
        val n = name.trim()
        if (n.isEmpty() || n in playlists) { firstId?.let { addToPlaylist(n, it) }; return }
        playlists = playlists + (n to listOfNotNull(firstId)); savePlaylists()
    }
    fun addToPlaylist(name: String, id: Long) {
        val l = playlists[name] ?: return
        if (id !in l) { playlists = playlists + (name to (l + id)); savePlaylists() }
    }
    fun removeFromPlaylist(name: String, id: Long) {
        playlists = playlists + (name to playlists[name].orEmpty().filter { it != id }); savePlaylists()
    }
    fun deletePlaylist(name: String) { playlists = playlists - name; savePlaylists() }
    fun playlistSongs(name: String) = playlists[name].orEmpty().mapNotNull { byId[it] }

    private fun readIds(key: String): Set<Long> =
        prefs.getString(key, "").orEmpty().split(",").mapNotNull { it.toLongOrNull() }.toSet()

    private fun readPlaylists(): Map<String, List<Long>> {
        val out = LinkedHashMap<String, List<Long>>()
        runCatching {
            val o = JSONObject(prefs.getString("playlists", "{}") ?: "{}")
            o.keys().forEach { k -> val a = o.getJSONArray(k); out[k] = List(a.length()) { a.getLong(it) } }
        }
        return out
    }

    private fun savePlaylists() {
        val o = JSONObject()
        playlists.forEach { (k, v) -> o.put(k, JSONArray(v)) }
        prefs.edit().putString("playlists", o.toString()).apply()
    }

    // ---- Recordar última canción y cola ----
    private fun saveState() {
        val c = controller ?: return
        if (c.mediaItemCount == 0) return
        prefs.edit()
            .putString("queue", (0 until c.mediaItemCount).joinToString(",") { c.getMediaItemAt(it).mediaId })
            .putLong("cur", c.currentMediaItem?.mediaId?.toLongOrNull() ?: -1L)
            .putLong("pos", c.currentPosition)
            .putBoolean("shuffle", c.shuffleModeEnabled)
            .putInt("repeat", c.repeatMode)
            .apply()
    }

    private fun tryRestore() {
        val c = controller ?: return
        if (restored || byId.isEmpty()) return
        restored = true
        if (c.mediaItemCount > 0) return // el servicio ya tenía cola
        val items = prefs.getString("queue", "").orEmpty().split(",")
            .mapNotNull { it.toLongOrNull() }.mapNotNull { byId[it] }
        if (items.isEmpty()) return
        val idx = items.indexOfFirst { it.id == prefs.getLong("cur", -1L) }.coerceAtLeast(0)
        c.shuffleModeEnabled = prefs.getBoolean("shuffle", false)
        c.repeatMode = prefs.getInt("repeat", Player.REPEAT_MODE_OFF)
        c.setMediaItems(items.map { it.toMediaItem() }, idx, prefs.getLong("pos", 0L))
        c.prepare()
    }

    override fun onCleared() {
        saveState()
        controller?.removeListener(listener)
        controller?.release()
        controller = null
        super.onCleared()
    }
}
