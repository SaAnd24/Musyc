package com.example.musicplayer

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val uri: Uri,
    val dateAdded: Long = 0L,   // ms desde epoch
    val genre: String = "",
    val year: Int = 0
) {
    val artUri: Uri
        get() = ContentUris.withAppendedId(
            Uri.parse("content://media/external/audio/albumart"), albumId
        )
}

fun storagePermission(): String =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE

object MusicRepository {
    fun load(context: Context): List<Song> {
        val collection = if (Build.VERSION.SDK_INT >= 29)
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        val cols = mutableListOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.YEAR
        )
        // El género solo existe en MediaStore desde Android 11; antes se omite y las recomendaciones usan artista/álbum.
        if (Build.VERSION.SDK_INT >= 30) cols += MediaStore.Audio.Media.GENRE
        val projection = cols.toTypedArray()
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val order = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"

        val songs = mutableListOf<Song>()
        context.contentResolver.query(collection, projection, selection, null, order)?.use { c ->
            val idC = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleC = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistC = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumC = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdC = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durC = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val addedC = c.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED)
            val yearC = c.getColumnIndex(MediaStore.Audio.Media.YEAR)
            val genreC = if (Build.VERSION.SDK_INT >= 30) c.getColumnIndex(MediaStore.Audio.Media.GENRE) else -1
            while (c.moveToNext()) {
                val id = c.getLong(idC)
                val artist = c.getString(artistC)
                val album = c.getString(albumC)
                songs += Song(
                    id = id,
                    title = c.getString(titleC) ?: "Sin título",
                    artist = if (artist.isNullOrBlank() || artist == "<unknown>") "Artista desconocido" else artist,
                    album = if (album.isNullOrBlank()) "Álbum desconocido" else album,
                    albumId = c.getLong(albumIdC),
                    durationMs = c.getLong(durC),
                    uri = ContentUris.withAppendedId(collection, id),
                    dateAdded = if (addedC >= 0) c.getLong(addedC) * 1000L else 0L,
                    genre = if (genreC >= 0) cleanGenre(c.getString(genreC)) else "",
                    year = if (yearC >= 0) c.getInt(yearC) else 0
                )
            }
        }
        return songs
    }

    /** Algunos archivos traen el género como número ID3v1 "(17)"; eso no sirve, se descarta. */
    private fun cleanGenre(raw: String?): String {
        val g = raw?.trim().orEmpty()
        if (g.isEmpty() || g.equals("unknown", true) || g.equals("<unknown>", true)) return ""
        if (g.all { it.isDigit() || it == '(' || it == ')' }) return ""
        return g
    }
}
