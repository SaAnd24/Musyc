package com.example.musicplayer

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/*
 * Importación de canciones de YouTube Music (v1.4, experimental).
 * El audio se descarga con yt-dlp (biblioteca youtubedl-android, GPL-3.0), se guarda en la carpeta de música
 * y JullMood lo trata desde ese momento como cualquier canción local.
 */

/** Falta permiso de escritura en la carpeta de música elegida (Storage Access Framework). */
class FolderAccessException : Exception("Falta permiso de escritura en tu carpeta de música")

/** Archivo ya guardado en la biblioteca local. */
data class SavedFile(val uri: Uri, val displayName: String)

object YtEngine {
    private val AUDIO_EXT = setOf("m4a", "mp4", "webm", "opus", "ogg", "oga", "mp3", "aac", "flac", "wav", "mka")

    @Volatile private var ready = false
    @Volatile private var ffmpegOk = false

    @Synchronized
    fun ensure(ctx: Context) {
        if (ready) return
        YoutubeDL.getInstance().init(ctx)
        ffmpegOk = runCatching { FFmpeg.getInstance().init(ctx) }.isSuccess
        ready = true
    }

    /** Descarga el audio de [videoId] a [dir] y devuelve el archivo. [onProgress] recibe 0..100. */
    fun download(
        ctx: Context, videoId: String, dir: File, cookies: File?, processId: String, onProgress: (Float) -> Unit
    ): File {
        ensure(ctx)
        dir.mkdirs()
        dir.listFiles { f -> f.name.startsWith("$videoId.") }?.forEach { it.delete() }
        val req = YoutubeDLRequest("https://www.youtube.com/watch?v=$videoId")
        req.addOption("--no-playlist")
        req.addOption("-f", "bestaudio[ext=m4a]/bestaudio")
        req.addOption("--no-mtime")
        if (ffmpegOk) req.addOption("--embed-metadata")
        if (cookies != null && cookies.exists()) req.addOption("--cookies", cookies.absolutePath)
        req.addOption("-o", File(dir, "$videoId.%(ext)s").absolutePath)
        YoutubeDL.getInstance().execute(request = req, processId = processId) { progress, _, _ -> onProgress(progress) }
        return dir.listFiles()
            ?.filter { it.name.startsWith("$videoId.") && it.extension.lowercase() in AUDIO_EXT }
            ?.maxByOrNull { it.length() }
            ?: throw IllegalStateException("yt-dlp no generó ningún archivo de audio")
    }

    fun cancel(processId: String) {
        runCatching { YoutubeDL.getInstance().destroyProcessById(processId) }
    }

    /**
     * Actualiza yt-dlp desde la propia app (YouTube cambia a menudo y la versión incluida envejece).
     * Se invoca por reflexión para no depender de la firma exacta de la biblioteca entre versiones.
     */
    fun update(ctx: Context): String {
        ensure(ctx)
        val yd = YoutubeDL.getInstance()
        val m = yd.javaClass.methods.filter { it.name == "updateYoutubeDL" }.minByOrNull { it.parameterTypes.size }
            ?: return "Esta versión del motor no permite actualizar desde la app"
        val args = arrayOfNulls<Any>(m.parameterTypes.size)
        for (i in args.indices) {
            args[i] = if (i == 0) ctx else defaultOf(m.parameterTypes[i])
        }
        val res = try { m.invoke(yd, *args) } catch (e: java.lang.reflect.InvocationTargetException) { throw e.cause ?: e }
        val txt = res?.toString().orEmpty()
        return when {
            txt.contains("ALREADY", true) -> "El motor ya estaba al día"
            txt.contains("DONE", true) -> "Motor actualizado"
            txt.isBlank() -> "Actualización terminada"
            else -> "Actualización: $txt"
        }
    }

    /** Valor por defecto (canal estable) para el parámetro opcional de updateYoutubeDL. */
    private fun defaultOf(type: Class<*>): Any? {
        if (type.isEnum) {
            val all = type.enumConstants
            return all?.firstOrNull { (it as Enum<*>).name.contains("STABLE", true) } ?: all?.firstOrNull()
        }
        fun isStable(n: String) = n.equals("STABLE", true) || n.equals("_STABLE", true)
        // Campos estáticos (p. ej. UpdateChannel._STABLE)
        type.fields.firstOrNull { isStable(it.name) && type.isAssignableFrom(it.type) }
            ?.let { f -> runCatching { return f.get(null) } }
        // Objeto anidado (UpdateChannel.STABLE) o acceso vía Companion
        type.classes.firstOrNull { isStable(it.simpleName) }
            ?.let { c -> runCatching { return c.getField("INSTANCE").get(null) } }
        runCatching {
            val comp = type.getField("Companion").get(null)
            comp.javaClass.methods.firstOrNull {
                it.parameterTypes.isEmpty() && type.isAssignableFrom(it.returnType) &&
                    it.name.removePrefix("get").let(::isStable)
            }?.let { m -> return m.invoke(comp) }
        }
        return null
    }

    /** Resume el error de yt-dlp en una línea legible. */
    fun friendlyError(e: Throwable): String {
        val raw = e.message.orEmpty()
        val line = raw.lines().lastOrNull { it.contains("ERROR:") }?.substringAfter("ERROR:")?.trim()
            ?: raw.lines().lastOrNull { it.isNotBlank() }?.trim()
            ?: e.javaClass.simpleName
        val hint = when {
            line.contains("Sign in", true) || line.contains("confirm you", true) ->
                " · Inicia sesión o actualiza el motor."
            line.contains("format is not available", true) || line.contains("HTTP Error 403", true) ||
                line.contains("JavaScript", true) -> " · Prueba a actualizar el motor."
            line.contains("Unable to resolve host", true) || line.contains("timed out", true) ->
                " · Revisa tu conexión."
            else -> ""
        }
        return (line.take(170) + hint)
    }
}

object YtLibraryWriter {
    // Carpetas de nivel superior que MediaStore admite para audio (Android 10+).
    private val MS_DIRS = setOf("music", "podcasts", "alarms", "notifications", "ringtones")
    private const val SUBDIR = "JullMood"

    fun save(ctx: Context, src: File, baseName: String, musicFolder: Uri?): SavedFile {
        val ext = src.extension.lowercase().ifEmpty { "m4a" }
        val name = safeName(baseName) + "." + ext
        val mime = mimeOf(ext)
        if (musicFolder != null) {
            val rel = relativeDirFor(musicFolder)
            if (rel != null && Build.VERSION.SDK_INT >= 29) {
                try { return viaMediaStore(ctx, src, name, mime, rel) } catch (_: Exception) { /* cae al selector de carpetas */ }
            }
            return viaTree(ctx, src, name, mime, musicFolder)
        }
        return if (Build.VERSION.SDK_INT >= 29) viaMediaStore(ctx, src, name, mime, "Music/$SUBDIR/")
        else viaAppDir(ctx, src, name)
    }

    /** "primary:Music/Rock" -> "Music/Rock/JullMood/" (solo si MediaStore admite esa ruta). */
    private fun relativeDirFor(tree: Uri): String? {
        val id = runCatching { DocumentsContract.getTreeDocumentId(tree) }.getOrNull() ?: return null
        if (!id.startsWith("primary:")) return null
        val path = id.substringAfter(':').trim('/')
        if (path.isEmpty() || path.substringBefore('/').lowercase() !in MS_DIRS) return null
        return "$path/$SUBDIR/"
    }

    private fun viaMediaStore(ctx: Context, src: File, name: String, mime: String, rel: String): SavedFile {
        val resolver = ctx.contentResolver
        val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, name)
            put(MediaStore.Audio.Media.MIME_TYPE, mime)
            put(MediaStore.Audio.Media.RELATIVE_PATH, rel)
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(collection, values) ?: throw IllegalStateException("MediaStore rechazó el archivo")
        try {
            resolver.openOutputStream(uri)?.use { out -> src.inputStream().use { it.copyTo(out) } }
                ?: throw IllegalStateException("No se pudo escribir en MediaStore")
            val done = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        } catch (e: Exception) {
            runCatching { resolver.delete(uri, null, null) }
            throw e
        }
        return SavedFile(uri, queryName(ctx, uri, MediaStore.Audio.Media.DISPLAY_NAME) ?: name)
    }

    private fun viaTree(ctx: Context, src: File, name: String, mime: String, tree: Uri): SavedFile {
        val resolver = ctx.contentResolver
        try {
            val rootDoc = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            val dir = findOrCreateDir(ctx, tree, rootDoc, SUBDIR)
            val doc = DocumentsContract.createDocument(resolver, dir, mime, name) ?: throw FolderAccessException()
            resolver.openOutputStream(doc)?.use { out -> src.inputStream().use { it.copyTo(out) } }
                ?: throw FolderAccessException()
            return SavedFile(doc, queryName(ctx, doc, DocumentsContract.Document.COLUMN_DISPLAY_NAME) ?: name)
        } catch (e: SecurityException) {
            throw FolderAccessException()
        }
    }

    private fun findOrCreateDir(ctx: Context, tree: Uri, parentDoc: Uri, name: String): Uri {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getDocumentId(parentDoc))
        ctx.contentResolver.query(
            children,
            arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                if (c.getString(1) == name && c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR)
                    return DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0))
            }
        }
        return DocumentsContract.createDocument(ctx.contentResolver, parentDoc, DocumentsContract.Document.MIME_TYPE_DIR, name)
            ?: throw FolderAccessException()
    }

    /** Android 8–9: carpeta propia de la app dentro de Música y aviso al indexador. */
    private fun viaAppDir(ctx: Context, src: File, name: String): SavedFile {
        val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC), SUBDIR).apply { mkdirs() }
        val dest = File(dir, name)
        src.copyTo(dest, overwrite = true)
        MediaScannerConnection.scanFile(ctx, arrayOf(dest.absolutePath), null, null)
        return SavedFile(Uri.fromFile(dest), dest.name)
    }

    private fun queryName(ctx: Context, uri: Uri, col: String): String? = runCatching {
        ctx.contentResolver.query(uri, arrayOf(col), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    }.getOrNull()

    private fun safeName(s: String): String =
        s.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_").trim().trim('.').take(120).ifEmpty { "cancion" }

    private fun mimeOf(ext: String): String {
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)?.takeIf { it.startsWith("audio/") }?.let { return it }
        return when (ext) {
            "m4a", "mp4" -> "audio/mp4"
            "webm" -> "audio/webm"
            "opus", "ogg", "oga" -> "audio/ogg"
            "mka" -> "audio/x-matroska"
            else -> "audio/mpeg"
        }
    }
}

object YtCovers {
    /** Descarga la portada de YouTube Music a la caché; null si no está disponible. */
    fun fetch(ctx: Context, videoId: String, url: String): File? {
        if (url.isBlank()) return null
        return runCatching {
            val dir = File(ctx.cacheDir, "ytm").apply { mkdirs() }
            val f = File(dir, "cover_$videoId.jpg")
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 12_000; c.readTimeout = 20_000
                if (c.responseCode !in 200..299) return null
                val bytes = c.inputStream.use { it.readBytes() }
                if (bytes.size < 1024) return null
                f.writeBytes(bytes)
                f
            } finally { c.disconnect() }
        }.getOrNull()
    }
}
