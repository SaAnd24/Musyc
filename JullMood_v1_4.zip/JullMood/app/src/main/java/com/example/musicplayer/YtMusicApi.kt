package com.example.musicplayer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/*
 * "Tu biblioteca online" (v1.4, experimental): cliente mínimo de YouTube Music.
 * Solo busca canciones y lista playlists de la cuenta. No reproduce nada: las canciones se importan a la
 * biblioteca local (YtImporter.kt) y desde ahí son canciones normales de JullMood.
 * Sin dependencias nuevas: HttpURLConnection + org.json (incluido en Android).
 */

/** Canción de YouTube Music tal como la devuelven la búsqueda o una playlist. */
data class YtSong(
    val videoId: String,
    val title: String,
    val artist: String,
    val album: String,
    val durationSec: Int,
    val thumbUrl: String
) {
    /** Portada en alta resolución para importarla a la biblioteca. */
    val coverUrl: String get() = resizeThumb(thumbUrl, 544)
    val durationText: String
        get() = if (durationSec <= 0) "" else "%d:%02d".format(durationSec / 60, durationSec % 60)
}

data class YtPlaylist(val browseId: String, val title: String, val subtitle: String, val thumbUrl: String)

/** La sesión caducó o YouTube rechazó las cookies. */
class YtAuthException(message: String) : Exception(message)

internal fun resizeThumb(url: String, px: Int): String =
    if (url.contains("googleusercontent.com") || url.contains("ggpht.com"))
        url.replace(Regex("=(w\\d+-h\\d+|s\\d+).*$"), "=w$px-h$px-l90-rj")
    else url

/** Cookies de la cuenta. Se guardan en noBackupFilesDir: no entran en copias de seguridad de Android. */
class YtSession(private val ctx: Context) {
    private val file get() = File(ctx.noBackupFilesDir, "ytm_session.txt")
    val cookiesFile: File get() = File(ctx.noBackupFilesDir, "ytm_cookies.txt")

    @Volatile
    var cookie: String = runCatching { file.takeIf { it.exists() }?.readText()?.trim().orEmpty() }.getOrDefault("")
        private set

    val loggedIn: Boolean get() = sapisid() != null

    fun save(c: String) {
        cookie = c.trim()
        runCatching { file.writeText(cookie) }
        writeCookiesTxt()
    }

    fun clear() {
        cookie = ""
        runCatching { file.delete() }
        runCatching { cookiesFile.delete() }
    }

    fun sapisid(): String? = valueOf("SAPISID") ?: valueOf("__Secure-3PAPISID")

    private fun valueOf(name: String): String? =
        cookie.split(";").map { it.trim() }.firstOrNull { it.startsWith("$name=") }
            ?.substringAfter('=')?.takeIf { it.isNotEmpty() }

    /** Formato Netscape para yt-dlp (--cookies). Todas las cookies se declaran de .youtube.com. */
    fun writeCookiesTxt(): File? {
        if (cookie.isEmpty()) return null
        val exp = System.currentTimeMillis() / 1000 + 365L * 24 * 3600
        val sb = StringBuilder("# Netscape HTTP Cookie File\n")
        for (part in cookie.split(";")) {
            val p = part.trim()
            val i = p.indexOf('=')
            if (i <= 0) continue
            sb.append(".youtube.com\tTRUE\t/\tTRUE\t").append(exp).append('\t')
                .append(p.substring(0, i)).append('\t').append(p.substring(i + 1)).append('\n')
        }
        return runCatching { cookiesFile.writeText(sb.toString()); cookiesFile }.getOrNull()
    }
}

class YtMusicApi(private val session: YtSession) {

    private companion object {
        const val BASE = "https://music.youtube.com/youtubei/v1/"
        const val ORIGIN = "https://music.youtube.com"
        const val KEY = "AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30"   // clave pública del cliente web de YouTube Music
        const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"
        /** Filtro "Canciones" de la búsqueda de YouTube Music. */
        const val SONGS_FILTER = "EgWKAQIIAWoMEA4QChADEAQQCRAF"
    }

    private fun context(): JSONObject = JSONObject().put(
        "client", JSONObject()
            .put("clientName", "WEB_REMIX")
            .put("clientVersion", "1." + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date()) + ".01.00")
            .put("hl", "es")
    )

    private fun sapisidHash(sapisid: String): String {
        val ts = System.currentTimeMillis() / 1000
        val digest = MessageDigest.getInstance("SHA-1").digest("$ts $sapisid $ORIGIN".toByteArray())
        return "SAPISIDHASH ${ts}_" + digest.joinToString("") { "%02x".format(it) }
    }

    private fun post(endpoint: String, body: JSONObject): JSONObject {
        val c = URL("$BASE$endpoint?prettyPrint=false&key=$KEY").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15_000
            c.readTimeout = 25_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Origin", ORIGIN)
            c.setRequestProperty("X-Origin", ORIGIN)
            c.setRequestProperty("Referer", "$ORIGIN/")
            c.setRequestProperty("Accept-Language", "es-ES,es;q=0.9")
            val sapisid = session.sapisid()
            if (sapisid != null) {
                c.setRequestProperty("Cookie", session.cookie)
                c.setRequestProperty("Authorization", sapisidHash(sapisid))
                c.setRequestProperty("X-Goog-AuthUser", "0")
            }
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            if (code == 401 || (code == 403 && sapisid != null))
                throw YtAuthException("Tu sesión de YouTube Music caducó. Vuelve a iniciar sesión.")
            if (code !in 200..299) throw IOException("YouTube Music respondió con el código $code")
            val text = c.inputStream.bufferedReader().use { it.readText() }
            return JSONObject(text)
        } finally {
            c.disconnect()
        }
    }

    // ---------------------------------------------------------------- consultas

    fun search(query: String): List<YtSong> {
        val root = post("search", JSONObject().put("context", context()).put("query", query).put("params", SONGS_FILTER))
        val rows = ArrayList<JSONObject>()
        collect(root, "musicResponsiveListItemRenderer", rows)
        return rows.mapNotNull { parseSong(it) }.distinctBy { it.videoId }
    }

    /** Playlists de la biblioteca de la cuenta (más "Canciones que te gustan"). Requiere sesión. */
    fun libraryPlaylists(): List<YtPlaylist> {
        val root = post("browse", JSONObject().put("context", context()).put("browseId", "FEmusic_liked_playlists"))
        val items = ArrayList<JSONObject>()
        collect(root, "musicTwoRowItemRenderer", items)
        val out = ArrayList<YtPlaylist>()
        out += YtPlaylist("VLLM", "Canciones que te gustan", "Tu lista de Me gusta", "")
        for (item in items) {
            val id = item.optJSONObject("navigationEndpoint")?.optJSONObject("browseEndpoint")?.optString("browseId").orEmpty()
            if (!id.startsWith("VL") || id == "VLLM") continue      // salta "Nueva playlist", álbumes y artistas
            val title = item.optJSONObject("title")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text").orEmpty()
            if (title.isBlank()) continue
            out += YtPlaylist(id, title, runsText(item.optJSONObject("subtitle")?.optJSONArray("runs")), thumbOf(item))
        }
        return out.distinctBy { it.browseId }
    }

    /** Canciones de una playlist (hasta [max]); sigue las páginas de continuación. */
    fun playlistSongs(browseId: String, max: Int = 500): List<YtSong> {
        var root = post("browse", JSONObject().put("context", context()).put("browseId", browseId))
        val out = LinkedHashMap<String, YtSong>()
        var first = true
        var pages = 0
        while (true) {
            // En la primera página solo se leen las filas de la playlist (no las "sugerencias" de abajo).
            val scope = ArrayList<JSONObject>()
            if (first) {
                collect(root, "musicPlaylistShelfRenderer", scope)
                if (scope.isEmpty()) collect(root, "musicShelfRenderer", scope)
            }
            if (scope.isEmpty()) scope += root
            val rows = ArrayList<JSONObject>()
            for (s in scope) collect(s, "musicResponsiveListItemRenderer", rows)
            for (r in rows) parseSong(r)?.let { out.putIfAbsent(it.videoId, it) }
            val token = scope.firstNotNullOfOrNull { findToken(it) }
            first = false
            if (token == null || out.size >= max || ++pages >= 12) break
            root = post("browse", JSONObject().put("context", context()).put("continuation", token))
        }
        return out.values.toList()
    }

    // ---------------------------------------------------------------- análisis del JSON

    /** Recorre el JSON y recoge los objetos bajo la clave [key] (sin entrar en los ya encontrados). */
    private fun collect(node: Any?, key: String, out: MutableList<JSONObject>) {
        when (node) {
            is JSONObject -> {
                val keys = node.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val v = node.opt(k)
                    if (k == key && v is JSONObject) out += v else collect(v, key, out)
                }
            }
            is JSONArray -> for (i in 0 until node.length()) collect(node.opt(i), key, out)
        }
    }

    private fun findToken(node: Any?): String? {
        when (node) {
            is JSONObject -> {
                node.optJSONObject("nextContinuationData")?.optString("continuation")?.takeIf { it.isNotEmpty() }?.let { return it }
                node.optJSONObject("continuationCommand")?.optString("token")?.takeIf { it.isNotEmpty() }?.let { return it }
                val keys = node.keys()
                while (keys.hasNext()) findToken(node.opt(keys.next()))?.let { return it }
            }
            is JSONArray -> for (i in 0 until node.length()) findToken(node.opt(i))?.let { return it }
        }
        return null
    }

    private fun firstString(node: Any?, key: String): String {
        when (node) {
            is JSONObject -> {
                val own = node.optString(key)
                if (own.isNotEmpty()) return own
                val keys = node.keys()
                while (keys.hasNext()) firstString(node.opt(keys.next()), key).takeIf { it.isNotEmpty() }?.let { return it }
            }
            is JSONArray -> for (i in 0 until node.length()) firstString(node.opt(i), key).takeIf { it.isNotEmpty() }?.let { return it }
        }
        return ""
    }

    private fun runsText(runs: JSONArray?): String {
        if (runs == null) return ""
        val sb = StringBuilder()
        for (i in 0 until runs.length()) sb.append(runs.optJSONObject(i)?.optString("text").orEmpty())
        return sb.toString()
    }

    private fun thumbOf(r: JSONObject): String {
        val thumbs = (r.optJSONObject("thumbnail") ?: r.optJSONObject("thumbnailRenderer"))
            ?.optJSONObject("musicThumbnailRenderer")?.optJSONObject("thumbnail")?.optJSONArray("thumbnails")
        val url = thumbs?.optJSONObject(thumbs.length() - 1)?.optString("url").orEmpty()
        return resizeThumb(url, 226)
    }

    private fun pageType(run: JSONObject): String =
        run.optJSONObject("navigationEndpoint")?.optJSONObject("browseEndpoint")
            ?.optJSONObject("browseEndpointContextSupportedConfigs")
            ?.optJSONObject("browseEndpointContextMusicConfig")?.optString("pageType").orEmpty()

    private fun parseDuration(t: String): Int {
        val s = t.trim()
        if (!Regex("^\\d{1,2}(:\\d{2}){1,2}$").matches(s)) return 0
        return s.split(":").fold(0) { acc, p -> acc * 60 + p.toInt() }
    }

    private fun looksLikeNoise(t: String): Boolean {
        val l = t.trim().lowercase()
        return l in setOf("canción", "cancion", "song", "vídeo", "video", "álbum", "album") ||
            l.contains("reproducciones") || l.contains("views") || l.contains("plays")
    }

    private fun parseSong(r: JSONObject): YtSong? {
        val id = r.optJSONObject("playlistItemData")?.optString("videoId").orEmpty()
            .ifEmpty { firstString(r.optJSONObject("overlay"), "videoId") }
        if (id.isEmpty()) return null
        val cols = r.optJSONArray("flexColumns") ?: return null
        fun runs(i: Int): JSONArray? = cols.optJSONObject(i)
            ?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")?.optJSONObject("text")?.optJSONArray("runs")

        val title = runs(0)?.optJSONObject(0)?.optString("text").orEmpty()
        if (title.isBlank()) return null

        val artists = ArrayList<String>()
        val loose = ArrayList<String>()
        var album = ""
        var dur = 0
        for (c in 1 until cols.length()) {
            val rs = runs(c) ?: continue
            for (j in 0 until rs.length()) {
                val run = rs.optJSONObject(j) ?: continue
                val t = run.optString("text")
                if (t.isBlank() || t.trim() == "•") continue
                when (pageType(run)) {
                    "MUSIC_PAGE_TYPE_ALBUM", "MUSIC_PAGE_TYPE_AUDIOBOOK" -> if (album.isEmpty()) album = t
                    "MUSIC_PAGE_TYPE_ARTIST", "MUSIC_PAGE_TYPE_USER_CHANNEL", "MUSIC_PAGE_TYPE_LIBRARY_ARTIST" -> artists += t
                    else -> { val d = parseDuration(t); if (d > 0) dur = d else loose += t }
                }
            }
        }
        if (dur == 0) {
            val fixed = r.optJSONArray("fixedColumns")?.optJSONObject(0)
                ?.optJSONObject("musicResponsiveListItemFixedColumnRenderer")?.optJSONObject("text")
                ?.optJSONArray("runs")?.optJSONObject(0)?.optString("text").orEmpty()
            dur = parseDuration(fixed)
        }
        val artist = artists.joinToString(", ").ifEmpty { loose.firstOrNull { !looksLikeNoise(it) }.orEmpty() }
        return YtSong(id, title.trim(), artist.trim(), album.trim(), dur, thumbOf(r))
    }
}
