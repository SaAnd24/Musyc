package com.example.musicplayer

import android.content.Context
import android.content.SharedPreferences
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.Buffer
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * v1.3 Audio Experience. Todo el procesado (JullEQ, preamp, balance y normalización) vive en UN solo AudioProcessor
 * dentro de la cadena de audio que ya existía (la de LiveJull): no hay otro reproductor ni otra cadena.
 * Con todo en OFF/Flat/Centro el procesador copia el audio tal cual (idéntico bit a bit a la v1.2-C).
 *
 * Los fundidos (crossfade y fade al pausar) NO se hacen aquí: el buffer del AudioSink adelanta el procesado
 * ~0,3-0,7 s respecto a lo que suena, así que se aplican con ExoPlayer.setVolume (ver AudioFlow.kt).
 */

// ---------- JullEQ ----------

internal val EQ_FREQS = floatArrayOf(63f, 160f, 400f, 1000f, 2500f, 6300f, 16000f)
internal val EQ_LABELS = listOf("63 Hz", "160 Hz", "400 Hz", "1 kHz", "2,5 kHz", "6,3 kHz", "16 kHz")
internal const val EQ_MAX_DB = 12f
private const val EQ_Q = 1.1f

private fun bands(vararg v: Float): List<Float> = v.toList()

/** Presets (dB por banda, de 63 Hz a 16 kHz) con su preamp. Custom = lo que haya guardado el usuario. */
enum class EqPreset(val label: String, val gains: List<Float>, val preamp: Float) {
    FLAT("Flat", bands(0f, 0f, 0f, 0f, 0f, 0f, 0f), 0f),
    BASS("Bass", bands(5f, 4f, 2f, 0f, 0f, 0f, 0f), -5f),
    BASS_BOOST("Bass Boost", bands(8f, 7f, 4f, 1f, 0f, -1f, -1f), -8.5f),
    VOCAL("Vocal", bands(-2f, -2f, 0f, 3f, 4f, 2f, -1f), -4f),
    TREBLE("Treble", bands(-1f, 0f, 0f, 0f, 2f, 4f, 6f), -5.5f),
    ROCK("Rock", bands(5f, 3f, -2f, -1f, 1f, 4f, 5f), -4.5f),
    POP("Pop", bands(-1f, 2f, 3f, 4f, 2f, -1f, -2f), -4f),
    CLASSICAL("Classical", bands(3f, 2f, 0f, -1f, 0f, 2f, 3f), -2.5f),
    CUSTOM("Custom", bands(0f, 0f, 0f, 0f, 0f, 0f, 0f), 0f)
}

// ---------- Normalización ----------

/** strength = parte de la corrección que se aplica; [minDb, maxDb] = límites de la ganancia. */
enum class NormMode(val label: String, val strength: Float, val minDb: Float, val maxDb: Float) {
    OFF("OFF", 0f, 0f, 0f), SOFT("Suave", 0.5f, -6f, 3f), NORMAL("Normal", 1f, -12f, 6f)
}

private const val NORM_TARGET_DB = -14f

/** Ganancia lineal para una canción medida (rmsDb = nivel RMS en dBFS de sus tramos activos, peak = pico 0..1). */
internal fun normGainLin(mode: NormMode, rmsDb: Float, peak: Float): Float {
    if (mode == NormMode.OFF) return 1f
    val db = ((NORM_TARGET_DB - rmsDb) * mode.strength).coerceIn(mode.minDb, mode.maxDb)
    var lin = 10f.pow(db / 20f)
    if (lin > 1f && peak > 0.001f) lin = min(lin, max(1f, 0.98f / peak))   // no subir más de lo que cabe sin saturar
    return lin
}

// ---------- Configuración compartida (VM -> procesador / AudioFlow) ----------

internal data class AudioCfg(
    val eqOn: Boolean = false,
    val eqGains: List<Float> = List(7) { 0f },
    val preampDb: Float = 0f,
    val norm: NormMode = NormMode.OFF,
    val balance: Float = 0f,          // -1 (izquierda) .. 0 (centro) .. +1 (derecha)
    val crossfadeMs: Int = 0,         // 0 = OFF
    val pauseFadeMs: Int = 0          // 0 = OFF
)

/**
 * Punto único de comunicación entre la interfaz y el audio. El ViewModel y PlaybackService viven en el mismo proceso,
 * así que basta con un objeto: la configuración es inmutable y se publica con un único @Volatile.
 */
internal object JullAudio {
    @Volatile var cfg = AudioCfg()
    @Volatile var loaded = false
    @Volatile var songId: String? = null
    @Volatile var songGen = 0

    /** Canción actual (la escribe AudioFlow desde el hilo principal). El procesador lo detecta en su siguiente buffer. */
    fun setSong(id: String?) { songId = id; songGen += 1 }

    fun parseGains(s: String?): List<Float> {
        val p = s?.split(",")?.mapNotNull { it.trim().toFloatOrNull() }
        return if (p != null && p.size == 7) p.map { it.coerceIn(-EQ_MAX_DB, EQ_MAX_DB) } else List(7) { 0f }
    }

    /** Lee la configuración guardada (mismas claves que usa el ViewModel). */
    fun readCfg(prefs: SharedPreferences): AudioCfg {
        val preset = EqPreset.values().firstOrNull { it.name == prefs.getString("eqPreset", null) } ?: EqPreset.FLAT
        val custom = parseGains(prefs.getString("eqCustom", null))
        val norm = NormMode.values().firstOrNull { it.name == prefs.getString("normMode", null) } ?: NormMode.OFF
        return AudioCfg(
            eqOn = prefs.getBoolean("eqOn", false),
            eqGains = if (preset == EqPreset.CUSTOM) custom else preset.gains,
            preampDb = if (preset == EqPreset.CUSTOM) prefs.getFloat("eqCustomPre", 0f) else preset.preamp,
            norm = norm,
            balance = prefs.getFloat("balance", 0f).coerceIn(-1f, 1f),
            crossfadeMs = prefs.getInt("crossfadeSec", 0).coerceIn(0, 10) * 1000,
            pauseFadeMs = prefs.getInt("pauseFadeMs", 0).coerceIn(0, 1000)
        )
    }

    /** Servicio: si la app aún no ha publicado nada (arranque por botón multimedia), carga lo guardado. */
    fun load(ctx: Context) {
        LoudnessStore.init(ctx)
        if (loaded) return
        runCatching { cfg = readCfg(ctx.applicationContext.getSharedPreferences("player", Context.MODE_PRIVATE)) }
        loaded = true
    }
}

// ---------- Memoria de volumen por canción (normalización) ----------

internal class Loud(val rmsDb: Float, val peak: Float)

/**
 * Nivel medido de cada canción: SOLO dos números por canción (~25 bytes), nunca audio. Se mide una vez (los primeros
 * ~10 s de reproducción) y se reutiliza siempre; así la normalización no analiza el audio de forma continua.
 */
internal object LoudnessStore {
    private class E(val rmsDb: Float, val peak: Float, var used: Long)

    private const val MAX = 5000
    private val map = HashMap<String, E>()
    private var file: File? = null
    private var dirty = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var flushJob: Job? = null

    @Synchronized fun init(ctx: Context) {
        if (file != null) return
        val f = File(ctx.applicationContext.filesDir, "loudness.json")
        file = f
        runCatching {
            if (!f.exists()) return@runCatching
            val arr = JSONObject(f.readText()).getJSONArray("e")
            for (i in 0 until arr.length()) {
                val a = arr.getJSONArray(i)
                map[a.getString(0)] = E(a.getDouble(1).toFloat(), a.getDouble(2).toFloat(), a.getLong(3))
            }
        }.onFailure { map.clear() }
    }

    @Synchronized fun get(id: String): Loud? {
        val e = map[id] ?: return null
        e.used = System.currentTimeMillis()
        return Loud(e.rmsDb, e.peak)
    }

    @Synchronized fun put(id: String, rmsDb: Float, peak: Float) {
        if (file == null) return
        map[id] = E(rmsDb, peak, System.currentTimeMillis())
        if (map.size > MAX) {
            val drop = map.entries.sortedBy { it.value.used }.take(map.size - MAX * 9 / 10).map { it.key }
            drop.forEach { map.remove(it) }
        }
        dirty = true
        if (flushJob?.isActive != true) flushJob = scope.launch { delay(4000); flushNow() }
    }

    fun flushNow() {
        val snap: Pair<File, String> = synchronized(this) {
            val f = file ?: return
            if (!dirty) return
            dirty = false
            val arr = JSONArray()
            for ((id, e) in map) arr.put(JSONArray().put(id).put(e.rmsDb.toDouble()).put(e.peak.toDouble()).put(e.used))
            f to JSONObject().put("v", 1).put("e", arr).toString()
        }
        val (f, text) = snap
        runCatching {
            val tmp = File(f.parentFile, f.name + ".tmp")
            tmp.writeText(text)
            if (!tmp.renameTo(f)) { f.writeText(text); tmp.delete() }
        }
    }
}

// ---------- El procesador ----------

private const val BLK = 64                      // los parámetros se suavizan cada 64 fotogramas (~1,4 ms)
private const val MEASURE_SKIP_BLOCKS = 30      // se ignora el primer 1,5 s (entradas, silencios)
private const val MEASURE_FULL_BLOCKS = 200     // 10 s de audio activo = medición completa
private const val MEASURE_MIN_BLOCKS = 80       // con 4 s ya vale si la canción se corta antes

private fun Buffer.flipSafe() { flip() }

/**
 * EQ de 7 bandas (filtros peaking RBJ, sin dependencias) + preamp + balance + ganancia de normalización, todo en un
 * único paso por muestra. Solo PCM 16 bits o float, mono/estéreo: con cualquier otro formato queda inactivo y el
 * audio pasa por la cadena original (degradación sin romper la reproducción).
 */
internal class JullAudioProcessor : BaseAudioProcessor() {
    private var rate = 44100
    private var ch = 2
    private var enc = C.ENCODING_PCM_16BIT
    private var blkLen = 2205
    private var cUser = 0.05f
    private var cNorm = 0.002f

    private var seenCfg: AudioCfg? = null
    private var seenGen = -1

    // EQ: coeficientes por banda (b0,b1,b2,a1,a2 normalizados) y estado de cada canal
    private val c0 = FloatArray(7); private val c1 = FloatArray(7); private val c2 = FloatArray(7)
    private val c3 = FloatArray(7); private val c4 = FloatArray(7)
    private val zl1 = FloatArray(7); private val zl2 = FloatArray(7)
    private val zr1 = FloatArray(7); private val zr2 = FloatArray(7)
    private val actIdx = IntArray(7)
    private val isAct = BooleanArray(7)
    private var nb = 0

    // ganancias objetivo y suavizadas (usuario = preamp·balance; norm = normalización por canción)
    private var tUserL = 1f; private var tUserR = 1f; private var tNorm = 1f
    private var gUL = 1f; private var gUR = 1f; private var gN = 1f

    // medición de volumen (solo mientras la normalización está activa y la canción es desconocida)
    private var curSong: String? = null
    private var measuring = false
    private var blkSq = 0f; private var blkN = 0
    private var totalBlocks = 0; private var activeBlocks = 0
    private var sumMs = 0.0
    private var pk = 0f

    private var inS = ShortArray(0)
    private var work = FloatArray(0)

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        val okEnc = inputAudioFormat.encoding == C.ENCODING_PCM_16BIT || inputAudioFormat.encoding == C.ENCODING_PCM_FLOAT
        val okCh = inputAudioFormat.channelCount == 1 || inputAudioFormat.channelCount == 2
        if (!okEnc || !okCh || inputAudioFormat.sampleRate < 8000) return AudioProcessor.AudioFormat.NOT_SET
        rate = inputAudioFormat.sampleRate
        ch = inputAudioFormat.channelCount
        enc = inputAudioFormat.encoding
        blkLen = max(256, rate / 20)
        cUser = 1f - exp(-BLK.toFloat() / (rate * 0.03f))
        cNorm = 1f - exp(-BLK.toFloat() / (rate * 0.6f))
        seenCfg = null
        return inputAudioFormat
    }

    override fun onFlush() {
        for (i in 0 until 7) { zl1[i] = 0f; zl2[i] = 0f; zr1[i] = 0f; zr2[i] = 0f; isAct[i] = false }
        nb = 0
        seenCfg = null          // se recalcula con el siguiente buffer (la medición de la canción continúa)
    }

    override fun onReset() {
        onFlush()
        inS = ShortArray(0); work = FloatArray(0)
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val bytesPer = if (enc == C.ENCODING_PCM_FLOAT) 4 else 2
        val frameBytes = bytesPer * ch
        val frames = inputBuffer.remaining() / frameBytes
        if (frames <= 0) {
            val left = inputBuffer.remaining()
            if (left > 0) { val o = replaceOutputBuffer(left); o.put(inputBuffer); o.flipSafe() }
            return
        }
        refreshSettings()
        if (!measuring && neutral()) {          // camino rápido: copia exacta
            val o = replaceOutputBuffer(inputBuffer.remaining())
            o.put(inputBuffer); o.flipSafe()
            return
        }
        val n = frames * ch
        val bytes = frames * frameBytes
        if (work.size < n) work = FloatArray(n)
        inputBuffer.order(ByteOrder.nativeOrder())
        if (enc == C.ENCODING_PCM_FLOAT) {
            inputBuffer.asFloatBuffer().get(work, 0, n)
        } else {
            if (inS.size < n) inS = ShortArray(n)
            inputBuffer.asShortBuffer().get(inS, 0, n)
            val k = 1f / 32768f
            for (i in 0 until n) work[i] = inS[i] * k
        }
        (inputBuffer as Buffer).position(inputBuffer.position() + bytes)

        process(work, frames)

        val out = replaceOutputBuffer(bytes)
        if (enc == C.ENCODING_PCM_FLOAT) {
            out.asFloatBuffer().put(work, 0, n)
        } else {
            for (i in 0 until n) inS[i] = (work[i] * 32768f).toInt().coerceIn(-32768, 32767).toShort()
            out.asShortBuffer().put(inS, 0, n)
        }
        (out as Buffer).position(bytes)
        out.flipSafe()
    }

    // ----- ajustes -----

    private fun refreshSettings() {
        val c = JullAudio.cfg
        val g = JullAudio.songGen
        val cfgChanged = c !== seenCfg
        val songChanged = g != seenGen
        if (!cfgChanged && !songChanged) return
        seenCfg = c
        seenGen = g
        if (cfgChanged) rebuild(c)
        evalSong(songChanged, c)
    }

    private fun rebuild(c: AudioCfg) {
        nb = 0
        for (i in 0 until 7) {
            val db = c.eqGains.getOrElse(i) { 0f }
            val on = c.eqOn && abs(db) > 0.05f && EQ_FREQS[i] < rate * 0.45f
            if (on) {
                if (!isAct[i]) { zl1[i] = 0f; zl2[i] = 0f; zr1[i] = 0f; zr2[i] = 0f }
                val a = 10.0.pow(db / 40.0)
                val w0 = 2.0 * PI * EQ_FREQS[i] / rate
                val alpha = sin(w0) / (2.0 * EQ_Q)
                val cw = cos(w0)
                val a0 = 1.0 + alpha / a
                c0[i] = ((1.0 + alpha * a) / a0).toFloat()
                c1[i] = ((-2.0 * cw) / a0).toFloat()
                c2[i] = ((1.0 - alpha * a) / a0).toFloat()
                c3[i] = ((-2.0 * cw) / a0).toFloat()
                c4[i] = ((1.0 - alpha / a) / a0).toFloat()
                actIdx[nb++] = i
            }
            isAct[i] = on
        }
        val pre = if (c.eqOn) 10f.pow(c.preampDb.coerceIn(-EQ_MAX_DB, EQ_MAX_DB) / 20f) else 1f
        val b = c.balance.coerceIn(-1f, 1f)
        tUserL = pre * (if (ch == 2 && b > 0f) 1f - b else 1f)
        tUserR = pre * (if (ch == 2 && b < 0f) 1f + b else 1f)
    }

    private fun evalSong(newSong: Boolean, c: AudioCfg) {
        if (newSong) {
            if (measuring && curSong != null && activeBlocks >= MEASURE_MIN_BLOCKS) storeMeasurement()
            resetMeasurement()
            curSong = JullAudio.songId
        }
        val id = curSong
        if (c.norm == NormMode.OFF || id == null) { tNorm = 1f; measuring = false; return }
        val known = LoudnessStore.get(id)
        if (known != null) { tNorm = normGainLin(c.norm, known.rmsDb, known.peak); measuring = false }
        else { tNorm = 1f; if (newSong || !measuring) measuring = true }
    }

    private fun resetMeasurement() {
        measuring = false; blkSq = 0f; blkN = 0; totalBlocks = 0; activeBlocks = 0; sumMs = 0.0; pk = 0f
    }

    private fun storeMeasurement(): Float? {
        val id = curSong ?: return null
        if (activeBlocks <= 0) return null
        val rms = (10.0 * log10(sumMs / activeBlocks)).toFloat()
        LoudnessStore.put(id, rms, pk)
        return rms
    }

    private fun neutral() = nb == 0 &&
        abs(tUserL - 1f) < 1e-3f && abs(tUserR - 1f) < 1e-3f && abs(tNorm - 1f) < 1e-3f &&
        abs(gUL - 1f) < 1e-3f && abs(gUR - 1f) < 1e-3f && abs(gN - 1f) < 1e-3f

    // ----- procesado -----

    private fun process(w: FloatArray, frames: Int) {
        val stereo = ch == 2
        var f = 0
        while (f < frames) {
            val n = min(BLK, frames - f)
            gUL += (tUserL - gUL) * cUser
            gUR += (tUserR - gUR) * cUser
            gN += (tNorm - gN) * cNorm
            val gl = gUL * gN
            val gr = gUR * gN
            var i = f * ch
            for (k in 0 until n) {
                var l = w[i]
                var r = if (stereo) w[i + 1] else 0f
                if (measuring) measure(l, r, stereo)        // se mide la señal original, antes de EQ y ganancias
                l *= gl
                if (stereo) r *= gr
                for (q in 0 until nb) {
                    val j = actIdx[q]
                    val yl = c0[j] * l + zl1[j]
                    zl1[j] = c1[j] * l - c3[j] * yl + zl2[j]
                    zl2[j] = c2[j] * l - c4[j] * yl
                    l = yl
                    if (stereo) {
                        val yr = c0[j] * r + zr1[j]
                        zr1[j] = c1[j] * r - c3[j] * yr + zr2[j]
                        zr2[j] = c2[j] * r - c4[j] * yr
                        r = yr
                    }
                }
                w[i] = soft(l)
                if (stereo) w[i + 1] = soft(r)
                i += ch
            }
            f += n
        }
    }

    /** Limitador suave: por debajo de 0,95 no toca nada; por encima satura progresivamente sin pasar de 1,0. */
    private fun soft(x: Float): Float {
        val a = abs(x)
        if (a <= 0.95f) return x
        val t = (a - 0.95f) * 20f
        val y = 0.95f + 0.05f * t / (1f + t)
        return if (x < 0f) -y else y
    }

    private fun measure(l: Float, r: Float, stereo: Boolean) {
        val m = if (stereo) (l + r) * 0.5f else l
        blkSq += m * m
        blkN++
        val a = abs(l); if (a > pk) pk = a
        if (stereo) { val b = abs(r); if (b > pk) pk = b }
        if (blkN >= blkLen) {
            val mean = blkSq / blkN
            blkSq = 0f; blkN = 0
            totalBlocks++
            if (totalBlocks <= MEASURE_SKIP_BLOCKS) return
            if (mean > 3e-6f) {                              // bloques por encima de -55 dBFS (se ignoran los silencios)
                sumMs += mean.toDouble()
                activeBlocks++
                if (activeBlocks >= MEASURE_FULL_BLOCKS) finishMeasurement()
            }
        }
    }

    private fun finishMeasurement() {
        measuring = false
        val rms = storeMeasurement() ?: return
        tNorm = normGainLin(seenCfg?.norm ?: NormMode.OFF, rms, pk)   // sube/baja con la suavización de ~0,6 s
    }
}
