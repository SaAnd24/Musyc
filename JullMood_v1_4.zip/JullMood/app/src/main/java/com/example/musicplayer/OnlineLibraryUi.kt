package com.example.musicplayer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/*
 * Sección "Tu biblioteca online": vive al final del Home (se llega con el scroll). No es una pestaña ni
 * una pantalla de navegación: todo ocurre dentro de estos ítems de la lista del Home.
 */

private const val LOGIN_URL =
    "https://accounts.google.com/ServiceLogin?ltmpl=music&service=youtube&passive=true" +
        "&continue=https%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26next%3Dhttps%253A%252F%252Fmusic.youtube.com%252F"

internal fun LazyListScope.onlineLibraryItems(o: OnlineLibrary) {
    item(key = "ol_title") { OnlineTitle() }
    item(key = "ol_account") { AccountCard(o) }
    if (o.needFolderAccess) item(key = "ol_folder") { FolderAccessCard(o) }
    item(key = "ol_tabs") { OnlineTabs(o) }

    o.notice?.let { n -> item(key = "ol_notice") { InfoLine(n, error = false) } }

    if (o.tab == 0) {
        item(key = "ol_search") { SearchBar(o) }
        if (o.searching) item(key = "ol_searching") { Busy("Buscando…") }
        o.searchError?.let { e -> item(key = "ol_search_err") { InfoLine(e, error = true) } }
        if (o.selected.isNotEmpty()) item(key = "ol_bar_s") { ImportBar(o, o.results) }
        items(o.results, key = { "ol_s_" + it.videoId }) { s ->
            YtRow(s, s.videoId in o.selected, o.jobs[s.videoId]) { o.toggle(s.videoId) }
        }
    } else {
        val open = o.openPlaylist
        if (!o.loggedIn) {
            item(key = "ol_pl_login") { InfoLine("Inicia sesión con YouTube Music para ver las playlists de tu cuenta.", error = false) }
        } else if (open == null) {
            item(key = "ol_pl_head") {
                Row(Modifier.padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Playlists de tu cuenta", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                    TextButton(onClick = { o.loadPlaylists() }, enabled = !o.plLoading) { Text("Actualizar") }
                }
            }
            if (o.plLoading) item(key = "ol_pl_busy") { Busy("Cargando playlists…") }
            o.plError?.let { e -> item(key = "ol_pl_err") { InfoLine(e, error = true) } }
            items(o.playlists, key = { "ol_p_" + it.browseId }) { p -> PlaylistRow(p) { o.showPlaylist(p) } }
        } else {
            item(key = "ol_pl_open") {
                Column(Modifier.padding(horizontal = 20.dp)) {
                    TextButton(onClick = { o.closePlaylist() }) { Text("← Volver a mis playlists") }
                    Text(open.title, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    if (open.subtitle.isNotBlank()) Text(open.subtitle, color = Gray, fontSize = 13.sp)
                    Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { o.selectAll(o.plSongs) }, enabled = o.plSongs.isNotEmpty()) { Text("Seleccionar todo") }
                        TextButton(onClick = { o.clearSelection() }, enabled = o.selected.isNotEmpty()) { Text("Quitar selección") }
                    }
                }
            }
            if (o.plSongsLoading) item(key = "ol_pls_busy") { Busy("Cargando canciones…") }
            o.plSongsError?.let { e -> item(key = "ol_pls_err") { InfoLine(e, error = true) } }
            if (o.selected.isNotEmpty()) item(key = "ol_bar_p") { ImportBar(o, o.plSongs) }
            items(o.plSongs, key = { "ol_ps_" + it.videoId }) { s ->
                YtRow(s, s.videoId in o.selected, o.jobs[s.videoId]) { o.toggle(s.videoId) }
            }
        }
    }

    if (o.jobs.isNotEmpty()) item(key = "ol_queue") { QueueCard(o) }
    item(key = "ol_footer") { EngineFooter(o) }
}

// ---------------------------------------------------------------------------------------------- piezas

@Composable
private fun OnlineTitle() {
    val ui = LocalUi.current
    Column(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = ui.d(36.dp), bottom = ui.d(12.dp))) {
        Text("Tu biblioteca online", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text(
            "Experimental · importa canciones de YouTube Music a tu biblioteca local",
            color = Gray, fontSize = 13.sp
        )
    }
}

@Composable
private fun AccountCard(o: OnlineLibrary) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.padding(horizontal = 20.dp).fillMaxWidth().clip(uiShape(24.dp)).background(cs.surface).padding(16.dp)) {
        Text(if (o.loggedIn) "Sesión de YouTube Music iniciada" else "Sin sesión", fontWeight = FontWeight.SemiBold)
        Text(
            if (o.loggedIn) "Puedes ver las playlists de tu cuenta e importar canciones."
            else "Buscar funciona sin cuenta. Para ver tus playlists, inicia sesión.",
            color = Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)
        )
        Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (o.loggedIn) OutlinedButton(onClick = { o.logout() }, shape = uiShape(14.dp)) { Text("Cerrar sesión") }
            else Button(onClick = { o.showLogin = true }, shape = uiShape(14.dp)) { Text("Iniciar sesión") }
        }
        Text(
            "Úsalo solo con música a la que tengas derecho y respeta los términos de YouTube.",
            color = Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp)
        )
    }
    if (o.showLogin) LoginDialog(o)
}

@Composable
private fun LoginDialog(o: OnlineLibrary) {
    val holder = remember { arrayOfNulls<WebView>(1) }
    DisposableEffect(Unit) { onDispose { runCatching { holder[0]?.destroy() } } }
    Dialog(onDismissRequest = { o.showLogin = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Iniciar sesión en YouTube Music", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                    TextButton(onClick = { o.showLogin = false }) { Text("Cerrar") }
                }
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            // Google rechaza el marcador "; wv" de las WebView incrustadas.
                            settings.userAgentString = settings.userAgentString.replace("; wv", "")
                            CookieManager.getInstance().setAcceptCookie(true)
                            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                            webViewClient = object : WebViewClient() {
                                override fun onPageFinished(view: WebView?, url: String?) {
                                    if (url != null && url.startsWith("https://music.youtube.com")) {
                                        val c = CookieManager.getInstance().getCookie(url)
                                        if (!c.isNullOrEmpty() && c.contains("SAPISID")) o.onLoginCookie(c)
                                    }
                                }
                            }
                            holder[0] = this
                            loadUrl(LOGIN_URL)
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun FolderAccessCard(o: OnlineLibrary) {
    val cs = MaterialTheme.colorScheme
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { o.grantFolderAccess(it) }
    Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp).fillMaxWidth().clip(uiShape(20.dp)).background(cs.surface).padding(16.dp)) {
        Text("Falta permiso de escritura", fontWeight = FontWeight.SemiBold)
        Text(
            "Para guardar las canciones en tu carpeta de música, JullMood necesita permiso de escritura en ella. Elige la misma carpeta que usa tu biblioteca.",
            color = Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)
        )
        Button(onClick = { picker.launch(null) }, shape = uiShape(14.dp), modifier = Modifier.padding(top = 10.dp)) { Text("Elegir carpeta") }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun OnlineTabs(o: OnlineLibrary) {
    Row(Modifier.padding(horizontal = 20.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected = o.tab == 0, onClick = { o.selectTab(0) }, label = { Text("Buscar") })
        FilterChip(selected = o.tab == 1, onClick = { o.selectTab(1) }, label = { Text("Mis playlists") })
    }
}

@Composable
private fun SearchBar(o: OnlineLibrary) {
    Row(Modifier.padding(horizontal = 20.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = o.query, onValueChange = { o.query = it }, singleLine = true,
            placeholder = { Text("Canción o artista") }, shape = uiShape(18.dp), modifier = Modifier.weight(1f),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { o.search() })
        )
        Spacer(Modifier.width(8.dp))
        Button(onClick = { o.search() }, enabled = o.query.isNotBlank() && !o.searching, shape = uiShape(16.dp)) { Text("Buscar") }
    }
}

@Composable
private fun ImportBar(o: OnlineLibrary, from: List<YtSong>) {
    val n = o.selected.size
    Row(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Button(onClick = { o.importSelected(from) }, shape = uiShape(16.dp)) {
            Text(if (n == 1) "Importar 1 canción" else "Importar $n canciones")
        }
        TextButton(onClick = { o.clearSelection() }) { Text("Quitar selección") }
    }
}

@Composable
private fun Busy(text: String) {
    Row(Modifier.padding(horizontal = 24.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
        Text(text, color = Gray, modifier = Modifier.padding(start = 12.dp))
    }
}

@Composable
private fun InfoLine(text: String, error: Boolean) {
    Text(
        text, fontSize = 13.sp,
        color = if (error) MaterialTheme.colorScheme.error else Gray,
        modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp)
    )
}

private fun statusText(j: ImportJob): String = when (j.state) {
    JobState.QUEUED -> "En cola"
    JobState.DOWNLOADING -> if (j.progress > 0f) "Descargando ${j.progress.toInt()} %" else "Preparando la descarga…"
    JobState.SAVING -> "Guardando en tu biblioteca…"
    JobState.DONE -> j.note ?: "Importada a tu biblioteca"
    JobState.ERROR -> "Error: " + (j.error ?: "desconocido")
    JobState.CANCELLED -> "Cancelada"
}

@Composable
private fun YtRow(s: YtSong, checked: Boolean, job: ImportJob?, onToggle: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val busy = job != null && job.active
    val done = job != null && job.state == JobState.DONE
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp).clip(uiShape(14.dp))
            .clickable(enabled = !busy && !done, onClick = onToggle).padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RemoteCover(s.thumbUrl, Modifier.size(52.dp))
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            val sub = listOf(s.artist, s.album, s.durationText).filter { it.isNotBlank() }.joinToString(" · ")
            Text(sub, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Gray, fontSize = 13.sp)
            if (job != null) {
                Text(
                    statusText(job), fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis,
                    color = if (job.state == JobState.ERROR) cs.error else cs.primary
                )
                if (job.state == JobState.DOWNLOADING && job.progress > 0f)
                    Box(Modifier.fillMaxWidth().padding(top = 4.dp).height(4.dp).clip(uiShape(2.dp)).background(cs.onSurface.copy(alpha = 0.12f))) {
                        Box(Modifier.fillMaxWidth((job.progress / 100f).coerceIn(0f, 1f)).fillMaxHeight().background(cs.primary))
                    }
            }
        }
        if (!busy && !done) Checkbox(checked = checked, onCheckedChange = { onToggle() })
        else if (busy && job != null && job.state != JobState.DOWNLOADING) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
        else if (done) Text("✓", color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    }
}

@Composable
private fun PlaylistRow(p: YtPlaylist, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp).clip(uiShape(14.dp)).clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RemoteCover(p.thumbUrl, Modifier.size(56.dp))
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(p.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            if (p.subtitle.isNotBlank()) Text(p.subtitle, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Gray, fontSize = 13.sp)
        }
        Text("›", color = Gray, fontSize = 22.sp)
    }
}

@Composable
private fun QueueCard(o: OnlineLibrary) {
    val cs = MaterialTheme.colorScheme
    val all = o.jobs.values.toList()
    val active = all.count { it.active }
    val ok = all.count { it.state == JobState.DONE }
    val failed = all.count { it.state == JobState.ERROR }
    Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp).fillMaxWidth().clip(uiShape(20.dp)).background(cs.surface).padding(16.dp)) {
        Text("Importaciones", fontWeight = FontWeight.SemiBold)
        Text(
            buildString {
                if (active > 0) append("$active en curso o en cola · ")
                append("$ok importadas")
                if (failed > 0) append(" · $failed con error")
            },
            color = Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp)
        )
        all.filter { it.state == JobState.ERROR }.take(6).forEach { j ->
            Text("• ${j.song.title}: ${j.error ?: "error"}", color = cs.error, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
        }
        Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (active > 0) OutlinedButton(onClick = { o.cancelAll() }, shape = uiShape(14.dp)) { Text("Cancelar") }
            if (failed > 0) FilledTonalButton(onClick = { o.retryFailed() }, shape = uiShape(14.dp)) { Text("Reintentar") }
            if (active == 0) TextButton(onClick = { o.clearFinished() }) { Text("Limpiar") }
        }
    }
}

@Composable
private fun EngineFooter(o: OnlineLibrary) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp).fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { o.updateEngine() }, enabled = !o.updating) { Text("Actualizar motor de descarga") }
            if (o.updating) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
        }
        o.engineMsg?.let { Text(it, color = Gray, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 12.dp)) }
        Text(
            "Mantén JullMood abierto mientras se importa. Si una descarga falla, actualiza el motor y reintenta.",
            color = Gray, fontSize = 11.sp, modifier = Modifier.padding(start = 12.dp, end = 12.dp, top = 4.dp)
        )
    }
}

// ---------------------------------------------------------------------------------------------- imágenes remotas

/** Miniaturas de YouTube Music: caché pequeña en memoria, sin librerías de imágenes. */
private object RemoteImages {
    private val cache = object : LruCache<String, Bitmap>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun peek(url: String): Bitmap? = cache.get(url)

    fun load(url: String): Bitmap? {
        cache.get(url)?.let { return it }
        return runCatching {
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 10_000; c.readTimeout = 15_000
                if (c.responseCode !in 200..299) return@runCatching null
                c.inputStream.use { BitmapFactory.decodeStream(it) }
            } finally { c.disconnect() }
        }.getOrNull()?.also { cache.put(url, it) }
    }
}

@Composable
private fun RemoteCover(url: String, modifier: Modifier) {
    val bmp by produceState<Bitmap?>(RemoteImages.peek(url), url) {
        if (value == null && url.isNotEmpty()) value = withContext(Dispatchers.IO) { RemoteImages.load(url) }
    }
    Box(modifier.clip(uiShape(10.dp)), Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else DefaultCover(url)
    }
}
