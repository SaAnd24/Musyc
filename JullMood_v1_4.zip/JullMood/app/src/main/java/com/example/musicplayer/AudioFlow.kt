package com.example.musicplayer

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * v1.3: fundidos de volumen sobre el ExoPlayer ÚNICO del servicio (sin segundo reproductor ni segunda cadena).
 *
 * - Fade al pausar / reanudar: baja el volumen unos ms y entonces pausa de verdad; al reanudar lo sube.
 * - Crossfade: en los últimos N s baja la canción actual (primera mitad) y salta a la SIGUIENTE de la cola real
 *   (seekToNextMediaItem: respeta Queue, Shuffle y Repeat) que entra subiendo durante la segunda mitad.
 *   Con un solo reproductor no pueden sonar las dos a la vez: es un fundido "una tras otra".
 *
 * Usa ExoPlayer.setVolume (se oye al instante) y no ganancia en el procesador de audio, porque el buffer del
 * AudioSink adelanta el procesado ~0,3-0,7 s respecto a lo que suena. Todo corre en el hilo principal (el mismo
 * donde vive el ExoPlayer), sin servicios ni hilos propios; el temporizador solo gira mientras suena música y el
 * crossfade está activo. Con todo OFF no hace nada (idéntico a la v1.2-C).
 */
internal object JullFlow {
    private val h = Handler(Looper.getMainLooper())
    private var exo: ExoPlayer? = null
    private var cur = 1f                       // último volumen que hemos fijado

    // rampa de volumen en curso (una sola a la vez; siempre arranca desde el volumen actual: sin saltos)
    private var ramping = false
    private var rFrom = 1f
    private var rTo = 1f
    private var rT0 = 0L
    private var rDur = 1L
    private var rEnd: (() -> Unit)? = null

    private enum class St { IDLE, OUT, IN }
    private var st = St.IDLE
    private var armedId: String? = null        // canción para la que se programó el fundido de salida
    private var expectedId: String? = null     // canción a la que saltamos nosotros (para distinguirla de un cambio manual)
    private var pausing = false                // fundido de pausa en curso
    private var tickOn = false

    private const val HALF_PI = 1.5707964f

    private val rampStep = object : Runnable {
        override fun run() {
            if (exo == null) { ramping = false; return }
            val k = ((SystemClock.uptimeMillis() - rT0).toFloat() / rDur).coerceIn(0f, 1f)
            // curva de potencia constante: la salida baja con coseno y la entrada sube con seno
            val v = if (rTo >= rFrom) rFrom + (rTo - rFrom) * sin(k * HALF_PI) else rTo + (rFrom - rTo) * cos(k * HALF_PI)
            setVol(v)
            if (k < 1f) h.postDelayed(this, 25L)
            else { ramping = false; val e = rEnd; rEnd = null; e?.invoke() }
        }
    }

    private val restore = Runnable {
        val p = exo ?: return@Runnable
        // Con el audio ya parado se devuelve el volumen a 1 para que cualquier reanudación externa suene normal.
        if (!ramping && !pausing && !p.playWhenReady && cur < 1f) setVol(1f)
    }

    private val tick = object : Runnable {
        override fun run() {
            val p = exo
            val n = JullAudio.cfg.crossfadeMs.toLong()
            if (p == null || n <= 0L || !p.isPlaying) {
                tickOn = false
                if (st == St.OUT) { st = St.IDLE; armedId = null; if (!pausing) rampTo(1f, 200L) }
                return
            }
            var delay = 400L
            val dur = p.duration
            if (dur != C.TIME_UNSET && dur > 0L) {
                val rem = dur - p.currentPosition
                val half = n / 2
                val nextIdx = p.nextMediaItemIndex
                // Solo hay fundido si existe una siguiente canción distinta (sin Repeat One), la canción es larga y no es en directo.
                val eligible = nextIdx != C.INDEX_UNSET && nextIdx != p.currentMediaItemIndex &&
                    p.repeatMode != Player.REPEAT_MODE_ONE && dur >= 2 * n + 12_000L && !p.isCurrentMediaItemLive
                when (st) {
                    St.IDLE -> {
                        if (eligible && rem <= n && rem > half + 350L && !pausing) {
                            st = St.OUT
                            armedId = p.currentMediaItem?.mediaId
                            rampTo(0f, rem - half)
                        } else if (cur < 0.999f && !ramping && !pausing) rampTo(1f, 300L)
                    }
                    St.OUT -> when {
                        // cambio manual, seek hacia atrás fuera de la ventana, cola cambiada… → se cancela y se recupera el volumen
                        !eligible || p.currentMediaItem?.mediaId != armedId || rem > n + 700L ->
                            { st = St.IDLE; armedId = null; if (!pausing) rampTo(1f, 300L) }
                        rem <= half + 80L -> jump(p, half)
                        else -> {
                            // seek dentro de la ventana: se recalcula la rampa para que termine justo al saltar
                            val need = rem - half
                            val left = rT0 + rDur - SystemClock.uptimeMillis()
                            if (ramping && abs(left - need) > 350L) rampTo(0f, max(need, 120L))
                        }
                    }
                    St.IN -> {}
                }
                val far = rem - n - 1500L
                delay = when {
                    st != St.IDLE -> if (st == St.IN) 300L else 100L
                    far > 1000L -> min(far - 500L, 5000L)     // lejos del final: duerme (los seeks lo despiertan)
                    else -> 100L
                }
            }
            h.postDelayed(this, delay)
        }
    }

    private val listener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val id = mediaItem?.mediaId
            JullAudio.setSong(id)
            when (st) {
                // La canción cambió sin que saltáramos nosotros (manual o fin natural): volumen normal enseguida.
                St.OUT -> { st = St.IDLE; armedId = null; if (!pausing) rampTo(1f, 120L) }
                St.IN -> if (id != expectedId) { st = St.IDLE; expectedId = null; if (!pausing) rampTo(1f, 120L) }
                St.IDLE -> {}
            }
            startTick()
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            val p = exo ?: return
            if (isPlaying) {
                startTick()
                if (!ramping && !pausing && cur < 0.999f && st == St.IDLE) rampTo(1f, 300L)
            } else if (!p.playWhenReady) {
                // Pausa real (no un simple buffering o seek, p. ej. justo tras saltar de canción): se cancela cualquier
                // fundido pendiente (se recalcula al reanudar) y se restaura el volumen.
                st = St.IDLE; armedId = null; expectedId = null
                if (!pausing) { cancelRamp(); scheduleRestore() }
            }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_ENDED || playbackState == Player.STATE_IDLE) {
                // Fin de la cola o parada: no puede quedar volumen a medias para la próxima reproducción.
                st = St.IDLE; armedId = null; expectedId = null
                if (!pausing) { cancelRamp(); setVol(1f) }
            }
        }

        override fun onPositionDiscontinuity(oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int) {
            // Seek o salto: se reevalúa ya, sin esperar al siguiente turno del temporizador.
            if (reason == Player.DISCONTINUITY_REASON_SEEK && tickOn) { h.removeCallbacks(tick); h.post(tick) }
        }
    }

    // ---------- ciclo de vida (lo llama PlaybackService) ----------

    fun attach(p: ExoPlayer) {
        detach()
        exo = p
        cur = 1f
        p.addListener(listener)
        JullAudio.setSong(p.currentMediaItem?.mediaId)
        startTick()
    }

    fun detach() {
        exo?.removeListener(listener)
        h.removeCallbacks(rampStep); h.removeCallbacks(tick); h.removeCallbacks(restore)
        ramping = false; rEnd = null; tickOn = false; pausing = false
        st = St.IDLE; armedId = null; expectedId = null
        exo = null
    }

    /** El ViewModel cambió la configuración (crossfade o fade al pausar). */
    fun onCfgChanged() {
        if (exo == null) return
        if (JullAudio.cfg.crossfadeMs <= 0 && st != St.IDLE) {
            st = St.IDLE; armedId = null; expectedId = null
            if (!pausing) rampTo(1f, 200L)
        }
        startTick()
    }

    // ---------- pausa / reanudación con fundido (las llama FadingPlayer) ----------

    fun pauseWithFade(p: ExoPlayer) {
        val ms = JullAudio.cfg.pauseFadeMs.toLong()
        if (ms <= 0L || !p.isPlaying) {                       // sin fundido (o ya no suena): pausa normal
            p.pause()
            return
        }
        if (pausing) return
        pausing = true
        st = St.IDLE; armedId = null; expectedId = null       // la pausa cancela cualquier crossfade pendiente
        rampTo(0f, ms) { pausing = false; p.pause(); scheduleRestore() }
    }

    fun playWithFade(p: ExoPlayer) {
        val ms = JullAudio.cfg.pauseFadeMs.toLong()
        if (pausing) {                                        // reanudar a mitad del fundido de pausa: no llega a pausar
            pausing = false
            rampTo(1f, max(ms / 2, 150L))
            return
        }
        h.removeCallbacks(restore)
        if (ms > 0L && !p.playWhenReady) {
            cancelRamp()
            setVol(0f)
            p.play()
            rampTo(1f, ms)
        } else p.play()
    }

    // ---------- crossfade ----------

    private fun startTick() {
        if (tickOn) return
        val p = exo ?: return
        if (JullAudio.cfg.crossfadeMs <= 0 || !p.isPlaying) return
        tickOn = true
        h.post(tick)
    }

    private fun jump(p: ExoPlayer, half: Long) {
        val nextIdx = p.nextMediaItemIndex
        if (nextIdx == C.INDEX_UNSET) { st = St.IDLE; armedId = null; rampTo(1f, 300L); return }
        expectedId = p.getMediaItemAt(nextIdx).mediaId
        st = St.IN
        armedId = null
        cancelRamp()
        setVol(0f)
        p.seekToNextMediaItem()                               // la cola real: respeta Shuffle y Repeat
        rampTo(1f, half) { if (st == St.IN) { st = St.IDLE; expectedId = null } }
    }

    // ---------- volumen ----------

    private fun setVol(v: Float) {
        cur = v.coerceIn(0f, 1f)
        exo?.volume = cur
    }

    private fun cancelRamp() {
        h.removeCallbacks(rampStep)
        ramping = false
        rEnd = null
    }

    private fun scheduleRestore() {
        h.removeCallbacks(restore)
        h.postDelayed(restore, 150L)
    }

    private fun rampTo(target: Float, ms: Long, end: (() -> Unit)? = null) {
        cancelRamp()
        if (ms <= 20L) { setVol(target); end?.invoke(); return }
        rFrom = cur; rTo = target; rT0 = SystemClock.uptimeMillis(); rDur = ms; rEnd = end
        ramping = true
        h.post(rampStep)
    }
}

/**
 * Envoltorio del ExoPlayer que usa la sesión: intercepta play/pause (botones de la app, notificación, auriculares…)
 * para aplicar el fade. Todo lo demás se reenvía tal cual; no es otro reproductor.
 */
internal class FadingPlayer(private val exo: ExoPlayer) : ForwardingPlayer(exo) {
    override fun play() { JullFlow.playWithFade(exo) }
    override fun pause() { JullFlow.pauseWithFade(exo) }
    override fun setPlayWhenReady(playWhenReady: Boolean) {
        if (playWhenReady) JullFlow.playWithFade(exo) else JullFlow.pauseWithFade(exo)
    }
}
