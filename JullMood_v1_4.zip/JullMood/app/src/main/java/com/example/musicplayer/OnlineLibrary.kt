package com.example.musicplayer

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.CookieManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.io.IOException

enum class JobState { QUEUED, DOWNLOADING, SAVING, DONE, ERROR, CANCELLED }

data class ImportJob(
    val song: YtSong,
    val state: JobState,
    val progress: Float = 0f,
    val error: String? = null,
    val note: String? = null
) {
    val active: Boolean get() = state == JobState.QUEUED || state == JobState.DOWNLOADING || state == JobState.SAVING
}

/**
 * "Tu biblioteca online" (v1.4, experimental). Es una sección independiente del Home: no reproduce nada de
 * YouTube Music. Solo busca, lista playlists e IMPORTA canciones a la biblioteca local; una vez importadas,
 * el sistema interno de JullMood (metadata, letras, estadísticas, mood…) se encarga de todo.
 */
class OnlineLibrary(private val vm: PlayerViewModel) {
    private val app: Application = vm.getApplication<Application>()
    private val prefs = app.getSharedPreferences("ytm", Context.MODE_PRIVATE)
    private val session = YtSession(app)
    private val api = YtMusicApi(session)
    private val scope get() = vm.viewModelScope

    // ---- Sesión ----
    var loggedIn by mutableStateOf(session.loggedIn); private set
    var showLogin by mutableStateOf(false)

    // ---- Pestañas internas de la sección (no son navegación de la app) ----
    var tab by mutableIntStateOf(0); private set          // 0 buscar, 1 mis playlists

    // ---- Búsqueda ----
    var query by mutableStateOf("")
    var results by mutableStateOf<List<YtSong>>(emptyList()); private set
    var searching by mutableStateOf(false); private set
    var searchError by mutableStateOf<String?>(null); private set
    private var searchJob: Job? = null

    // ---- Playlists ----
    var playlists by mutableStateOf<List<YtPlaylist>>(emptyList()); private set
    var plLoading by mutableStateOf(false); private set
    var plError by mutableStateOf<String?>(null); private set
    var openPlaylist by mutableStateOf<YtPlaylist?>(null); private set
    var plSongs by mutableStateOf<List<YtSong>>(emptyList()); private set
    var plSongsLoading by mutableStateOf(false); private set
    var plSongsError by mutableStateOf<String?>(null); private set
    private var plJob: Job? = null

    // ---- Selección e importación ----
    val selected = mutableStateListOf<String>()
    val jobs = mutableStateMapOf<String, ImportJob>()
    var needFolderAccess by mutableStateOf(false); private set
    var notice by mutableStateOf<String?>(null); private set
    var engineMsg by mutableStateOf<String?>(null); private set
    var updating by mutableStateOf(false); private set
    private val queue = ArrayDeque<YtSong>()
    private var worker: Job? = null
    private var currentId: String? = null

    // ------------------------------------------------------------------ sesión

    fun onLoginCookie(cookie: String) {
        session.save(cookie)
        loggedIn = session.loggedIn
        if (loggedIn) {
            showLogin = false
            notice = null
            loadPlaylists()
        }
    }

    fun logout() {
        session.clear()
        runCatching { CookieManager.getInstance().removeAllCookies(null) }
        loggedIn = false
        playlists = emptyList()
        openPlaylist = null
        plSongs = emptyList()
        selected.clear()
        if (tab == 1) tab = 0
    }

    // ------------------------------------------------------------------ navegación interna

    fun selectTab(t: Int) {
        if (tab == t) return
        tab = t
        selected.clear()
        if (t == 1 && loggedIn && playlists.isEmpty() && !plLoading) loadPlaylists()
    }

    fun toggle(id: String) { if (id in selected) selected.remove(id) else selected.add(id) }
    fun selectAll(list: List<YtSong>) {
        selected.clear()
        selected.addAll(list.filter { jobs[it.videoId]?.state != JobState.DONE }.map { it.videoId })
    }
    fun clearSelection() = selected.clear()

    // ------------------------------------------------------------------ consultas

    fun search() {
        val q = query.trim()
        if (q.isEmpty()) return
        searchJob?.cancel()
        searchJob = scope.launch {
            searching = true; searchError = null
            try {
                val found = withContext(Dispatchers.IO) { api.search(q) }
                results = found
                selected.clear()
                if (found.isEmpty()) searchError = "Sin resultados para \"$q\""
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) { searchError = explain(e) }
            finally { searching = false }
        }
    }

    fun loadPlaylists() {
        if (!loggedIn) return
        scope.launch {
            plLoading = true; plError = null
            try {
                playlists = withContext(Dispatchers.IO) { api.libraryPlaylists() }
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) {
                plError = explain(e)
                if (e is YtAuthException) logoutKeepingMessage()
            } finally { plLoading = false }
        }
    }

    fun showPlaylist(p: YtPlaylist) {
        openPlaylist = p
        plSongs = emptyList()
        plSongsError = null
        selected.clear()
        plJob?.cancel()
        plJob = scope.launch {
            plSongsLoading = true
            try {
                plSongs = withContext(Dispatchers.IO) { api.playlistSongs(p.browseId) }
                if (plSongs.isEmpty()) plSongsError = "Esta playlist no tiene canciones disponibles"
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) { plSongsError = explain(e) }
            finally { plSongsLoading = false }
        }
    }

    fun closePlaylist() {
        plJob?.cancel()
        openPlaylist = null
        plSongs = emptyList()
        plSongsError = null
        selected.clear()
    }

    private fun logoutKeepingMessage() {
        val msg = plError
        logout()
        plError = msg
    }

    private fun explain(e: Exception): String = when (e) {
        is YtAuthException -> e.message ?: "Sesión caducada"
        is IOException -> "No se pudo conectar con YouTube Music. Revisa tu conexión."
        else -> "Error: " + (e.message ?: e.javaClass.simpleName)
    }

    // ------------------------------------------------------------------ importación

    fun importSelected(from: List<YtSong>) {
        val picked = from.filter { it.videoId in selected }
        selected.clear()
        enqueue(picked)
    }

    private fun enqueue(songs: List<YtSong>) {
        var skipped = 0
        for (s in songs) {
            val cur = jobs[s.videoId]
            if (cur != null && (cur.active || cur.state == JobState.DONE)) { skipped++; continue }
            if (inLibrary(s)) {
                jobs[s.videoId] = ImportJob(s, JobState.DONE, note = "Ya estaba en tu biblioteca")
                continue
            }
            jobs[s.videoId] = ImportJob(s, JobState.QUEUED)
            queue.addLast(s)
        }
        if (skipped > 0) notice = "$skipped canción(es) ya estaban importadas o en cola"
        startWorker()
    }

    private fun norm(t: String) = t.lowercase().filter { it.isLetterOrDigit() }

    private fun inLibrary(s: YtSong): Boolean {
        val t = norm(s.title)
        val a = norm(s.artist)
        if (t.isEmpty() || a.isEmpty()) return false
        return vm.songs.any { norm(it.title) == t && norm(it.artist) == a }
    }

    fun retryFailed() {
        val failed = jobs.values.filter { it.state == JobState.ERROR }.map { it.song }
        failed.forEach { jobs.remove(it.videoId) }
        enqueue(failed)
    }

    fun cancelAll() {
        queue.clear()
        for ((id, j) in jobs.entries.toList()) if (j.active) jobs[id] = j.copy(state = JobState.CANCELLED, progress = 0f)
        currentId?.let { YtEngine.cancel("ytm_$it") }
    }

    fun clearFinished() {
        for ((id, j) in jobs.entries.toList()) if (!j.active) jobs.remove(id)
        needFolderAccess = false
    }

    fun grantFolderAccess(uri: Uri?) {
        if (uri == null) return
        runCatching {
            app.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        }
        if (vm.musicFolder != null && uri != vm.musicFolder) {
            notice = "Elige la misma carpeta de música que usa JullMood (la de tu biblioteca)."
            return
        }
        needFolderAccess = false
        notice = null
        retryFailed()
    }

    private fun setJob(id: String, f: (ImportJob) -> ImportJob) {
        val cur = jobs[id] ?: return
        if (cur.state == JobState.CANCELLED) return
        jobs[id] = f(cur)
    }

    private fun startWorker() {
        if (worker?.isActive == true) return
        worker = scope.launch {
            maybeAutoUpdate()
            do {
                val done = ArrayList<Pair<YtSong, Pair<SavedFile, File?>>>()
                while (true) {
                    val s = queue.removeFirstOrNull() ?: break
                    if (jobs[s.videoId]?.state != JobState.QUEUED) continue
                    currentId = s.videoId
                    try {
                        val res = withContext(Dispatchers.IO) { importOne(s) }
                        done += s to res
                        setJob(s.videoId) { it.copy(state = JobState.SAVING, progress = 100f) }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: FolderAccessException) {
                        needFolderAccess = true
                        setJob(s.videoId) { it.copy(state = JobState.ERROR, error = e.message) }
                    } catch (e: Throwable) {
                        if (jobs[s.videoId]?.state != JobState.CANCELLED)
                            setJob(s.videoId) { it.copy(state = JobState.ERROR, error = YtEngine.friendlyError(e)) }
                    } finally { currentId = null }
                }
                if (done.isNotEmpty()) completeImports(done)
            } while (queue.isNotEmpty())
        }
    }

    private fun importOne(s: YtSong): Pair<SavedFile, File?> {
        setJob(s.videoId) { it.copy(state = JobState.DOWNLOADING, progress = 0f) }
        val tmp = File(app.cacheDir, "ytm")
        val cookies = if (session.loggedIn) session.writeCookiesTxt() else null
        val audio = YtEngine.download(app, s.videoId, tmp, cookies, "ytm_${s.videoId}") { p ->
            setJob(s.videoId) { it.copy(progress = p) }
        }
        setJob(s.videoId) { it.copy(state = JobState.SAVING, progress = 100f) }
        val cover = YtCovers.fetch(app, s.videoId, s.coverUrl)
        val base = if (s.artist.isNotBlank()) "${s.artist} - ${s.title}" else s.title
        try {
            val saved = YtLibraryWriter.save(app, audio, base, vm.musicFolder)
            return saved to cover
        } finally { runCatching { audio.delete() } }
    }

    /** Reescanea la biblioteca una sola vez y completa título, artista, álbum y portada si hiciera falta. */
    private suspend fun completeImports(done: List<Pair<YtSong, Pair<SavedFile, File?>>>) {
        vm.loadSongs()
        withTimeoutOrNull(120_000L) {
            delay(300)
            while (!vm.scanFinished || vm.loading) delay(300)
        }
        for ((s, res) in done) {
            val (saved, cover) = res
            val key = saved.displayName.lowercase()
            val song = vm.songs.firstOrNull { it.pathKey == key || it.pathKey.endsWith("/$key") }
            if (song == null) {
                setJob(s.videoId) { it.copy(state = JobState.DONE, note = "Guardada en tu carpeta de música; si no aparece, revisa la carpeta de tu biblioteca") }
                continue
            }
            try {
                val same = song.title.equals(s.title, true) &&
                    (s.artist.isBlank() || song.artist.equals(s.artist, true)) &&
                    (s.album.isBlank() || song.album.equals(s.album, true))
                if (!same) {
                    vm.applyManualInfo(song, s.title, s.artist.ifBlank { null }, s.album.ifBlank { null })
                    delay(500)
                }
                val hasArt = withContext(Dispatchers.IO) { ArtCache.load(app, song, 128) != null }
                if (!hasArt && cover != null) vm.applyCoverFromUri(song, Uri.fromFile(cover)) { }
            } catch (e: CancellationException) { throw e
            } catch (_: Exception) { /* los datos ya están en el archivo; el ajuste fino es opcional */ }
            setJob(s.videoId) { it.copy(state = JobState.DONE, progress = 100f, note = null) }
        }
    }

    // ------------------------------------------------------------------ motor (yt-dlp)

    fun updateEngine() {
        if (updating) return
        scope.launch {
            updating = true
            engineMsg = "Actualizando el motor de descarga…"
            engineMsg = try {
                val r = withContext(Dispatchers.IO) { YtEngine.update(app) }
                prefs.edit().putLong("engineUpdatedAt", System.currentTimeMillis()).apply()
                r
            } catch (e: Throwable) { "No se pudo actualizar: " + YtEngine.friendlyError(e) }
            updating = false
        }
    }

    /** Antes de la primera descarga de la sesión, si el motor lleva más de 3 días sin actualizarse. */
    private suspend fun maybeAutoUpdate() {
        if (autoChecked) return
        autoChecked = true
        val last = prefs.getLong("engineUpdatedAt", 0L)
        if (System.currentTimeMillis() - last < 3L * 24 * 3600 * 1000) return
        engineMsg = "Actualizando el motor de descarga…"
        engineMsg = try {
            val r = withContext(Dispatchers.IO) { YtEngine.update(app) }
            prefs.edit().putLong("engineUpdatedAt", System.currentTimeMillis()).apply()
            r
        } catch (e: CancellationException) { throw e
        } catch (e: Throwable) { "No se pudo actualizar el motor (se usa la versión incluida)" }
    }
    private var autoChecked = false
}
