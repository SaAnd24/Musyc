# Avisos de terceros y licencia

## Licencia de JullMood a partir de la v1.4
Desde la v1.4 JullMood incluye **youtubedl-android** (GPL-3.0), por lo que el proyecto completo se
distribuye bajo **GNU GPL v3** (ver `LICENSE`). Si compartes el APK, debes ofrecer también el código
fuente completo bajo la misma licencia. Para uso personal sin distribuir el APK no hay obligación adicional.

## Componentes
| Componente | Uso | Licencia |
|---|---|---|
| youtubedl-android (`io.github.junkfood02.youtubedl-android:library` y `:ffmpeg`, 0.18.1) | Envoltura Android de yt-dlp y FFmpeg para descargar el audio | GPL-3.0 |
| yt-dlp (incluido en la biblioteca anterior) | Extracción y descarga | Unlicense |
| FFmpeg (módulo `ffmpeg` de la biblioteca) | Incrustar metadatos | Ver avisos del módulo (LGPL/GPL según compilación) |
| AndroidX, Jetpack Compose, Material 3, Media3 | Interfaz y reproducción | Apache-2.0 |

## Aviso de uso
"Tu biblioteca online" es una función **experimental**. YouTube Music y YouTube pueden cambiar o bloquear
el acceso en cualquier momento. Importa solo música a la que tengas derecho y respeta los términos de
servicio de YouTube y las leyes de propiedad intelectual de tu país. La responsabilidad del uso es tuya.
