# JullMood v1.4 — Tu biblioteca online (experimental)

## Qué añade
Una sección independiente **al final del Home** (después de todo el contenido existente, solo con el scroll).
No es una pestaña, ni una pantalla principal, ni un elemento de navegación: JullMood conserva su diseño y su
experiencia offline.

- **Iniciar sesión con YouTube Music** (WebView de Google; las cookies se guardan en `noBackupFilesDir`).
- **Buscar canciones** en YT Music (funciona sin cuenta).
- **Ver las playlists de la cuenta** (incluye "Canciones que te gustan"), abrir una y **seleccionar canciones**.
- **Importar** a la biblioteca local: título, artista, álbum y portada cuando están disponibles.
- **Progreso y errores** por canción (en cola, descargando %, guardando, importada, error con motivo), con
  Cancelar y Reintentar.

Una vez importada, la canción es una canción local más: organización, reproducción, metadata, letras,
estadísticas y moods dependen solo del sistema interno de JullMood.

## Qué NO hace (a propósito)
Sin streaming de YT Music, sin reproductor aparte, sin recomendaciones, sin sincronización bidireccional.

## Cómo funciona por dentro
- `YtMusicApi.kt`: cliente mínimo (HttpURLConnection + org.json) para búsqueda y playlists. Sin librerías nuevas.
- `YtImporter.kt`: descarga con yt-dlp (youtubedl-android) y guarda el archivo en la biblioteca:
  - Sin carpeta elegida: `Music/JullMood/` vía MediaStore.
  - Con carpeta elegida bajo `Music/…` (almacenamiento interno): `<tu carpeta>/JullMood/` vía MediaStore.
  - Otra ubicación: Storage Access Framework; la app pedirá una vez permiso de escritura (elige la misma carpeta).
- `OnlineLibrary.kt`: estado y cola de importación (una a la vez). Tras importar reescanea la biblioteca una sola
  vez y, si el archivo no trae tags, aplica título/artista/álbum/portada con el sistema interno (`applyManualInfo`).
- `OnlineLibraryUi.kt`: ítems de Compose que se añaden al final de la lista del Home (una sola línea en `Home.kt`).

## Cambios en el proyecto
- `app/build.gradle.kts`: v1.4 (versionCode 7), dependencias `youtubedl-android` (library + ffmpeg 0.18.1) y
  `useLegacyPackaging = true` para las librerías nativas. Sin cambios de Kotlin, AGP ni Gradle.
- `Home.kt`: `onlineLibraryItems(vm.online)` al final del `LazyColumn`.
- `PlayerViewModel.kt`: `internal val online by lazy { OnlineLibrary(this) }`.
- Gradle Wrapper: `gradlew`, `gradlew.bat` y `gradle-wrapper.properties` (8.2). El workflow genera
  `gradle-wrapper.jar` si falta y compila con `./gradlew assembleDebug`.
- `LICENSE` (GPL-3.0) y `NOTICE_TERCEROS.md`.

## Notas de uso
- El APK crece bastante (Python + yt-dlp + FFmpeg).
- Desde noviembre de 2025 yt-dlp pide un runtime de JavaScript externo para YouTube. Si una descarga falla,
  usa **Actualizar motor de descarga** (también se intenta solo antes de la primera descarga si pasaron 3 días).
- Mantén JullMood abierto mientras se importa.
- No se pudo compilar ni probar en el entorno donde se generó el proyecto: la primera compilación en GitHub
  Actions es la verificación real.
