package com.example.musicplayer

import android.app.PendingIntent
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.Player
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/** Temporizador para dormir: vive en el proceso del servicio, así sigue aunque cierres la pantalla. */
object SleepTimer {
    var leftMs by mutableLongStateOf(0L); private set
    var player: Player? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            leftMs -= 1000
            if (leftMs <= 0) { leftMs = 0; player?.pause() } else handler.postDelayed(this, 1000)
        }
    }
    fun start(minutes: Int) { cancel(); leftMs = minutes * 60_000L; handler.postDelayed(tick, 1000) }
    fun cancel() { handler.removeCallbacks(tick); leftMs = 0 }
}

class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private var cast: CastController? = null     // v1.5: transmitir a TV
    private var exoPlayer: ExoPlayer? = null      // v1.5: la sesión puede estar usando el CastPlayer; este se libera siempre

    override fun onCreate() {
        super.onCreate()
        JullAudio.load(applicationContext)      // v1.3: ajustes de audio guardados (por si el servicio arranca sin la app)
        val player = ExoPlayer.Builder(this)
            // v1.2-C (LiveJull): mismo audio de siempre; solo añade un medidor de volumen que no modifica el sonido.
            .setRenderersFactory(LiveRenderersFactory(applicationContext))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()

        exoPlayer = player
        SleepTimer.player = player
        JullFlow.attach(player)                 // v1.3: crossfade y fade al pausar sobre este mismo reproductor

        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val phonePlayer = FadingPlayer(player)
        val built = MediaSession.Builder(this, phonePlayer)   // v1.3: mismo reproductor; solo intercepta play/pause para el fade
            .setSessionActivity(openApp)
            .setBitmapLoader(JmBitmapLoader(applicationContext))   // portada real en notificación y pantalla bloqueada
            .build()
        session = built
        // v1.5: si hay Google Cast disponible, la sesión puede pasar al CastPlayer (TV) y volver al teléfono.
        cast = CastController(this, built, player, phonePlayer).also { runCatching { it.init() } }
        // Icono pequeño de la notificación con la identidad de JullMood (auriculares); los botones son los estándar.
        setMediaNotificationProvider(
            DefaultMediaNotificationProvider.Builder(this).build().also { it.setSmallIcon(R.drawable.ic_notification) }
        )
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = session?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        runCatching { cast?.release() }
        cast = null
        SleepTimer.cancel()
        SleepTimer.player = null
        JullFlow.detach()                       // v1.3: libera temporizadores y listeners
        LoudnessStore.flushNow()
        session?.release()
        exoPlayer?.release()
        exoPlayer = null
        session = null
        super.onDestroy()
    }
}
