package com.example.musicplayer

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.mediarouter.media.MediaRouteSelector
import androidx.mediarouter.media.MediaRouter

/**
 * v1.5 · Botón "Transmitir". Se tiñe con el color de acento mientras hay una TV conectada.
 * Usa un selector propio (en vez del MediaRouteButton del SDK) para respetar el tema de la app.
 */
@Composable
internal fun CastButton() {
    var open by remember { mutableStateOf(false) }
    val connected = CastState.device != null
    IconBtn(
        R.drawable.ic_cast,
        if (connected) "Transmitiendo a ${CastState.device}" else "Transmitir a TV",
        if (connected) MaterialTheme.colorScheme.primary else Gray
    ) { open = true }
    if (open) CastDialog { open = false }
}

@Composable
private fun CastDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val castCtx = remember { CastBridge.castContext(ctx) }

    if (castCtx == null) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text("Transmitir a TV") },
            text = { Text("Este teléfono no tiene Google Play Services, necesario para Google Cast.") },
            confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }
        )
        return
    }

    val router = remember { MediaRouter.getInstance(ctx) }
    val selector = remember { castCtx.mergedSelector ?: MediaRouteSelector.EMPTY }
    var routes by remember { mutableStateOf(emptyList<MediaRouter.RouteInfo>()) }
    var scanning by remember { mutableStateOf(true) }

    // Mientras el diálogo está abierto se buscan TVs en la red; al cerrarlo se deja de buscar (ahorra batería).
    DisposableEffect(router) {
        fun refresh() {
            routes = router.routes.filter { it.isEnabled && it.matchesSelector(selector) }
        }
        val cb = object : MediaRouter.Callback() {
            override fun onRouteAdded(r: MediaRouter, route: MediaRouter.RouteInfo) { refresh(); scanning = false }
            override fun onRouteRemoved(r: MediaRouter, route: MediaRouter.RouteInfo) = refresh()
            override fun onRouteChanged(r: MediaRouter, route: MediaRouter.RouteInfo) = refresh()
        }
        router.addCallback(selector, cb, MediaRouter.CALLBACK_FLAG_REQUEST_DISCOVERY)
        refresh()
        onDispose { router.removeCallback(cb) }
    }

    val current = CastState.device
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("Transmitir a TV") },
        text = {
            Column {
                if (current != null) {
                    Text("Transmitiendo a $current", color = MaterialTheme.colorScheme.primary)
                    TextButton(onClick = { castCtx.sessionManager.endCurrentSession(true); onDismiss() }) {
                        Text("Desconectar y volver al teléfono")
                    }
                } else if (routes.isEmpty()) {
                    Text(
                        if (scanning) "Buscando TVs en tu red Wi‑Fi…" else "No se encontraron TVs.",
                        color = Gray
                    )
                    Text(
                        "El teléfono y la TV deben estar en la misma Wi‑Fi, y la TV debe tener Chromecast o Google Cast integrado.",
                        color = Gray
                    )
                }
                if (current == null) routes.forEach { r ->
                    TextButton(onClick = { router.selectRoute(r); onDismiss() }) { Text(r.name) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }
    )
}
