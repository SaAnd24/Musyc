package com.example.musicplayer

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.media3.cast.CastPlayer
import androidx.media3.cast.SessionAvailabilityListener
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import com.google.android.gms.cast.CastMediaControlIntent
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastOptions
import com.google.android.gms.cast.framework.OptionsProvider
import com.google.android.gms.cast.framework.SessionProvider
import com.google.android.gms.cast.framework.media.CastMediaOptions

/** Configuración de Google Cast (se declara en el manifest). Receptor por defecto de Google: audio + título + portada. */
class JullCastOptions : OptionsProvider {
    override fun getCastOptions(context: Context): CastOptions =
        CastOptions.Builder()
            .setReceiverApplicationId(CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID)
            .setStopReceiverApplicationWhenEndingSession(true)
            // La notificación y la pantalla bloqueada ya las gestiona la MediaSession de JullMood: se desactivan las del SDK.
            .setCastMediaOptions(CastMediaOptions.Builder().setMediaSessionEnabled(false).setNotificationOptions(null).build())
            .build()

    override fun getAdditionalSessionProviders(context: Context): List<SessionProvider>? = null
}

/** Acceso al CastContext sin romper la app en dispositivos sin Google Play Services. */
object CastBridge {
    @Suppress("DEPRECATION")
    fun castContext(ctx: Context): CastContext? =
        runCatching { CastContext.getSharedInstance(ctx.applicationContext) }.getOrNull()
}

/**
 * v1.5 · Transmitir a TV. Vive dentro de PlaybackService.
 *
 * Cuando se conecta una TV, la MediaSession cambia de reproductor (ExoPlayer del teléfono -> CastPlayer) conservando
 * cola, posición, repetición y estado de reproducción; al desconectar, vuelve al teléfono (en pausa) con la misma cola.
 * La app (MediaController) no nota la diferencia: sigue hablando con la misma sesión.
 */
internal class CastController(
    private val service: Context,
    private val session: MediaSession,
    private val exo: ExoPlayer,            // ExoPlayer real (con crossfade, ecualizador, etc.)
    private val phonePlayer: Player        // el mismo ExoPlayer envuelto en FadingPlayer, tal como lo usa la sesión
) {
    private companion object {
        const val MAX_ITEMS = 300          // la cola de Cast tiene límite: se envía una ventana alrededor de la canción actual
        const val BEFORE = 10
    }

    private val main = Handler(Looper.getMainLooper())
    private var castCtx: CastContext? = null
    private var cast: CastPlayer? = null
    private var onCast = false

    // Copia del estado de Cast: al terminar la sesión el CastPlayer vacía su cola, así que hay que tenerla guardada.
    private var mItems: List<MediaItem> = emptyList()
    private var mIndex = 0
    private var mPos = 0L
    private var mRepeat = Player.REPEAT_MODE_OFF
    private var shuffleWas = false
    private var backup: Backup? = null
    private class Backup(val full: List<MediaItem>, val from: Int, val windowIds: List<String>)

    private val mirror = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            if (!onCast) return
            if (player.mediaItemCount > 0) {
                if (events.contains(Player.EVENT_TIMELINE_CHANGED) || mItems.size != player.mediaItemCount) {
                    mItems = List(player.mediaItemCount) { player.getMediaItemAt(it) }
                }
                mIndex = player.currentMediaItemIndex
                mPos = player.currentPosition.coerceAtLeast(0L)
                mRepeat = player.repeatMode
            }
        }
    }
    private val poll = object : Runnable {
        override fun run() {
            val c = cast
            if (onCast && c != null && c.mediaItemCount > 0) mPos = c.currentPosition.coerceAtLeast(0L)
            if (onCast) main.postDelayed(this, 1000)
        }
    }

    fun init() {
        val ctx = CastBridge.castContext(service) ?: return        // sin Google Play Services: la función simplemente no aparece
        castCtx = ctx
        val cp = runCatching { CastPlayer(ctx, JullCastConverter(service)) }.getOrNull() ?: return
        cast = cp
        cp.addListener(mirror)
        cp.setSessionAvailabilityListener(object : SessionAvailabilityListener {
            override fun onCastSessionAvailable() { toCast() }
            override fun onCastSessionUnavailable() { toPhone() }
        })
        if (cp.isCastSessionAvailable) toCast()
    }

    fun release() {
        main.removeCallbacks(poll)
        if (onCast) { onCast = false; session.player = phonePlayer; SleepTimer.player = exo }
        cast?.run { setSessionAvailabilityListener(null); removeListener(mirror); release() }
        cast = null
        CastServer.stop()
        CastState.device = null
    }

    private fun toast(msg: String) = Toast.makeText(service.applicationContext, msg, Toast.LENGTH_LONG).show()

    private fun toCast() {
        val cp = cast ?: return
        if (onCast) return
        // Sin red local no hay forma de que la TV lea los archivos: se cancela la conexión y se sigue en el teléfono.
        if (!CastServer.start(service)) {
            toast("No se pudo transmitir: conecta el teléfono a la misma Wi‑Fi que la TV.")
            castCtx?.sessionManager?.endCurrentSession(true)
            return
        }
        val old = session.player
        val n = old.mediaItemCount
        val cur = old.currentMediaItemIndex.coerceAtLeast(0)
        val pos = old.currentPosition.coerceAtLeast(0L)
        val wasPlaying = old.playWhenReady
        val repeat = old.repeatMode
        val shuffle = old.shuffleModeEnabled
        shuffleWas = shuffle
        backup = null

        var items: List<MediaItem> = emptyList()
        var start = 0
        if (n > 0) {
            if (shuffle) {
                // Cast no baraja: se envía la cola en el mismo orden aleatorio que llevaba el teléfono, desde la canción actual.
                val tl = old.currentTimeline
                val order = ArrayList<Int>().apply { add(cur) }
                var i = cur
                while (order.size < MAX_ITEMS) {
                    i = tl.getNextWindowIndex(i, Player.REPEAT_MODE_OFF, true)
                    if (i == C.INDEX_UNSET) break
                    order.add(i)
                }
                items = order.map { old.getMediaItemAt(it) }
            } else {
                val from = (cur - BEFORE).coerceAtLeast(0)
                val to = (from + MAX_ITEMS).coerceAtMost(n)
                items = (from until to).map { old.getMediaItemAt(it) }
                start = cur - from
                backup = Backup(List(n) { old.getMediaItemAt(it) }, from, items.map { it.mediaId })
            }
        }

        exo.stop(); exo.clearMediaItems()
        onCast = true
        session.player = cp
        SleepTimer.player = cp
        try {
            cp.repeatMode = repeat
            if (items.isNotEmpty()) {
                mItems = items; mIndex = start; mPos = pos; mRepeat = repeat
                cp.setMediaItems(items, start, pos)
                cp.playWhenReady = wasPlaying
                cp.prepare()
            }
        } catch (e: Exception) {
            toast("No se pudo enviar la lista a la TV.")
            castCtx?.sessionManager?.endCurrentSession(true)
        }
        CastState.device = castCtx?.sessionManager?.currentCastSession?.castDevice?.friendlyName ?: "TV"
        main.removeCallbacks(poll); main.postDelayed(poll, 1000)
    }

    private fun toPhone() {
        if (!onCast) { CastState.device = null; return }
        onCast = false
        main.removeCallbacks(poll)
        CastState.device = null

        var items = mItems
        var idx = mIndex
        val pos = mPos
        backup?.let { b ->
            // Si la cola no cambió durante la transmisión, se recupera completa (no solo la ventana enviada).
            if (items.map { it.mediaId } == b.windowIds) { items = b.full; idx = b.from + mIndex }
        }
        backup = null
        CastServer.stop()

        exo.repeatMode = mRepeat
        if (items.isNotEmpty()) {
            exo.setMediaItems(items, idx.coerceIn(0, items.size - 1), pos)
            exo.shuffleModeEnabled = shuffleWas
            exo.playWhenReady = false          // al volver al teléfono queda en pausa: no suena de golpe
            exo.prepare()
        }
        session.player = phonePlayer
        SleepTimer.player = exo
    }
}
