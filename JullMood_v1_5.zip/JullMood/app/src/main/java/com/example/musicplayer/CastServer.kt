package com.example.musicplayer

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.cast.MediaItemConverter
import androidx.media3.common.MediaItem
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaMetadata as CastMeta
import com.google.android.gms.cast.MediaQueueItem
import com.google.android.gms.common.images.WebImage
import java.io.ByteArrayOutputStream
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import org.json.JSONObject

/** Estado visible para la interfaz (lo actualiza PlaybackService). */
object CastState {
    /** Nombre de la TV conectada, o null si no se está transmitiendo. */
    var device by mutableStateOf<String?>(null)
}

/**
 * v1.5 · Mini servidor HTTP en la red local.
 *
 * La TV no puede leer los content:// del teléfono, así que mientras se transmite el teléfono sirve cada archivo
 * (con soporte de Range para poder saltar dentro de la canción) y su carátula. Las rutas llevan un token aleatorio
 * por ejecución, y el servidor solo está encendido mientras hay una sesión de Cast activa.
 */
object CastServer {
    private const val BUF = 64 * 1024

    private val token = UUID.randomUUID().toString().replace("-", "").take(20)
    private val audio = ConcurrentHashMap<String, Uri>()          // mediaId -> content://
    private val originals = ConcurrentHashMap<String, MediaItem>() // mediaId -> item original (para volver al teléfono)

    @Volatile private var socket: ServerSocket? = null
    @Volatile private var pool: ExecutorService? = null
    @Volatile private var appCtx: Context? = null
    @Volatile private var base: String? = null

    /** Enciende el servidor. Devuelve false si no hay una IP de red local (sin Wi‑Fi) o no se pudo abrir el puerto. */
    @Synchronized
    fun start(ctx: Context): Boolean {
        if (socket != null && base != null) return true
        appCtx = ctx.applicationContext
        val ip = localIp() ?: return false
        return try {
            val ss = ServerSocket(0).apply { reuseAddress = true }
            socket = ss
            pool = Executors.newCachedThreadPool()
            base = "http://$ip:${ss.localPort}"
            Thread({ acceptLoop(ss) }, "jullmood-cast-http").apply { isDaemon = true }.start()
            true
        } catch (_: Exception) { stop(); false }
    }

    @Synchronized
    fun stop() {
        runCatching { socket?.close() }
        socket = null
        pool?.shutdownNow(); pool = null
        base = null
        audio.clear(); originals.clear()
    }

    fun baseUrl(): String? = base

    internal fun register(mediaId: String, uri: Uri, original: MediaItem) {
        audio[mediaId] = uri
        originals[mediaId] = original
    }

    internal fun original(mediaId: String?): MediaItem? = mediaId?.let { originals[it] }

    fun audioUrl(mediaId: String): String? = base?.let { "$it/a/$token/${Uri.encode(mediaId)}" }
    fun artUrl(songId: Long): String? = base?.let { "$it/c/$token/$songId" }

    /** IPv4 privada de la red local (prefiere wlan; sirve también si el teléfono comparte su propia red). */
    private fun localIp(): String? {
        val all = runCatching { NetworkInterface.getNetworkInterfaces()?.toList() }.getOrNull() ?: return null
        val found = ArrayList<Pair<String, String>>()
        for (ni in all) {
            if (!runCatching { ni.isUp && !ni.isLoopback }.getOrDefault(false)) continue
            for (addr: InetAddress in ni.inetAddresses.toList()) {
                if (addr is Inet4Address && !addr.isLoopbackAddress && addr.isSiteLocalAddress) {
                    found += ni.name to (addr.hostAddress ?: continue)
                }
            }
        }
        return (found.firstOrNull { it.first.startsWith("wlan") } ?: found.firstOrNull())?.second
    }

    // ---------- HTTP ----------

    private fun acceptLoop(ss: ServerSocket) {
        while (!ss.isClosed) {
            val c = try { ss.accept() } catch (_: IOException) { break }
            val p = pool ?: break
            try { p.execute { handle(c) } } catch (_: Exception) { runCatching { c.close() } }
        }
    }

    private fun handle(s: Socket) {
        s.use {
            runCatching { it.soTimeout = 30_000 }
            try { serve(it) } catch (_: IOException) { /* la TV cortó la conexión: normal al saltar de canción */ }
            catch (_: Exception) { }
        }
    }

    private fun readLine(ins: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = ins.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) return sb.toString().trimEnd('\r')
            sb.append(b.toChar())
            if (sb.length > 8192) return null
        }
    }

    private fun serve(s: Socket) {
        val ins = s.getInputStream().buffered()
        val out = s.getOutputStream()
        val line = readLine(ins) ?: return
        val parts = line.split(" ")
        if (parts.size < 2) return
        val method = parts[0].uppercase(Locale.ROOT)
        val headers = HashMap<String, String>()
        while (true) {
            val h = readLine(ins) ?: break
            if (h.isEmpty()) break
            val i = h.indexOf(':')
            if (i > 0) headers[h.substring(0, i).trim().lowercase(Locale.ROOT)] = h.substring(i + 1).trim()
        }
        if (method == "OPTIONS") { respond(out, 204, "No Content", null, 0, emptyMap()); return }
        if (method != "GET" && method != "HEAD") { respond(out, 405, "Method Not Allowed", null, 0, emptyMap()); return }

        val path = parts[1].substringBefore('?')
        val seg = path.split('/').filter { it.isNotEmpty() }
        if (seg.size != 3 || seg[1] != token) { respond(out, 404, "Not Found", null, 0, emptyMap()); return }
        val ctx = appCtx ?: return
        val head = method == "HEAD"

        when (seg[0]) {
            "a" -> serveAudio(ctx, out, Uri.decode(seg[2]), headers["range"], head)
            "c" -> serveArt(ctx, out, seg[2].toLongOrNull(), head)
            else -> respond(out, 404, "Not Found", null, 0, emptyMap())
        }
    }

    private fun serveAudio(ctx: Context, out: OutputStream, mediaId: String, range: String?, head: Boolean) {
        val uri = audio[mediaId]
        if (uri == null) { respond(out, 404, "Not Found", null, 0, emptyMap()); return }
        val pfd = try { ctx.contentResolver.openFileDescriptor(uri, "r") } catch (_: Exception) { null }
        if (pfd == null) { respond(out, 404, "Not Found", null, 0, emptyMap()); return }
        pfd.use {
            val total = it.statSize
            val mime = mimeOf(ctx, uri)
            var start = 0L
            var end = total - 1
            var partial = false
            if (range != null && range.startsWith("bytes=") && total > 0) {
                val r = range.removePrefix("bytes=").substringBefore(',').trim()
                val a = r.substringBefore('-').trim()
                val b = r.substringAfter('-', "").trim()
                try {
                    if (a.isEmpty()) {                       // "-N": los últimos N bytes
                        val n = b.toLong(); start = (total - n).coerceAtLeast(0)
                    } else {
                        start = a.toLong()
                        if (b.isNotEmpty()) end = b.toLong().coerceAtMost(total - 1)
                    }
                    partial = true
                } catch (_: NumberFormatException) { start = 0; end = total - 1; partial = false }
                if (start > end || start >= total) {
                    respond(out, 416, "Range Not Satisfiable", mime, 0, mapOf("Content-Range" to "bytes */$total")); return
                }
            }
            val len = if (total > 0) end - start + 1 else 0L
            val h = HashMap<String, String>()
            h["Accept-Ranges"] = "bytes"
            if (partial) h["Content-Range"] = "bytes $start-$end/$total"
            sendHead(out, if (partial) 206 else 200, if (partial) "Partial Content" else "OK", mime, len, h)
            if (head) return
            FileInputStream(it.fileDescriptor).use { fis ->
                fis.channel.position(start)
                val buf = ByteArray(BUF)
                var left = len
                while (left > 0) {
                    val n = fis.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                    if (n < 0) break
                    out.write(buf, 0, n)
                    left -= n
                }
                out.flush()
            }
        }
    }

    private fun serveArt(ctx: Context, out: OutputStream, songId: Long?, head: Boolean) {
        val song = songId?.let { SongArt.songs[it] }
        val bmp: Bitmap? = song?.let { runCatching { ArtCache.load(ctx, it, 512) }.getOrNull() }
        if (bmp == null) { respond(out, 404, "Not Found", null, 0, emptyMap()); return }
        val bos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 88, bos)
        val bytes = bos.toByteArray()
        sendHead(out, 200, "OK", "image/jpeg", bytes.size.toLong(), mapOf("Cache-Control" to "max-age=3600"))
        if (!head) out.write(bytes)
        out.flush()
    }

    private fun respond(out: OutputStream, code: Int, msg: String, mime: String?, len: Long, extra: Map<String, String>) {
        sendHead(out, code, msg, mime, len, extra); out.flush()
    }

    private fun sendHead(out: OutputStream, code: Int, msg: String, mime: String?, len: Long, extra: Map<String, String>) {
        val sb = StringBuilder("HTTP/1.1 $code $msg\r\n")
        if (mime != null) sb.append("Content-Type: $mime\r\n")
        sb.append("Content-Length: $len\r\n")
        sb.append("Access-Control-Allow-Origin: *\r\n")
        sb.append("Access-Control-Allow-Methods: GET, HEAD, OPTIONS\r\n")
        sb.append("Access-Control-Allow-Headers: Range, Content-Type\r\n")
        sb.append("Access-Control-Expose-Headers: Content-Range, Content-Length, Accept-Ranges\r\n")
        sb.append("Connection: close\r\n")
        for ((k, v) in extra) sb.append("$k: $v\r\n")
        sb.append("\r\n")
        out.write(sb.toString().toByteArray(Charsets.ISO_8859_1))
    }

    /** Tipo MIME que entiende el receptor de Cast (MediaStore a veces devuelve variantes "x-"). */
    internal fun mimeOf(ctx: Context, uri: Uri): String {
        val raw = runCatching { ctx.contentResolver.getType(uri) }.getOrNull()?.lowercase(Locale.ROOT).orEmpty()
        return when {
            raw.isEmpty() -> "audio/mpeg"
            raw == "audio/x-m4a" || raw == "audio/m4a" || raw == "audio/mp4a-latm" -> "audio/mp4"
            raw == "audio/x-wav" || raw == "audio/wave" -> "audio/wav"
            raw == "audio/x-flac" -> "audio/flac"
            raw == "application/ogg" -> "audio/ogg"
            raw == "audio/x-mpeg" || raw == "audio/mp3" -> "audio/mpeg"
            else -> raw
        }
    }
}

/**
 * Traduce los MediaItem de la app (content://) a elementos de cola de Cast (http://IP:puerto/…) y viceversa.
 * Al volver al teléfono se recupera el MediaItem original (mismo mediaId y URI local), así la cola no se rompe.
 */
class JullCastConverter(private val ctx: Context) : MediaItemConverter {

    override fun toMediaQueueItem(mediaItem: MediaItem): MediaQueueItem {
        val local = mediaItem.localConfiguration ?: throw IllegalArgumentException("El item no tiene URI")
        val id = mediaItem.mediaId
        CastServer.register(id, local.uri, mediaItem)
        val url = CastServer.audioUrl(id) ?: throw IllegalStateException("Servidor de Cast apagado")

        val md = CastMeta(CastMeta.MEDIA_TYPE_MUSIC_TRACK)
        mediaItem.mediaMetadata.title?.let { md.putString(CastMeta.KEY_TITLE, it.toString()) }
        mediaItem.mediaMetadata.artist?.let { md.putString(CastMeta.KEY_ARTIST, it.toString()) }
        mediaItem.mediaMetadata.albumTitle?.let { md.putString(CastMeta.KEY_ALBUM_TITLE, it.toString()) }
        val songId = id.toLongOrNull()
        val song = songId?.let { SongArt.songs[it] }
        if (songId != null && song != null) CastServer.artUrl(songId)?.let { md.addImage(WebImage(Uri.parse(it))) }

        val info = MediaInfo.Builder(url)
            .setStreamType(MediaInfo.STREAM_TYPE_BUFFERED)
            .setContentType(CastServer.mimeOf(ctx, local.uri))
            .setMetadata(md)
            .setCustomData(JSONObject().put("mediaId", id))
            .apply { if (song != null && song.durationMs > 0) setStreamDuration(song.durationMs) }
            .build()
        return MediaQueueItem.Builder(info).setAutoplay(true).setPreloadTime(15.0).build()
    }

    override fun toMediaItem(item: MediaQueueItem): MediaItem {
        val info = item.media ?: throw IllegalArgumentException("Elemento de cola sin media")
        val id = info.customData?.optString("mediaId")?.takeIf { it.isNotEmpty() }
        CastServer.original(id)?.let { return it }
        return MediaItem.Builder().setMediaId(id ?: info.contentId).setUri(info.contentId).build()
    }
}
