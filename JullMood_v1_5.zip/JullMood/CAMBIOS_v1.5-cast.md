# JullMood v1.5 — Transmitir a TV (Google Cast)

## Qué añade
Un icono de **Transmitir** en la barra superior del reproductor. Al tocarlo busca TVs con Chromecast / Google Cast
(Android TV, Google TV, Chromecast, muchas Smart TV de Sony, Philips, TCL…) en la misma Wi‑Fi. Al elegir una:
- La cola, la canción y la posición pasan a la TV sin cortes; título y portada se ven en pantalla.
- Play/pausa, siguiente/anterior, saltar en la barra, repetir, notificación y pantalla bloqueada siguen funcionando igual.
- **Desconectar** (mismo icono) devuelve la cola al teléfono, en pausa, en la misma canción y posición.

## Cómo funciona
- `CastServer.kt`: mini servidor HTTP en el teléfono (solo encendido mientras se transmite). La TV descarga el audio
  y la portada desde `http://IP-del-teléfono:puerto/...` con soporte de Range. Rutas con token aleatorio.
  `JullCastConverter` traduce cada `MediaItem` (content://) a un elemento de cola de Cast y de vuelta.
- `CastSupport.kt`: `JullCastOptions` (receptor por defecto de Google) y `CastController`, que cambia el reproductor
  de la `MediaSession` entre el `ExoPlayer` y el `CastPlayer`. Guarda una copia de la cola para poder volver.
- `CastUi.kt`: botón + diálogo de dispositivos (selector propio, respeta el tema de la app).
- `PlaybackService.kt`: crea el `CastController`; libera siempre el ExoPlayer.
- `PlayerV11.kt`: una línea en `PlayerTopBar` (`CastButton()`).
- `build.gradle.kts`: v1.5 (versionCode 8), `media3-cast 1.3.1`, `play-services-cast-framework 21.4.0`, `mediarouter 1.6.0`.
- `AndroidManifest.xml`: `OPTIONS_PROVIDER_CLASS_NAME` y permisos de Wi‑Fi.

## Límites (a propósito)
- Teléfono y TV en la misma Wi‑Fi. La TV debe soportar Google Cast (no Samsung/LG sin Cast, ni Apple TV).
- Mientras se transmite no actúan crossfade, fade al pausar, ecualizador ni medidor de LiveJull (son del ExoPlayer del teléfono).
- Cast no baraja: al conectar con aleatorio activado se envía la cola ya en ese orden; el botón de aleatorio no cambia el orden en la TV.
- A la TV se envía una ventana de hasta 300 canciones (10 antes de la actual). Si no tocas la cola, al volver recuperas la completa.
- El teléfono debe seguir encendido y con Wi‑Fi: es quien sirve los archivos.
- Formatos: los que lee la TV (MP3, AAC/M4A, FLAC, WAV, OGG/Opus en la mayoría).

## No probado
Esta versión se escribió sin poder compilar ni probar con una TV real. Compila con el workflow de GitHub y prueba primero
con una canción local. Si algo falla, mándame el error de Gradle o el crash.txt.
