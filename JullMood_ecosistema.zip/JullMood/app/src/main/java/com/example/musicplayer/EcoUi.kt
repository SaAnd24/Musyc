@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.example.musicplayer

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

/** Aviso ligero (álbum completado / logro). Se muestra ~2 s, sin bloquear toques ni el reproductor. */
internal class EcoToast(val id: Long, val emoji: String, val heading: String, val title: String, val sub: String?)

@Composable
internal fun EcoToastView(t: EcoToast, modifier: Modifier, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val reduced = rememberReducedMotion()
    val state = remember(t.id) { MutableTransitionState(reduced).apply { targetState = true } }
    LaunchedEffect(t.id) {
        delay(1_900L)
        state.targetState = false
        delay(if (reduced) 0L else 300L)
        onDismiss()
    }
    AnimatedVisibility(
        state, modifier,
        enter = if (reduced) fadeIn(tween(0)) else fadeIn(tween(250)) + slideInVertically(tween(320)) { -it / 2 } + scaleIn(tween(320), initialScale = 0.8f),
        exit = if (reduced) fadeOut(tween(0)) else fadeOut(tween(250))
    ) {
        val shape = uiShape(22.dp)
        Row(
            Modifier.padding(horizontal = 24.dp, vertical = 8.dp).shadow(6.dp, shape).clip(shape)
                .background(cs.tertiaryContainer).padding(horizontal = 18.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(t.emoji, fontSize = 30.sp)
            Column(Modifier.padding(start = 12.dp)) {
                Text(t.heading, color = cs.onTertiaryContainer, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                Text(t.title, color = cs.onTertiaryContainer, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                t.sub?.let { Text(it, color = cs.onTertiaryContainer.copy(alpha = 0.8f), fontSize = 12.sp, maxLines = 1) }
            }
        }
    }
}

// ---------- Piezas comunes ----------

@Composable
internal fun EcoBar(frac: Float, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Box(modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(cs.surfaceVariant)) {
        Box(Modifier.fillMaxWidth(frac.coerceIn(0f, 1f)).fillMaxHeight().background(cs.primary))
    }
}

@Composable
private fun EcoHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        IconBtn(R.drawable.ic_down, "Volver", rotate = true, onClick = onBack)
        Text(title, fontWeight = FontWeight.Bold, fontSize = 20.sp)
    }
}

@Composable
private fun EcoCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val m = modifier.fillMaxWidth().clip(uiShape(20.dp)).background(MaterialTheme.colorScheme.surface)
    Column((if (onClick != null) m.clickable { onClick() } else m).padding(16.dp), content = content)
}

@Composable
private fun Label(text: String) =
    Text(text, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp, top = 10.dp))

private fun fmtDate(ms: Long): String = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(ms))

@Composable
private fun rememberSnap(vm: PlayerViewModel): EcoSnap? {
    val s by produceState<EcoSnap?>(null, vm.songs, vm.stats, vm.eco.rev) { value = withContext(Dispatchers.Default) { vm.ecoSnapshot() } }
    return s
}

private fun n(c: Int, one: String, many: String) = "$c ${if (c == 1) one else many}"

// ---------- Progreso de álbum / artista (se usa dentro de las pantallas existentes) ----------

@Composable
internal fun AlbumProgressCard(vm: PlayerViewModel, name: String, list: List<Song>, modifier: Modifier = Modifier) {
    val (heard, total) = remember(list, vm.stats) { Eco.progressOf(list.map { StatsCalc.songKey(it) to it.id }, vm.stats) }
    if (total == 0) return
    val g = GroupProg(name, total, heard, emptyList(), 0L)
    val rec = vm.eco.albumInfo(name)
    EcoCard(modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (g.state == AlbumState.DONE && total >= Eco.MIN_ALBUM) "🏆" else "💿", fontSize = 20.sp)
            Text(g.state.label, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 8.dp).weight(1f))
            Text("${g.pct}%", fontWeight = FontWeight.Bold)
        }
        EcoBar(heard / total.toFloat(), Modifier.padding(vertical = 8.dp))
        Text("$heard / $total canciones escuchadas", color = Gray, fontSize = 13.sp)
        if (rec != null && rec[0] > 0L) Text("Primera escucha: ${fmtDate(rec[0])}", color = Gray, fontSize = 12.sp)
        if (rec != null && rec[1] > 0L) Text("Completado: ${fmtDate(rec[1])}", color = Gray, fontSize = 12.sp)
    }
}

@Composable
internal fun ArtistProgressRow(vm: PlayerViewModel, list: List<Song>, modifier: Modifier = Modifier) {
    val (heard, total) = remember(list, vm.stats) { Eco.progressOf(list.map { StatsCalc.songKey(it) to it.id }, vm.stats) }
    if (total == 0) return
    EcoCard(modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row {
            Text("🎤 Exploración del artista", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Text("${heard * 100 / total}%", fontWeight = FontWeight.Bold)
        }
        EcoBar(heard / total.toFloat(), Modifier.padding(vertical = 8.dp))
        Text("$heard conocidas · $total disponibles", color = Gray, fontSize = 13.sp)
    }
}

// ---------- Tu identidad musical ----------

@Composable
internal fun IdentityScreen(vm: PlayerViewModel, onBack: () -> Unit, onOpen: (Detail) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val snap = rememberSnap(vm)
    val stats by produceState<StatsData?>(null, vm.songs, vm.stats, vm.autoMoods, vm.manualMoods) {
        value = withContext(Dispatchers.Default) {
            StatsCalc.compute(vm.songs, vm.stats, { s -> vm.manualMoods[s.id] ?: vm.autoMoods[s.id] ?: emptyList() }, System.currentTimeMillis())
        }
    }
    Column(Modifier.fillMaxSize()) {
        EcoHeader("Tu identidad musical", onBack)
        val s = snap
        if (s == null) { Empty("Calculando…"); return@Column }
        if (s.heard == 0) { Empty("Todavía no hay historia que contar. Escucha música y aquí aparecerá tu identidad."); return@Column }
        val st = vm.eco.streak(System.currentTimeMillis())
        val lvl = s.level; val next = Eco.nextLevel(lvl)
        val ach = vm.eco.unlocked.size
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Column(Modifier.fillMaxWidth().clip(uiShape(24.dp)).background(cs.primaryContainer).padding(20.dp)) {
                    Text("${lvl.emoji} ${lvl.label}", color = cs.onPrimaryContainer, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                    Text("${s.pct.toInt()}% de tu biblioteca explorada", color = cs.onPrimaryContainer, modifier = Modifier.padding(top = 4.dp))
                    EcoBar(((s.pct - lvl.from) / ((next?.from ?: 100) - lvl.from)).toFloat().coerceIn(0f, 1f), Modifier.padding(top = 10.dp))
                    Text(
                        if (next != null) "Hasta ${next.emoji} ${next.label}: ${next.from - s.pct.toInt()} % más" else "Nivel máximo",
                        color = cs.onPrimaryContainer.copy(alpha = 0.8f), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
            item {
                EcoCard(onClick = { onOpen(Detail(9, "")) }) {
                    Text("🗺️ Tu biblioteca", fontWeight = FontWeight.SemiBold)
                    EcoBar(s.heard / s.total.toFloat(), Modifier.padding(vertical = 8.dp))
                    Text("${s.heard} / ${s.total} canciones exploradas", color = Gray, fontSize = 13.sp)
                    val left = s.total - s.heard
                    if (left > 0) Text("$left ${if (left == 1) "canción todavía espera" else "canciones todavía esperan"} su primera reproducción.", color = Gray, fontSize = 13.sp)
                }
            }
            item {
                EcoCard {
                    Text("🎧 ${s.heard} canciones escuchadas", fontWeight = FontWeight.SemiBold)
                    Text("🎤 ${s.artistsHeard} artistas", modifier = Modifier.padding(top = 6.dp))
                    Text("💿 ${s.completedAlbums} álbumes completados", modifier = Modifier.padding(top = 6.dp))
                    Text(
                        if (st.current > 0) "🔥 ${n(st.current, "día", "días")} de racha · mejor: ${st.best}"
                        else if (st.endedLen > 0) "🔥 Racha terminada: ${n(st.endedLen, "día", "días")} · mejor: ${st.best}" else "🔥 Sin racha todavía",
                        modifier = Modifier.padding(top = 6.dp)
                    )
                    if (st.nights >= 2) Text("🌙 ${st.nights} noches seguidas", modifier = Modifier.padding(top = 6.dp))
                }
            }
            item {
                val d = stats
                EcoCard {
                    Text("Mood dominante", color = Gray, fontSize = 12.sp)
                    Text(d?.topMood?.let { "${it.first.emoji} ${it.first.label}" } ?: "—", fontWeight = FontWeight.Bold)
                    Text("Artista más escuchado", color = Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
                    Text(d?.topArtist?.title ?: "—", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("Canción más repetida", color = Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
                    Text(d?.topSong?.let { "${it.title} · ${it.plays}×" } ?: "—", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("Álbum más escuchado", color = Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
                    Text(d?.topAlbum?.title ?: "—", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    EcoCard(Modifier.weight(1f), onClick = { onOpen(Detail(8, "")) }) {
                        Text("🏆 $ach / ${Achievements.all.size}", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        Text("logros", color = Gray, fontSize = 13.sp)
                    }
                    EcoCard(Modifier.weight(1f), onClick = { onOpen(Detail(6, "")) }) {
                        Text("🔒 ${vm.eggs.found.size} / ${vm.eggs.total}", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        Text("secretos de Juli", color = Gray, fontSize = 13.sp)
                    }
                }
            }
            val badges = vm.eco.unlocked.entries.sortedByDescending { it.value }.mapNotNull { e -> Achievements.all.firstOrNull { it.id == e.key } }.take(12)
            if (badges.isNotEmpty()) item {
                EcoCard {
                    Text("Insignias", fontWeight = FontWeight.SemiBold)
                    Text(badges.joinToString("  ") { it.emoji }, fontSize = 24.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }
            val mem = memoryLines(vm, s)
            if (mem.isNotEmpty()) item {
                EcoCard {
                    Text("🧠 Memoria musical", fontWeight = FontWeight.SemiBold)
                    mem.forEach { Text(it, color = Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
                }
            }
            item {
                EcoCard(onClick = { onOpen(Detail(10, "")) }) {
                    Text("📚 Colecciones", fontWeight = FontWeight.SemiBold)
                    Text("Completados, olvidadas, rescatadas y más", color = Gray, fontSize = 13.sp)
                }
            }
        }
    }
}

/** Memoria musical: solo hechos derivados del historial local. */
private fun memoryLines(vm: PlayerViewModel, s: EcoSnap): List<String> {
    val out = ArrayList<String>()
    val now = System.currentTimeMillis()
    val byKey = HashMap<String, Song>()
    for (x in vm.songs) byKey.getOrPut(StatsCalc.songKey(x)) { x }
    vm.eco.firstSongKeys.firstOrNull { byKey[it] != null }?.let { out += "Esta fue una de las primeras canciones que escuchaste: ${byKey.getValue(it).title}." }
    vm.eco.rescuedEntries.firstOrNull { byKey[it.first] != null }?.let { out += "Volviste a escuchar «${byKey.getValue(it.first).title}» después de ${Eco.span(it.third.toLong())}." }
    s.forgottenIds.firstOrNull()?.let { id -> vm.songs.firstOrNull { it.id == id }?.let { x ->
        out += "«${x.title}» lleva ${Eco.span((now - (vm.stats[id]?.last ?: now)) / Eco.DAY)} sin sonar."
    } }
    s.albums.filter { it.heard > 0 && it.last > 0L && now - it.last >= 120 * Eco.DAY }.minByOrNull { it.last }?.let {
        out += "Hace ${Eco.span((now - it.last) / Eco.DAY)} que no escuchabas el álbum «${it.name}»."
    }
    val month = now - 30 * Eco.DAY
    val perArtist = HashMap<String, Int>()
    for (x in vm.songs) { val st = vm.stats[x.id] ?: continue; val c = st.recent.count { it >= month }; if (c > 0 && x.artist != "Artista desconocido") perArtist[x.artist] = (perArtist[x.artist] ?: 0) + c }
    perArtist.maxByOrNull { it.value }?.takeIf { it.value >= 5 }?.let { out += "${it.key} apareció ${it.value} veces este mes." }
    return out.take(4)
}

// ---------- Logros de JullMood ----------

@Composable
internal fun AchievementsScreen(vm: PlayerViewModel, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val snap = rememberSnap(vm)
    Column(Modifier.fillMaxSize()) {
        EcoHeader("Logros de JullMood", onBack)
        val s = snap
        if (s == null) { Empty("Calculando…"); return@Column }
        val m = vm.ecoMetrics(s)
        val got = vm.eco.unlocked
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Column(Modifier.fillMaxWidth().clip(uiShape(24.dp)).background(cs.primaryContainer).padding(20.dp)) {
                    Text("🏆 ${got.size} / ${Achievements.all.size} logros", color = cs.onPrimaryContainer, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    Text("Pequeñas recompensas por escuchar música con normalidad.", color = cs.onPrimaryContainer.copy(alpha = 0.85f), fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
            Achievements.cats.forEach { cat ->
                val defs = Achievements.all.filter { it.cat == cat }
                item(key = "c$cat") { Label(cat) }
                items(defs, key = { it.id }) { d ->
                    val at = got[d.id]
                    val v = d.value(m).coerceAtMost(d.target)
                    EcoCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (at != null) d.emoji else "⚪", fontSize = 24.sp)
                            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                Text(d.name, fontWeight = FontWeight.Bold)
                                Text(d.desc, color = Gray, fontSize = 12.sp)
                            }
                        }
                        if (at != null) Text(
                            if (at > 0L) "✓ Conseguido · ${fmtDate(at)}" else "✓ Conseguido",
                            color = cs.primary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp)
                        ) else {
                            EcoBar(v / d.target.toFloat(), Modifier.padding(top = 10.dp))
                            Text("$v / ${d.target}", color = Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            }
        }
    }
}

// ---------- Descubrir ----------

@Composable
internal fun DiscoverScreen(vm: PlayerViewModel, onBack: () -> Unit, onOpen: (Detail) -> Unit) {
    val snap = rememberSnap(vm)
    Column(Modifier.fillMaxSize()) {
        EcoHeader("Descubrir", onBack)
        val s = snap
        if (s == null) { Empty("Calculando…"); return@Column }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                EcoCard {
                    Text("🧭 Tu biblioteca todavía tiene secretos.", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    Text("${s.pct.toInt()}% explorada · ${s.heard} / ${s.total} canciones", color = Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                    EcoBar(if (s.total == 0) 0f else s.heard / s.total.toFloat(), Modifier.padding(top = 8.dp))
                }
            }
            item {
                EcoCard {
                    Text("🎵 ${n(s.neverIds.size, "canción nunca escuchada", "canciones nunca escuchadas")}")
                    Text("💿 ${n(s.openAlbums.size, "álbum sin completar", "álbumes sin completar")}", modifier = Modifier.padding(top = 8.dp))
                    Text("🎤 ${n(s.lowArtists.size, "artista poco explorado", "artistas poco explorados")}", modifier = Modifier.padding(top = 8.dp))
                    Text("🕰️ ${n(s.staleCount, "canción que no escuchas", "canciones que no escuchas")} desde hace más de 6 meses", modifier = Modifier.padding(top = 8.dp))
                    if (s.oldUnheard > 0) Text("📦 ${n(s.oldUnheard, "canción antigua", "canciones antiguas")} que nunca has reproducido", modifier = Modifier.padding(top = 8.dp))
                    if (s.newUnheard > 0) Text("🆕 ${n(s.newUnheard, "canción reciente", "canciones recientes")} todavía sin escuchar", modifier = Modifier.padding(top = 8.dp))
                }
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton({ onOpen(Detail(12, "never")) }, Modifier.weight(1f), shape = uiShape(16.dp)) { Text("Explorar canciones", maxLines = 1, fontSize = 13.sp) }
                        FilledTonalButton({ onOpen(Detail(13, "open")) }, Modifier.weight(1f), shape = uiShape(16.dp)) { Text("Explorar álbumes", maxLines = 1, fontSize = 13.sp) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton({ onOpen(Detail(14, "low")) }, Modifier.weight(1f), shape = uiShape(16.dp)) { Text("Explorar artistas", maxLines = 1, fontSize = 13.sp) }
                        Button({ vm.surpriseMe() }, Modifier.weight(1f), shape = uiShape(16.dp)) { Text("🎲 Sorpréndeme", maxLines = 1, fontSize = 13.sp) }
                    }
                }
            }
            item { Label("Escuchar ahora") }
            items(EcoPick.values().toList(), key = { it.name }) { p ->
                EcoCard(onClick = { vm.playEco(p) }) {
                    Text("${p.emoji} ${p.label}", fontWeight = FontWeight.SemiBold)
                    Text(p.hint, color = Gray, fontSize = 12.sp)
                }
            }
        }
    }
}

// ---------- Colecciones ----------

@Composable
internal fun CollectionsScreen(vm: PlayerViewModel, onBack: () -> Unit, onOpen: (Detail) -> Unit) {
    val snap = rememberSnap(vm)
    Column(Modifier.fillMaxSize()) {
        EcoHeader("Colecciones", onBack)
        val s = snap
        if (s == null) { Empty("Calculando…"); return@Column }
        val rows = listOf(
            Triple("💿 Álbumes completados", "${s.completedAlbums}", Detail(13, "done")),
            Triple("❤️ Favoritas", "${vm.favorites.size}", Detail(12, "fav")),
            Triple("🔥 Más repetidas", "${vm.ecoList("repeat").size}", Detail(12, "repeat")),
            Triple("🌙 Nocturnas", "${vm.songsFor(Mood.NOCTURNA).size}", Detail(12, "night")),
            Triple("🕰️ Rescatadas del olvido", "${vm.ecoList("rescued").size}", Detail(12, "rescued")),
            Triple("🧭 Descubrimientos", "${s.neverIds.size} sin escuchar", Detail(12, "never")),
            Triple("🕰️ Olvidadas", "${s.forgottenIds.size}", Detail(12, "forgotten")),
            Triple("🏆 Logros", "${vm.eco.unlocked.size} / ${Achievements.all.size}", Detail(8, "")),
            Triple("🔒 Secretos de Juli", "${vm.eggs.found.size} / ${vm.eggs.total}", Detail(6, ""))
        )
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(rows, key = { it.first }) { (t, c, d) ->
                EcoCard(onClick = { onOpen(d) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(t, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text(c, color = Gray, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

/** Lista de canciones de una colección (nunca escuchadas, olvidadas, rescatadas, favoritas, más repetidas, nocturnas). */
@Composable
internal fun EcoListScreen(vm: PlayerViewModel, key: String, onBack: () -> Unit) {
    val items = remember(vm.songs, vm.stats, vm.favorites, vm.eco.rev, key) { vm.ecoList(key) }
    val list = items.map { it.first }
    val title = when (key) {
        "never" -> "🧭 Nunca escuchadas"; "forgotten" -> "🕰️ Olvidadas"; "rescued" -> "🕰️ Rescatadas del olvido"
        "fav" -> "❤️ Favoritas"; "repeat" -> "🔥 Más repetidas"; else -> "🌙 Nocturnas"
    }
    Column(Modifier.fillMaxSize()) {
        EcoHeader(title, onBack)
        if (list.isEmpty()) { Empty(if (key == "rescued") "Aún no has rescatado ninguna canción del olvido." else "Nada por aquí todavía."); return@Column }
        Row(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ vm.playSong(list.first(), list) }, shape = uiShape(16.dp)) { Text("Reproducir", fontSize = 13.sp) }
            if (key == "forgotten" || key == "rescued") FilledTonalButton({ vm.playSimilar(list.first()) }, shape = uiShape(16.dp)) { Text("Similares", fontSize = 13.sp) }
            FilledTonalButton({ vm.surpriseMe() }, shape = uiShape(16.dp)) { Text("🎲", fontSize = 13.sp) }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            items(items.take(300), key = { it.first.id }) { (s, note) ->
                Row(Modifier.fillMaxWidth().clickable { vm.playSong(s, list) }.padding(horizontal = 20.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Cover(s, Modifier.size(48.dp), radius = 8.dp)
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text(s.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(s.artist, color = Gray, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (note != null) Text(note, color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, maxLines = 2)
                    }
                }
            }
        }
    }
}

/** Progreso por álbum (kind 13) o por artista (kind 14). key: all / open / done (álbumes) · all / low (artistas). */
@Composable
internal fun ProgressListScreen(vm: PlayerViewModel, albums: Boolean, key: String, onBack: () -> Unit, onOpen: (Detail) -> Unit) {
    val snap = rememberSnap(vm)
    val byName = remember(vm.songs, albums) { vm.songs.groupBy { if (albums) it.album else it.artist } }
    Column(Modifier.fillMaxSize()) {
        EcoHeader(if (albums) "Progreso de álbumes" else "Exploración de artistas", onBack)
        val s = snap
        if (s == null) { Empty("Calculando…"); return@Column }
        val rows = if (albums) {
            val a = s.albums.filter { it.total >= Eco.MIN_ALBUM }
            when (key) { "done" -> a.filter { it.heard >= it.total }; "open" -> a.filter { it.heard < it.total }; else -> a }
                .sortedWith(compareByDescending<GroupProg> { it.heard in 1 until it.total }.thenByDescending { it.pct }.thenBy { it.name })
        } else {
            val a = s.artists.filter { it.total >= 2 }
            (if (key == "low") s.lowArtists else a).sortedWith(compareBy<GroupProg> { it.pct }.thenByDescending { it.total })
        }
        if (rows.isEmpty()) { Empty(if (key == "done") "Todavía no has completado ningún álbum." else "Nada por explorar aquí."); return@Column }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(rows.take(300), key = { it.name }) { g ->
                EcoCard(onClick = { onOpen(Detail(if (albums) 0 else 1, g.name)) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        GroupCover(byName[g.name].orEmpty().take(4), Modifier.size(48.dp), radius = 10.dp)
                        Column(Modifier.weight(1f).padding(start = 12.dp)) {
                            Text(g.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                if (albums) "${g.heard} / ${g.total} canciones · ${g.state.label}" else "${g.heard} conocidas · ${g.total} disponibles",
                                color = Gray, fontSize = 12.sp
                            )
                        }
                        Text("${g.pct}%", fontWeight = FontWeight.Bold)
                    }
                    EcoBar(g.heard / g.total.toFloat(), Modifier.padding(top = 8.dp))
                }
            }
        }
    }
}

/** Acceso desde el Home: identidad musical y descubrir. */
@Composable
internal fun EcoHomeCard(vm: PlayerViewModel, onOpen: (Detail) -> Unit) {
    val s = rememberSnap(vm)
    Column(Modifier.padding(horizontal = 20.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        EcoCard(onClick = { onOpen(Detail(7, "")) }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(s?.level?.emoji ?: "🪪", fontSize = 22.sp)
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text("Tu identidad musical", fontWeight = FontWeight.SemiBold)
                    Text(
                        if (s != null && s.total > 0) "${s.level.label} · ${s.pct.toInt()}% explorada · 🏆 ${vm.eco.unlocked.size}" else "Tu historia, logros y nivel de exploración",
                        color = Gray, fontSize = 12.sp, maxLines = 1
                    )
                }
            }
        }
        if (s != null && s.neverIds.isNotEmpty()) EcoCard(onClick = { onOpen(Detail(9, "")) }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🧭", fontSize = 22.sp)
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text("Descubrir", fontWeight = FontWeight.SemiBold)
                    Text("${n(s.neverIds.size, "canción espera", "canciones esperan")} su primera reproducción", color = Gray, fontSize = 12.sp, maxLines = 1)
                }
            }
        }
    }
}
