package com.example.musicplayer

/**
 * Datos externos opcionales preparados para futuras funciones (por ejemplo Mood enriquecido).
 * No participa en la reproducción ni en el módulo de letras.
 */
data class SongEnrichment(
    val genre: String? = null,
    val subgenre: String? = null,
    val bpm: Double? = null,
    val energy: Double? = null,
    val features: Map<String, String> = emptyMap()
)
