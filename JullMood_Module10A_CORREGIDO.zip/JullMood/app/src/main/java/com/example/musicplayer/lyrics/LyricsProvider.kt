package com.example.musicplayer.lyrics

import com.example.musicplayer.Song

/** Proveedor intercambiable: la app no conoce detalles HTTP del servicio de letras. */
interface LyricsProvider {
    suspend fun findLyrics(song: Song): LyricsProviderResult
}
