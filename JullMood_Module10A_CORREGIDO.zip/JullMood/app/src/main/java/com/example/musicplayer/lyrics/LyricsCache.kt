package com.example.musicplayer.lyrics

import android.content.Context
import org.json.JSONObject
import java.io.File

/** Caché privada de la app: no usa almacenamiento público ni una BD adicional. */
class LyricsCache(context: Context) {
    private val dir = File(context.filesDir, "lyrics_cache")

    init {
        runCatching { if (!dir.exists()) dir.mkdirs() }
    }

    fun load(songKey: String): LyricsEntry? {
        val file = fileFor(songKey)
        if (!file.isFile) return null
        return runCatching {
            val json = JSONObject(file.readText(Charsets.UTF_8))
            val status = json.optString("status", "").let { runCatching { LyricsStatus.valueOf(it) }.getOrNull() }
                ?: return null
            val type = json.optString("type", "").takeIf { it.isNotBlank() }
                ?.let { runCatching { LyricsType.valueOf(it) }.getOrNull() }
            LyricsEntry(
                songKey = json.optString("songKey", songKey),
                status = status,
                type = type,
                plainLyrics = json.optNullableString("plainLyrics"),
                syncedLyrics = json.optNullableString("syncedLyrics"),
                lines = emptyList(),
                updatedAt = json.optLong("updatedAt", 0L),
                checkedAt = json.optLong("checkedAt", 0L),
                retryAfterAt = json.optLong("retryAfterAt", 0L),
                provider = json.optNullableString("provider"),
                providerId = if (json.has("providerId") && !json.isNull("providerId")) json.optLong("providerId") else null,
                fromCache = true
            )
        }.getOrNull()
    }

    @Synchronized
    fun save(entry: LyricsEntry) {
        runCatching {
            if (!dir.exists()) dir.mkdirs()
            val target = fileFor(entry.songKey)
            val temp = File(dir, target.name + ".tmp")
            val json = JSONObject()
                .put("version", 1)
                .put("songKey", entry.songKey)
                .put("status", entry.status.name)
                .put("type", entry.type?.name)
                .put("plainLyrics", entry.plainLyrics)
                .put("syncedLyrics", entry.syncedLyrics)
                .put("updatedAt", entry.updatedAt)
                .put("checkedAt", entry.checkedAt)
                .put("retryAfterAt", entry.retryAfterAt)
                .put("provider", entry.provider)
                .put("providerId", entry.providerId)
            temp.writeText(json.toString(), Charsets.UTF_8)
            if (!temp.renameTo(target)) {
                target.delete()
                check(temp.renameTo(target)) { "No se pudo guardar la caché de letras" }
            }
        }
    }

    private fun fileFor(songKey: String) = File(dir, "$songKey.json")

    private fun JSONObject.optNullableString(name: String): String? =
        if (has(name) && !isNull(name)) optString(name).takeIf { it.isNotBlank() } else null
}
