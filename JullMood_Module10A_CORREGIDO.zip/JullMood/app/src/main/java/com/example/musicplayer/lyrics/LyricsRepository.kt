package com.example.musicplayer.lyrics

import com.example.musicplayer.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.async
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.text.Normalizer
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Orquesta caché + proveedor. La red nunca es responsabilidad de la UI.
 * Las peticiones de distintas canciones se serializan para respetar el throttling de LRCLIB.
 */
class LyricsRepository(
    context: android.content.Context,
    private val provider: LyricsProvider = LrcLibLyricsProvider()
) {
    companion object {
        private const val PROVIDER_NAME = "LRCLIB"
        private const val ERROR_COOLDOWN_MS = 10 * 60 * 1000L
        private const val NOT_FOUND_COOLDOWN_MS = 7 * 24 * 60 * 60 * 1000L
        private const val MAX_DURATION_DELTA_SEC = 2.5
        private const val MIN_TITLE_SIMILARITY = 0.82
        private const val MIN_ARTIST_SIMILARITY = 0.72
        private const val MIN_ALBUM_SIMILARITY = 0.35
    }

    private val cache = LyricsCache(context.applicationContext)
    private val repositoryScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val inFlightMutex = Mutex()
    private val networkMutex = Mutex()
    private val inFlight = HashMap<String, kotlinx.coroutines.Deferred<LyricsEntry>>()

    suspend fun getLyrics(song: Song, forceRetry: Boolean = false): LyricsEntry {
        val key = SongLyricsKey.from(song)
        val now = System.currentTimeMillis()
        val cached = withContext(Dispatchers.IO) { cache.load(key) }
        if (cached != null) {
            val normalized = normalizeCached(song, cached)
            if (normalized != null) {
                val validContent = cached.status == LyricsStatus.SYNCED || cached.status == LyricsStatus.UNSYNCED
                if (validContent || (!forceRetry && cached.retryAfterAt > now)) {
                    return normalized.copy(fromCache = true)
                }
            }
        }

        val deferred = inFlightMutex.withLock {
            inFlight[key]?.let { return@withLock it }
            repositoryScope.async {
                fetchAndCache(song, key)
            }.also { inFlight[key] = it }
        }

        return try {
            deferred.await()
        } finally {
            inFlightMutex.withLock {
                if (inFlight[key] === deferred) inFlight.remove(key)
            }
        }
    }

    fun cacheKey(song: Song): String = SongLyricsKey.from(song)

    fun close() {
        repositoryScope.cancel()
    }

    private suspend fun fetchAndCache(song: Song, key: String): LyricsEntry {
        val now = System.currentTimeMillis()
        val result = networkMutex.withLock {
            runCatching { provider.findLyrics(song) }
                .getOrElse { e ->
                    if (e is kotlinx.coroutines.CancellationException) throw e
                    LyricsProviderResult.Error(e.message ?: "Error del proveedor")
                }
        }

        val entry = when (result) {
            is LyricsProviderResult.Found -> buildFoundEntry(song, key, result, now)
            LyricsProviderResult.NotFound -> LyricsEntry(
                songKey = key,
                status = LyricsStatus.NOT_FOUND,
                type = null,
                plainLyrics = null,
                syncedLyrics = null,
                lines = emptyList(),
                updatedAt = now,
                checkedAt = now,
                retryAfterAt = now + NOT_FOUND_COOLDOWN_MS,
                provider = PROVIDER_NAME,
                providerId = null,
                fromCache = false
            )
            is LyricsProviderResult.Error -> {
                val cooldown = result.retryAfterMs ?: ERROR_COOLDOWN_MS
                LyricsEntry(
                    songKey = key,
                    status = LyricsStatus.ERROR,
                    type = null,
                    plainLyrics = null,
                    syncedLyrics = null,
                    lines = emptyList(),
                    updatedAt = now,
                    checkedAt = now,
                    retryAfterAt = now + cooldown.coerceIn(30_000L, 24 * 60 * 60 * 1000L),
                    provider = PROVIDER_NAME,
                    providerId = null,
                    fromCache = false
                )
            }
        }

        withContext(Dispatchers.IO) {
            cache.save(entry)
        }
        return entry
    }

    private fun buildFoundEntry(
        song: Song,
        key: String,
        remote: LyricsProviderResult.Found,
        now: Long
    ): LyricsEntry {
        if (!metadataMatches(song, remote)) {
            return LyricsEntry(
                songKey = key,
                status = LyricsStatus.ERROR,
                type = null,
                plainLyrics = null,
                syncedLyrics = null,
                lines = emptyList(),
                updatedAt = now,
                checkedAt = now,
                retryAfterAt = now + ERROR_COOLDOWN_MS,
                provider = PROVIDER_NAME,
                providerId = remote.providerId,
                fromCache = false
            )
        }

        val lrc = remote.syncedLyrics?.trim().takeIf { !it.isNullOrBlank() }
        val plain = remote.plainLyrics?.trim().takeIf { !it.isNullOrBlank() }
        val parsed = LyricsParser.parse(lrc)

        return when {
            lrc != null && parsed.isNotEmpty() -> LyricsEntry(
                songKey = key,
                status = LyricsStatus.SYNCED,
                type = LyricsType.SYNCED,
                plainLyrics = plain,
                syncedLyrics = lrc,
                lines = parsed,
                updatedAt = now,
                checkedAt = now,
                retryAfterAt = 0L,
                provider = PROVIDER_NAME,
                providerId = remote.providerId,
                fromCache = false
            )
            plain != null -> LyricsEntry(
                songKey = key,
                status = LyricsStatus.UNSYNCED,
                type = LyricsType.UNSYNCED,
                plainLyrics = plain,
                syncedLyrics = null,
                lines = emptyList(),
                updatedAt = now,
                checkedAt = now,
                retryAfterAt = 0L,
                provider = PROVIDER_NAME,
                providerId = remote.providerId,
                fromCache = false
            )
            else -> LyricsEntry(
                songKey = key,
                status = LyricsStatus.ERROR,
                type = null,
                plainLyrics = null,
                syncedLyrics = null,
                lines = emptyList(),
                updatedAt = now,
                checkedAt = now,
                retryAfterAt = now + ERROR_COOLDOWN_MS,
                provider = PROVIDER_NAME,
                providerId = remote.providerId,
                fromCache = false
            )
        }
    }

    private fun normalizeCached(@Suppress("UNUSED_PARAMETER") song: Song, cached: LyricsEntry): LyricsEntry? {
        return when (cached.status) {
            LyricsStatus.SYNCED -> {
                val synced = cached.syncedLyrics?.takeIf { LyricsParser.isValid(it) } ?: return null
                cached.copy(type = LyricsType.SYNCED, syncedLyrics = synced, lines = LyricsParser.parse(synced))
            }
            LyricsStatus.UNSYNCED -> {
                val plain = cached.plainLyrics?.takeIf { it.isNotBlank() } ?: return null
                cached.copy(type = LyricsType.UNSYNCED, plainLyrics = plain, lines = emptyList())
            }
            LyricsStatus.NOT_FOUND, LyricsStatus.ERROR -> cached.copy(lines = emptyList())
            LyricsStatus.LOADING, LyricsStatus.NOT_QUERIED -> null
        }
    }

    private fun metadataMatches(song: Song, remote: LyricsProviderResult.Found): Boolean {
        val titleScore = similarity(song.title, remote.title)
        val artistScore = similarity(song.artist, remote.artist)
        if (titleScore < MIN_TITLE_SIMILARITY || artistScore < MIN_ARTIST_SIMILARITY) return false

        val songAlbum = cleanOptionalMetadata(song.album, "Álbum desconocido")
        val remoteAlbum = cleanOptionalMetadata(remote.album, "")
        if (songAlbum != null && remoteAlbum != null && remoteAlbum.isNotBlank()) {
            if (similarity(songAlbum, remoteAlbum) < MIN_ALBUM_SIMILARITY) return false
        }

        val localDuration = song.durationMs / 1000.0
        val remoteDuration = remote.durationSec
        if (localDuration > 0.0 && remoteDuration != null && remoteDuration > 0.0) {
            if (abs(localDuration - remoteDuration) > MAX_DURATION_DELTA_SEC) return false
        }
        return true
    }

    private fun cleanOptionalMetadata(value: String, unknown: String): String? =
        value.trim().takeIf { it.isNotBlank() && !it.equals(unknown, ignoreCase = true) }

    private fun similarity(a: String, b: String): Double {
        val na = normalize(a)
        val nb = normalize(b)
        if (na.isBlank() || nb.isBlank()) return 0.0
        if (na == nb) return 1.0
        if (na.contains(nb) || nb.contains(na)) return min(na.length, nb.length).toDouble() / max(na.length, nb.length).toDouble()
        val sa = na.split(' ').filter { it.isNotBlank() }.toSet()
        val sb = nb.split(' ').filter { it.isNotBlank() }.toSet()
        if (sa.isEmpty() || sb.isEmpty()) return 0.0
        return sa.intersect(sb).size.toDouble() / sa.union(sb).size.toDouble()
    }

    private fun normalize(value: String): String {
        val decomposed = Normalizer.normalize(value.trim().lowercase(Locale.ROOT), Normalizer.Form.NFD)
        return buildString(decomposed.length) {
            var lastSpace = true
            for (ch in decomposed) {
                if (Character.getType(ch) == Character.NON_SPACING_MARK.toInt()) continue
                if (ch.isLetterOrDigit()) {
                    append(ch)
                    lastSpace = false
                } else if (!lastSpace) {
                    append(' ')
                    lastSpace = true
                }
            }
        }.trim()
    }
}
