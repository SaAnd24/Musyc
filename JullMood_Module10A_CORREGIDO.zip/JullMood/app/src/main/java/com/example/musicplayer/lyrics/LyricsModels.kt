package com.example.musicplayer.lyrics

/** Estado de disponibilidad de las letras para una canción. */
enum class LyricsStatus {
    SYNCED,
    UNSYNCED,
    NOT_FOUND,
    LOADING,
    ERROR,
    NOT_QUERIED
}

enum class LyricsType {
    SYNCED,
    UNSYNCED
}

data class LyricLine(
    val timestampMs: Long,
    val text: String
)

/**
 * Registro público que usa la app. La LRC original se conserva en [syncedLyrics].
 * [lines] contiene el resultado procesado únicamente cuando el LRC es válido.
 */
data class LyricsEntry(
    val songKey: String,
    val status: LyricsStatus,
    val type: LyricsType?,
    val plainLyrics: String?,
    val syncedLyrics: String?,
    val lines: List<LyricLine>,
    val updatedAt: Long,
    val checkedAt: Long,
    val retryAfterAt: Long = 0L,
    val provider: String? = null,
    val providerId: Long? = null,
    val fromCache: Boolean = false
)

sealed interface LyricsProviderResult {
    data class Found(
        val title: String,
        val artist: String,
        val album: String,
        val durationSec: Double?,
        val plainLyrics: String?,
        val syncedLyrics: String?,
        val providerId: Long? = null
    ) : LyricsProviderResult

    data object NotFound : LyricsProviderResult

    data class Error(
        val message: String,
        val retryAfterMs: Long? = null
    ) : LyricsProviderResult
}
