package com.example.musicplayer.lyrics

import java.util.regex.Pattern

/** Parser de LRC clásico: mm:ss, mm:ss.d, mm:ss.dd y mm:ss.ddd. */
object LyricsParser {
    private val timestampPattern = Pattern.compile("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?]")

    fun parse(lrc: String?): List<LyricLine> {
        if (lrc.isNullOrBlank()) return emptyList()

        val lines = ArrayList<LyricLine>()
        lrc.lineSequence().forEach { rawLine ->
            val line = rawLine.trimEnd()
            if (line.isBlank()) return@forEach

            val matcher = timestampPattern.matcher(line)
            val matches = ArrayList<Long>()
            while (matcher.find()) {
                val minutes = matcher.group(1)?.toLongOrNull() ?: continue
                val seconds = matcher.group(2)?.toLongOrNull() ?: continue
                if (seconds > 59L) continue
                val fraction = matcher.group(3).orEmpty()
                val millis = when (fraction.length) {
                    0 -> 0L
                    1 -> fraction.toLongOrNull()?.times(100L) ?: 0L
                    2 -> fraction.toLongOrNull()?.times(10L) ?: 0L
                    else -> fraction.take(3).toLongOrNull() ?: 0L
                }
                matches += minutes * 60_000L + seconds * 1_000L + millis
            }
            if (matches.isEmpty()) return@forEach

            // LRC permite varios timestamps para una misma línea: [00:10.00][00:20.00]texto.
            // Todos ellos deben compartir exactamente el mismo texto, sin dejar un timestamp dentro.
            val text = timestampPattern.matcher(line).replaceAll("").trim()
            if (text.isBlank()) return@forEach
            matches.forEach { timestampMs -> lines += LyricLine(timestampMs, text) }
        }

        return lines
            .filter { it.text.isNotBlank() && it.timestampMs >= 0L }
            .sortedWith(compareBy<LyricLine> { it.timestampMs }.thenBy { it.text })
    }

    fun isValid(lrc: String?): Boolean = parse(lrc).isNotEmpty()
}
