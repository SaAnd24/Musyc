package com.example.musicplayer.lyrics

import com.example.musicplayer.Song
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.text.Normalizer
import java.util.Locale

object SongLyricsKey {
    /**
     * Identificador estable de contenido/metadatos. La URI/ruta participa en la clave local,
     * pero jamás se envía al proveedor online.
     */
    fun from(song: Song): String {
        val canonical = buildString {
            append(song.uri.toString().trim())
            append('\u001f')
            append(normalize(song.title))
            append('\u001f')
            append(normalize(song.artist))
            append('\u001f')
            append(normalize(song.album))
            append('\u001f')
            append(song.durationMs)
        }
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(canonical.toByteArray(StandardCharsets.UTF_8))
        return digest.joinToString("") { "%02x".format(Locale.ROOT, it.toInt() and 0xff) }
    }

    private fun normalize(value: String): String {
        if (value.isBlank()) return ""
        val decomposed = Normalizer.normalize(value.trim().lowercase(Locale.ROOT), Normalizer.Form.NFD)
        return buildString(decomposed.length) {
            var lastSpace = true
            for (ch in decomposed) {
                if (Character.getType(ch) == Character.NON_SPACING_MARK.toInt()) continue
                if (ch.isLetterOrDigit()) {
                    append(ch)
                    lastSpace = false
                } else if (!lastSpace) {
                    append(' ')
                    lastSpace = true
                }
            }
        }.trim()
    }
}
