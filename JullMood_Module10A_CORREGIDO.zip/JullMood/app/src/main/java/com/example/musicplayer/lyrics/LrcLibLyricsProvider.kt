package com.example.musicplayer.lyrics

import com.example.musicplayer.BuildConfig
import com.example.musicplayer.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URI
import java.util.Locale

/** Implementación HTTP aislada para LRCLIB. */
class LrcLibLyricsProvider : LyricsProvider {
    companion object {
        private const val BASE_URL = "https://lrclib.net/api/get"
        private const val CONNECT_TIMEOUT_MS = 7_000
        private const val READ_TIMEOUT_MS = 7_000
        private const val CLIENT_DELAY_MS = 350L
        private const val DEFAULT_ERROR_COOLDOWN_MS = 10 * 60 * 1000L
    }

    override suspend fun findLyrics(song: Song): LyricsProviderResult = withContext(Dispatchers.IO) {
        try {
            val params = LinkedHashMap<String, String>()
            params["track_name"] = song.title.trim()
            params["artist_name"] = song.artist.trim().ifBlank { return@withContext LyricsProviderResult.Error("Artista vacío") }
            val album = song.album.trim()
            if (album.isNotBlank() && !album.equals("Álbum desconocido", ignoreCase = true)) {
                params["album_name"] = album
            }
            val durationSec = song.durationMs / 1000.0
            if (durationSec in 1.0..3600.0) {
                params["duration"] = "%.0f".format(Locale.ROOT, durationSec)
            }

            val url = buildUrl(BASE_URL, params)
            val response = requestJson(url)
            when (response.code) {
                HttpURLConnection.HTTP_NOT_FOUND -> LyricsProviderResult.NotFound
                200 -> parseResponse(response.body)
                429 -> LyricsProviderResult.Error(
                    "Límite de solicitudes LRCLIB",
                    response.retryAfterSeconds?.coerceAtLeast(1L)?.times(1000L)
                )
                else -> LyricsProviderResult.Error("HTTP ${response.code}")
            }
        } catch (e: Throwable) {
            when (e) {
                is kotlinx.coroutines.CancellationException -> throw e
                is IOException -> LyricsProviderResult.Error(e.message ?: "Error de red")
                else -> LyricsProviderResult.Error(e.message ?: "Error del proveedor")
            }
        }
    }

    private fun parseResponse(body: String): LyricsProviderResult {
        if (body.isBlank()) return LyricsProviderResult.Error("Respuesta vacía del proveedor")
        val json = try {
            JSONObject(body)
        } catch (_: JSONException) {
            return LyricsProviderResult.Error("JSON inválido del proveedor")
        }

        val title = json.optString("trackName").trim()
        val artist = json.optString("artistName").trim()
        val album = json.optString("albumName").trim()
        val duration = if (json.has("duration") && !json.isNull("duration")) json.optDouble("duration") else null
        val plain = json.optString("plainLyrics").takeIf { it.isNotBlank() }
        val synced = json.optString("syncedLyrics").takeIf { it.isNotBlank() }
        val instrumental = json.optBoolean("instrumental", false)
        val id = if (json.has("id") && !json.isNull("id")) json.optLong("id") else null

        if (instrumental && plain == null && synced == null) return LyricsProviderResult.NotFound
        if (title.isBlank() || artist.isBlank()) return LyricsProviderResult.Error("Metadatos incompletos en respuesta")
        if (plain == null && synced == null) return LyricsProviderResult.Error("Respuesta sin letras")

        return LyricsProviderResult.Found(title, artist, album, duration, plain, synced, id)
    }

    private suspend fun requestJson(url: String): HttpResponse {
        // LRCLIB pide clientes identificables y recomienda espaciar peticiones sucesivas.
        // Aquí el retraso se aplica por petición del proveedor; el repositorio además serializa llamadas.
        delay(CLIENT_DELAY_MS)
        val connection = (URI.create(url).toURL().openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = CONNECT_TIMEOUT_MS
            readTimeout = READ_TIMEOUT_MS
            useCaches = false
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "JullMood/${BuildConfig.VERSION_NAME} (Android; ${BuildConfig.APPLICATION_ID})")
        }
        return try {
            val code = connection.responseCode
            val body = runCatching {
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            }.getOrDefault("")
            val retryAfter = connection.getHeaderField("Retry-After")?.trim()?.toLongOrNull()
            HttpResponse(code, body, retryAfter)
        } finally {
            connection.disconnect()
        }
    }

    private fun buildUrl(base: String, params: Map<String, String>): String =
        buildString {
            append(base)
            if (params.isNotEmpty()) append('?')
            append(params.entries.joinToString("&") {
                URLEncoder.encode(it.key, Charsets.UTF_8.name()) + "=" + URLEncoder.encode(it.value, Charsets.UTF_8.name())
            })
        }

    private data class HttpResponse(val code: Int, val body: String, val retryAfterSeconds: Long?)
}

