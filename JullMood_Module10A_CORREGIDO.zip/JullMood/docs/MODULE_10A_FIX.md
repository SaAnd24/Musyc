# Módulo 10A — corrección de compilación

Se habilitó la generación de `BuildConfig` en `app/build.gradle.kts`.
Esto corrige las referencias usadas por `LrcLibLyricsProvider.kt` sin quitar
información del User-Agent ni alterar la reproducción existente.
