# JullMood – Módulo 10A (Letras)

Este módulo agrega obtención, validación, caché local y parsing de letras sin crear un segundo sistema de canciones ni tocar el motor Media3/ExoPlayer.

## Flujo

`Song` existente → `LyricsRepository` → `LyricsCache` → `LyricsProvider` → `LrcLibLyricsProvider`

La caché se guarda en `filesDir/lyrics_cache/`, un JSON por canción.

La clave es SHA-256 de URI + título + artista + álbum + duración. La URI nunca se envía al proveedor.

## Estados

`NOT_QUERIED`, `LOADING`, `SYNCED`, `UNSYNCED`, `NOT_FOUND`, `ERROR`.

## Proveedor

LRCLIB (`https://lrclib.net/api/get`). Se usa `HttpURLConnection`, timeout de 7 s y solicitudes serializadas con una pausa corta. El resultado se valida contra título, artista, álbum y duración antes de guardarse.

## Parser

`LyricsParser` conserva el LRC original y genera `LyricLine(timestampMs, text)`. Acepta timestamps LRC comunes `mm:ss`, `mm:ss.d`, `mm:ss.dd` y `mm:ss.ddd`, además de múltiples timestamps en una misma línea.

## Prueba manual

1. Compila e instala el APK debug.
2. Con Internet, reproduce una canción con metadatos completos y espera a que termine la consulta.
3. Reproduce de nuevo la misma canción: el registro debe salir de caché.
4. Desactiva Internet y vuelve a reproducirla: las letras sincronizadas deben seguir estando disponibles para el futuro reproductor.
5. Para una canción sin letras, el primer intento guarda `NOT_FOUND`; volver a abrirla durante el cooldown no genera otra petición.

El proyecto incluye el workflow de GitHub Actions existente para `assembleDebug`.
